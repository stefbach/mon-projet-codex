export type Locale = "fr" | "en"

export function changeLocale(locale: Locale): void {
  // This function should ideally trigger a re-render of the app
  // or update some global state that causes the i18n context to update.
  // Since we don't have access to the app's state management system,
  // we can only store the locale in localStorage.
  localStorage.setItem("locale", locale)

  // Reload the page to apply the new locale (not ideal, but necessary without a proper state management system)
  window.location.reload()
}

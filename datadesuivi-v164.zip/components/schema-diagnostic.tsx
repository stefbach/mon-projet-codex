"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Loader2, RefreshCw, CheckCircle, AlertTriangle, Database } from "lucide-react"
import { refreshSchemaCache, verifyPatientUserRelationship } from "@/lib/supabase"
import { ensureUpdatedAtColumn } from "@/lib/supabase-schema-utils"
import { createClient } from "@supabase/supabase-js"

const supabaseUrl = "https://your-supabase-url.supabase.co"
const supabaseKey = "your-supabase-key"
const supabase = createClient(supabaseUrl, supabaseKey)

export function SchemaDiagnostic() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<{
    success: boolean
    message: string
    details?: any
  } | null>(null)

  async function diagnoseSchema() {
    setLoading(true)
    setResult(null)

    try {
      // Step 1: Check patient-user relationship
      const relationshipResult = await verifyPatientUserRelationship()

      if (!relationshipResult.success) {
        setResult({
          success: false,
          message: `Patient-user relationship issue: ${relationshipResult.error}`,
          details: relationshipResult,
        })

        // Try to refresh the schema cache
        await refreshSchemaCache()
        return
      }

      // Step 2: Check if updated_at column exists
      const { exists, error } = await checkUpdatedAtColumn()

      if (error) {
        setResult({
          success: false,
          message: `Error checking updated_at column: ${error}`,
          details: { exists, error },
        })
        return
      }

      if (!exists) {
        setResult({
          success: false,
          message: "The updated_at column is missing from the patients table",
          details: { exists, error },
        })
        return
      }

      // All checks passed
      setResult({
        success: true,
        message: "Schema diagnostic completed successfully. All required columns and relationships are present.",
        details: { relationshipOk: true, updatedAtExists: true },
      })
    } catch (error: any) {
      setResult({
        success: false,
        message: `Error during schema diagnostic: ${error.message}`,
        details: error,
      })
    } finally {
      setLoading(false)
    }
  }

  async function checkUpdatedAtColumn() {
    try {
      const { data, error } = await supabase.rpc("check_column_exists", {
        table_name: "patients",
        column_name: "updated_at",
      })

      return { exists: data, error: error?.message }
    } catch (error: any) {
      return { exists: false, error: error.message }
    }
  }

  async function fixSchema() {
    setLoading(true)
    setResult(null)

    try {
      // Step 1: Ensure updated_at column exists with trigger
      const updatedAtResult = await ensureUpdatedAtColumn("patients")

      if (!updatedAtResult.success) {
        setResult({
          success: false,
          message: `Failed to ensure updated_at column: ${updatedAtResult.error}`,
          details: updatedAtResult,
        })
        return
      }

      // Step 2: Refresh the schema cache
      const refreshResult = await refreshSchemaCache()

      if (!refreshResult.success) {
        setResult({
          success: false,
          message: `Failed to refresh schema cache: ${refreshResult.error}`,
          details: { updatedAtResult, refreshResult },
        })
        return
      }

      // All fixes applied successfully
      setResult({
        success: true,
        message:
          "Schema fixed successfully. The updated_at column is now available and the schema cache has been refreshed.",
        details: { updatedAtResult, refreshResult },
      })
    } catch (error: any) {
      setResult({
        success: false,
        message: `Error fixing schema: ${error.message}`,
        details: error,
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database className="h-5 w-5" />
          Schema Diagnostic
        </CardTitle>
        <CardDescription>Diagnose and fix issues with the database schema</CardDescription>
      </CardHeader>

      <CardContent className="space-y-4">
        {result && (
          <Alert variant={result.success ? "default" : "destructive"}>
            {result.success ? <CheckCircle className="h-4 w-4" /> : <AlertTriangle className="h-4 w-4" />}
            <AlertTitle>{result.success ? "Success" : "Issue Detected"}</AlertTitle>
            <AlertDescription>
              {result.message}
              {result.details && (
                <pre className="mt-2 p-2 bg-gray-100 rounded-md text-xs overflow-auto max-h-40">
                  {JSON.stringify(result.details, null, 2)}
                </pre>
              )}
            </AlertDescription>
          </Alert>
        )}
      </CardContent>

      <CardFooter className="flex justify-between">
        <Button variant="outline" onClick={diagnoseSchema} disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Diagnosing...
            </>
          ) : (
            "Diagnose Schema"
          )}
        </Button>

        <Button variant="default" onClick={fixSchema} disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Fixing...
            </>
          ) : (
            <>
              <RefreshCw className="mr-2 h-4 w-4" />
              Fix Schema Issues
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}

"use client"

import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Search, Save, Trash2 } from "lucide-react"
import { PATIENT_FIELDS } from "@/lib/constants"

interface ColumnMappingProps {
  sourceHeaders: string[]
  mapping: Record<string, string>
  onMappingChange: (sourceField: string, targetField: string) => void
  isProcessing: boolean
}

export function ColumnMapping({ sourceHeaders, mapping, onMappingChange, isProcessing }: ColumnMappingProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [savedMappings, setSavedMappings] = useState<Record<string, Record<string, string>>>({})
  const [mappingName, setMappingName] = useState("")
  const [selectedMapping, setSelectedMapping] = useState<string | null>(null)

  const filteredHeaders = sourceHeaders.filter((header) => header.toLowerCase().includes(searchTerm.toLowerCase()))

  const handleSaveMapping = () => {
    if (!mappingName.trim()) return

    setSavedMappings((prev) => ({
      ...prev,
      [mappingName]: { ...mapping },
    }))

    setMappingName("")
  }

  const handleLoadMapping = (name: string) => {
    const loadedMapping = savedMappings[name]
    if (loadedMapping) {
      // Only apply mappings for headers that exist in the current file
      const newMapping = { ...mapping }

      sourceHeaders.forEach((header) => {
        if (loadedMapping[header]) {
          newMapping[header] = loadedMapping[header]
        }
      })

      // Update all mappings at once
      Object.entries(newMapping).forEach(([source, target]) => {
        onMappingChange(source, target)
      })

      setSelectedMapping(name)
    }
  }

  const handleDeleteMapping = (name: string) => {
    setSavedMappings((prev) => {
      const newMappings = { ...prev }
      delete newMappings[name]
      return newMappings
    })

    if (selectedMapping === name) {
      setSelectedMapping(null)
    }
  }

  const requiredFields = ["full_name", "email"]
  const mappedRequiredFields = Object.values(mapping).filter((field) => requiredFields.includes(field))

  const missingRequiredFields = requiredFields.filter((field) => !Object.values(mapping).includes(field))

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div className="space-y-1">
          <h3 className="text-lg font-medium">Mapping des colonnes</h3>
          <p className="text-sm text-muted-foreground">Associez chaque colonne de votre fichier à un champ patient</p>
        </div>

        <div className="relative w-64">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Rechercher une colonne..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {missingRequiredFields.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 p-3 rounded-md">
          <p className="text-amber-800 text-sm font-medium">
            Champs obligatoires manquants: {missingRequiredFields.join(", ")}
          </p>
        </div>
      )}

      <div className="border rounded-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-1/3">Colonne source</TableHead>
              <TableHead className="w-1/3">Champ destination</TableHead>
              <TableHead>Aperçu</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredHeaders.map((header) => (
              <TableRow key={header}>
                <TableCell>{header}</TableCell>
                <TableCell>
                  <Select
                    value={mapping[header] || "none"}
                    onValueChange={(value) => onMappingChange(header, value)}
                    disabled={isProcessing}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Sélectionner un champ" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">Ne pas importer</SelectItem>
                      {PATIENT_FIELDS.map((field) => (
                        <SelectItem key={field.value} value={field.value}>
                          {field.label}
                          {requiredFields.includes(field.value) && " *"}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </TableCell>
                <TableCell>
                  {requiredFields.includes(mapping[header]) && <Badge variant="default">Obligatoire</Badge>}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <div className="flex items-center gap-4 pt-2 border-t">
        <div className="flex-1">
          <h4 className="text-sm font-medium mb-1">Sauvegarder ce mapping</h4>
          <div className="flex gap-2">
            <Input
              placeholder="Nom du mapping"
              value={mappingName}
              onChange={(e) => setMappingName(e.target.value)}
              disabled={isProcessing}
            />
            <Button variant="outline" onClick={handleSaveMapping} disabled={!mappingName.trim() || isProcessing}>
              <Save className="h-4 w-4 mr-2" />
              Sauvegarder
            </Button>
          </div>
        </div>

        {Object.keys(savedMappings).length > 0 && (
          <div className="flex-1">
            <h4 className="text-sm font-medium mb-1">Charger un mapping</h4>
            <div className="flex gap-2">
              <Select value={selectedMapping || "none"} onValueChange={handleLoadMapping} disabled={isProcessing}>
                <SelectTrigger className="flex-1">
                  <SelectValue placeholder="Sélectionner un mapping" />
                </SelectTrigger>
                <SelectContent>
                  {Object.keys(savedMappings).map((name) => (
                    <SelectItem key={name} value={name}>
                      {name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {selectedMapping && (
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => handleDeleteMapping(selectedMapping)}
                  disabled={isProcessing}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

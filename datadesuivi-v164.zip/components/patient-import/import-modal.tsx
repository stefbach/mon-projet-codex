"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import { Download, Upload, FileSpreadsheet, AlertTriangle, X } from "lucide-react"
import { ColumnMapping } from "./column-mapping"
import { DataPreview } from "./data-preview"
import { ImportSummary } from "./import-summary"
import { parseFile, normalizeData, insertPatients, generateTemplateFile } from "@/lib/import-service"
import { useToast } from "@/hooks/use-toast"

export function PatientImportModal({ open, onOpenChange }) {
  const [step, setStep] = useState<"upload" | "mapping" | "preview" | "import" | "summary">("upload")
  const [file, setFile] = useState<File | null>(null)
  const [fileName, setFileName] = useState<string>("")
  const [rawData, setRawData] = useState<any[]>([])
  const [headers, setHeaders] = useState<string[]>([])
  const [mapping, setMapping] = useState<Record<string, string>>({})
  const [normalizedData, setNormalizedData] = useState<any[]>([])
  const [importProgress, setImportProgress] = useState<number>(0)
  const [importSummary, setImportSummary] = useState<{
    total: number
    success: number
    failed: number
    errors: { row: number; message: string }[]
  }>({ total: 0, success: 0, failed: 0, errors: [] })
  const [isProcessing, setIsProcessing] = useState<boolean>(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  const resetState = () => {
    setStep("upload")
    setFile(null)
    setFileName("")
    setRawData([])
    setHeaders([])
    setMapping({})
    setNormalizedData([])
    setImportProgress(0)
    setImportSummary({ total: 0, success: 0, failed: 0, errors: [] })
    setIsProcessing(false)
  }

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    try {
      setIsProcessing(true)
      const selectedFile = e.target.files?.[0]
      if (!selectedFile) return

      setFile(selectedFile)
      setFileName(selectedFile.name)

      // Parse the file
      const { data, headers } = await parseFile(selectedFile)
      setRawData(data)
      setHeaders(headers)

      // Generate initial mapping suggestion
      const initialMapping: Record<string, string> = {}
      headers.forEach((header) => {
        // Try to match header with patient fields
        const normalizedHeader = header.toLowerCase().trim()

        // Map common field names
        if (normalizedHeader.includes("nom") || normalizedHeader.includes("name")) {
          initialMapping[header] = "full_name"
        } else if (normalizedHeader.includes("email") || normalizedHeader.includes("mail")) {
          initialMapping[header] = "email"
        } else if (normalizedHeader.includes("téléphone") || normalizedHeader.includes("phone")) {
          initialMapping[header] = "phone"
        } else if (normalizedHeader.includes("statut") || normalizedHeader.includes("status")) {
          initialMapping[header] = "status"
        } else if (normalizedHeader.includes("médecin") || normalizedHeader.includes("doctor")) {
          initialMapping[header] = "doctor"
        } else if (normalizedHeader.includes("closer") || normalizedHeader.includes("commercial")) {
          initialMapping[header] = "closer"
        } else if (normalizedHeader.includes("note") || normalizedHeader.includes("commentaire")) {
          initialMapping[header] = "notes"
        } else if (normalizedHeader.includes("rdv") || normalizedHeader.includes("consultation")) {
          initialMapping[header] = "consultation_date"
        } else if (normalizedHeader.includes("opération") || normalizedHeader.includes("operation")) {
          initialMapping[header] = "operation_date"
        } else {
          initialMapping[header] = "" // Empty means not mapped
        }
      })

      setMapping(initialMapping)
      setStep("mapping")
    } catch (error) {
      console.error("Error processing file:", error)
      toast({
        title: "Erreur lors du traitement du fichier",
        description: error.message || "Veuillez vérifier le format du fichier et réessayer.",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  const handleMappingChange = (sourceField: string, targetField: string) => {
    setMapping((prev) => ({
      ...prev,
      [sourceField]: targetField,
    }))
  }

  const handlePreviewData = async () => {
    try {
      setIsProcessing(true)
      // Normalize data based on mapping
      const normalized = await normalizeData(rawData, mapping)
      setNormalizedData(normalized)
      setStep("preview")
    } catch (error) {
      console.error("Error normalizing data:", error)
      toast({
        title: "Erreur lors de la normalisation des données",
        description: error.message || "Une erreur est survenue lors de la préparation des données.",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  const handleImportData = async () => {
    try {
      setIsProcessing(true)
      setStep("import")

      const batchSize = 100
      const totalBatches = Math.ceil(normalizedData.length / batchSize)
      let successCount = 0
      let failedCount = 0
      const errors: { row: number; message: string }[] = []

      for (let i = 0; i < normalizedData.length; i += batchSize) {
        const batch = normalizedData.slice(i, i + batchSize)
        const result = await insertPatients(batch)

        successCount += result.success
        failedCount += result.failed
        errors.push(...result.errors)

        // Update progress
        setImportProgress(Math.round(((i + batch.length) / normalizedData.length) * 100))
      }

      setImportSummary({
        total: normalizedData.length,
        success: successCount,
        failed: failedCount,
        errors,
      })

      setStep("summary")

      if (failedCount === 0) {
        toast({
          title: "Import réussi",
          description: `${successCount} patients ont été importés avec succès.`,
        })
      } else {
        toast({
          title: "Import terminé avec des avertissements",
          description: `${successCount} patients importés, ${failedCount} échecs.`,
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error importing data:", error)
      toast({
        title: "Erreur lors de l'import",
        description: error.message || "Une erreur est survenue lors de l'import des données.",
        variant: "destructive",
      })
      setStep("preview") // Go back to preview
    } finally {
      setIsProcessing(false)
    }
  }

  const handleDownloadTemplate = async () => {
    try {
      const blob = await generateTemplateFile()
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = "template_patients.xlsx"
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    } catch (error) {
      console.error("Error generating template:", error)
      toast({
        title: "Erreur",
        description: "Impossible de générer le template.",
        variant: "destructive",
      })
    }
  }

  const handleDownloadNormalized = () => {
    try {
      // Convert normalized data to CSV
      const headers = Object.keys(normalizedData[0] || {}).join(",")
      const rows = normalizedData.map((row) =>
        Object.values(row)
          .map((value) => (typeof value === "string" ? `"${value.replace(/"/g, '""')}"` : value))
          .join(","),
      )
      const csv = [headers, ...rows].join("\n")

      // Create and download file
      const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" })
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = "donnees_normalisees.csv"
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    } catch (error) {
      console.error("Error downloading normalized data:", error)
      toast({
        title: "Erreur",
        description: "Impossible de télécharger les données normalisées.",
        variant: "destructive",
      })
    }
  }

  const handleClose = () => {
    if (step === "import" && isProcessing) {
      // Prevent closing during import
      toast({
        title: "Import en cours",
        description: "Veuillez attendre la fin de l'import avant de fermer.",
        variant: "destructive",
      })
      return
    }

    resetState()
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Importation de patients</DialogTitle>
          <DialogDescription>Importez vos patients depuis un fichier Excel ou CSV.</DialogDescription>
          <Button variant="ghost" size="icon" className="absolute right-4 top-4" onClick={handleClose}>
            <X className="h-4 w-4" />
          </Button>
        </DialogHeader>

        <Tabs value={step} className="w-full">
          <TabsList className="grid grid-cols-5 w-full">
            <TabsTrigger value="upload" disabled={isProcessing}>
              1. Fichier
            </TabsTrigger>
            <TabsTrigger value="mapping" disabled={!file || isProcessing}>
              2. Mapping
            </TabsTrigger>
            <TabsTrigger value="preview" disabled={!normalizedData.length || isProcessing}>
              3. Aperçu
            </TabsTrigger>
            <TabsTrigger value="import" disabled={!normalizedData.length || isProcessing}>
              4. Import
            </TabsTrigger>
            <TabsTrigger value="summary" disabled={step !== "summary"}>
              5. Résumé
            </TabsTrigger>
          </TabsList>

          <TabsContent value="upload" className="py-4">
            <div className="flex flex-col items-center justify-center p-8 border-2 border-dashed rounded-lg">
              <FileSpreadsheet className="h-16 w-16 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">Sélectionnez un fichier Excel ou CSV</h3>
              <p className="text-sm text-muted-foreground mb-4 text-center">Formats supportés: .xlsx, .xls, .csv</p>

              <div className="flex gap-4">
                <Button onClick={() => fileInputRef.current?.click()} disabled={isProcessing}>
                  <Upload className="h-4 w-4 mr-2" />
                  Parcourir
                </Button>

                <Button variant="outline" onClick={handleDownloadTemplate} disabled={isProcessing}>
                  <Download className="h-4 w-4 mr-2" />
                  Télécharger un template
                </Button>
              </div>

              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept=".xlsx,.xls,.csv"
                className="hidden"
              />

              {fileName && (
                <div className="mt-4 p-2 bg-muted rounded flex items-center gap-2">
                  <FileSpreadsheet className="h-4 w-4" />
                  <span className="text-sm">{fileName}</span>
                </div>
              )}
            </div>

            <Alert className="mt-4">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Important</AlertTitle>
              <AlertDescription>
                Assurez-vous que votre fichier contient au minimum les colonnes nom et email. Les données seront
                automatiquement nettoyées et formatées lors de l'import.
              </AlertDescription>
            </Alert>
          </TabsContent>

          <TabsContent value="mapping" className="py-4">
            <ColumnMapping
              sourceHeaders={headers}
              mapping={mapping}
              onMappingChange={handleMappingChange}
              isProcessing={isProcessing}
            />

            <div className="flex justify-end gap-4 mt-4">
              <Button variant="outline" onClick={() => setStep("upload")} disabled={isProcessing}>
                Retour
              </Button>
              <Button
                onClick={handlePreviewData}
                disabled={isProcessing || Object.values(mapping).filter(Boolean).length === 0}
              >
                {isProcessing ? "Traitement..." : "Aperçu des données"}
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="preview" className="py-4">
            <DataPreview data={normalizedData.slice(0, 10)} />

            <div className="flex justify-between mt-4">
              <Button variant="outline" onClick={handleDownloadNormalized} disabled={isProcessing}>
                <Download className="h-4 w-4 mr-2" />
                Télécharger données normalisées
              </Button>

              <div className="flex gap-4">
                <Button variant="outline" onClick={() => setStep("mapping")} disabled={isProcessing}>
                  Retour
                </Button>
                <Button onClick={handleImportData} disabled={isProcessing || normalizedData.length === 0}>
                  {isProcessing ? "Traitement..." : "Importer les données"}
                </Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="import" className="py-4">
            <div className="flex flex-col items-center justify-center p-8">
              <h3 className="text-lg font-medium mb-4">Import en cours...</h3>
              <Progress value={importProgress} className="w-full mb-4" />
              <p className="text-sm text-muted-foreground">{importProgress}% terminé - Veuillez patienter</p>
            </div>
          </TabsContent>

          <TabsContent value="summary" className="py-4">
            <ImportSummary summary={importSummary} />

            <div className="flex justify-end gap-4 mt-4">
              <Button variant="outline" onClick={resetState}>
                Nouvel import
              </Button>
              <Button onClick={handleClose}>Terminer</Button>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}

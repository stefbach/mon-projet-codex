"use client"

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { getStatusBadgeClass } from "@/lib/constants"

interface DataPreviewProps {
  data: any[]
}

export function DataPreview({ data }: DataPreviewProps) {
  if (!data || data.length === 0) {
    return (
      <div className="text-center p-8 border rounded-md">
        <p className="text-muted-foreground">Aucune donnée à afficher</p>
      </div>
    )
  }

  // Get all unique keys from all objects
  const allKeys = Array.from(new Set(data.flatMap((item) => Object.keys(item))))

  // Format value for display
  const formatValue = (value: any, key: string) => {
    if (value === null || value === undefined) {
      return <span className="text-muted-foreground italic">Non défini</span>
    }

    if (key === "status") {
      return <Badge className={getStatusBadgeClass(value)}>{value}</Badge>
    }

    if (typeof value === "boolean") {
      return value ? "Oui" : "Non"
    }

    if (value instanceof Date) {
      return value.toLocaleDateString()
    }

    return String(value)
  }

  return (
    <div className="space-y-4">
      <div className="space-y-1">
        <h3 className="text-lg font-medium">Aperçu des données normalisées</h3>
        <p className="text-sm text-muted-foreground">Voici les {data.length} premières lignes après normalisation</p>
      </div>

      <div className="border rounded-md overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-12">#</TableHead>
              {allKeys.map((key) => (
                <TableHead key={key}>{key}</TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.map((row, index) => (
              <TableRow key={index}>
                <TableCell className="font-medium">{index + 1}</TableCell>
                {allKeys.map((key) => (
                  <TableCell key={key}>{formatValue(row[key], key)}</TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}

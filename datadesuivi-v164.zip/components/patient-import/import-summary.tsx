"use client"

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { CheckCircle, AlertTriangle, XCircle } from "lucide-react"

interface ImportSummaryProps {
  summary: {
    total: number
    success: number
    failed: number
    errors: { row: number; message: string }[]
  }
}

export function ImportSummary({ summary }: ImportSummaryProps) {
  const { total, success, failed, errors } = summary

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-green-50 border border-green-100 rounded-lg p-4 flex items-center">
          <CheckCircle className="h-8 w-8 text-green-500 mr-3" />
          <div>
            <h4 className="font-medium">Importés avec succès</h4>
            <p className="text-2xl font-bold">{success}</p>
          </div>
        </div>

        <div className="bg-amber-50 border border-amber-100 rounded-lg p-4 flex items-center">
          <AlertTriangle className="h-8 w-8 text-amber-500 mr-3" />
          <div>
            <h4 className="font-medium">Échecs</h4>
            <p className="text-2xl font-bold">{failed}</p>
          </div>
        </div>

        <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 flex items-center">
          <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 font-bold mr-3">
            {total}
          </div>
          <div>
            <h4 className="font-medium">Total traité</h4>
            <p className="text-lg">{Math.round((success / total) * 100)}% de réussite</p>
          </div>
        </div>
      </div>

      {failed > 0 && (
        <Alert variant="destructive">
          <XCircle className="h-4 w-4" />
          <AlertTitle>Erreurs d'importation</AlertTitle>
          <AlertDescription>
            Certaines lignes n'ont pas pu être importées. Consultez les détails ci-dessous.
          </AlertDescription>
        </Alert>
      )}

      {errors.length > 0 && (
        <div className="border rounded-md overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-16">Ligne</TableHead>
                <TableHead>Message d'erreur</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {errors.map((error, index) => (
                <TableRow key={index}>
                  <TableCell>{error.row}</TableCell>
                  <TableCell>{error.message}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      {success > 0 && failed === 0 && (
        <Alert className="bg-green-50 border-green-200 text-green-800">
          <CheckCircle className="h-4 w-4 text-green-500" />
          <AlertTitle>Import réussi</AlertTitle>
          <AlertDescription>Toutes les données ont été importées avec succès.</AlertDescription>
        </Alert>
      )}
    </div>
  )
}

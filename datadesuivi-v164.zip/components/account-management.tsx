"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { toast } from "@/components/ui/use-toast"
import { Loader2, Lock, Check, X } from "lucide-react"
import { useSimpleAuth } from "@/contexts/simple-auth-context"
import { changePassword } from "@/lib/user-service"

export function AccountManagement() {
  const { user } = useSimpleAuth()
  const [currentPassword, setCurrentPassword] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [passwordVisible, setPasswordVisible] = useState(false)

  // Vérification de la force du mot de passe
  const hasMinLength = newPassword.length >= 8
  const hasUpperCase = /[A-Z]/.test(newPassword)
  const hasLowerCase = /[a-z]/.test(newPassword)
  const hasNumber = /\d/.test(newPassword)
  const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(newPassword)

  const passwordStrength = [hasMinLength, hasUpperCase, hasLowerCase, hasNumber, hasSpecialChar].filter(Boolean).length

  const getStrengthLabel = () => {
    if (passwordStrength <= 2) return "Faible"
    if (passwordStrength <= 4) return "Moyen"
    return "Fort"
  }

  const getStrengthColor = () => {
    if (passwordStrength <= 2) return "bg-red-500"
    if (passwordStrength <= 4) return "bg-yellow-500"
    return "bg-green-500"
  }

  const handleChangePassword = async () => {
    // Validation des entrées
    if (!currentPassword) {
      toast({
        variant: "destructive",
        title: "Mot de passe actuel requis",
        description: "Veuillez entrer votre mot de passe actuel.",
      })
      return
    }

    if (newPassword !== confirmPassword) {
      toast({
        variant: "destructive",
        title: "Les mots de passe ne correspondent pas",
        description: "Le nouveau mot de passe et la confirmation doivent être identiques.",
      })
      return
    }

    if (passwordStrength < 3) {
      toast({
        variant: "destructive",
        title: "Mot de passe trop faible",
        description: "Votre mot de passe doit respecter au moins 3 des critères de sécurité.",
      })
      return
    }

    setIsLoading(true)

    try {
      // Appeler l'API pour changer le mot de passe
      const result = await changePassword(user?.id || "", currentPassword, newPassword)

      if (result.success) {
        toast({
          title: "Mot de passe modifié",
          description: "Votre mot de passe a été changé avec succès.",
        })

        // Réinitialiser le formulaire
        setCurrentPassword("")
        setNewPassword("")
        setConfirmPassword("")
      } else {
        toast({
          variant: "destructive",
          title: "Échec de la modification",
          description: result.message || "Une erreur s'est produite. Vérifiez votre mot de passe actuel.",
        })
      }
    } catch (error) {
      console.error("Erreur lors du changement de mot de passe:", error)
      toast({
        variant: "destructive",
        title: "Erreur",
        description: "Une erreur s'est produite. Veuillez réessayer.",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Gestion de compte</CardTitle>
        <CardDescription>Mettez à jour vos informations et votre mot de passe</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Informations de compte */}
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="account-name">Nom</Label>
              <Input id="account-name" value={user?.name || ""} disabled />
            </div>
            <div>
              <Label htmlFor="account-email">Email</Label>
              <Input id="account-email" value={user?.email || ""} disabled />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="account-role">Rôle</Label>
              <Input id="account-role" value={user?.role === "admin" ? "Administrateur" : "Conseiller"} disabled />
            </div>
            <div>
              <Label htmlFor="account-last-login">Dernière connexion</Label>
              <Input
                id="account-last-login"
                value={user?.last_login ? new Date(user.last_login).toLocaleString() : "N/A"}
                disabled
              />
            </div>
          </div>
        </div>

        {/* Changement de mot de passe */}
        <div className="pt-4 border-t">
          <h3 className="text-lg font-medium mb-4">Changer votre mot de passe</h3>

          <div className="space-y-4">
            <div>
              <Label htmlFor="current-password">Mot de passe actuel</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="current-password"
                  type={passwordVisible ? "text" : "password"}
                  placeholder="Entrez votre mot de passe actuel"
                  className="pl-10"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="new-password">Nouveau mot de passe</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="new-password"
                  type={passwordVisible ? "text" : "password"}
                  placeholder="Entrez votre nouveau mot de passe"
                  className="pl-10"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                />
              </div>

              {/* Indicateur de force de mot de passe */}
              {newPassword && (
                <div className="mt-2">
                  <div className="flex justify-between text-xs mb-1">
                    <span>Force: {getStrengthLabel()}</span>
                    <button
                      type="button"
                      className="text-gray-500 hover:text-gray-700"
                      onClick={() => setPasswordVisible(!passwordVisible)}
                    >
                      {passwordVisible ? "Masquer" : "Afficher"}
                    </button>
                  </div>
                  <div className="h-1.5 w-full bg-gray-200 rounded-full overflow-hidden">
                    <div
                      className={`h-full ${getStrengthColor()}`}
                      style={{ width: `${(passwordStrength / 5) * 100}%` }}
                    ></div>
                  </div>

                  {/* Critères de mot de passe */}
                  <div className="grid grid-cols-2 gap-1 mt-2 text-xs">
                    <div className="flex items-center">
                      {hasMinLength ? (
                        <Check className="h-3 w-3 text-green-500 mr-1" />
                      ) : (
                        <X className="h-3 w-3 text-red-500 mr-1" />
                      )}
                      <span>8 caractères minimum</span>
                    </div>
                    <div className="flex items-center">
                      {hasUpperCase ? (
                        <Check className="h-3 w-3 text-green-500 mr-1" />
                      ) : (
                        <X className="h-3 w-3 text-red-500 mr-1" />
                      )}
                      <span>Une majuscule</span>
                    </div>
                    <div className="flex items-center">
                      {hasLowerCase ? (
                        <Check className="h-3 w-3 text-green-500 mr-1" />
                      ) : (
                        <X className="h-3 w-3 text-red-500 mr-1" />
                      )}
                      <span>Une minuscule</span>
                    </div>
                    <div className="flex items-center">
                      {hasNumber ? (
                        <Check className="h-3 w-3 text-green-500 mr-1" />
                      ) : (
                        <X className="h-3 w-3 text-red-500 mr-1" />
                      )}
                      <span>Un chiffre</span>
                    </div>
                    <div className="flex items-center">
                      {hasSpecialChar ? (
                        <Check className="h-3 w-3 text-green-500 mr-1" />
                      ) : (
                        <X className="h-3 w-3 text-red-500 mr-1" />
                      )}
                      <span>Un caractère spécial</span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div>
              <Label htmlFor="confirm-password">Confirmer le mot de passe</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="confirm-password"
                  type={passwordVisible ? "text" : "password"}
                  placeholder="Confirmez votre nouveau mot de passe"
                  className="pl-10"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                />
              </div>
              {newPassword && confirmPassword && newPassword !== confirmPassword && (
                <p className="text-xs text-red-500 mt-1">Les mots de passe ne correspondent pas</p>
              )}
            </div>

            <Button
              onClick={handleChangePassword}
              disabled={
                isLoading || !currentPassword || !newPassword || !confirmPassword || newPassword !== confirmPassword
              }
              className="w-full"
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Changement en cours...
                </>
              ) : (
                "Changer le mot de passe"
              )}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useToast } from "@/components/ui/use-toast"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Loader2, Copy, Save, ArrowLeft, AlertCircle } from "lucide-react"
import { useAuth } from "@/contexts/auth-context"
import { getClosers, type Patient } from "@/lib/patient-service"
import { PATIENT_STATUSES } from "@/lib/constants"
import { useMobile } from "@/hooks/use-mobile"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

// Options pour les menus déroulants
const SUITE_GROUPE_OPTIONS = ["NHS", "CASH", "non_specifie"]
const QUALIFICATION_OPTIONS = ["chaud", "tiede", "froid", "D/DEAD"]
const RDV_OBTENU_PAR_OPTIONS = ["rain", "subham", "mariam", "mika", "summer", "dilan"]
const CHIRURGIE_OPTIONS = ["sg", "bariclip", "bypass", "esg", "sassi"]

// Ajoutez ce code à votre composant de formulaire existant

import { cleanPatientDataForSupabase } from "@/lib/validations/patient-schema"
import { updatePatientFixed, createPatientFixed } from "@/lib/patient-service-fix"

interface EnhancedPatientFormProps {
  patient?: Patient
  isEditMode?: boolean
}

export function EnhancedPatientForm({ patient, isEditMode = false }: EnhancedPatientFormProps) {
  const { toast } = useToast()
  const router = useRouter()
  const { user } = useAuth()
  const [loading, setLoading] = useState(false)
  const [closers, setClosers] = useState<{ id: string; name: string; email: string }[]>([])
  const [loadingClosers, setLoadingClosers] = useState(true)
  const isMobile = useMobile()
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({})
  const [showUnsavedChangesAlert, setShowUnsavedChangesAlert] = useState(false)
  const [hasChanges, setHasChanges] = useState(false)
  const [initialFormData, setInitialFormData] = useState<any>({})

  // Définir la date d'enregistrement comme la date actuelle pour les nouveaux patients
  const currentDate = new Date().toISOString().split("T")[0]

  const [formData, setFormData] = useState<Partial<Patient>>({
    name: "",
    email: "",
    phone: "",
    doctor: "",
    consultationDate: "",
    registrationDate: currentDate,
    income: "",
    expenses: "",
    creditScore: "",
    creditPlatform: "non_specifie",
    loanAmount: "",
    simulationValidated: "Non",
    platform: "non_specifie",
    status: "a_rappeler", // Valeur par défaut
    loanRequested: "Non",
    nextFollowUp: "",
    comments: "",
    notes: "",
    closer: "non_assigne", // Valeur par défaut
    validated: false,
    // Nouveaux champs avec valeurs par défaut
    suiteGroupe: "non_specifie",
    poids: "",
    taille: "",
    bmi: "",
    chirurgie: "non_specifie",
    qualification: QUALIFICATION_OPTIONS[0],
    rdvObtenuPar: RDV_OBTENU_PAR_OPTIONS[0],
    premierEmail: "",
    premierWhatsapp: "",
    secondEmail: "",
    secondWhatsapp: "",
    factureEnvoye: false,
    medicalAgrement: false,
    consentForm: false,
    autorisationPatientS2: false,
    compteRenduHospitalisation: false,
    compteRenduConsultation: false,
    emailPatientGp: false,
    patientS2Form: false,
    lettreGp: false,
    s2SaintJames: false,
    nhsTier4PremierEmail: "",
    nhsTier4SecondEmail: "",
  })

  // Charger les données du patient en mode édition
  useEffect(() => {
    if (isEditMode && patient) {
      // Convertir les valeurs booléennes "Oui"/"Non" en booléens
      const processedData = {
        ...patient,
        simulationValidated:
          patient.simulationValidated === true || patient.simulationValidated === "Oui" ? "Oui" : "Non",
        loanRequested: patient.loanRequested === true || patient.loanRequested === "Oui" ? "Oui" : "Non",
        factureEnvoye: patient.factureEnvoye === true || patient.factureEnvoye === "Oui",
        medicalAgrement: patient.medicalAgrement === true || patient.medicalAgrement === "Oui",
        consentForm: patient.consentForm === true || patient.consentForm === "Oui",
        autorisationPatientS2: patient.autorisationPatientS2 === true || patient.autorisationPatientS2 === "Oui",
        compteRenduHospitalisation:
          patient.compteRenduHospitalisation === true || patient.compteRenduHospitalisation === "Oui",
        compteRenduConsultation: patient.compteRenduConsultation === true || patient.compteRenduConsultation === "Oui",
        emailPatientGp: patient.emailPatientGp === true || patient.emailPatientGp === "Oui",
        patientS2Form: patient.patientS2Form === true || patient.patientS2Form === "Oui",
        lettreGp: patient.lettreGp === true || patient.lettreGp === "Oui",
        s2SaintJames: patient.s2SaintJames === true || patient.s2SaintJames === "Oui",
      }

      // Add debugging logs for critical fields
      console.log("Loading patient data with fields:", {
        doctor: patient.doctor,
        rdvObtenuPar: patient.rdvObtenuPar,
        qualification: patient.qualification,
        suiteGroupe: patient.suiteGroupe,
      })

      setFormData(processedData)
      setInitialFormData(processedData)
    }
  }, [isEditMode, patient])

  // Détecter les changements dans le formulaire
  useEffect(() => {
    if (isEditMode && Object.keys(initialFormData).length > 0) {
      // Comparer les données actuelles avec les données initiales
      const hasFormChanged = JSON.stringify(formData) !== JSON.stringify(initialFormData)
      setHasChanges(hasFormChanged)
    }
  }, [formData, initialFormData, isEditMode])

  // Charger la liste des closers au chargement du composant
  useEffect(() => {
    async function loadClosers() {
      try {
        const closersList = await getClosers()

        // Filtrer les closers qui pourraient avoir des noms vides ou null
        const validClosers = closersList.filter((closer) => closer && closer.name && closer.name.trim() !== "")

        setClosers(validClosers)

        // Si des closers valides sont disponibles et qu'on n'est pas en mode édition, sélectionner le premier par défaut
        if (Array.isArray(validClosers) && validClosers.length > 0 && !isEditMode) {
          const firstCloserName = validClosers[0].name?.trim() || `closer-${validClosers[0].id}`
          setFormData((prev) => ({
            ...prev,
            closer: firstCloserName,
          }))
        }

        setLoadingClosers(false)
      } catch (error) {
        console.error("Erreur lors du chargement des closers:", error)
        setLoadingClosers(false)
        // En cas d'erreur, définir une liste vide mais valide
        setClosers([])
      }
    }

    loadClosers()
  }, [isEditMode])

  const copyPhoneToClipboard = () => {
    if (formData.phone) {
      navigator.clipboard
        .writeText(formData.phone.toString())
        .then(() => {
          toast({
            title: "Numéro copié",
            description: "Le numéro de téléphone a été copié dans le presse-papiers",
            duration: 2000,
          })
        })
        .catch((err) => {
          console.error("Erreur lors de la copie:", err)
          toast({
            variant: "destructive",
            title: "Erreur",
            description: "Impossible de copier le numéro",
            duration: 2000,
          })
        })
    }
  }

  const validatePhoneNumber = (phone: string): boolean => {
    if (!phone) return true // Le téléphone n'est pas obligatoire
    const phoneRegex = /^\+?[1-9][0-9]{7,14}$/
    return phoneRegex.test(phone)
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))

    // Effacer l'erreur de validation si elle existe
    if (validationErrors[name]) {
      setValidationErrors((prev) => {
        const newErrors = { ...prev }
        delete newErrors[name]
        return newErrors
      })
    }

    // Validation du numéro de téléphone
    if (name === "phone" && value) {
      if (!validatePhoneNumber(value)) {
        setValidationErrors((prev) => ({
          ...prev,
          phone: "Format invalide. Exemple: +33612345678",
        }))
      }
    }
  }

  const handleSelectChange = (name: string, value: string) => {
    console.log(`Dropdown changed: ${name} = "${value}"`)

    // S'assurer que la valeur n'est jamais vide
    const safeValue =
      value && value.trim() !== ""
        ? value
        : name === "closer"
          ? "non_assigne"
          : name === "doctor"
            ? "non_specifie"
            : name === "chirurgie"
              ? "non_specifie"
              : name === "qualification"
                ? QUALIFICATION_OPTIONS[0]
                : name === "rdvObtenuPar"
                  ? RDV_OBTENU_PAR_OPTIONS[0]
                  : name === "suiteGroupe"
                    ? "non_specifie"
                    : "non_specifie"

    setFormData((prev) => {
      const newData = { ...prev, [name]: safeValue }
      console.log(`Updated form data for ${name}:`, newData[name])
      return newData
    })

    // Effacer l'erreur de validation si elle existe
    if (validationErrors[name]) {
      setValidationErrors((prev) => {
        const newErrors = { ...prev }
        delete newErrors[name]
        return newErrors
      })
    }
  }

  const handleRadioChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))

    // Effacer l'erreur de validation si elle existe
    if (validationErrors[name]) {
      setValidationErrors((prev) => {
        const newErrors = { ...prev }
        delete newErrors[name]
        return newErrors
      })
    }
  }

  const handleSwitchChange = (name: string, checked: boolean) => {
    setFormData((prev) => ({ ...prev, [name]: checked }))

    // Effacer l'erreur de validation si elle existe
    if (validationErrors[name]) {
      setValidationErrors((prev) => {
        const newErrors = { ...prev }
        delete newErrors[name]
        return newErrors
      })
    }
  }

  // Calculate BMI when weight or height changes
  useEffect(() => {
    if (formData.poids && formData.taille) {
      const weight = typeof formData.poids === "string" ? Number.parseFloat(formData.poids) : formData.poids
      const height = typeof formData.taille === "string" ? Number.parseFloat(formData.taille) : formData.taille
      if (!isNaN(weight) && !isNaN(height) && height > 0) {
        const bmi = (weight / ((height / 100) * (height / 100))).toFixed(1)
        setFormData((prev) => ({ ...prev, bmi: Number.parseFloat(bmi) }))
      }
    }
  }, [formData.poids, formData.taille])

  // Fonction pour formater la date et l'heure avec le fuseau horaire
  const formatDateTimeWithTimezone = (dateTimeString: string | undefined): string => {
    if (!dateTimeString) return ""

    try {
      const date = new Date(dateTimeString)
      // Format ISO avec timezone
      return date.toISOString()
    } catch (error) {
      console.error("Erreur de formatage de date:", error)
      return dateTimeString
    }
  }

  // Replace the validateForm function with this updated version
  const validateForm = (): boolean => {
    // Validation minimale - uniquement les champs vraiment obligatoires
    if (!formData.name || formData.name.trim() === "") {
      setValidationErrors({ name: "Le nom est obligatoire" })
      return false
    }

    if (!formData.email || !/\S+@\S+\.\S+/.test(formData.email)) {
      setValidationErrors({ email: "Un email valide est obligatoire" })
      return false
    }

    return true
  }

  const handleCancel = () => {
    if (hasChanges) {
      setShowUnsavedChangesAlert(true)
    } else {
      navigateBack()
    }
  }

  const navigateBack = () => {
    if (isEditMode && patient?.id) {
      router.push(`/patients/${patient.id}`)
    } else {
      router.push("/patients")
    }
  }

  const handleSubmitFixed = async (e: React.FormEvent, shouldValidate = false) => {
    e.preventDefault()
    setLoading(true)

    try {
      // Vérification explicite des champs critiques
      console.log("SOUMISSION DU FORMULAIRE - Champs critiques:")
      console.log("Doctor:", formData.doctor)
      console.log("Suite/Groupe:", formData.suiteGroupe)
      console.log("Qualification:", formData.qualification)
      console.log("RDV Obtenu Par:", formData.rdvObtenuPar)

      // Assurez-vous que ces champs ne sont jamais undefined
      const dataToSubmit = {
        ...formData,
        doctor: formData.doctor || "",
        suiteGroupe: formData.suiteGroupe || "",
        qualification: formData.qualification || "",
        rdvObtenuPar: formData.rdvObtenuPar || "",
        // S'assurer que les champs de date vides sont explicitement null
        consultationDate: formData.consultationDate === "" ? null : formData.consultationDate,
        registrationDate: formData.registrationDate === "" ? null : formData.registrationDate,
        nextFollowUp: formData.nextFollowUp === "" ? null : formData.nextFollowUp,
        premierEmail: formData.premierEmail === "" ? null : formData.premierEmail,
        premierWhatsapp: formData.premierWhatsapp === "" ? null : formData.premierWhatsapp,
        secondEmail: formData.secondEmail === "" ? null : formData.secondEmail,
        secondWhatsapp: formData.secondWhatsapp === "" ? null : formData.secondWhatsapp,
        nhsTier4PremierEmail: formData.nhsTier4PremierEmail === "" ? null : formData.nhsTier4PremierEmail,
        nhsTier4SecondEmail: formData.nhsTier4SecondEmail === "" ? null : formData.nhsTier4SecondEmail,
      }

      // Nettoyer les données avant de les envoyer à Supabase
      const cleanedData = cleanPatientDataForSupabase(dataToSubmit)

      // Log after cleaning data
      console.log("After cleaning data - critical fields:", {
        doctor: cleanedData.doctor,
        rdvObtenuPar: cleanedData.rdvObtenuPar,
        qualification: cleanedData.qualification,
        suiteGroupe: cleanedData.suiteGroupe,
      })

      let result

      if (isEditMode && patient?.id && user) {
        // Mode édition : Mettre à jour le patient
        result = await updatePatientFixed(patient.id, cleanedData, user)
      } else {
        // Mode création : Créer un nouveau patient
        result = await createPatientFixed(cleanedData, shouldValidate, user)
      }

      if (result?.success) {
        toast({
          title: isEditMode ? "Patient mis à jour" : "Patient ajouté",
          description:
            result.message ||
            (isEditMode ? "Le patient a été mis à jour avec succès" : "Le patient a été ajouté avec succès"),
        })

        if (isEditMode && patient?.id) {
          router.push(`/patients/${patient.id}`)
        } else {
          router.push("/patients")
        }
      } else {
        toast({
          variant: "destructive",
          title: "Erreur",
          description:
            result?.message ||
            `Une erreur s'est produite lors de ${isEditMode ? "la mise à jour" : "l'ajout"} du patient`,
        })
      }
    } catch (error) {
      console.error(`Erreur lors de ${isEditMode ? "la mise à jour" : "la soumission"} :`, error)
      toast({
        variant: "destructive",
        title: "Erreur",
        description: `Une erreur s'est produite lors de ${isEditMode ? "la mise à jour" : "l'ajout"} du patient`,
      })
    } finally {
      setLoading(false)
    }
  }

  // Vérifier si l'utilisateur est un admin
  const isAdmin = user?.role === "admin"
  const isCloser = user?.role === "closer"

  // Rendu pour mobile avec accordions
  if (isMobile) {
    return (
      <div className="space-y-4 w-full overflow-y-auto pb-20">
        <div className="flex items-center justify-between">
          <Button variant="outline" onClick={handleCancel}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Retour
          </Button>
          <h1 className="text-xl font-bold">{isEditMode ? "Modifier le patient" : "Nouveau patient"}</h1>
        </div>

        <form onSubmit={(e) => handleSubmitFixed(e, false)} className="space-y-4">
          <div className="overflow-y-auto max-h-[calc(100vh-180px)]">
            <Accordion type="multiple" defaultValue={["informations"]} className="w-full">
              <AccordionItem value="informations">
                <AccordionTrigger className="text-lg font-semibold">
                  Informations personnelles
                  {validationErrors.name ||
                  validationErrors.email ||
                  validationErrors.phone ||
                  validationErrors.registrationDate ||
                  validationErrors.doctor ? (
                    <AlertCircle className="h-4 w-4 text-red-500 ml-2" />
                  ) : null}
                </AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-3">
                    <div>
                      <Label htmlFor="name" className={validationErrors.name ? "text-red-500" : ""}>
                        Nom complet *
                      </Label>
                      <Input
                        id="name"
                        name="name"
                        value={formData.name || ""}
                        onChange={handleChange}
                        required
                        className={validationErrors.name ? "border-red-500" : ""}
                      />
                      {validationErrors.name && <p className="text-sm text-red-500 mt-1">{validationErrors.name}</p>}
                    </div>

                    <div>
                      <Label htmlFor="email" className={validationErrors.email ? "text-red-500" : ""}>
                        Email *
                      </Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email || ""}
                        onChange={handleChange}
                        required
                        className={validationErrors.email ? "border-red-500" : ""}
                      />
                      {validationErrors.email && <p className="text-sm text-red-500 mt-1">{validationErrors.email}</p>}
                    </div>

                    <div>
                      <Label htmlFor="phone" className={validationErrors.phone ? "text-red-500" : ""}>
                        Téléphone
                      </Label>
                      <div className="flex items-center space-x-2">
                        <div className="relative flex-1">
                          <Input
                            id="phone"
                            name="phone"
                            type="tel"
                            value={formData.phone || ""}
                            onChange={handleChange}
                            className={validationErrors.phone ? "border-red-500 pr-10" : "pr-10"}
                            placeholder="+33612345678"
                          />
                        </div>
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                type="button"
                                variant="outline"
                                size="icon"
                                onClick={copyPhoneToClipboard}
                                disabled={!formData.phone}
                                className="flex-shrink-0"
                              >
                                <Copy className="h-4 w-4" />
                                <span className="sr-only">Copier le numéro</span>
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Copier le numéro</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </div>
                      {validationErrors.phone && <p className="text-sm text-red-500 mt-1">{validationErrors.phone}</p>}
                    </div>

                    <div>
                      <Label htmlFor="doctor" className={validationErrors.doctor ? "text-red-500" : ""}>
                        Médecin *
                      </Label>
                      <Select
                        value={formData.doctor || "non_specifie"}
                        onValueChange={(value) => handleSelectChange("doctor", value)}
                      >
                        <SelectTrigger className={validationErrors.doctor ? "border-red-500" : "bg-white"}>
                          <SelectValue placeholder="Sélectionner un médecin" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Noel">Noel</SelectItem>
                          <SelectItem value="Nedelcu">Nedelcu</SelectItem>
                          <SelectItem value="Coste">Coste</SelectItem>
                          <SelectItem value="Manos">Manos</SelectItem>
                        </SelectContent>
                      </Select>
                      {validationErrors.doctor && (
                        <p className="text-sm text-red-500 mt-1">{validationErrors.doctor}</p>
                      )}
                    </div>

                    <div>
                      <Label
                        htmlFor="registrationDate"
                        className={validationErrors.registrationDate ? "text-red-500" : ""}
                      >
                        Date d'enregistrement *
                      </Label>
                      <Input
                        id="registrationDate"
                        name="registrationDate"
                        type="date"
                        value={formData.registrationDate || ""}
                        onChange={handleChange}
                        required
                        className={validationErrors.registrationDate ? "border-red-500" : ""}
                      />
                      {validationErrors.registrationDate && (
                        <p className="text-sm text-red-500 mt-1">{validationErrors.registrationDate}</p>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="consultationDate">Date de consultation</Label>
                      <Input
                        id="consultationDate"
                        name="consultationDate"
                        type="date"
                        value={formData.consultationDate || ""}
                        onChange={handleChange}
                      />
                    </div>

                    <div>
                      <Label htmlFor="suiteGroupe">Suite/Groupe</Label>
                      <Select
                        value={formData.suiteGroupe || "non_specifie"}
                        onValueChange={(value) => handleSelectChange("suiteGroupe", value)}
                      >
                        <SelectTrigger className="bg-white">
                          <SelectValue placeholder="Sélectionner une option" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="non_specifie">Non spécifié</SelectItem>
                          <SelectItem value="NHS">NHS</SelectItem>
                          <SelectItem value="CASH">CASH</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="qualification">Qualification</Label>
                      <Select
                        value={formData.qualification || ""}
                        onValueChange={(value) => handleSelectChange("qualification", value)}
                      >
                        <SelectTrigger className="bg-white">
                          <SelectValue placeholder="Sélectionner une qualification" />
                        </SelectTrigger>
                        <SelectContent>
                          {QUALIFICATION_OPTIONS.map((option) => (
                            <SelectItem key={option} value={option}>
                              {option}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="rdvObtenuPar">RDV obtenu par</Label>
                      <Select
                        value={formData.rdvObtenuPar || ""}
                        onValueChange={(value) => handleSelectChange("rdvObtenuPar", value)}
                      >
                        <SelectTrigger className="bg-white">
                          <SelectValue placeholder="Sélectionner une personne" />
                        </SelectTrigger>
                        <SelectContent>
                          {RDV_OBTENU_PAR_OPTIONS.map((option) => (
                            <SelectItem key={option} value={option}>
                              {option}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="medical">
                <AccordionTrigger className="text-lg font-semibold">Informations médicales</AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-3">
                    <div>
                      <Label htmlFor="poids">Poids (kg)</Label>
                      <Input
                        id="poids"
                        name="poids"
                        type="number"
                        step="0.1"
                        value={formData.poids?.toString() || ""}
                        onChange={handleChange}
                      />
                    </div>

                    <div>
                      <Label htmlFor="taille">Taille (cm)</Label>
                      <Input
                        id="taille"
                        name="taille"
                        type="number"
                        step="0.1"
                        value={formData.taille?.toString() || ""}
                        onChange={handleChange}
                      />
                    </div>

                    <div>
                      <Label htmlFor="bmi">IMC</Label>
                      <Input
                        id="bmi"
                        name="bmi"
                        type="number"
                        step="0.1"
                        value={formData.bmi?.toString() || ""}
                        onChange={handleChange}
                        readOnly
                      />
                    </div>

                    <div>
                      <Label htmlFor="chirurgie">Type de chirurgie</Label>
                      <Select
                        value={formData.chirurgie || ""}
                        onValueChange={(value) => handleSelectChange("chirurgie", value)}
                      >
                        <SelectTrigger className="bg-white">
                          <SelectValue placeholder="Sélectionner un type de chirurgie" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="non_specifie">Non spécifié</SelectItem>
                          {CHIRURGIE_OPTIONS.map((option) => (
                            <SelectItem key={option} value={option}>
                              {option}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="flex items-center justify-between">
                      <Label htmlFor="medicalAgrement">Agrément médical</Label>
                      <Switch
                        id="medicalAgrement"
                        checked={formData.medicalAgrement === true}
                        onCheckedChange={(checked) => handleSwitchChange("medicalAgrement", checked)}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label htmlFor="consentForm">Formulaire de consentement</Label>
                      <Switch
                        id="consentForm"
                        checked={formData.consentForm === true}
                        onCheckedChange={(checked) => handleSwitchChange("consentForm", checked)}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label htmlFor="compteRenduConsultation">Compte rendu de consultation</Label>
                      <Switch
                        id="compteRenduConsultation"
                        checked={formData.compteRenduConsultation === true}
                        onCheckedChange={(checked) => handleSwitchChange("compteRenduConsultation", checked)}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label htmlFor="compteRenduHospitalisation">Compte rendu d'hospitalisation</Label>
                      <Switch
                        id="compteRenduHospitalisation"
                        checked={formData.compteRenduHospitalisation === true}
                        onCheckedChange={(checked) => handleSwitchChange("compteRenduHospitalisation", checked)}
                      />
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="financier">
                <AccordionTrigger className="text-lg font-semibold">Informations financières</AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-3">
                    <div>
                      <Label htmlFor="income">Revenus (£)</Label>
                      <Input
                        id="income"
                        name="income"
                        type="number"
                        value={formData.income?.toString() || ""}
                        onChange={handleChange}
                      />
                    </div>

                    <div>
                      <Label htmlFor="expenses">Dépenses (£)</Label>
                      <Input
                        id="expenses"
                        name="expenses"
                        type="number"
                        value={formData.expenses?.toString() || ""}
                        onChange={handleChange}
                      />
                    </div>

                    <div>
                      <Label htmlFor="creditScore">Score de crédit</Label>
                      <Input
                        id="creditScore"
                        name="creditScore"
                        value={formData.creditScore?.toString() || ""}
                        onChange={handleChange}
                      />
                    </div>

                    <div>
                      <Label htmlFor="creditPlatform">Plateforme de credit score</Label>
                      <Select
                        value={formData.creditPlatform || ""}
                        onValueChange={(value) => handleSelectChange("creditPlatform", value)}
                      >
                        <SelectTrigger className="bg-white">
                          <SelectValue placeholder="Sélectionner une plateforme" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="non_specifie">Non spécifié</SelectItem>
                          <SelectItem value="Experian">Experian</SelectItem>
                          <SelectItem value="Equifax">Equifax</SelectItem>
                          <SelectItem value="TransUnion">TransUnion</SelectItem>
                          <SelectItem value="Clearscore">Clearscore</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="loanAmount">Montant du prêt (£)</Label>
                      <Input
                        id="loanAmount"
                        name="loanAmount"
                        type="number"
                        value={formData.loanAmount?.toString() || ""}
                        onChange={handleChange}
                      />
                    </div>

                    <div>
                      <Label>Simulation validée</Label>
                      <RadioGroup
                        value={
                          formData.simulationValidated === true || formData.simulationValidated === "Oui"
                            ? "Oui"
                            : "Non"
                        }
                        onValueChange={(value) => handleRadioChange("simulationValidated", value)}
                        className="flex space-x-4 mt-2"
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="Oui" id="simulation-oui" />
                          <Label htmlFor="simulation-oui">Oui</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="Non" id="simulation-non" />
                          <Label htmlFor="simulation-non">Non</Label>
                        </div>
                      </RadioGroup>
                    </div>

                    <div>
                      <Label htmlFor="platform">Plateforme de prêt</Label>
                      <Select
                        value={formData.platform || ""}
                        onValueChange={(value) => handleSelectChange("platform", value)}
                      >
                        <SelectTrigger className="bg-white">
                          <SelectValue placeholder="Sélectionner une plateforme" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="non_specifie">Non spécifié</SelectItem>
                          <SelectItem value="Zopa">Zopa</SelectItem>
                          <SelectItem value="Novuna Personal Finance">Novuna Personal Finance</SelectItem>
                          <SelectItem value="GetABound">GetABound</SelectItem>
                          <SelectItem value="Lendable">Lendable</SelectItem>
                          <SelectItem value="Bamboo Loans">Bamboo Loans</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label>Prêt demandé</Label>
                      <RadioGroup
                        value={formData.loanRequested === true || formData.loanRequested === "Oui" ? "Oui" : "Non"}
                        onValueChange={(value) => handleRadioChange("loanRequested", value)}
                        className="flex space-x-4 mt-2"
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="Oui" id="loan-oui" />
                          <Label htmlFor="loan-oui">Oui</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="Non" id="loan-non" />
                          <Label htmlFor="loan-non">Non</Label>
                        </div>
                      </RadioGroup>
                    </div>

                    <div className="flex items-center justify-between">
                      <Label htmlFor="factureEnvoye">Facture envoyée</Label>
                      <Switch
                        id="factureEnvoye"
                        checked={formData.factureEnvoye === true}
                        onCheckedChange={(checked) => handleSwitchChange("factureEnvoye", checked)}
                      />
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="suivi">
                <AccordionTrigger className="text-lg font-semibold">
                  Statut et suivi
                  {validationErrors.status ? <AlertCircle className="h-4 w-4 text-red-500 ml-2" /> : null}
                </AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-3">
                    <div>
                      <Label htmlFor="status" className={validationErrors.status ? "text-red-500" : ""}>
                        Statut *
                      </Label>
                      <Select
                        value={formData.status || "a_rappeler"}
                        onValueChange={(value) => handleSelectChange("status", value)}
                        required
                      >
                        <SelectTrigger className={validationErrors.status ? "border-red-500" : "bg-white"}>
                          <SelectValue placeholder="Sélectionner un statut" />
                        </SelectTrigger>
                        <SelectContent>
                          {PATIENT_STATUSES.map((status) => (
                            <SelectItem key={status.value} value={status.value}>
                              {status.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {validationErrors.status && (
                        <p className="text-sm text-red-500 mt-1">{validationErrors.status}</p>
                      )}
                    </div>

                    {/* Sélection du closer */}
                    <div>
                      <Label htmlFor="closer">Commercial assigné</Label>
                      <Select
                        value={formData.closer && formData.closer.trim() !== "" ? formData.closer : "non_assigne"}
                        onValueChange={(value) => handleSelectChange("closer", value)}
                        disabled={loadingClosers}
                      >
                        <SelectTrigger className="bg-white">
                          <SelectValue placeholder={loadingClosers ? "Chargement..." : "Sélectionner un commercial"} />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="non_assigne">Non assigné</SelectItem>
                          {Array.isArray(closers) &&
                            closers
                              .filter((closer) => closer && closer.name && closer.name.trim() !== "") // Filtrer les closers avec des noms vides
                              .map((closer) => {
                                // Garantir que la valeur n'est jamais vide
                                const safeValue = closer.name?.trim() ? closer.name.trim() : `closer-${closer.id}`
                                return (
                                  <SelectItem key={closer.id} value={safeValue}>
                                    {closer.name?.trim() || `Closer ${closer.id}`}
                                  </SelectItem>
                                )
                              })}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="nextFollowUp">Prochain suivi</Label>
                      <Input
                        id="nextFollowUp"
                        name="nextFollowUp"
                        type="date"
                        value={formData.nextFollowUp?.toString() || ""}
                        onChange={handleChange}
                      />
                    </div>

                    <div>
                      <Label htmlFor="comments">Commentaires</Label>
                      <Textarea
                        id="comments"
                        name="comments"
                        value={formData.comments || ""}
                        onChange={handleChange}
                        rows={3}
                      />
                    </div>

                    <div>
                      <Label htmlFor="notes">Notes</Label>
                      <Textarea id="notes" name="notes" value={formData.notes || ""} onChange={handleChange} rows={3} />
                    </div>

                    <div>
                      <Label htmlFor="premierEmail">Premier email</Label>
                      <Input
                        id="premierEmail"
                        name="premierEmail"
                        type="datetime-local"
                        value={formData.premierEmail?.toString() || ""}
                        onChange={handleChange}
                      />
                    </div>

                    <div>
                      <Label htmlFor="premierWhatsapp">Premier WhatsApp</Label>
                      <Input
                        id="premierWhatsapp"
                        name="premierWhatsapp"
                        type="datetime-local"
                        value={formData.premierWhatsapp?.toString() || ""}
                        onChange={handleChange}
                      />
                    </div>

                    <div>
                      <Label htmlFor="secondEmail">Second email</Label>
                      <Input
                        id="secondEmail"
                        name="secondEmail"
                        type="datetime-local"
                        value={formData.secondEmail?.toString() || ""}
                        onChange={handleChange}
                      />
                    </div>

                    <div>
                      <Label htmlFor="secondWhatsapp">Second WhatsApp</Label>
                      <Input
                        id="secondWhatsapp"
                        name="secondWhatsapp"
                        type="datetime-local"
                        value={formData.secondWhatsapp?.toString() || ""}
                        onChange={handleChange}
                      />
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="documents">
                <AccordionTrigger className="text-lg font-semibold">Documents</AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="emailPatientGp">Email patient GP</Label>
                      <Switch
                        id="emailPatientGp"
                        checked={formData.emailPatientGp === true}
                        onCheckedChange={(checked) => handleSwitchChange("emailPatientGp", checked)}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label htmlFor="patientS2Form">Formulaire S2 patient</Label>
                      <Switch
                        id="patientS2Form"
                        checked={formData.patientS2Form === true}
                        onCheckedChange={(checked) => handleSwitchChange("patientS2Form", checked)}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label htmlFor="lettreGp">Lettre GP</Label>
                      <Switch
                        id="lettreGp"
                        checked={formData.lettreGp === true}
                        onCheckedChange={(checked) => handleSwitchChange("lettreGp", checked)}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label htmlFor="s2SaintJames">S2 Saint James</Label>
                      <Switch
                        id="s2SaintJames"
                        checked={formData.s2SaintJames === true}
                        onCheckedChange={(checked) => handleSwitchChange("s2SaintJames", checked)}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label htmlFor="autorisationPatientS2">Autorisation patient S2</Label>
                      <Switch
                        id="autorisationPatientS2"
                        checked={formData.autorisationPatientS2 === true}
                        onCheckedChange={(checked) => handleSwitchChange("autorisationPatientS2", checked)}
                      />
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="nhs">
                <AccordionTrigger className="text-lg font-semibold">NHS Tier 4</AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-3">
                    <div>
                      <Label htmlFor="nhsTier4PremierEmail">Premier email NHS Tier 4</Label>
                      <Input
                        id="nhsTier4PremierEmail"
                        name="nhsTier4PremierEmail"
                        type="datetime-local"
                        value={formData.nhsTier4PremierEmail?.toString() || ""}
                        onChange={handleChange}
                      />
                    </div>

                    <div>
                      <Label htmlFor="nhsTier4SecondEmail">Second email NHS Tier 4</Label>
                      <Input
                        id="nhsTier4SecondEmail"
                        name="nhsTier4SecondEmail"
                        type="datetime-local"
                        value={formData.nhsTier4SecondEmail?.toString() || ""}
                        onChange={handleChange}
                      />
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>

              {isAdmin && (
                <AccordionItem value="admin">
                  <AccordionTrigger className="text-lg font-semibold">Administration</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-3">
                      <div>
                        <Label>Valider le dossier</Label>
                        <RadioGroup
                          value={formData.validated === true ? "Oui" : "Non"}
                          onValueChange={(value) => handleRadioChange("validated", value === "Oui")}
                          className="flex space-x-4 mt-2"
                        >
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="Oui" id="validated-oui" />
                            <Label htmlFor="validated-oui">Oui</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="Non" id="validated-non" />
                            <Label htmlFor="validated-non">Non</Label>
                          </div>
                        </RadioGroup>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              )}
            </Accordion>
          </div>

          {/* Boutons fixes en bas de l'écran */}
          <div className="fixed bottom-0 left-0 right-0 bg-background border-t p-4 flex justify-end space-x-2 z-10">
            <Button type="button" variant="outline" onClick={handleCancel}>
              Annuler
            </Button>

            {isAdmin && !isEditMode && (
              <Button type="button" onClick={(e) => handleSubmitFixed(e, true)} disabled={loading} variant="secondary">
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Validation...
                  </>
                ) : (
                  "Enregistrer et Valider"
                )}
              </Button>
            )}

            <Button type="submit" disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {isEditMode ? "Mise à jour..." : "Enregistrement..."}
                </>
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  {isEditMode ? "Mettre à jour" : "Enregistrer"}
                </>
              )}
            </Button>
          </div>
        </form>
        <AlertDialog open={showUnsavedChangesAlert} onOpenChange={setShowUnsavedChangesAlert}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Modifications non sauvegardées</AlertDialogTitle>
              <AlertDialogDescription>
                Vous avez des modifications non sauvegardées. Êtes-vous sûr de vouloir quitter cette page ?
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Annuler</AlertDialogCancel>
              <AlertDialogAction onClick={navigateBack}>Quitter sans sauvegarder</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    )
  }

  // Rendu pour desktop avec tabs
  return (
    <div className="space-y-6 w-full overflow-y-auto">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="outline" onClick={handleCancel}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Retour
          </Button>
          <h1 className="text-2xl font-bold">{isEditMode ? "Modifier le patient" : "Nouveau patient"}</h1>
        </div>
      </div>

      <form onSubmit={(e) => handleSubmitFixed(e, false)} className="space-y-8">
        <Tabs defaultValue="informations" className="w-full">
          <TabsList className="w-full">
            <TabsTrigger value="informations" className="relative">
              Informations personnelles
              {(validationErrors.name ||
                validationErrors.email ||
                validationErrors.phone ||
                validationErrors.registrationDate ||
                validationErrors.doctor) && (
                <span className="absolute top-0 right-0 h-2 w-2 rounded-full bg-red-500"></span>
              )}
            </TabsTrigger>
            <TabsTrigger value="medical">Médical</TabsTrigger>
            <TabsTrigger value="financier">Financier</TabsTrigger>
            <TabsTrigger value="suivi" className="relative">
              Suivi
              {validationErrors.status && (
                <span className="absolute top-0 right-0 h-2 w-2 rounded-full bg-red-500"></span>
              )}
            </TabsTrigger>
            <TabsTrigger value="documents">Documents</TabsTrigger>
            <TabsTrigger value="nhs">NHS</TabsTrigger>
            {isAdmin && <TabsTrigger value="admin">Admin</TabsTrigger>}
          </TabsList>

          <TabsContent value="informations" className="space-y-4 mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Informations personnelles</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="name" className={validationErrors.name ? "text-red-500" : ""}>
                      Nom complet *
                    </Label>
                    <Input
                      id="name"
                      name="name"
                      value={formData.name || ""}
                      onChange={handleChange}
                      required
                      className={validationErrors.name ? "border-red-500" : ""}
                    />
                    {validationErrors.name && <p className="text-sm text-red-500 mt-1">{validationErrors.name}</p>}
                  </div>

                  <div>
                    <Label htmlFor="email" className={validationErrors.email ? "text-red-500" : ""}>
                      Email *
                    </Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email || ""}
                      onChange={handleChange}
                      required
                      className={validationErrors.email ? "border-red-500" : ""}
                    />
                    {validationErrors.email && <p className="text-sm text-red-500 mt-1">{validationErrors.email}</p>}
                  </div>

                  <div>
                    <Label htmlFor="phone" className={validationErrors.phone ? "text-red-500" : ""}>
                      Téléphone
                    </Label>
                    <div className="flex items-center space-x-2">
                      <div className="relative flex-1">
                        <Input
                          id="phone"
                          name="phone"
                          type="tel"
                          value={formData.phone || ""}
                          onChange={handleChange}
                          className={validationErrors.phone ? "border-red-500 pr-10" : "pr-10"}
                          placeholder="+33612345678"
                        />
                      </div>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              type="button"
                              variant="outline"
                              size="icon"
                              onClick={copyPhoneToClipboard}
                              disabled={!formData.phone}
                              className="flex-shrink-0"
                            >
                              <Copy className="h-4 w-4" />
                              <span className="sr-only">Copier le numéro</span>
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Copier le numéro</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                    {validationErrors.phone && <p className="text-sm text-red-500 mt-1">{validationErrors.phone}</p>}
                  </div>

                  <div>
                    <Label htmlFor="doctor" className={validationErrors.doctor ? "text-red-500" : ""}>
                      Médecin *
                    </Label>
                    <Select
                      value={formData.doctor || "non_specifie"}
                      onValueChange={(value) => handleSelectChange("doctor", value)}
                    >
                      <SelectTrigger className={validationErrors.doctor ? "border-red-500" : "bg-white"}>
                        <SelectValue placeholder="Sélectionner un médecin" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Noel">Noel</SelectItem>
                        <SelectItem value="Nedelcu">Nedelcu</SelectItem>
                        <SelectItem value="Coste">Coste</SelectItem>
                        <SelectItem value="Manos">Manos</SelectItem>
                      </SelectContent>
                    </Select>
                    {validationErrors.doctor && <p className="text-sm text-red-500 mt-1">{validationErrors.doctor}</p>}
                  </div>

                  <div>
                    <Label
                      htmlFor="registrationDate"
                      className={validationErrors.registrationDate ? "text-red-500" : ""}
                    >
                      Date d'enregistrement *
                    </Label>
                    <Input
                      id="registrationDate"
                      name="registrationDate"
                      type="date"
                      value={formData.registrationDate || ""}
                      onChange={handleChange}
                      required
                      className={validationErrors.registrationDate ? "border-red-500" : ""}
                    />
                    {validationErrors.registrationDate && (
                      <p className="text-sm text-red-500 mt-1">{validationErrors.registrationDate}</p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="consultationDate">Date de consultation</Label>
                    <Input
                      id="consultationDate"
                      name="consultationDate"
                      type="date"
                      value={formData.consultationDate || ""}
                      onChange={handleChange}
                    />
                  </div>

                  <div>
                    <Label htmlFor="suiteGroupe">Suite/Groupe</Label>
                    <Select
                      value={formData.suiteGroupe || "non_specifie"}
                      onValueChange={(value) => handleSelectChange("suiteGroupe", value)}
                    >
                      <SelectTrigger className="bg-white">
                        <SelectValue placeholder="Sélectionner une option" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="non_specifie">Non spécifié</SelectItem>
                        <SelectItem value="NHS">NHS</SelectItem>
                        <SelectItem value="CASH">CASH</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="qualification">Qualification</Label>
                    <Select
                      value={formData.qualification || ""}
                      onValueChange={(value) => handleSelectChange("qualification", value)}
                    >
                      <SelectTrigger className="bg-white">
                        <SelectValue placeholder="Sélectionner une qualification" />
                      </SelectTrigger>
                      <SelectContent>
                        {QUALIFICATION_OPTIONS.map((option) => (
                          <SelectItem key={option} value={option}>
                            {option}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="rdvObtenuPar">RDV obtenu par</Label>
                    <Select
                      value={formData.rdvObtenuPar || ""}
                      onValueChange={(value) => handleSelectChange("rdvObtenuPar", value)}
                    >
                      <SelectTrigger className="bg-white">
                        <SelectValue placeholder="Sélectionner une personne" />
                      </SelectTrigger>
                      <SelectContent>
                        {RDV_OBTENU_PAR_OPTIONS.map((option) => (
                          <SelectItem key={option} value={option}>
                            {option}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="medical" className="space-y-4 mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Informations médicales</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="poids">Poids (kg)</Label>
                      <Input
                        id="poids"
                        name="poids"
                        type="number"
                        step="0.1"
                        value={formData.poids?.toString() || ""}
                        onChange={handleChange}
                      />
                    </div>

                    <div>
                      <Label htmlFor="taille">Taille (cm)</Label>
                      <Input
                        id="taille"
                        name="taille"
                        type="number"
                        step="0.1"
                        value={formData.taille?.toString() || ""}
                        onChange={handleChange}
                      />
                    </div>

                    <div>
                      <Label htmlFor="bmi">IMC</Label>
                      <Input
                        id="bmi"
                        name="bmi"
                        type="number"
                        step="0.1"
                        value={formData.bmi?.toString() || ""}
                        onChange={handleChange}
                        readOnly
                      />
                    </div>

                    <div>
                      <Label htmlFor="chirurgie">Type de chirurgie</Label>
                      <Select
                        value={formData.chirurgie || ""}
                        onValueChange={(value) => handleSelectChange("chirurgie", value)}
                      >
                        <SelectTrigger className="bg-white">
                          <SelectValue placeholder="Sélectionner un type de chirurgie" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="non_specifie">Non spécifié</SelectItem>
                          {CHIRURGIE_OPTIONS.map((option) => (
                            <SelectItem key={option} value={option}>
                              {option}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                    <div className="flex items-center space-x-2">
                      <Label htmlFor="medicalAgrement" className="flex-1">
                        Agrément médical
                      </Label>
                      <Switch
                        id="medicalAgrement"
                        checked={formData.medicalAgrement === true}
                        onCheckedChange={(checked) => handleSwitchChange("medicalAgrement", checked)}
                      />
                    </div>

                    <div className="flex items-center space-x-2">
                      <Label htmlFor="consentForm" className="flex-1">
                        Formulaire de consentement
                      </Label>
                      <Switch
                        id="consentForm"
                        checked={formData.consentForm === true}
                        onCheckedChange={(checked) => handleSwitchChange("consentForm", checked)}
                      />
                    </div>

                    <div className="flex items-center space-x-2">
                      <Label htmlFor="compteRenduConsultation" className="flex-1">
                        Compte rendu de consultation
                      </Label>
                      <Switch
                        id="compteRenduConsultation"
                        checked={formData.compteRenduConsultation === true}
                        onCheckedChange={(checked) => handleSwitchChange("compteRenduConsultation", checked)}
                      />
                    </div>

                    <div className="flex items-center space-x-2">
                      <Label htmlFor="compteRenduHospitalisation" className="flex-1">
                        Compte rendu d'hospitalisation
                      </Label>
                      <Switch
                        id="compteRenduHospitalisation"
                        checked={formData.compteRenduHospitalisation === true}
                        onCheckedChange={(checked) => handleSwitchChange("compteRenduHospitalisation", checked)}
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="financier" className="space-y-4 mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Informations financières</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="income">Revenus (£)</Label>
                    <Input
                      id="income"
                      name="income"
                      type="number"
                      value={formData.income?.toString() || ""}
                      onChange={handleChange}
                    />
                  </div>

                  <div>
                    <Label htmlFor="expenses">Dépenses (£)</Label>
                    <Input
                      id="expenses"
                      name="expenses"
                      type="number"
                      value={formData.expenses?.toString() || ""}
                      onChange={handleChange}
                    />
                  </div>

                  <div>
                    <Label htmlFor="creditScore">Score de crédit</Label>
                    <Input
                      id="creditScore"
                      name="creditScore"
                      value={formData.creditScore?.toString() || ""}
                      onChange={handleChange}
                    />
                  </div>

                  <div>
                    <Label htmlFor="creditPlatform">Plateforme de credit score</Label>
                    <Select
                      value={formData.creditPlatform || ""}
                      onValueChange={(value) => handleSelectChange("creditPlatform", value)}
                    >
                      <SelectTrigger className="bg-white">
                        <SelectValue placeholder="Sélectionner une plateforme" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="non_specifie">Non spécifié</SelectItem>
                        <SelectItem value="Experian">Experian</SelectItem>
                        <SelectItem value="Equifax">Equifax</SelectItem>
                        <SelectItem value="TransUnion">TransUnion</SelectItem>
                        <SelectItem value="Clearscore">Clearscore</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="loanAmount">Montant du prêt (£)</Label>
                    <Input
                      id="loanAmount"
                      name="loanAmount"
                      type="number"
                      value={formData.loanAmount?.toString() || ""}
                      onChange={handleChange}
                    />
                  </div>

                  <div>
                    <Label>Simulation validée</Label>
                    <RadioGroup
                      value={
                        formData.simulationValidated === true || formData.simulationValidated === "Oui" ? "Oui" : "Non"
                      }
                      onValueChange={(value) => handleRadioChange("simulationValidated", value)}
                      className="flex space-x-4 mt-2"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="Oui" id="simulation-oui" />
                        <Label htmlFor="simulation-oui">Oui</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="Non" id="simulation-non" />
                        <Label htmlFor="simulation-non">Non</Label>
                      </div>
                    </RadioGroup>
                  </div>

                  <div>
                    <Label htmlFor="platform">Plateforme de prêt</Label>
                    <Select
                      value={formData.platform || ""}
                      onValueChange={(value) => handleSelectChange("platform", value)}
                    >
                      <SelectTrigger className="bg-white">
                        <SelectValue placeholder="Sélectionner une plateforme" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="non_specifie">Non spécifié</SelectItem>
                        <SelectItem value="Zopa">Zopa</SelectItem>
                        <SelectItem value="Novuna Personal Finance">Novuna Personal Finance</SelectItem>
                        <SelectItem value="GetABound">GetABound</SelectItem>
                        <SelectItem value="Lendable">Lendable</SelectItem>
                        <SelectItem value="Bamboo Loans">Bamboo Loans</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Prêt demandé</Label>
                    <RadioGroup
                      value={formData.loanRequested === true || formData.loanRequested === "Oui" ? "Oui" : "Non"}
                      onValueChange={(value) => handleRadioChange("loanRequested", value)}
                      className="flex space-x-4 mt-2"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="Oui" id="loan-oui" />
                        <Label htmlFor="loan-oui">Oui</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="Non" id="loan-non" />
                        <Label htmlFor="loan-non">Non</Label>
                      </div>
                    </RadioGroup>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Label htmlFor="factureEnvoye" className="flex-1">
                      Facture envoyée
                    </Label>
                    <Switch
                      id="factureEnvoye"
                      checked={formData.factureEnvoye === true}
                      onCheckedChange={(checked) => handleSwitchChange("factureEnvoye", checked)}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="suivi" className="space-y-4 mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Statut et suivi</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="status" className={validationErrors.status ? "text-red-500" : ""}>
                        Statut *
                      </Label>
                      <Select
                        value={formData.status || "a_rappeler"}
                        onValueChange={(value) => handleSelectChange("status", value)}
                        required
                      >
                        <SelectTrigger className={validationErrors.status ? "border-red-500" : "bg-white"}>
                          <SelectValue placeholder="Sélectionner un statut" />
                        </SelectTrigger>
                        <SelectContent>
                          {PATIENT_STATUSES.map((status) => (
                            <SelectItem key={status.value} value={status.value}>
                              {status.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {validationErrors.status && (
                        <p className="text-sm text-red-500 mt-1">{validationErrors.status}</p>
                      )}
                    </div>

                    {/* Sélection du closer */}
                    <div>
                      <Label htmlFor="closer">Commercial assigné</Label>
                      <Select
                        value={formData.closer && formData.closer.trim() !== "" ? formData.closer : "non_assigne"}
                        onValueChange={(value) => handleSelectChange("closer", value)}
                        disabled={loadingClosers}
                      >
                        <SelectTrigger className="bg-white">
                          <SelectValue placeholder={loadingClosers ? "Chargement..." : "Sélectionner un commercial"} />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="non_assigne">Non assigné</SelectItem>
                          {Array.isArray(closers) &&
                            closers
                              .filter((closer) => closer.name && closer.name.trim() !== "")
                              .map((closer) => {
                                const safeValue = closer.name?.trim() || `closer-${closer.id}`
                                return (
                                  <SelectItem key={closer.id} value={safeValue}>
                                    {closer.name?.trim() || `Closer ${closer.id}`}
                                  </SelectItem>
                                )
                              })}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="nextFollowUp">Prochain suivi</Label>
                      <Input
                        id="nextFollowUp"
                        name="nextFollowUp"
                        type="date"
                        value={formData.nextFollowUp?.toString() || ""}
                        onChange={handleChange}
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="comments">Commentaires</Label>
                    <Textarea
                      id="comments"
                      name="comments"
                      value={formData.comments || ""}
                      onChange={handleChange}
                      rows={5}
                    />
                  </div>

                  <div>
                    <Label htmlFor="notes">Notes</Label>
                    <Textarea id="notes" name="notes" value={formData.notes || ""} onChange={handleChange} rows={5} />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="premierEmail">Premier email</Label>
                      <Input
                        id="premierEmail"
                        name="premierEmail"
                        type="datetime-local"
                        value={formData.premierEmail?.toString() || ""}
                        onChange={handleChange}
                      />
                    </div>

                    <div>
                      <Label htmlFor="premierWhatsapp">Premier WhatsApp</Label>
                      <Input
                        id="premierWhatsapp"
                        name="premierWhatsapp"
                        type="datetime-local"
                        value={formData.premierWhatsapp?.toString() || ""}
                        onChange={handleChange}
                      />
                    </div>

                    <div>
                      <Label htmlFor="secondEmail">Second email</Label>
                      <Input
                        id="secondEmail"
                        name="secondEmail"
                        type="datetime-local"
                        value={formData.secondEmail?.toString() || ""}
                        onChange={handleChange}
                      />
                    </div>

                    <div>
                      <Label htmlFor="secondWhatsapp">Second WhatsApp</Label>
                      <Input
                        id="secondWhatsapp"
                        name="secondWhatsapp"
                        type="datetime-local"
                        value={formData.secondWhatsapp?.toString() || ""}
                        onChange={handleChange}
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="documents" className="space-y-4 mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Documents</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center space-x-2">
                    <Label htmlFor="emailPatientGp" className="flex-1">
                      Email patient GP
                    </Label>
                    <Switch
                      id="emailPatientGp"
                      checked={formData.emailPatientGp === true}
                      onCheckedChange={(checked) => handleSwitchChange("emailPatientGp", checked)}
                    />
                  </div>

                  <div className="flex items-center space-x-2">
                    <Label htmlFor="patientS2Form" className="flex-1">
                      Formulaire S2 patient
                    </Label>
                    <Switch
                      id="patientS2Form"
                      checked={formData.patientS2Form === true}
                      onCheckedChange={(checked) => handleSwitchChange("patientS2Form", checked)}
                    />
                  </div>

                  <div className="flex items-center space-x-2">
                    <Label htmlFor="lettreGp" className="flex-1">
                      Lettre GP
                    </Label>
                    <Switch
                      id="lettreGp"
                      checked={formData.lettreGp === true}
                      onCheckedChange={(checked) => handleSwitchChange("lettreGp", checked)}
                    />
                  </div>

                  <div className="flex items-center space-x-2">
                    <Label htmlFor="s2SaintJames" className="flex-1">
                      S2 Saint James
                    </Label>
                    <Switch
                      id="s2SaintJames"
                      checked={formData.s2SaintJames === true}
                      onCheckedChange={(checked) => handleSwitchChange("s2SaintJames", checked)}
                    />
                  </div>

                  <div className="flex items-center space-x-2">
                    <Label htmlFor="autorisationPatientS2" className="flex-1">
                      Autorisation patient S2
                    </Label>
                    <Switch
                      id="autorisationPatientS2"
                      checked={formData.autorisationPatientS2 === true}
                      onCheckedChange={(checked) => handleSwitchChange("autorisationPatientS2", checked)}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="nhs" className="space-y-4 mt-4">
            <Card>
              <CardHeader>
                <CardTitle>NHS Tier 4</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="nhsTier4PremierEmail">Premier email NHS Tier 4</Label>
                    <Input
                      id="nhsTier4PremierEmail"
                      name="nhsTier4PremierEmail"
                      type="datetime-local"
                      value={formData.nhsTier4PremierEmail?.toString() || ""}
                      onChange={handleChange}
                    />
                  </div>

                  <div>
                    <Label htmlFor="nhsTier4SecondEmail">Second email NHS Tier 4</Label>
                    <Input
                      id="nhsTier4SecondEmail"
                      name="nhsTier4SecondEmail"
                      type="datetime-local"
                      value={formData.nhsTier4SecondEmail?.toString() || ""}
                      onChange={handleChange}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {isAdmin && (
            <TabsContent value="admin" className="space-y-4 mt-4">
              <Card>
                <CardHeader>
                  <CardTitle>Administration</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <Label>Valider le dossier</Label>
                      <RadioGroup
                        value={formData.validated === true ? "Oui" : "Non"}
                        onValueChange={(value) => handleRadioChange("validated", value === "Oui")}
                        className="flex space-x-4 mt-2"
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="Oui" id="validated-oui" />
                          <Label htmlFor="validated-oui">Oui</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="Non" id="validated-non" />
                          <Label htmlFor="validated-non">Non</Label>
                        </div>
                      </RadioGroup>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          )}
        </Tabs>

        <div className="flex justify-end space-x-4">
          <Button type="button" variant="outline" onClick={handleCancel}>
            Annuler
          </Button>

          {isAdmin && !isEditMode && (
            <Button type="button" onClick={(e) => handleSubmitFixed(e, true)} disabled={loading} variant="secondary">
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Validation...
                </>
              ) : (
                "Enregistrer et Valider"
              )}
            </Button>
          )}

          <Button type="submit" disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                {isEditMode ? "Mise à jour..." : "Enregistrement..."}
              </>
            ) : (
              <>
                <Save className="h-4 w-4 mr-2" />
                {isEditMode ? "Mettre à jour" : "Enregistrer"}
              </>
            )}
          </Button>
        </div>
      </form>

      {/* Alerte pour les modifications non sauvegardées */}
      <AlertDialog open={showUnsavedChangesAlert} onOpenChange={setShowUnsavedChangesAlert}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Modifications non sauvegardées</AlertDialogTitle>
            <AlertDialogDescription>
              Vous avez des modifications non sauvegardées. Êtes-vous sûr de vouloir quitter cette page ?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuler</AlertDialogCancel>
            <AlertDialogAction onClick={navigateBack}>Quitter sans sauvegarder</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

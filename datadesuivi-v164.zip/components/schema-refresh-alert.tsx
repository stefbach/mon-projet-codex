"use client"

import { useState, useEffect } from "react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { AlertCircle, RefreshCw, Loader2 } from "lucide-react"
import { refreshSchemaCache, verifyPatientUserRelationship } from "@/lib/supabase"
import { useRouter } from "next/navigation"

export function SchemaRefreshAlert() {
  const [loading, setLoading] = useState(false)
  const [checking, setChecking] = useState(true)
  const [needsRefresh, setNeedsRefresh] = useState(false)
  const router = useRouter()

  useEffect(() => {
    checkRelationship()
  }, [])

  async function checkRelationship() {
    setChecking(true)
    try {
      const result = await verifyPatientUserRelationship()
      setNeedsRefresh(!result.success && result.needsRefresh)
    } catch (error) {
      console.error("Error checking relationship:", error)
      setNeedsRefresh(true)
    } finally {
      setChecking(false)
    }
  }

  async function handleRefresh() {
    setLoading(true)
    try {
      const result = await refreshSchemaCache()
      if (result.success) {
        setNeedsRefresh(false)
        // Refresh the page to apply changes
        router.refresh()
      }
    } catch (error) {
      console.error("Error refreshing schema:", error)
    } finally {
      setLoading(false)
    }
  }

  if (checking || !needsRefresh) {
    return null
  }

  return (
    <Alert variant="destructive" className="mb-4">
      <AlertCircle className="h-4 w-4" />
      <AlertTitle>Problème de schéma détecté</AlertTitle>
      <AlertDescription className="flex items-center justify-between">
        <span>
          Un problème a été détecté avec le schéma de la base de données. Cela peut affecter l'affichage des données.
        </span>
        <Button
          variant="outline"
          size="sm"
          onClick={handleRefresh}
          disabled={loading}
          className="ml-4 bg-white hover:bg-gray-100"
        >
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Rafraîchissement...
            </>
          ) : (
            <>
              <RefreshCw className="mr-2 h-4 w-4" />
              Rafraîchir le schéma
            </>
          )}
        </Button>
      </AlertDescription>
    </Alert>
  )
}

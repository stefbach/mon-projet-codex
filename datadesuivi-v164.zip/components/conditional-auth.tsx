"use client"

import type React from "react"

import { usePathname } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"

// Composant qui vérifie si l'authentification est nécessaire pour la page actuelle
export function ConditionalAuth({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const { user, loading, isDemoMode } = useAuth()

  // Routes qui ne nécessitent pas d'authentification
  const publicRoutes = ["/login", "/docs", "/docs/setup"]

  // Vérifier si la route actuelle est publique
  const isPublicRoute = publicRoutes.some((route) => pathname?.startsWith(route))

  // Si la route est publique, afficher le contenu sans vérification
  if (isPublicRoute) {
    return <>{children}</>
  }

  // Si l'utilisateur est en cours de chargement, afficher un indicateur de chargement
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-neutral-50">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-500"></div>
      </div>
    )
  }

  // Si l'utilisateur n'est pas connecté et que nous ne sommes pas en mode démo, rediriger vers la page de connexion
  if (!user && !isDemoMode) {
    window.location.href = "/login"
    return null
  }

  // Sinon, afficher le contenu
  return <>{children}</>
}

"use client"

import { useAuth } from "@/contexts/auth-context"
import { usePathname } from "next/navigation"
import Link from "next/link"
import { LayoutDashboard, Users, Phone, UserPlus, LogOut } from "lucide-react"
import { cn } from "@/lib/utils"

export function MobileNav() {
  const { user, logout } = useAuth()
  const pathname = usePathname()
  const isAdmin = user?.role === "admin"

  const handleLogout = async () => {
    try {
      console.log("Déconnexion en cours...")
      await logout()
    } catch (error) {
      console.error("Erreur lors de la déconnexion:", error)
    }
  }

  const navItems = [
    {
      href: "/dashboard",
      label: "Dashboard",
      icon: <LayoutDashboard className="h-5 w-5" />,
    },
    {
      href: "/patients",
      label: "Patients",
      icon: <Users className="h-5 w-5" />,
    },
    {
      href: "/calls",
      label: "Appels",
      icon: <Phone className="h-5 w-5" />,
    },
    {
      href: "/form",
      label: "Nouveau",
      icon: <UserPlus className="h-5 w-5" />,
    },
    {
      href: "#",
      label: "Déconnexion",
      icon: <LogOut className="h-5 w-5" />,
      onClick: handleLogout,
    },
  ]

  return (
    <div className="fixed bottom-0 left-0 z-50 w-full h-16 bg-white border-t border-gray-200 md:hidden">
      <div className="grid h-full grid-cols-5 mx-auto">
        {navItems.map((item, index) =>
          item.onClick ? (
            <button
              key={index}
              onClick={item.onClick}
              className={cn("inline-flex flex-col items-center justify-center px-1 hover:bg-gray-50 text-gray-500")}
            >
              {item.icon}
              <span className="text-xs mt-1">{item.label}</span>
            </button>
          ) : (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "inline-flex flex-col items-center justify-center px-1 hover:bg-gray-50",
                pathname === item.href ? "text-primary-600" : "text-gray-500",
              )}
            >
              {item.icon}
              <span className="text-xs mt-1">{item.label}</span>
            </Link>
          ),
        )}
      </div>
    </div>
  )
}

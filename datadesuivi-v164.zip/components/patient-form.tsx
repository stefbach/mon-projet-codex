"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useToast } from "@/components/ui/use-toast"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent } from "@/components/ui/card"
import { Loader2, Copy } from "lucide-react"
import { useAuth } from "@/contexts/auth-context"
import { submitPatient, getClosers } from "@/lib/patient-service"
import { PATIENT_STATUSES } from "@/lib/constants"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { useMobile } from "@/hooks/use-mobile"

// Options pour les menus déroulants
const SUITE_GROUPE_OPTIONS = ["NHS", "CASH"]
const QUALIFICATION_OPTIONS = ["chaud", "tiede", "froid"]
const RDV_OBTENU_PAR_OPTIONS = ["rain", "subham", "mariam", "mika", "summer", "dilan"]
const CHIRURGIE_OPTIONS = ["sg", "bariclip", "bypass", "esg", "sassi"]

export function PatientForm() {
  const { toast } = useToast()
  const router = useRouter()
  const { user } = useAuth()
  const [loading, setLoading] = useState(false)
  const [closers, setClosers] = useState<{ id: string; name: string; email: string }[]>([])
  const [loadingClosers, setLoadingClosers] = useState(true)
  const isMobile = useMobile()
  const [phoneError, setPhoneError] = useState<string | null>(null)

  // Définir la date d'enregistrement comme la date actuelle
  const currentDate = new Date().toISOString().split("T")[0]

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    doctor: "non_specifie",
    consultationDate: "",
    registrationDate: currentDate, // Date d'enregistrement par défaut
    income: "",
    expenses: "",
    creditScore: "",
    creditPlatform: "non_specifie",
    loanAmount: "",
    simulationValidated: "Non",
    platform: "non_specifie",
    status: "en_attente", // Valeur par défaut exacte
    loanRequested: "Non",
    nextFollowUp: "",
    comments: "",
    notes: "",
    closer: "non_assigne", // Valeur par défaut
    validated: false, // Pour indiquer si la fiche est validée
    // New fields avec valeurs par défaut
    suiteGroupe: SUITE_GROUPE_OPTIONS[0], // Valeur par défaut: "NHS"
    poids: "",
    taille: "",
    bmi: "",
    chirurgie: "non_specifie",
    qualification: QUALIFICATION_OPTIONS[0], // Valeur par défaut: "chaud"
    rdvObtenuPar: RDV_OBTENU_PAR_OPTIONS[0], // Valeur par défaut: "rain"
    premierEmail: "",
    premierWhatsapp: "",
    secondEmail: "",
    secondWhatsapp: "",
    factureEnvoye: false,
    medicalAgrement: false,
    consentForm: false,
    autorisationPatientS2: false,
    compteRenduHospitalisation: false,
    compteRenduConsultation: false,
    emailPatientGp: false,
    patientS2Form: false,
    lettreGp: false,
    s2SaintJames: false,
    nhsTier4PremierEmail: "",
    nhsTier4SecondEmail: "",
  })

  const copyPhoneToClipboard = () => {
    if (formData.phone) {
      navigator.clipboard
        .writeText(formData.phone)
        .then(() => {
          toast({
            title: "Numéro copié",
            description: "Le numéro de téléphone a été copié dans le presse-papiers",
            duration: 2000,
          })
        })
        .catch((err) => {
          console.error("Erreur lors de la copie:", err)
          toast({
            variant: "destructive",
            title: "Erreur",
            description: "Impossible de copier le numéro",
            duration: 2000,
          })
        })
    }
  }

  const validatePhoneNumber = (phone: string): boolean => {
    const phoneRegex = /^\+?[1-9][0-9]{7,14}$/
    return phoneRegex.test(phone)
  }

  // Charger la liste des closers au chargement du composant
  useEffect(() => {
    async function loadClosers() {
      try {
        const closersList = await getClosers()
        // Filtrer les closers qui pourraient avoir des noms vides
        const validClosers = closersList.filter((closer) => closer.name?.trim() !== "")
        setClosers(validClosers)

        // Si des closers valides sont disponibles, sélectionner le premier par défaut
        if (validClosers.length > 0) {
          const firstCloserName = validClosers[0].name?.trim() || `closer-${validClosers[0].id}`
          setFormData((prev) => ({
            ...prev,
            closer: firstCloserName,
          }))
        }

        setLoadingClosers(false)
      } catch (error) {
        console.error("Erreur lors du chargement des closers:", error)
        setLoadingClosers(false)
      }
    }

    loadClosers()
  }, [])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))

    // Validation du numéro de téléphone
    if (name === "phone" && value) {
      if (!validatePhoneNumber(value)) {
        setPhoneError("Format invalide. Exemple: +33612345678")
      } else {
        setPhoneError(null)
      }
    } else if (name === "phone" && !value) {
      setPhoneError(null)
    }
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleRadioChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSwitchChange = (name: string, checked: boolean) => {
    setFormData((prev) => ({ ...prev, [name]: checked }))
  }

  // Calculate BMI when weight or height changes
  useEffect(() => {
    if (formData.poids && formData.taille) {
      const weight = Number.parseFloat(formData.poids)
      const height = Number.parseFloat(formData.taille) / 100 // convert cm to m
      if (!isNaN(weight) && !isNaN(height) && height > 0) {
        const bmi = (weight / (height * height)).toFixed(1)
        setFormData((prev) => ({ ...prev, bmi }))
      }
    }
  }, [formData.poids, formData.taille])

  // Modifions la fonction handleSubmit pour s'assurer que les dates vides sont correctement traitées

  // Recherchez la fonction handleSubmit et modifiez la section qui prépare les données pour la soumission
  // Remplacez la section qui traite les dates par celle-ci:

  // Fonction pour formater la date et l'heure avec le fuseau horaire
  const formatDateTimeWithTimezone = (dateTimeString: string): string | null => {
    if (!dateTimeString || dateTimeString === "") return null

    try {
      const date = new Date(dateTimeString)
      // Format ISO avec timezone
      return date.toISOString()
    } catch (error) {
      console.error("Erreur de formatage de date:", error)
      return null
    }
  }

  const handleSubmit = async (e: React.FormEvent, validate = false) => {
    e.preventDefault()

    // Vérifier la validation du téléphone
    if (formData.phone && !validatePhoneNumber(formData.phone)) {
      toast({
        variant: "destructive",
        title: "Erreur de validation",
        description: "Le format du numéro de téléphone est invalide",
      })
      return
    }

    setLoading(true)

    try {
      // Formater les dates avec fuseau horaire et gérer les chaînes vides
      const formattedData = {
        ...formData,
        // Convertir les valeurs numériques
        income: formData.income ? Number(formData.income) : undefined,
        expenses: formData.expenses ? Number(formData.expenses) : undefined,
        loanAmount: formData.loanAmount ? Number(formData.loanAmount) : undefined,
        creditScore: formData.creditScore || undefined,
        poids: formData.poids ? Number(formData.poids) : undefined,
        taille: formData.taille ? Number(formData.taille) : undefined,
        bmi: formData.bmi ? Number(formData.bmi) : undefined,
        // Formater les dates avec fuseau horaire et gérer les chaînes vides
        consultationDate: formData.consultationDate ? formData.consultationDate : null,
        registrationDate: formData.registrationDate ? formData.registrationDate : null,
        nextFollowUp: formData.nextFollowUp ? formData.nextFollowUp : null,
        premierEmail: formatDateTimeWithTimezone(formData.premierEmail),
        premierWhatsapp: formatDateTimeWithTimezone(formData.premierWhatsapp),
        secondEmail: formatDateTimeWithTimezone(formData.secondEmail),
        secondWhatsapp: formatDateTimeWithTimezone(formData.secondWhatsapp),
        nhsTier4PremierEmail: formatDateTimeWithTimezone(formData.nhsTier4PremierEmail),
        nhsTier4SecondEmail: formatDateTimeWithTimezone(formData.nhsTier4SecondEmail),
      }

      const result = await submitPatient(formattedData, validate)

      if (result.success) {
        toast({
          title: "Patient ajouté",
          description: result.message || "Le patient a été ajouté avec succès",
        })
        router.push("/patients")
      } else {
        toast({
          variant: "destructive",
          title: "Erreur",
          description: result.message || "Une erreur s'est produite lors de l'ajout du patient",
        })
      }
    } catch (error) {
      console.error("Erreur lors de la soumission:", error)
      toast({
        variant: "destructive",
        title: "Erreur",
        description: "Une erreur s'est produite lors de l'ajout du patient",
      })
    } finally {
      setLoading(false)
    }
  }

  // Vérifier si l'utilisateur est un admin
  const isAdmin = user?.role === "admin"

  // Rendu pour mobile avec accordions
  if (isMobile) {
    return (
      <form onSubmit={(e) => handleSubmit(e, false)} className="space-y-4 pb-20 relative">
        <div className="overflow-y-auto max-h-[calc(100vh-180px)]">
          <Accordion type="multiple" defaultValue={["informations"]} className="w-full">
            <AccordionItem value="informations">
              <AccordionTrigger className="text-lg font-semibold">Informations personnelles</AccordionTrigger>
              <AccordionContent>
                <div className="space-y-3">
                  <div>
                    <Label htmlFor="name">Nom complet *</Label>
                    <Input id="name" name="name" value={formData.name} onChange={handleChange} required />
                  </div>

                  <div>
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="phone">Téléphone</Label>
                    <div className="flex items-center space-x-2">
                      <div className="relative flex-1">
                        <Input
                          id="phone"
                          name="phone"
                          type="tel"
                          value={formData.phone}
                          onChange={handleChange}
                          className={phoneError ? "border-red-500 pr-10" : "pr-10"}
                          placeholder="+33612345678"
                        />
                      </div>
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        onClick={copyPhoneToClipboard}
                        disabled={!formData.phone}
                        className="flex-shrink-0"
                      >
                        <Copy className="h-4 w-4" />
                        <span className="sr-only">Copier le numéro</span>
                      </Button>
                    </div>
                    {phoneError && <p className="text-sm text-red-500 mt-1">{phoneError}</p>}
                  </div>

                  <div>
                    <Label htmlFor="doctor">Médecin *</Label>
                    <Select
                      value={formData.doctor || "non_specifie"}
                      onValueChange={(value) => handleSelectChange("doctor", value)}
                    >
                      <SelectTrigger className="bg-white">
                        <SelectValue placeholder="Sélectionner un médecin" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Noel">Noel</SelectItem>
                        <SelectItem value="Nedelcu">Nedelcu</SelectItem>
                        <SelectItem value="Coste">Coste</SelectItem>
                        <SelectItem value="Manos">Manos</SelectItem>
                        <SelectItem value="non_specifie">Non spécifié</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="registrationDate">Date d'enregistrement *</Label>
                    <Input
                      id="registrationDate"
                      name="registrationDate"
                      type="date"
                      value={formData.registrationDate}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="consultationDate">Date de consultation</Label>
                    <Input
                      id="consultationDate"
                      name="consultationDate"
                      type="date"
                      value={formData.consultationDate}
                      onChange={handleChange}
                    />
                  </div>

                  <div>
                    <Label htmlFor="suiteGroupe">Suite/Groupe</Label>
                    <Select
                      value={formData.suiteGroupe}
                      onValueChange={(value) => handleSelectChange("suiteGroupe", value)}
                    >
                      <SelectTrigger className="bg-white">
                        <SelectValue placeholder="Sélectionner une option" />
                      </SelectTrigger>
                      <SelectContent>
                        {SUITE_GROUPE_OPTIONS.map((option) => (
                          <SelectItem key={option} value={option}>
                            {option}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="qualification">Qualification</Label>
                    <Select
                      value={formData.qualification}
                      onValueChange={(value) => handleSelectChange("qualification", value)}
                    >
                      <SelectTrigger className="bg-white">
                        <SelectValue placeholder="Sélectionner une qualification" />
                      </SelectTrigger>
                      <SelectContent>
                        {QUALIFICATION_OPTIONS.map((option) => (
                          <SelectItem key={option} value={option}>
                            {option}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="rdvObtenuPar">RDV obtenu par</Label>
                    <Select
                      value={formData.rdvObtenuPar}
                      onValueChange={(value) => handleSelectChange("rdvObtenuPar", value)}
                    >
                      <SelectTrigger className="bg-white">
                        <SelectValue placeholder="Sélectionner une personne" />
                      </SelectTrigger>
                      <SelectContent>
                        {RDV_OBTENU_PAR_OPTIONS.map((option) => (
                          <SelectItem key={option} value={option}>
                            {option}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="financier">
              <AccordionTrigger className="text-lg font-semibold">Informations financières</AccordionTrigger>
              <AccordionContent>
                <div className="space-y-3">
                  <div>
                    <Label htmlFor="income">Revenus (£)</Label>
                    <Input id="income" name="income" type="number" value={formData.income} onChange={handleChange} />
                  </div>

                  <div>
                    <Label htmlFor="expenses">Dépenses (£)</Label>
                    <Input
                      id="expenses"
                      name="expenses"
                      type="number"
                      value={formData.expenses}
                      onChange={handleChange}
                    />
                  </div>

                  <div>
                    <Label htmlFor="creditScore">Score de crédit</Label>
                    <Input id="creditScore" name="creditScore" value={formData.creditScore} onChange={handleChange} />
                  </div>

                  <div>
                    <Label htmlFor="creditPlatform">Plateforme de credit score</Label>
                    <Select
                      value={formData.creditPlatform}
                      onValueChange={(value) => handleSelectChange("creditPlatform", value)}
                    >
                      <SelectTrigger className="bg-white">
                        <SelectValue placeholder="Sélectionner une plateforme" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="non_specifie">Non spécifié</SelectItem>
                        <SelectItem value="Experian">Experian</SelectItem>
                        <SelectItem value="Equifax">Equifax</SelectItem>
                        <SelectItem value="TransUnion">TransUnion</SelectItem>
                        <SelectItem value="Clearscore">Clearscore</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="loanAmount">Montant du prêt (£)</Label>
                    <Input
                      id="loanAmount"
                      name="loanAmount"
                      type="number"
                      value={formData.loanAmount}
                      onChange={handleChange}
                    />
                  </div>

                  <div>
                    <Label>Simulation validée</Label>
                    <RadioGroup
                      value={formData.simulationValidated}
                      onValueChange={(value) => handleRadioChange("simulationValidated", value)}
                      className="flex space-x-4 mt-2"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="Oui" id="simulation-oui" />
                        <Label htmlFor="simulation-oui">Oui</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="Non" id="simulation-non" />
                        <Label htmlFor="simulation-non">Non</Label>
                      </div>
                    </RadioGroup>
                  </div>

                  <div>
                    <Label htmlFor="platform">Plateforme de prêt</Label>
                    <Select value={formData.platform} onValueChange={(value) => handleSelectChange("platform", value)}>
                      <SelectTrigger className="bg-white">
                        <SelectValue placeholder="Sélectionner une plateforme" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="non_specifie">Non spécifié</SelectItem>
                        <SelectItem value="Zopa">Zopa</SelectItem>
                        <SelectItem value="Novuna Personal Finance">Novuna Personal Finance</SelectItem>
                        <SelectItem value="GetABound">GetABound</SelectItem>
                        <SelectItem value="Lendable">Lendable</SelectItem>
                        <SelectItem value="Bamboo Loans">Bamboo Loans</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Prêt demandé</Label>
                    <RadioGroup
                      value={formData.loanRequested}
                      onValueChange={(value) => handleRadioChange("loanRequested", value)}
                      className="flex space-x-4 mt-2"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="Oui" id="loan-oui" />
                        <Label htmlFor="loan-oui">Oui</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="Non" id="loan-non" />
                        <Label htmlFor="loan-non">Non</Label>
                      </div>
                    </RadioGroup>
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="factureEnvoye">Facture envoyée</Label>
                    <Switch
                      id="factureEnvoye"
                      checked={formData.factureEnvoye}
                      onCheckedChange={(checked) => handleSwitchChange("factureEnvoye", checked)}
                    />
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="suivi">
              <AccordionTrigger className="text-lg font-semibold">Statut et suivi</AccordionTrigger>
              <AccordionContent>
                <div className="space-y-3">
                  <div>
                    <Label htmlFor="status">Statut *</Label>
                    <Select
                      value={formData.status}
                      onValueChange={(value) => handleSelectChange("status", value)}
                      required
                    >
                      <SelectTrigger className="bg-white">
                        <SelectValue placeholder="Sélectionner un statut" />
                      </SelectTrigger>
                      <SelectContent>
                        {PATIENT_STATUSES.map((status) => (
                          <SelectItem key={status.value} value={status.value}>
                            {status.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Sélection du closer */}
                  <div>
                    <Label htmlFor="closer">Commercial assigné</Label>
                    <Select
                      value={formData.closer || "non_assigne"}
                      onValueChange={(value) => handleSelectChange("closer", value)}
                      disabled={loadingClosers}
                    >
                      <SelectTrigger className="bg-white">
                        <SelectValue placeholder={loadingClosers ? "Chargement..." : "Sélectionner un commercial"} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="non_assigne">Non assigné</SelectItem>
                        {closers.map((closer) => {
                          // Garantir que la valeur n'est jamais vide
                          const safeValue = closer.name?.trim() ? closer.name.trim() : `closer-${closer.id}`
                          return (
                            <SelectItem key={closer.id} value={safeValue}>
                              {closer.name?.trim() || `Closer ${closer.id}`}
                            </SelectItem>
                          )
                        })}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="nextFollowUp">Prochain suivi</Label>
                    <Input
                      id="nextFollowUp"
                      name="nextFollowUp"
                      type="date"
                      value={formData.nextFollowUp}
                      onChange={handleChange}
                    />
                  </div>

                  <div>
                    <Label htmlFor="comments">Commentaires</Label>
                    <Textarea
                      id="comments"
                      name="comments"
                      value={formData.comments}
                      onChange={handleChange}
                      rows={3}
                    />
                  </div>

                  <div>
                    <Label htmlFor="notes">Notes</Label>
                    <Textarea id="notes" name="notes" value={formData.notes} onChange={handleChange} rows={3} />
                  </div>

                  <div>
                    <Label htmlFor="premierEmail">Premier email</Label>
                    <Input
                      id="premierEmail"
                      name="premierEmail"
                      type="datetime-local"
                      value={formData.premierEmail}
                      onChange={handleChange}
                    />
                  </div>

                  <div>
                    <Label htmlFor="premierWhatsapp">Premier WhatsApp</Label>
                    <Input
                      id="premierWhatsapp"
                      name="premierWhatsapp"
                      type="datetime-local"
                      value={formData.premierWhatsapp}
                      onChange={handleChange}
                    />
                  </div>

                  <div>
                    <Label htmlFor="secondEmail">Second email</Label>
                    <Input
                      id="secondEmail"
                      name="secondEmail"
                      type="datetime-local"
                      value={formData.secondEmail}
                      onChange={handleChange}
                    />
                  </div>

                  <div>
                    <Label htmlFor="secondWhatsapp">Second WhatsApp</Label>
                    <Input
                      id="secondWhatsapp"
                      name="secondWhatsapp"
                      type="datetime-local"
                      value={formData.secondWhatsapp}
                      onChange={handleChange}
                    />
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="medical">
              <AccordionTrigger className="text-lg font-semibold">Informations médicales</AccordionTrigger>
              <AccordionContent>
                <div className="space-y-3">
                  <div>
                    <Label htmlFor="poids">Poids (kg)</Label>
                    <Input
                      id="poids"
                      name="poids"
                      type="number"
                      step="0.1"
                      value={formData.poids}
                      onChange={handleChange}
                    />
                  </div>

                  <div>
                    <Label htmlFor="taille">Taille (cm)</Label>
                    <Input
                      id="taille"
                      name="taille"
                      type="number"
                      step="0.1"
                      value={formData.taille}
                      onChange={handleChange}
                    />
                  </div>

                  <div>
                    <Label htmlFor="bmi">IMC</Label>
                    <Input
                      id="bmi"
                      name="bmi"
                      type="number"
                      step="0.1"
                      value={formData.bmi}
                      onChange={handleChange}
                      readOnly
                    />
                  </div>

                  <div>
                    <Label htmlFor="chirurgie">Type de chirurgie</Label>
                    <Select
                      value={formData.chirurgie}
                      onValueChange={(value) => handleSelectChange("chirurgie", value)}
                    >
                      <SelectTrigger className="bg-white">
                        <SelectValue placeholder="Sélectionner un type de chirurgie" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="non_specifie">Non spécifié</SelectItem>
                        {CHIRURGIE_OPTIONS.map((option) => (
                          <SelectItem key={option} value={option}>
                            {option}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="compteRenduConsultation">Compte rendu de consultation</Label>
                    <Switch
                      id="compteRenduConsultation"
                      checked={formData.compteRenduConsultation === true}
                      onCheckedChange={(checked) => handleSwitchChange("compteRenduConsultation", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="compteRenduHospitalisation">Compte rendu d'hospitalisation</Label>
                    <Switch
                      id="compteRenduHospitalisation"
                      checked={formData.compteRenduHospitalisation === true}
                      onCheckedChange={(checked) => handleSwitchChange("compteRenduHospitalisation", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="medicalAgrement">Agrément médical</Label>
                    <Switch
                      id="medicalAgrement"
                      checked={formData.medicalAgrement}
                      onCheckedChange={(checked) => handleSwitchChange("medicalAgrement", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="consentForm">Formulaire de consentement</Label>
                    <Switch
                      id="consentForm"
                      checked={formData.consentForm}
                      onCheckedChange={(checked) => handleSwitchChange("consentForm", checked)}
                    />
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="documents">
              <AccordionTrigger className="text-lg font-semibold">Documents</AccordionTrigger>
              <AccordionContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="emailPatientGp">Email patient GP</Label>
                    <Switch
                      id="emailPatientGp"
                      checked={formData.emailPatientGp === true}
                      onCheckedChange={(checked) => handleSwitchChange("emailPatientGp", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="patientS2Form">Formulaire S2 patient</Label>
                    <Switch
                      id="patientS2Form"
                      checked={formData.patientS2Form === true}
                      onCheckedChange={(checked) => handleSwitchChange("patientS2Form", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="lettreGp">Lettre GP</Label>
                    <Switch
                      id="lettreGp"
                      checked={formData.lettreGp === true}
                      onCheckedChange={(checked) => handleSwitchChange("lettreGp", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="s2SaintJames">S2 Saint James</Label>
                    <Switch
                      id="s2SaintJames"
                      checked={formData.s2SaintJames === true}
                      onCheckedChange={(checked) => handleSwitchChange("s2SaintJames", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="autorisationPatientS2">Autorisation patient S2</Label>
                    <Switch
                      id="autorisationPatientS2"
                      checked={formData.autorisationPatientS2}
                      onCheckedChange={(checked) => handleSwitchChange("autorisationPatientS2", checked)}
                    />
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="nhs">
              <AccordionTrigger className="text-lg font-semibold">NHS Tier 4</AccordionTrigger>
              <AccordionContent>
                <div className="space-y-3">
                  <div>
                    <Label htmlFor="nhsTier4PremierEmail">Premier email NHS Tier 4</Label>
                    <Input
                      id="nhsTier4PremierEmail"
                      name="nhsTier4PremierEmail"
                      type="datetime-local"
                      value={formData.nhsTier4PremierEmail}
                      onChange={handleChange}
                    />
                  </div>

                  <div>
                    <Label htmlFor="nhsTier4SecondEmail">Second email NHS Tier 4</Label>
                    <Input
                      id="nhsTier4SecondEmail"
                      name="nhsTier4SecondEmail"
                      type="datetime-local"
                      value={formData.nhsTier4SecondEmail}
                      onChange={handleChange}
                    />
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>

        {/* Boutons fixes en bas de l'écran */}
        <div className="fixed bottom-0 left-0 right-0 bg-background border-t p-4 flex justify-end space-x-2 z-10">
          <Button type="button" variant="outline" onClick={() => router.push("/patients")}>
            Annuler
          </Button>

          {isAdmin && (
            <Button type="button" onClick={(e) => handleSubmit(e, true)} disabled={loading} variant="secondary">
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Validation...
                </>
              ) : (
                "Valider"
              )}
            </Button>
          )}

          <Button type="submit" disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Enregistrement...
              </>
            ) : (
              "Enregistrer"
            )}
          </Button>
        </div>
      </form>
    )
  }

  // Rendu pour desktop avec tabs
  return (
    <form onSubmit={(e) => handleSubmit(e, false)} className="space-y-8">
      <Tabs defaultValue="informations" className="w-full">
        <TabsList className="w-full">
          <TabsTrigger value="informations">Informations personnelles</TabsTrigger>
          <TabsTrigger value="financier">Financier</TabsTrigger>
          <TabsTrigger value="suivi">Suivi</TabsTrigger>
          <TabsTrigger value="medical">Médical</TabsTrigger>
          <TabsTrigger value="documents">Documents</TabsTrigger>
          <TabsTrigger value="nhs">NHS</TabsTrigger>
        </TabsList>

        <TabsContent value="informations" className="space-y-4 mt-4">
          <Card>
            <CardContent className="pt-6">
              <h2 className="text-xl font-semibold mb-6">Informations personnelles</h2>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="name">Nom complet *</Label>
                  <Input id="name" name="name" value={formData.name} onChange={handleChange} required />
                </div>

                <div>
                  <Label htmlFor="email">Email *</Label>
                  <Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} required />
                </div>

                <div>
                  <Label htmlFor="phone">Téléphone</Label>
                  <div className="flex items-center space-x-2">
                    <div className="relative flex-1">
                      <Input
                        id="phone"
                        name="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={handleChange}
                        className={phoneError ? "border-red-500 pr-10" : "pr-10"}
                        placeholder="+33612345678"
                      />
                    </div>
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      onClick={copyPhoneToClipboard}
                      disabled={!formData.phone}
                      className="flex-shrink-0"
                    >
                      <Copy className="h-4 w-4" />
                      <span className="sr-only">Copier le numéro</span>
                    </Button>
                  </div>
                  {phoneError && <p className="text-sm text-red-500 mt-1">{phoneError}</p>}
                </div>

                <div>
                  <Label htmlFor="doctor">Médecin *</Label>
                  <Select
                    value={formData.doctor || "non_specifie"}
                    onValueChange={(value) => handleSelectChange("doctor", value)}
                  >
                    <SelectTrigger className="bg-white">
                      <SelectValue placeholder="Sélectionner un médecin" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Noel">Noel</SelectItem>
                      <SelectItem value="Nedelcu">Nedelcu</SelectItem>
                      <SelectItem value="Coste">Coste</SelectItem>
                      <SelectItem value="Manos">Manos</SelectItem>
                      <SelectItem value="non_specifie">Non spécifié</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="registrationDate">Date d'enregistrement *</Label>
                  <Input
                    id="registrationDate"
                    name="registrationDate"
                    type="date"
                    value={formData.registrationDate}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="consultationDate">Date de consultation</Label>
                  <Input
                    id="consultationDate"
                    name="consultationDate"
                    type="date"
                    value={formData.consultationDate}
                    onChange={handleChange}
                  />
                </div>

                <div>
                  <Label htmlFor="suiteGroupe">Suite/Groupe</Label>
                  <Select
                    value={formData.suiteGroupe}
                    onValueChange={(value) => handleSelectChange("suiteGroupe", value)}
                  >
                    <SelectTrigger className="bg-white">
                      <SelectValue placeholder="Sélectionner une option" />
                    </SelectTrigger>
                    <SelectContent>
                      {SUITE_GROUPE_OPTIONS.map((option) => (
                        <SelectItem key={option} value={option}>
                          {option}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="qualification">Qualification</Label>
                  <Select
                    value={formData.qualification}
                    onValueChange={(value) => handleSelectChange("qualification", value)}
                  >
                    <SelectTrigger className="bg-white">
                      <SelectValue placeholder="Sélectionner une qualification" />
                    </SelectTrigger>
                    <SelectContent>
                      {QUALIFICATION_OPTIONS.map((option) => (
                        <SelectItem key={option} value={option}>
                          {option}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="rdvObtenuPar">RDV obtenu par</Label>
                  <Select
                    value={formData.rdvObtenuPar}
                    onValueChange={(value) => handleSelectChange("rdvObtenuPar", value)}
                  >
                    <SelectTrigger className="bg-white">
                      <SelectValue placeholder="Sélectionner une personne" />
                    </SelectTrigger>
                    <SelectContent>
                      {RDV_OBTENU_PAR_OPTIONS.map((option) => (
                        <SelectItem key={option} value={option}>
                          {option}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="financier" className="space-y-4 mt-4">
          <Card>
            <CardContent className="pt-6">
              <h2 className="text-xl font-semibold mb-6">Informations financières</h2>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="income">Revenus (£)</Label>
                  <Input id="income" name="income" type="number" value={formData.income} onChange={handleChange} />
                </div>

                <div>
                  <Label htmlFor="expenses">Dépenses (£)</Label>
                  <Input
                    id="expenses"
                    name="expenses"
                    type="number"
                    value={formData.expenses}
                    onChange={handleChange}
                  />
                </div>

                <div>
                  <Label htmlFor="creditScore">Score de crédit</Label>
                  <Input id="creditScore" name="creditScore" value={formData.creditScore} onChange={handleChange} />
                </div>

                <div>
                  <Label htmlFor="creditPlatform">Plateforme de credit score</Label>
                  <Select
                    value={formData.creditPlatform}
                    onValueChange={(value) => handleSelectChange("creditPlatform", value)}
                  >
                    <SelectTrigger className="bg-white">
                      <SelectValue placeholder="Sélectionner une plateforme" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="non_specifie">Non spécifié</SelectItem>
                      <SelectItem value="Experian">Experian</SelectItem>
                      <SelectItem value="Equifax">Equifax</SelectItem>
                      <SelectItem value="TransUnion">TransUnion</SelectItem>
                      <SelectItem value="Clearscore">Clearscore</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="loanAmount">Montant du prêt (£)</Label>
                  <Input
                    id="loanAmount"
                    name="loanAmount"
                    type="number"
                    value={formData.loanAmount}
                    onChange={handleChange}
                  />
                </div>

                <div>
                  <Label>Simulation validée</Label>
                  <RadioGroup
                    value={formData.simulationValidated}
                    onValueChange={(value) => handleRadioChange("simulationValidated", value)}
                    className="flex space-x-4 mt-2"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="Oui" id="simulation-oui" />
                      <Label htmlFor="simulation-oui">Oui</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="Non" id="simulation-non" />
                      <Label htmlFor="simulation-non">Non</Label>
                    </div>
                  </RadioGroup>
                </div>

                <div>
                  <Label htmlFor="platform">Plateforme de prêt</Label>
                  <Select value={formData.platform} onValueChange={(value) => handleSelectChange("platform", value)}>
                    <SelectTrigger className="bg-white">
                      <SelectValue placeholder="Sélectionner une plateforme" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="non_specifie">Non spécifié</SelectItem>
                      <SelectItem value="Zopa">Zopa</SelectItem>
                      <SelectItem value="Novuna Personal Finance">Novuna Personal Finance</SelectItem>
                      <SelectItem value="GetABound">GetABound</SelectItem>
                      <SelectItem value="Lendable">Lendable</SelectItem>
                      <SelectItem value="Bamboo Loans">Bamboo Loans</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Prêt demandé</Label>
                  <RadioGroup
                    value={formData.loanRequested}
                    onValueChange={(value) => handleRadioChange("loanRequested", value)}
                    className="flex space-x-4 mt-2"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="Oui" id="loan-oui" />
                      <Label htmlFor="loan-oui">Oui</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="Non" id="loan-non" />
                      <Label htmlFor="loan-non">Non</Label>
                    </div>
                  </RadioGroup>
                </div>

                <div className="flex items-center space-x-2">
                  <Label htmlFor="factureEnvoye" className="flex-1">
                    Facture envoyée
                  </Label>
                  <Switch
                    id="factureEnvoye"
                    checked={formData.factureEnvoye}
                    onCheckedChange={(checked) => handleSwitchChange("factureEnvoye", checked)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="suivi" className="space-y-4 mt-4">
          <Card>
            <CardContent className="pt-6">
              <h2 className="text-xl font-semibold mb-6">Statut et suivi</h2>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="status">Statut *</Label>
                  <Select
                    value={formData.status}
                    onValueChange={(value) => handleSelectChange("status", value)}
                    required
                  >
                    <SelectTrigger className="bg-white">
                      <SelectValue placeholder="Sélectionner un statut" />
                    </SelectTrigger>
                    <SelectContent>
                      {PATIENT_STATUSES.map((status) => (
                        <SelectItem key={status.value} value={status.value}>
                          {status.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Sélection du closer */}
                <div>
                  <Label htmlFor="closer">Commercial assigné</Label>
                  <Select
                    value={formData.closer || "non_assigne"}
                    onValueChange={(value) => handleSelectChange("closer", value)}
                    disabled={loadingClosers}
                  >
                    <SelectTrigger className="bg-white">
                      <SelectValue placeholder={loadingClosers ? "Chargement..." : "Sélectionner un commercial"} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="non_assigne">Non assigné</SelectItem>
                      {closers.map((closer) => {
                        // Garantir que la valeur n'est jamais vide
                        const safeValue = closer.name?.trim() ? closer.name.trim() : `closer-${closer.id}`
                        return (
                          <SelectItem key={closer.id} value={safeValue}>
                            {closer.name?.trim() || `Closer ${closer.id}`}
                          </SelectItem>
                        )
                      })}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="nextFollowUp">Prochain suivi</Label>
                  <Input
                    id="nextFollowUp"
                    name="nextFollowUp"
                    type="date"
                    value={formData.nextFollowUp}
                    onChange={handleChange}
                  />
                </div>

                <div>
                  <Label htmlFor="comments">Commentaires</Label>
                  <Textarea id="comments" name="comments" value={formData.comments} onChange={handleChange} rows={3} />
                </div>

                <div>
                  <Label htmlFor="notes">Notes</Label>
                  <Textarea id="notes" name="notes" value={formData.notes} onChange={handleChange} rows={3} />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="premierEmail">Premier email</Label>
                    <Input
                      id="premierEmail"
                      name="premierEmail"
                      type="datetime-local"
                      value={formData.premierEmail}
                      onChange={handleChange}
                    />
                  </div>

                  <div>
                    <Label htmlFor="premierWhatsapp">Premier WhatsApp</Label>
                    <Input
                      id="premierWhatsapp"
                      name="premierWhatsapp"
                      type="datetime-local"
                      value={formData.premierWhatsapp}
                      onChange={handleChange}
                    />
                  </div>

                  <div>
                    <Label htmlFor="secondEmail">Second email</Label>
                    <Input
                      id="secondEmail"
                      name="secondEmail"
                      type="datetime-local"
                      value={formData.secondEmail}
                      onChange={handleChange}
                    />
                  </div>

                  <div>
                    <Label htmlFor="secondWhatsapp">Second WhatsApp</Label>
                    <Input
                      id="secondWhatsapp"
                      name="secondWhatsapp"
                      type="datetime-local"
                      value={formData.secondWhatsapp}
                      onChange={handleChange}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="medical" className="space-y-4 mt-4">
          <Card>
            <CardContent className="pt-6">
              <h2 className="text-xl font-semibold mb-6">Informations médicales</h2>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="poids">Poids (kg)</Label>
                    <Input
                      id="poids"
                      name="poids"
                      type="number"
                      step="0.1"
                      value={formData.poids}
                      onChange={handleChange}
                    />
                  </div>

                  <div>
                    <Label htmlFor="taille">Taille (cm)</Label>
                    <Input
                      id="taille"
                      name="taille"
                      type="number"
                      step="0.1"
                      value={formData.taille}
                      onChange={handleChange}
                    />
                  </div>

                  <div>
                    <Label htmlFor="bmi">IMC</Label>
                    <Input
                      id="bmi"
                      name="bmi"
                      type="number"
                      step="0.1"
                      value={formData.bmi}
                      onChange={handleChange}
                      readOnly
                    />
                  </div>

                  <div>
                    <Label htmlFor="chirurgie">Type de chirurgie</Label>
                    <Select
                      value={formData.chirurgie}
                      onValueChange={(value) => handleSelectChange("chirurgie", value)}
                    >
                      <SelectTrigger className="bg-white">
                        <SelectValue placeholder="Sélectionner un type de chirurgie" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="non_specifie">Non spécifié</SelectItem>
                        {CHIRURGIE_OPTIONS.map((option) => (
                          <SelectItem key={option} value={option}>
                            {option}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center space-x-2">
                    <Label htmlFor="compteRenduConsultation" className="flex-1">
                      Compte rendu de consultation
                    </Label>
                    <Switch
                      id="compteRenduConsultation"
                      checked={formData.compteRenduConsultation === true}
                      onCheckedChange={(checked) => handleSwitchChange("compteRenduConsultation", checked)}
                    />
                  </div>

                  <div className="flex items-center space-x-2">
                    <Label htmlFor="compteRenduHospitalisation" className="flex-1">
                      Compte rendu d'hospitalisation
                    </Label>
                    <Switch
                      id="compteRenduHospitalisation"
                      checked={formData.compteRenduHospitalisation === true}
                      onCheckedChange={(checked) => handleSwitchChange("compteRenduHospitalisation", checked)}
                    />
                  </div>

                  <div className="flex items-center space-x-2">
                    <Label htmlFor="medicalAgrement" className="flex-1">
                      Agrément médical
                    </Label>
                    <Switch
                      id="medicalAgrement"
                      checked={formData.medicalAgrement}
                      onCheckedChange={(checked) => handleSwitchChange("medicalAgrement", checked)}
                    />
                  </div>

                  <div className="flex items-center space-x-2">
                    <Label htmlFor="consentForm" className="flex-1">
                      Formulaire de consentement
                    </Label>
                    <Switch
                      id="consentForm"
                      checked={formData.consentForm}
                      onCheckedChange={(checked) => handleSwitchChange("consentForm", checked)}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="documents" className="space-y-4 mt-4">
          <Card>
            <CardContent className="pt-6">
              <h2 className="text-xl font-semibold mb-6">Documents</h2>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center space-x-2">
                    <Label htmlFor="emailPatientGp" className="flex-1">
                      Email patient GP
                    </Label>
                    <Switch
                      id="emailPatientGp"
                      checked={formData.emailPatientGp === true}
                      onCheckedChange={(checked) => handleSwitchChange("emailPatientGp", checked)}
                    />
                  </div>

                  <div className="flex items-center space-x-2">
                    <Label htmlFor="patientS2Form" className="flex-1">
                      Formulaire S2 patient
                    </Label>
                    <Switch
                      id="patientS2Form"
                      checked={formData.patientS2Form === true}
                      onCheckedChange={(checked) => handleSwitchChange("patientS2Form", checked)}
                    />
                  </div>

                  <div className="flex items-center space-x-2">
                    <Label htmlFor="lettreGp" className="flex-1">
                      Lettre GP
                    </Label>
                    <Switch
                      id="lettreGp"
                      checked={formData.lettreGp === true}
                      onCheckedChange={(checked) => handleSwitchChange("lettreGp", checked)}
                    />
                  </div>

                  <div className="flex items-center space-x-2">
                    <Label htmlFor="s2SaintJames" className="flex-1">
                      S2 Saint James
                    </Label>
                    <Switch
                      id="s2SaintJames"
                      checked={formData.s2SaintJames === true}
                      onCheckedChange={(checked) => handleSwitchChange("s2SaintJames", checked)}
                    />
                  </div>

                  <div className="flex items-center space-x-2">
                    <Label htmlFor="autorisationPatientS2" className="flex-1">
                      Autorisation patient S2
                    </Label>
                    <Switch
                      id="autorisationPatientS2"
                      checked={formData.autorisationPatientS2 === true}
                      onCheckedChange={(checked) => handleSwitchChange("autorisationPatientS2", checked)}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="nhs" className="space-y-4 mt-4">
          <Card>
            <CardContent className="pt-6">
              <h2 className="text-xl font-semibold mb-6">NHS Tier 4</h2>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="nhsTier4PremierEmail">Premier email NHS Tier 4</Label>
                  <Input
                    id="nhsTier4PremierEmail"
                    name="nhsTier4PremierEmail"
                    type="datetime-local"
                    value={formData.nhsTier4PremierEmail}
                    onChange={handleChange}
                  />
                </div>

                <div>
                  <Label htmlFor="nhsTier4SecondEmail">Second email NHS Tier 4</Label>
                  <Input
                    id="nhsTier4SecondEmail"
                    name="nhsTier4SecondEmail"
                    type="datetime-local"
                    value={formData.nhsTier4SecondEmail}
                    onChange={handleChange}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex justify-end space-x-4">
        <Button type="button" variant="outline" onClick={() => router.push("/patients")}>
          Annuler
        </Button>

        {isAdmin && (
          <Button type="button" onClick={(e) => handleSubmit(e, true)} disabled={loading} variant="secondary">
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Validation...
              </>
            ) : (
              "Enregistrer et Valider"
            )}
          </Button>
        )}

        <Button type="submit" disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Enregistrement...
            </>
          ) : (
            "Enregistrer le patient"
          )}
        </Button>
      </div>
    </form>
  )
}

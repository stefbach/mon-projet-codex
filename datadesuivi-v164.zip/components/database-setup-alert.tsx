import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Database } from "lucide-react"
import Link from "next/link"

export function DatabaseSetupAlert() {
  return (
    <Alert className="bg-amber-50 border-amber-200 mb-4">
      <Database className="h-4 w-4 text-amber-600" />
      <AlertTitle className="text-amber-800">Configuration de la base de données</AlertTitle>
      <AlertDescription className="text-amber-700">
        <p className="mb-2">
          Pour utiliser l'application avec des données réelles, vous devez configurer la base de données Supabase.
        </p>
        <p className="mb-2">
          Les informations de connexion Supabase sont maintenant intégrées directement dans l'application.
        </p>
        <p>
          <Link href="/test/supabase-connection" className="text-amber-800 underline font-medium">
            Tester la connexion à Supabase
          </Link>
        </p>
      </AlertDescription>
    </Alert>
  )
}

"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Calendar, Loader2, Phone } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { toast } from "@/components/ui/use-toast"
import { logPatientCall } from "@/lib/patient-service"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { PATIENT_STATUSES, isValidStatus } from "@/lib/constants"

interface QuickCallLogProps {
  patientId: string
  onCallLogged?: () => void
}

export function QuickCallLog({ patientId, onCallLogged }: QuickCallLogProps) {
  const [notes, setNotes] = useState("")
  const [status, setStatus] = useState<string | undefined>(undefined)
  const [loading, setLoading] = useState(false)
  const [validationError, setValidationError] = useState<string | null>(null)

  // Obtenir la date actuelle au format YYYY-MM-DD
  const today = new Date().toISOString().split("T")[0]

  const validateForm = (): boolean => {
    // Si un statut est sélectionné, vérifier qu'il est valide
    if (status && !isValidStatus(status)) {
      setValidationError("Statut non autorisé. Veuillez sélectionner un statut valide.")
      return false
    }

    setValidationError(null)
    return true
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    // Valider le formulaire avant soumission
    if (!validateForm()) {
      toast({
        variant: "destructive",
        title: "Erreur de validation",
        description: validationError || "Veuillez corriger les erreurs dans le formulaire",
      })
      return
    }

    setLoading(true)

    try {
      const result = await logPatientCall(patientId, {
        date: today,
        notes: notes.trim(),
        status: status,
      })

      if (result.success) {
        toast({
          title: "Appel enregistré",
          description: "L'appel a été enregistré avec succès.",
        })
        setNotes("")
        setStatus(undefined)
        if (onCallLogged) {
          onCallLogged()
        }
      } else {
        toast({
          variant: "destructive",
          title: "Erreur",
          description: result.message || "Une erreur s'est produite lors de l'enregistrement de l'appel",
        })
      }
    } catch (error) {
      console.error("Erreur lors de l'enregistrement:", error)
      toast({
        variant: "destructive",
        title: "Erreur",
        description: "Une erreur s'est produite lors de l'enregistrement de l'appel",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleStatusChange = (value: string) => {
    setStatus(value)
    setValidationError(null) // Effacer l'erreur de validation
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg flex items-center">
          <Phone className="h-4 w-4 mr-2" />
          Enregistrer un appel
        </CardTitle>
        <CardDescription>Ajoutez rapidement un appel pour ce patient</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex items-center gap-2">
            <Calendar className="h-4 w-4 text-gray-500" />
            <span className="text-sm text-gray-500">Date: {new Date().toLocaleDateString()}</span>
          </div>

          <div>
            <Select value={status} onValueChange={handleStatusChange}>
              <SelectTrigger className={validationError ? "border-red-500" : ""}>
                <SelectValue placeholder="Choisir un statut (optionnel)" />
              </SelectTrigger>
              <SelectContent>
                {PATIENT_STATUSES.map((s) => (
                  <SelectItem key={s.value} value={s.value}>
                    {s.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {validationError && <p className="text-sm text-red-500 mt-1">{validationError}</p>}
          </div>

          <Textarea
            placeholder="Notes de l'appel..."
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={3}
          />

          <Button type="submit" disabled={loading} className="w-full">
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Enregistrement...
              </>
            ) : (
              "Enregistrer l'appel"
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}

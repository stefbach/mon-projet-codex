"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { toast } from "@/components/ui/use-toast"
import { Loader2, Eye, EyeOff } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"

interface ResetPasswordDialogProps {
  isOpen: boolean
  onClose: () => void
  userEmail: string
  userName: string
}

export function ResetPasswordDialog({ isOpen, onClose, userEmail, userName }: ResetPasswordDialogProps) {
  const [loading, setLoading] = useState(false)
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [error, setError] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [passwordStrength, setPasswordStrength] = useState(0)

  // Fonction pour évaluer la force du mot de passe
  const evaluatePasswordStrength = (pass: string) => {
    let strength = 0

    if (pass.length >= 8) strength += 1
    if (/[A-Z]/.test(pass)) strength += 1
    if (/[a-z]/.test(pass)) strength += 1
    if (/[0-9]/.test(pass)) strength += 1
    if (/[^A-Za-z0-9]/.test(pass)) strength += 1

    setPasswordStrength(strength)
    return strength
  }

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newPassword = e.target.value
    setPassword(newPassword)
    evaluatePasswordStrength(newPassword)
  }

  const handleResetPassword = () => {
    // Validation
    if (!password) {
      setError("Le mot de passe est requis")
      return
    }

    if (password.length < 8) {
      setError("Le mot de passe doit contenir au moins 8 caractères")
      return
    }

    if (evaluatePasswordStrength(password) < 3) {
      setError("Le mot de passe est trop faible. Ajoutez des majuscules, minuscules, chiffres ou caractères spéciaux.")
      return
    }

    if (password !== confirmPassword) {
      setError("Les mots de passe ne correspondent pas")
      return
    }

    setError("")
    setLoading(true)

    // Simuler un délai d'API
    setTimeout(() => {
      // Ici, vous implémenteriez la logique réelle de réinitialisation du mot de passe

      toast({
        title: "Mot de passe réinitialisé",
        description: `Le mot de passe de ${userName} a été réinitialisé avec succès.`,
      })

      // Réinitialiser le formulaire et fermer la boîte de dialogue
      setPassword("")
      setConfirmPassword("")
      onClose()
      setLoading(false)
    }, 1000)
  }

  // Fonction pour obtenir la couleur de la barre de force du mot de passe
  const getStrengthColor = () => {
    if (passwordStrength <= 1) return "bg-red-500"
    if (passwordStrength <= 3) return "bg-yellow-500"
    return "bg-green-500"
  }

  // Fonction pour obtenir le texte de force du mot de passe
  const getStrengthText = () => {
    if (passwordStrength <= 1) return "Très faible"
    if (passwordStrength <= 2) return "Faible"
    if (passwordStrength <= 3) return "Moyen"
    if (passwordStrength <= 4) return "Fort"
    return "Très fort"
  }

  return (
    <Dialog
      open={isOpen}
      onOpenChange={(open) => {
        if (!open) {
          setPassword("")
          setConfirmPassword("")
          setError("")
          onClose()
        }
      }}
    >
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Réinitialiser le mot de passe</DialogTitle>
          <DialogDescription>
            Définissez un nouveau mot de passe pour {userName} ({userEmail})
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="new-password">Nouveau mot de passe</Label>
            <div className="relative">
              <Input
                id="new-password"
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={handlePasswordChange}
                placeholder="Nouveau mot de passe"
              />
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="absolute right-0 top-0 h-full px-3"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? (
                  <EyeOff className="h-4 w-4 text-gray-400" />
                ) : (
                  <Eye className="h-4 w-4 text-gray-400" />
                )}
              </Button>
            </div>

            {password && (
              <div className="mt-2">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs">Force du mot de passe:</span>
                  <span className="text-xs font-medium">{getStrengthText()}</span>
                </div>
                <div className="h-1 w-full bg-gray-200 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${getStrengthColor()}`}
                    style={{ width: `${(passwordStrength / 5) * 100}%` }}
                  ></div>
                </div>
                <ul className="text-xs text-gray-500 mt-2 space-y-1">
                  <li className={password.length >= 8 ? "text-green-600" : ""}>• Au moins 8 caractères</li>
                  <li className={/[A-Z]/.test(password) ? "text-green-600" : ""}>• Au moins une lettre majuscule</li>
                  <li className={/[a-z]/.test(password) ? "text-green-600" : ""}>• Au moins une lettre minuscule</li>
                  <li className={/[0-9]/.test(password) ? "text-green-600" : ""}>• Au moins un chiffre</li>
                  <li className={/[^A-Za-z0-9]/.test(password) ? "text-green-600" : ""}>
                    • Au moins un caractère spécial
                  </li>
                </ul>
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="confirm-password">Confirmer le mot de passe</Label>
            <div className="relative">
              <Input
                id="confirm-password"
                type={showConfirmPassword ? "text" : "password"}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Confirmer le mot de passe"
              />
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="absolute right-0 top-0 h-full px-3"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
              >
                {showConfirmPassword ? (
                  <EyeOff className="h-4 w-4 text-gray-400" />
                ) : (
                  <Eye className="h-4 w-4 text-gray-400" />
                )}
              </Button>
            </div>
          </div>

          {error && <p className="text-red-500 text-sm">{error}</p>}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Annuler
          </Button>
          <Button onClick={handleResetPassword} disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Réinitialisation...
              </>
            ) : (
              "Réinitialiser le mot de passe"
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

"use client"

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export function EnvConfigAlert() {
  return (
    <Alert variant="destructive" className="mb-4 bg-secondary-50 border-secondary-200">
      <AlertCircle className="h-4 w-4 text-secondary-600" />
      <AlertTitle className="text-secondary-700">Configuration requise</AlertTitle>
      <AlertDescription className="text-secondary-600">
        <p>
          Pour utiliser l'application en mode fonctionnel, vous devez configurer les variables d'environnement Firebase
          et Google Sheets.
        </p>
        <div className="mt-4">
          <Link href="/docs/setup">
            <Button variant="secondary" size="sm">
              Voir le guide de configuration
            </Button>
          </Link>
        </div>
      </AlertDescription>
    </Alert>
  )
}

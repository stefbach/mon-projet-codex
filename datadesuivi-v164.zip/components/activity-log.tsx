"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Search, Clock } from "lucide-react"
import { format, parseISO } from "date-fns"
import { fr } from "date-fns/locale"

// Type pour les journaux d'activité
interface ActivityLogEntry {
  id: string
  userId: string
  userName: string
  action: string
  details: string
  timestamp: string
}

interface ActivityLogProps {
  activityLogs: ActivityLogEntry[]
}

export function ActivityLog({ activityLogs }: ActivityLogProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [filteredLogs, setFilteredLogs] = useState(activityLogs)

  // Filtrer les journaux en fonction du terme de recherche
  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const term = e.target.value
    setSearchTerm(term)

    if (!term.trim()) {
      setFilteredLogs(activityLogs)
      return
    }

    const filtered = activityLogs.filter(
      (log) =>
        log.userName.toLowerCase().includes(term.toLowerCase()) ||
        log.action.toLowerCase().includes(term.toLowerCase()) ||
        log.details.toLowerCase().includes(term.toLowerCase()),
    )

    setFilteredLogs(filtered)
  }

  // Formater la date
  const formatDate = (dateString: string) => {
    try {
      const date = parseISO(dateString)
      return format(date, "dd MMMM yyyy à HH:mm", { locale: fr })
    } catch (error) {
      return dateString
    }
  }

  // Obtenir la couleur du badge en fonction de l'action
  const getBadgeColor = (action: string) => {
    switch (action) {
      case "Création d'utilisateur":
        return "bg-green-100 text-green-800 border-green-200"
      case "Modification d'utilisateur":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "Suppression d'utilisateur":
        return "bg-red-100 text-red-800 border-red-200"
      case "Désactivation d'utilisateur":
        return "bg-amber-100 text-amber-800 border-amber-200"
      case "Activation d'utilisateur":
        return "bg-green-100 text-green-800 border-green-200"
      case "Réinitialisation de mot de passe":
        return "bg-purple-100 text-purple-800 border-purple-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Journal d'activité</CardTitle>
        <CardDescription>Historique des actions effectuées par les administrateurs</CardDescription>
        <div className="relative w-full mt-2">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            type="search"
            placeholder="Rechercher dans le journal..."
            className="pl-8"
            value={searchTerm}
            onChange={handleSearch}
          />
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {filteredLogs.length > 0 ? (
            filteredLogs.map((log) => (
              <div key={log.id} className="border-b pb-4 last:border-0">
                <div className="flex justify-between items-start">
                  <div>
                    <Badge variant="outline" className={getBadgeColor(log.action)}>
                      {log.action}
                    </Badge>
                    <p className="mt-1 text-sm font-medium">{log.details}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-gray-500 flex items-center justify-end">
                      <Clock className="h-3 w-3 mr-1" />
                      {formatDate(log.timestamp)}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">par {log.userName}</p>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-4 text-gray-500">Aucune activité trouvée</div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

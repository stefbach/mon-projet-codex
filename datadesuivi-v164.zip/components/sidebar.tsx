"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"
import { useI18n } from "@/lib/i18n"
import { LayoutDashboard, Users, UserCircle, LogOut, UserPlus, ChevronLeft, ChevronRight, Phone } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface SidebarProps {
  collapsed?: boolean
  onToggle?: () => void
}

export function Sidebar({ collapsed = false, onToggle }: SidebarProps) {
  const { t } = useI18n()
  const { user, logout } = useAuth()
  const pathname = usePathname()

  const isAdmin = user?.role === "admin"

  const handleLogout = async () => {
    try {
      console.log("Déconnexion en cours...")
      await logout()
    } catch (error) {
      console.error("Erreur lors de la déconnexion:", error)
    }
  }

  const navItems = [
    {
      href: "/dashboard",
      label: t("nav.dashboard"),
      icon: <LayoutDashboard className="h-5 w-5" />,
    },
    {
      href: "/patients",
      label: t("nav.patients"),
      icon: <Users className="h-5 w-5" />,
    },
    {
      href: "/calls",
      label: t("nav.calls"),
      icon: <Phone className="h-5 w-5" />,
    },
    {
      href: "/form",
      label: t("nav.newPatient"),
      icon: <UserPlus className="h-5 w-5" />,
    },
    {
      href: "/profile",
      label: t("nav.profile"),
      icon: <UserCircle className="h-5 w-5" />,
    },
  ]

  // Ajouter la gestion des comptes pour les admins
  if (isAdmin) {
    navItems.push({
      href: "/admin/users",
      label: t("nav.users") || "User Management",
      icon: <Users className="h-5 w-5" />,
    })
  }

  return (
    <div
      className={cn(
        "h-full bg-white border-r border-gray-200 flex flex-col transition-all duration-300 ease-in-out",
        collapsed ? "w-16" : "w-64",
      )}
    >
      <div className="flex items-center justify-between h-16 border-b border-gray-200 px-4">
        {!collapsed && <span className="text-xl font-bold text-primary-600 truncate">Obesity Care</span>}
        <Button variant="ghost" size="icon" onClick={onToggle} className={cn("ml-auto", collapsed ? "mx-auto" : "")}>
          {collapsed ? <ChevronRight className="h-5 w-5" /> : <ChevronLeft className="h-5 w-5" />}
        </Button>
      </div>

      <div className="flex flex-col justify-between flex-1 overflow-y-auto">
        <nav className={cn("px-2 pt-4", collapsed ? "space-y-2" : "space-y-1")}>
          <TooltipProvider>
            <ul className="space-y-1">
              {navItems.map((item) => (
                <li key={item.href}>
                  {collapsed ? (
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Link
                          href={item.href}
                          className={cn(
                            "flex items-center justify-center p-3 rounded-md",
                            pathname === item.href
                              ? "bg-primary-50 text-primary-700"
                              : "text-gray-600 hover:bg-gray-50 hover:text-gray-900",
                          )}
                        >
                          {item.icon}
                        </Link>
                      </TooltipTrigger>
                      <TooltipContent side="right">{item.label}</TooltipContent>
                    </Tooltip>
                  ) : (
                    <Link
                      href={item.href}
                      className={cn(
                        "flex items-center px-4 py-3 text-sm font-medium rounded-md",
                        pathname === item.href
                          ? "bg-primary-50 text-primary-700"
                          : "text-gray-600 hover:bg-gray-50 hover:text-gray-900",
                      )}
                    >
                      <span className="mr-3">{item.icon}</span>
                      {item.label}
                    </Link>
                  )}
                </li>
              ))}
              {isAdmin && (
                <li>
                  {collapsed ? (
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Link
                          href="/admin/users"
                          className={cn(
                            "flex items-center justify-center p-3 rounded-md",
                            pathname === "/admin/users"
                              ? "bg-primary-50 text-primary-700"
                              : "text-gray-600 hover:bg-gray-50 hover:text-gray-900",
                          )}
                        >
                          <Users className="h-5 w-5" />
                        </Link>
                      </TooltipTrigger>
                      <TooltipContent side="right">User Management</TooltipContent>
                    </Tooltip>
                  ) : (
                    <Link
                      href="/admin/users"
                      className={cn(
                        "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-all hover:text-gray-900",
                        pathname === "/admin/users"
                          ? "bg-primary-50 text-primary-700"
                          : "text-gray-600 hover:bg-gray-50",
                      )}
                    >
                      <Users className="h-4 w-4" />
                      <span>User Management</span>
                    </Link>
                  )}
                </li>
              )}
            </ul>
          </TooltipProvider>
        </nav>

        <div className={cn("p-4 mt-auto", collapsed ? "px-2" : "")}>
          <div className="border-t border-gray-200 pt-4">
            {!collapsed && (
              <div className="flex items-center mb-4">
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-900 truncate">{user?.name || user?.email}</p>
                  <p className="text-xs text-gray-500">{user?.role === "admin" ? t("role.admin") : t("role.closer")}</p>
                </div>
              </div>
            )}

            {collapsed ? (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="destructive" size="icon" onClick={handleLogout} className="w-full">
                    <LogOut className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent side="right">Déconnexion</TooltipContent>
              </Tooltip>
            ) : (
              <Button
                variant="destructive"
                onClick={handleLogout}
                className="w-full flex items-center justify-center gap-2"
              >
                <LogOut className="h-4 w-4" />
                Déconnexion
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

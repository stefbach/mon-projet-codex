"use client"

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"
import { useI18n } from "@/lib/i18n"

export function FirebaseConfigAlert() {
  const { t } = useI18n()

  return (
    <Alert variant="destructive" className="mb-4 bg-secondary-50 border-secondary-200">
      <AlertCircle className="h-4 w-4 text-secondary-600" />
      <AlertTitle className="text-secondary-700">{t("error.configMissing")}</AlertTitle>
      <AlertDescription className="text-secondary-600">
        <p>{t("error.configMissingDesc")}</p>
        <ul className="list-disc pl-5 mt-2 space-y-1">
          <li>NEXT_PUBLIC_FIREBASE_API_KEY</li>
          <li>NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN</li>
          <li>NEXT_PUBLIC_FIREBASE_PROJECT_ID</li>
          <li>NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET</li>
          <li>NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID</li>
          <li>NEXT_PUBLIC_FIREBASE_APP_ID</li>
        </ul>
        <p className="mt-2">
          Créez un fichier <code className="bg-secondary-100 px-1 py-0.5 rounded">.env.local</code> à la racine du
          projet avec ces variables.
        </p>
      </AlertDescription>
    </Alert>
  )
}

"use client"

import { useState, useEffect } from "react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { AlertTriangle, RefreshCw, Loader2 } from "lucide-react"
import { diagnoseAndRepairSchema } from "@/lib/schema-repair"
import { useRouter } from "next/navigation"

export function AutoSchemaRepair() {
  const [loading, setLoading] = useState(false)
  const [checking, setChecking] = useState(true)
  const [needsRepair, setNeedsRepair] = useState(false)
  const [repairResult, setRepairResult] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    checkSchema()
  }, [])

  async function checkSchema() {
    setChecking(true)
    try {
      // Vérifier uniquement si la relation fonctionne sans tenter de réparer
      const result = await diagnoseAndRepairSchema()
      setNeedsRepair(!result.success)
      setRepairResult(result)
    } catch (error) {
      console.error("Erreur lors de la vérification du schéma:", error)
      setNeedsRepair(true)
    } finally {
      setChecking(false)
    }
  }

  async function handleRepair() {
    setLoading(true)
    try {
      const result = await diagnoseAndRepairSchema()
      setRepairResult(result)
      setNeedsRepair(!result.success)

      if (result.success) {
        // Rafraîchir la page pour appliquer les changements
        router.refresh()
      }
    } catch (error) {
      console.error("Erreur lors de la réparation du schéma:", error)
    } finally {
      setLoading(false)
    }
  }

  if (checking) {
    return (
      <Alert variant="default" className="mb-4">
        <Loader2 className="h-4 w-4 animate-spin" />
        <AlertTitle>Vérification du schéma...</AlertTitle>
        <AlertDescription>
          Veuillez patienter pendant que nous vérifions l'intégrité du schéma de la base de données.
        </AlertDescription>
      </Alert>
    )
  }

  if (!needsRepair) {
    return null
  }

  return (
    <Alert variant="destructive" className="mb-4">
      <AlertTriangle className="h-4 w-4" />
      <AlertTitle>Problème de schéma détecté</AlertTitle>
      <AlertDescription className="flex flex-col space-y-2">
        <p>
          Un problème a été détecté avec les relations dans le schéma de la base de données. Cela peut affecter
          l'affichage des données et le fonctionnement de l'application.
        </p>

        {repairResult && repairResult.error && <p className="text-sm text-red-700">Erreur: {repairResult.error}</p>}

        <div className="flex justify-end mt-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleRepair}
            disabled={loading}
            className="bg-white hover:bg-gray-100"
          >
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Réparation en cours...
              </>
            ) : (
              <>
                <RefreshCw className="mr-2 h-4 w-4" />
                Réparer automatiquement
              </>
            )}
          </Button>
        </div>
      </AlertDescription>
    </Alert>
  )
}

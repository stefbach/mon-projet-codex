import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"
import Link from "next/link"

export function SupabaseConfigAlert() {
  return (
    <Alert variant="warning" className="mb-4">
      <AlertCircle className="h-4 w-4" />
      <AlertTitle>Configuration Supabase</AlertTitle>
      <AlertDescription>
        <p className="mb-2">
          Les informations de connexion Supabase sont maintenant intégrées directement dans l'application :
        </p>
        <ul className="list-disc pl-5 mb-2 text-sm">
          <li>URL : https://gllhemdeucwaxbmoyzee.supabase.co</li>
          <li>
            Clé anonyme :
            eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdsbGhlbWRldWN3YXhibW95emVlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDY5ODk3OTEsImV4cCI6MjA2MjU2NTc5MX0.F492Qh8X-BbyiytBTc2vFPyeu8sBhQR5ivAfpzlXoo0
          </li>
        </ul>
        <p className="text-sm">
          <Link href="/test/supabase-connection" className="underline">
            Tester la connexion à Supabase
          </Link>
        </p>
      </AlertDescription>
    </Alert>
  )
}

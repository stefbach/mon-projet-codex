"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Check, X, Loader2 } from "lucide-react"
import { updatePatientStatus } from "@/lib/patient-service"
import { PATIENT_STATUSES } from "@/lib/constants"
import { statusEnum } from "@/lib/validations/patient-schema"
import { useToast } from "@/components/ui/use-toast"

interface QuickStatusEditProps {
  patientId: string
  currentStatus: string | null
  onStatusUpdated: (newStatus: string) => void
  onCancel: () => void
}

export function QuickStatusEdit({ patientId, currentStatus, onStatusUpdated, onCancel }: QuickStatusEditProps) {
  const [selectedStatus, setSelectedStatus] = useState<string>(currentStatus || "")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()

  const handleSubmit = async () => {
    if (!selectedStatus) {
      toast({
        variant: "destructive",
        title: "Erreur",
        description: "Veuillez sélectionner un statut",
      })
      return
    }

    // Validate the status using Zod
    try {
      statusEnum.parse(selectedStatus)
    } catch {
      toast({
        variant: "destructive",
        title: "Erreur",
        description: "Le statut sélectionné n'est pas valide",
      })
      return
    }

    setIsSubmitting(true)
    try {
      await updatePatientStatus(patientId, selectedStatus)
      onStatusUpdated(selectedStatus)
      toast({
        title: "Statut mis à jour",
        description: "Le statut du patient a été mis à jour avec succès",
      })
    } catch (error) {
      console.error("Erreur lors de la mise à jour du statut:", error)
      toast({
        variant: "destructive",
        title: "Erreur",
        description: "Impossible de mettre à jour le statut",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="flex items-center gap-2">
      <Select value={selectedStatus} onValueChange={setSelectedStatus} disabled={isSubmitting}>
        <SelectTrigger className="w-[180px]">
          <SelectValue placeholder="Sélectionner un statut" />
        </SelectTrigger>
        <SelectContent>
          {PATIENT_STATUSES.map((status) => (
            <SelectItem key={status.value} value={status.value}>
              {status.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      <div className="flex gap-1">
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8 text-green-600"
          onClick={handleSubmit}
          disabled={isSubmitting}
        >
          {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
        </Button>
        <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600" onClick={onCancel} disabled={isSubmitting}>
          <X className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}

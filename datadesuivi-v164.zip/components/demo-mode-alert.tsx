"use client"

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"
import { useI18n } from "@/lib/i18n"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export function DemoModeAlert() {
  const { t } = useI18n()

  return (
    <Alert className="mb-4 bg-primary-50 border-primary-200">
      <AlertCircle className="h-4 w-4 text-primary-600" />
      <AlertTitle className="text-primary-700">{t("auth.demoMode")}</AlertTitle>
      <AlertDescription className="text-primary-600">
        <p>{t("misc.demoModeAlert")}</p>
        <div className="mt-2">
          <Link href="/docs/setup">
            <Button variant="outline" size="sm" className="text-primary-600 border-primary-300">
              Voir le guide de configuration
            </Button>
          </Link>
        </div>
      </AlertDescription>
    </Alert>
  )
}

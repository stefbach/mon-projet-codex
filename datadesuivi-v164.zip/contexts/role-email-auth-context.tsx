"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useRouter } from "next/navigation"
import { toast } from "@/components/ui/use-toast"
import Cookies from "js-cookie"
import { supabase } from "@/lib/supabase"

// Types pour les rôles
export type UserRole = "admin" | "closer"

// Interface pour le contexte d'authentification
interface RoleEmailAuthContextType {
  isAuthenticated: boolean
  role: UserRole | null
  login: (role: UserRole, password: string) => Promise<boolean>
  logout: () => void
  isLoading: boolean
}

// Emails prédéfinis pour chaque rôle
const ROLE_EMAILS: Record<UserRole, string> = {
  admin: "admin@obesitycareclinic.com",
  closer: "closer@obesitycareclinic.com",
}

// Créer le contexte
const RoleEmailAuthContext = createContext<RoleEmailAuthContextType | undefined>(undefined)

export function RoleEmailAuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [role, setRole] = useState<UserRole | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  // Vérifier si l'utilisateur est déjà authentifié
  useEffect(() => {
    const checkSession = async () => {
      try {
        const { data } = await supabase.auth.getSession()
        if (data.session) {
          const { data: userData } = await supabase.auth.getUser()
          if (userData.user) {
            setIsAuthenticated(true)

            // Déterminer le rôle en fonction de l'email
            const userEmail = userData.user.email || ""
            if (userEmail === ROLE_EMAILS.admin) {
              setRole("admin")
            } else if (userEmail === ROLE_EMAILS.closer) {
              setRole("closer")
            }
          }
        }
      } catch (error) {
        console.error("Erreur lors de la vérification de la session:", error)
      }
    }

    checkSession()
  }, [])

  // Fonction de connexion
  const login = async (selectedRole: UserRole, password: string) => {
    setIsLoading(true)

    try {
      const email = ROLE_EMAILS[selectedRole]

      // Connexion avec Supabase
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (error) {
        toast({
          variant: "destructive",
          title: "Erreur de connexion",
          description: error.message,
        })
        setIsLoading(false)
        return false
      }

      if (data.user) {
        setIsAuthenticated(true)
        setRole(selectedRole)

        // Stocker dans un cookie pour le middleware
        Cookies.set("authSession", "true", { expires: 7 }) // Expire après 7 jours
        Cookies.set("userRole", selectedRole, { expires: 7 })

        toast({
          title: "Connexion réussie",
          description: `Connecté en tant que ${selectedRole}`,
        })

        // Rediriger vers le tableau de bord
        router.push("/dashboard")
        return true
      }
    } catch (error) {
      console.error("Erreur lors de la connexion:", error)
      toast({
        variant: "destructive",
        title: "Erreur de connexion",
        description: "Une erreur s'est produite lors de la connexion",
      })
    }

    setIsLoading(false)
    return false
  }

  // Fonction de déconnexion
  const logout = async () => {
    try {
      await supabase.auth.signOut()
      setIsAuthenticated(false)
      setRole(null)
      Cookies.remove("authSession")
      Cookies.remove("userRole")
      router.push("/login")

      toast({
        title: "Déconnexion réussie",
        description: "Vous avez été déconnecté avec succès",
      })
    } catch (error) {
      console.error("Erreur lors de la déconnexion:", error)
    }
  }

  return (
    <RoleEmailAuthContext.Provider
      value={{
        isAuthenticated,
        role,
        login,
        logout,
        isLoading,
      }}
    >
      {children}
    </RoleEmailAuthContext.Provider>
  )
}

// Hook pour utiliser le contexte d'authentification
export function useRoleEmailAuth() {
  const context = useContext(RoleEmailAuthContext)
  if (context === undefined) {
    throw new Error("useRoleEmailAuth doit être utilisé à l'intérieur d'un RoleEmailAuthProvider")
  }
  return context
}

// Ajouter cette ligne à la fin du fichier pour exporter useRoleEmailAuth sous le nom useAuth
export const useAuth = useRoleEmailAuth

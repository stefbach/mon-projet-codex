"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useRouter } from "next/navigation"
import { toast } from "@/components/ui/use-toast"
import Cookies from "js-cookie"
import { supabase } from "@/lib/supabase"

// Types pour les rôles
export type UserRole = "admin" | "closer"

// Interface pour le contexte d'authentification
interface EmailAuthContextType {
  isAuthenticated: boolean
  role: UserRole | null
  email: string | null
  login: (email: string, password: string) => Promise<boolean>
  logout: () => void
  isLoading: boolean
}

// Créer le contexte
const EmailAuthContext = createContext<EmailAuthContextType | undefined>(undefined)

export function EmailAuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [role, setRole] = useState<UserRole | null>(null)
  const [email, setEmail] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  // Vérifier si l'utilisateur est déjà authentifié
  useEffect(() => {
    const checkSession = async () => {
      try {
        const { data } = await supabase.auth.getSession()
        if (data.session) {
          const { data: userData } = await supabase.auth.getUser()
          if (userData.user) {
            setIsAuthenticated(true)
            setEmail(userData.user.email)

            // Récupérer le rôle de l'utilisateur
            const { data: userDetails } = await supabase
              .from("users")
              .select("role")
              .eq("id", userData.user.id)
              .single()

            if (userDetails) {
              setRole(userDetails.role as UserRole)
            } else {
              // Par défaut, on considère l'utilisateur comme un closer
              setRole("closer")
            }
          }
        }
      } catch (error) {
        console.error("Erreur lors de la vérification de la session:", error)
      }
    }

    checkSession()
  }, [])

  // Fonction de connexion
  const login = async (email: string, password: string) => {
    setIsLoading(true)

    try {
      // Connexion avec Supabase
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (error) {
        toast({
          variant: "destructive",
          title: "Erreur de connexion",
          description: error.message,
        })
        setIsLoading(false)
        return false
      }

      if (data.user) {
        setIsAuthenticated(true)
        setEmail(data.user.email)

        // Récupérer le rôle de l'utilisateur
        const { data: userDetails } = await supabase.from("users").select("role").eq("id", data.user.id).single()

        if (userDetails) {
          setRole(userDetails.role as UserRole)
        } else {
          // Par défaut, on considère l'utilisateur comme un closer
          setRole("closer")
        }

        // Stocker dans un cookie pour le middleware
        Cookies.set("authSession", "true", { expires: 7 }) // Expire après 7 jours

        toast({
          title: "Connexion réussie",
          description: `Connecté en tant que ${email}`,
        })

        // Rediriger vers le tableau de bord
        router.push("/dashboard")
        return true
      }
    } catch (error) {
      console.error("Erreur lors de la connexion:", error)
      toast({
        variant: "destructive",
        title: "Erreur de connexion",
        description: "Une erreur s'est produite lors de la connexion",
      })
    }

    setIsLoading(false)
    return false
  }

  // Fonction de déconnexion
  const logout = async () => {
    try {
      await supabase.auth.signOut()
      setIsAuthenticated(false)
      setRole(null)
      setEmail(null)
      Cookies.remove("authSession")
      router.push("/login")

      toast({
        title: "Déconnexion réussie",
        description: "Vous avez été déconnecté avec succès",
      })
    } catch (error) {
      console.error("Erreur lors de la déconnexion:", error)
    }
  }

  return (
    <EmailAuthContext.Provider
      value={{
        isAuthenticated,
        role,
        email,
        login,
        logout,
        isLoading,
      }}
    >
      {children}
    </EmailAuthContext.Provider>
  )
}

// Hook pour utiliser le contexte d'authentification
export function useEmailAuth() {
  const context = useContext(EmailAuthContext)
  if (context === undefined) {
    throw new Error("useEmailAuth doit être utilisé à l'intérieur d'un EmailAuthProvider")
  }
  return context
}

// Ajouter cette ligne à la fin du fichier pour exporter useEmailAuth sous le nom useAuth
export const useAuth = useEmailAuth

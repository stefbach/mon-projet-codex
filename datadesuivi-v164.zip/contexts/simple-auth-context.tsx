"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useRouter } from "next/navigation"
import { toast } from "@/components/ui/use-toast"
import { supabase } from "@/lib/supabase"

// Types pour les rôles
export type UserRole = "admin" | "closer"

// Interface pour le contexte d'authentification
interface SimpleAuthContextType {
  isAuthenticated: boolean
  role: UserRole | null
  login: (email: string, password: string) => Promise<void>
  logout: () => void
  isLoading: boolean
}

// Créer le contexte
const SimpleAuthContext = createContext<SimpleAuthContextType | undefined>(undefined)

export function SimpleAuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [role, setRole] = useState<UserRole | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  // Vérifier si l'utilisateur est déjà authentifié
  useEffect(() => {
    const checkAuth = async () => {
      try {
        const {
          data: { session },
        } = await supabase.auth.getSession()

        if (session) {
          // Récupérer le rôle de l'utilisateur
          const { data: userData } = await supabase.from("users").select("role").eq("id", session.user.id).single()

          setIsAuthenticated(true)
          setRole((userData?.role as UserRole) || "closer")
        }
      } catch (error) {
        console.error("Erreur lors de la vérification de l'authentification:", error)
      } finally {
        setIsLoading(false)
      }
    }

    checkAuth()
  }, [])

  // Fonction de connexion
  const login = async (email: string, password: string) => {
    setIsLoading(true)

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (error) {
        toast({
          variant: "destructive",
          title: "Erreur de connexion",
          description: error.message,
        })
        setIsLoading(false)
        return
      }

      // Récupérer le rôle de l'utilisateur
      const { data: userData } = await supabase.from("users").select("role").eq("id", data.user.id).single()

      setIsAuthenticated(true)
      setRole((userData?.role as UserRole) || "closer")

      toast({
        title: "Connexion réussie",
        description: `Connecté en tant que ${userData?.role === "admin" ? "administrateur" : "closer"}`,
      })

      router.push("/dashboard")
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Erreur de connexion",
        description: error.message,
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Fonction de déconnexion
  const logout = async () => {
    try {
      await supabase.auth.signOut()

      setIsAuthenticated(false)
      setRole(null)

      toast({
        title: "Déconnexion réussie",
        description: "Vous avez été déconnecté avec succès",
      })

      router.push("/login")
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Erreur de déconnexion",
        description: error.message,
      })
    }
  }

  return (
    <SimpleAuthContext.Provider
      value={{
        isAuthenticated,
        role,
        login,
        logout,
        isLoading,
      }}
    >
      {children}
    </SimpleAuthContext.Provider>
  )
}

// Hook pour utiliser le contexte d'authentification
export function useSimpleAuth() {
  const context = useContext(SimpleAuthContext)
  if (context === undefined) {
    throw new Error("useSimpleAuth doit être utilisé à l'intérieur d'un SimpleAuthProvider")
  }
  return context
}

// Ajouter cette ligne à la fin du fichier pour exporter useSimpleAuth sous le nom useAuth
export const useAuth = useSimpleAuth

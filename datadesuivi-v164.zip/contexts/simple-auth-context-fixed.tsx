"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { loginWithRolePassword } from "@/lib/role-auth-service"
import { supabase } from "@/lib/supabase"

export type UserRole = "admin" | "closer"

interface User {
  id: string
  email: string
  name?: string
  role: UserRole
  active?: boolean
  last_login?: string
}

interface SimpleAuthContextType {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
  login: (password: string, role: UserRole) => Promise<boolean>
  logout: () => Promise<void>
}

const SimpleAuthContext = createContext<SimpleAuthContextType | undefined>(undefined)

export function SimpleAuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const checkSession = async () => {
      try {
        const { data } = await supabase.auth.getSession()

        if (data.session) {
          const { user: authUser } = data.session

          // Récupérer les informations supplémentaires de l'utilisateur
          const { data: userData } = await supabase.from("users").select("*").eq("id", authUser.id).single()

          setUser({
            id: authUser.id,
            email: authUser.email || "",
            name: userData?.name || authUser.user_metadata?.name,
            role: (userData?.role || authUser.user_metadata?.role) as UserRole,
            active: userData?.active,
            last_login: new Date().toISOString(),
          })
        }
      } catch (error) {
        console.error("Erreur lors de la vérification de la session:", error)
      } finally {
        setIsLoading(false)
      }
    }

    checkSession()

    // Écouter les changements d'authentification
    const { data: authListener } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === "SIGNED_IN" && session) {
        const { user: authUser } = session

        // Récupérer les informations supplémentaires de l'utilisateur
        const { data: userData } = await supabase.from("users").select("*").eq("id", authUser.id).single()

        setUser({
          id: authUser.id,
          email: authUser.email || "",
          name: userData?.name || authUser.user_metadata?.name,
          role: (userData?.role || authUser.user_metadata?.role) as UserRole,
          active: userData?.active,
          last_login: new Date().toISOString(),
        })
      } else if (event === "SIGNED_OUT") {
        setUser(null)
      }
    })

    return () => {
      authListener.subscription.unsubscribe()
    }
  }, [])

  const login = async (password: string, role: UserRole): Promise<boolean> => {
    setIsLoading(true)
    try {
      const result = await loginWithRolePassword(role, password)

      if (result.success && result.user) {
        // Mettre à jour la date de dernière connexion
        await supabase.from("users").update({ last_login: new Date().toISOString() }).eq("id", result.user.id)

        return true
      }
      return false
    } catch (error) {
      console.error("Erreur lors de la connexion:", error)
      return false
    } finally {
      setIsLoading(false)
    }
  }

  const logout = async () => {
    setIsLoading(true)
    try {
      await supabase.auth.signOut()
      setUser(null)
    } catch (error) {
      console.error("Erreur lors de la déconnexion:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <SimpleAuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        login,
        logout,
      }}
    >
      {children}
    </SimpleAuthContext.Provider>
  )
}

export function useSimpleAuth() {
  const context = useContext(SimpleAuthContext)
  if (context === undefined) {
    throw new Error("useSimpleAuth doit être utilisé à l'intérieur d'un SimpleAuthProvider")
  }
  return context
}

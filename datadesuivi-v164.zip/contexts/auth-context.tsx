"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useRouter } from "next/navigation"
import Cookies from "js-cookie"
import { supabase } from "@/lib/supabase"

// Types pour les rôles
export type UserRole = "admin" | "closer"

// Interface pour l'utilisateur
interface User {
  id?: string
  email: string
  name: string
  role: UserRole
  active?: boolean
}

// Interface pour le contexte d'authentification
interface AuthContextType {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
  login: (email: string, password: string) => Promise<{ success: boolean; message?: string }>
  logout: () => Promise<void>
}

// Utilisateurs prédéfinis pour le mode démo
const DEMO_USERS = [
  {
    email: "admin@obesitycareclinic.com",
    password: "admin123",
    name: "Administrateur",
    role: "admin" as UserRole,
  },
  {
    email: "closer@obesitycareclinic.com",
    password: "closer123",
    name: "Closer",
    role: "closer" as UserRole,
  },
]

// Créer le contexte
const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  // Vérifier si l'utilisateur est déjà authentifié
  useEffect(() => {
    const checkAuth = async () => {
      try {
        setIsLoading(true)
        console.log("[AuthContext] Vérification de l'authentification...")

        // Vérifier d'abord si nous sommes en mode démo
        if (process.env.NODE_ENV === "development" && process.env.NEXT_PUBLIC_FORCE_DEMO === "true") {
          console.log("[AuthContext] Mode démo détecté")
          const storedUser = localStorage.getItem("user")
          const authCookie = Cookies.get("authSession")

          if (storedUser && authCookie) {
            console.log("[AuthContext] Utilisateur trouvé dans localStorage")
            const parsedUser = JSON.parse(storedUser)
            setUser(parsedUser)
          }
        } else {
          // Vérifier la session Supabase
          console.log("[AuthContext] Vérification de la session Supabase")
          const {
            data: { session },
            error,
          } = await supabase.auth.getSession()

          if (error) {
            console.error("[AuthContext] Erreur lors de la récupération de la session:", error)
            throw error
          }

          if (session) {
            console.log("[AuthContext] Session Supabase trouvée")
            // Récupérer les informations de l'utilisateur depuis la table users
            const { data: userData, error: userError } = await supabase
              .from("users")
              .select("*")
              .eq("id", session.user.id)
              .single()

            if (userError && userError.code !== "PGRST116") {
              console.error("[AuthContext] Erreur lors de la récupération des données utilisateur:", userError)
            }

            // Créer l'objet utilisateur
            const userObj: User = {
              id: session.user.id,
              email: session.user.email || "",
              name: userData?.name || session.user.email?.split("@")[0] || "Utilisateur",
              role: (userData?.role as UserRole) || "closer",
              active: userData?.active !== undefined ? userData.active : true,
            }

            console.log("[AuthContext] Utilisateur authentifié:", userObj)
            setUser(userObj)

            // S'assurer que les cookies sont définis
            Cookies.set("authSession", "true", { expires: 7 })
            Cookies.set("userRole", userObj.role, { expires: 7 })
          } else {
            console.log("[AuthContext] Aucune session Supabase trouvée")
          }
        }
      } catch (error) {
        console.error("[AuthContext] Erreur lors de la vérification de l'authentification:", error)
        localStorage.removeItem("user")
        Cookies.remove("authSession")
        Cookies.remove("userRole")
      } finally {
        setIsLoading(false)
      }
    }

    checkAuth()
  }, [])

  // Fonction de connexion
  const login = async (email: string, password: string): Promise<{ success: boolean; message?: string }> => {
    try {
      console.log("[AuthContext] Tentative de connexion pour:", email)

      // Mode démo/prévisualisation
      if (process.env.NODE_ENV === "development" && process.env.NEXT_PUBLIC_FORCE_DEMO === "true") {
        console.log("[AuthContext] Mode démo forcé: simulation d'authentification")

        // Rechercher l'utilisateur correspondant
        const foundUser = DEMO_USERS.find(
          (u) => u.email.toLowerCase() === email.toLowerCase() && u.password === password,
        )

        if (foundUser) {
          // Créer l'objet utilisateur (sans le mot de passe)
          const userObj: User = {
            id: `demo-${Date.now()}`,
            email: foundUser.email,
            name: foundUser.name,
            role: foundUser.role,
            active: true,
          }

          // Stocker dans localStorage
          localStorage.setItem("user", JSON.stringify(userObj))

          // Stocker dans un cookie pour le middleware
          Cookies.set("authSession", "true", { expires: 7 }) // Expire après 7 jours
          Cookies.set("userRole", foundUser.role, { expires: 7 })

          // Mettre à jour l'état
          setUser(userObj)
          console.log("[AuthContext] Connexion réussie en mode démo")

          return { success: true }
        }

        return { success: false, message: "Email ou mot de passe incorrect" }
      }

      // En production ou développement normal, utiliser Supabase Auth
      console.log("[AuthContext] Authentification via Supabase Auth")

      // Utiliser Supabase Auth pour la connexion
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (error) {
        console.error("[AuthContext] Erreur Supabase Auth lors de l'authentification:", error)

        // Vérifier si l'erreur est due à un email non confirmé
        if (error.message.includes("Email not confirmed")) {
          // Essayer de confirmer automatiquement l'utilisateur
          try {
            const { error: confirmError } = await supabase.rpc("admin_confirm_user", {
              user_email: email,
            })

            if (!confirmError) {
              console.log("[AuthContext] Utilisateur confirmé automatiquement, nouvelle tentative de connexion")

              // Réessayer la connexion après confirmation
              const { data: retryData, error: retryError } = await supabase.auth.signInWithPassword({
                email,
                password,
              })

              if (!retryError && retryData.user) {
                // Récupérer les informations supplémentaires de l'utilisateur depuis la table users
                const { data: userData, error: userError } = await supabase
                  .from("users")
                  .select("*")
                  .eq("id", retryData.user.id)
                  .single()

                // Créer l'objet utilisateur
                const userObj: User = {
                  id: retryData.user.id,
                  email: retryData.user.email || "",
                  name: userData?.name || retryData.user.email?.split("@")[0] || "Utilisateur",
                  role: (userData?.role as UserRole) || "closer",
                  active: userData?.active !== undefined ? userData.active : true,
                }

                setUser(userObj)

                // S'assurer que les cookies sont définis
                Cookies.set("authSession", "true", { expires: 7 })
                Cookies.set("userRole", userObj.role, { expires: 7 })

                console.log("[AuthContext] Connexion réussie après confirmation automatique")
                return { success: true }
              }
            }
          } catch (confirmError) {
            console.warn("[AuthContext] Erreur lors de la confirmation automatique:", confirmError)
          }

          return {
            success: false,
            message: "Veuillez confirmer votre email avant de vous connecter",
          }
        }

        return { success: false, message: "Email ou mot de passe incorrect" }
      }

      if (!data || !data.user) {
        return { success: false, message: "Authentification échouée" }
      }

      // Récupérer les informations supplémentaires de l'utilisateur depuis la table users
      const { data: userData, error: userError } = await supabase
        .from("users")
        .select("*")
        .eq("id", data.user.id)
        .single()

      if (userError && userError.code !== "PGRST116") {
        console.error("[AuthContext] Erreur Supabase lors de la récupération des données utilisateur:", userError)
      }

      // Si l'utilisateur n'existe pas dans la table users, l'ajouter
      if (userError && userError.code === "PGRST116") {
        console.log("[AuthContext] Utilisateur non trouvé dans la table users, ajout automatique")

        const { error: insertError } = await supabase.from("users").insert([
          {
            id: data.user.id,
            email: data.user.email || "",
            name: data.user.email?.split("@")[0] || "Utilisateur",
            role: "closer", // Rôle par défaut
            active: true,
          },
        ])

        if (insertError) {
          console.error("[AuthContext] Erreur lors de l'ajout de l'utilisateur à la table users:", insertError)
        }
      }

      // Créer l'objet utilisateur
      const userObj: User = {
        id: data.user.id,
        email: data.user.email || "",
        name: userData?.name || data.user.email?.split("@")[0] || "Utilisateur",
        role: (userData?.role as UserRole) || "closer",
        active: userData?.active !== undefined ? userData.active : true,
      }

      // S'assurer que les cookies sont définis
      Cookies.set("authSession", "true", { expires: 7 })
      Cookies.set("userRole", userObj.role, { expires: 7 })

      setUser(userObj)
      console.log("[AuthContext] Connexion réussie via Supabase")
      return { success: true }
    } catch (error: any) {
      console.error("[AuthContext] Erreur lors de l'authentification:", error)
      return { success: false, message: "Une erreur s'est produite lors de l'authentification" }
    }
  }

  // Fonction de déconnexion
  const logout = async () => {
    try {
      setIsLoading(true)
      console.log("[AuthContext] Tentative de déconnexion")

      // Mode démo/prévisualisation
      if (process.env.NODE_ENV === "development" && process.env.NEXT_PUBLIC_FORCE_DEMO === "true") {
        // Supprimer de localStorage
        localStorage.removeItem("user")

        // Supprimer les cookies
        Cookies.remove("authSession")
        Cookies.remove("userRole")
        console.log("[AuthContext] Déconnexion en mode démo réussie")
      } else {
        // Déconnexion de Supabase Auth
        const { error } = await supabase.auth.signOut()

        if (error) {
          console.error("[AuthContext] Erreur lors de la déconnexion de Supabase:", error)
          throw error
        }

        // Supprimer les cookies
        Cookies.remove("authSession")
        Cookies.remove("userRole")
        console.log("[AuthContext] Déconnexion de Supabase réussie")
      }

      // Mettre à jour l'état
      setUser(null)

      // Rediriger vers la page de connexion
      router.push("/login")
    } catch (error) {
      console.error("[AuthContext] Erreur lors de la déconnexion:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        login,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

// Hook pour utiliser le contexte d'authentification
export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth doit être utilisé à l'intérieur d'un AuthProvider")
  }
  return context
}

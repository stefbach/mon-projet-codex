-- Création de la table users si elle n'existe pas déjà
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email VARCHAR(255) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  role VARCHAR(50) NOT NULL DEFAULT 'user',
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  last_password_change TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  status VARCHAR(50) DEFAULT 'active'
);

-- Création de la table patients si elle n'existe pas déjà
CREATE TABLE IF NOT EXISTS patients (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255),
  phone VARCHAR(20),
  address TEXT,
  date_of_birth DATE,
  gender VARCHAR(10),
  status VARCHAR(50) DEFAULT 'active',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  created_by UUID REFERENCES users(id),
  notes TEXT
);

-- Création de la table appointments si elle n'existe pas déjà
CREATE TABLE IF NOT EXISTS appointments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  patient_id UUID REFERENCES patients(id) ON DELETE CASCADE,
  date TIMESTAMP WITH TIME ZONE NOT NULL,
  duration INTEGER NOT NULL, -- durée en minutes
  status VARCHAR(50) DEFAULT 'scheduled',
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  created_by UUID REFERENCES users(id)
);

-- Création de la table medical_records si elle n'existe pas déjà
CREATE TABLE IF NOT EXISTS medical_records (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  patient_id UUID REFERENCES patients(id) ON DELETE CASCADE,
  record_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  diagnosis TEXT,
  treatment TEXT,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  created_by UUID REFERENCES users(id)
);

-- Création de la table activity_logs si elle n'existe pas déjà
CREATE TABLE IF NOT EXISTS activity_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id),
  action VARCHAR(255) NOT NULL,
  entity_type VARCHAR(50) NOT NULL,
  entity_id UUID,
  details JSONB,
  ip_address VARCHAR(45),
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Insertion d'un utilisateur administrateur par défaut si la table est vide
INSERT INTO users (email, name, role, password_hash, status)
SELECT 'admin@example.com', 'Administrateur', 'admin', '$2a$10$X7VYVy6FJKDCmQbCJZJzXeygYH4U5dHjzXmUxKYp6rqAGRKGtFTie', 'active'
WHERE NOT EXISTS (SELECT 1 FROM users LIMIT 1);

-- Insertion de quelques utilisateurs de test
INSERT INTO users (email, name, role, password_hash, status)
VALUES 
('user1@example.com', 'Utilisateur Test 1', 'user', '$2a$10$X7VYVy6FJKDCmQbCJZJzXeygYH4U5dHjzXmUxKYp6rqAGRKGtFTie', 'active'),
('user2@example.com', 'Utilisateur Test 2', 'user', '$2a$10$X7VYVy6FJKDCmQbCJZJzXeygYH4U5dHjzXmUxKYp6rqAGRKGtFTie', 'active'),
('manager@example.com', 'Manager Test', 'manager', '$2a$10$X7VYVy6FJKDCmQbCJZJzXeygYH4U5dHjzXmUxKYp6rqAGRKGtFTie', 'active')
ON CONFLICT (email) DO NOTHING;

-- Insertion de quelques patients de test
INSERT INTO patients (name, email, phone, status, gender, date_of_birth)
VALUES 
('Patient Test 1', 'patient1@example.com', '0123456789', 'active', 'M', '1980-01-15'),
('Patient Test 2', 'patient2@example.com', '0123456790', 'active', 'F', '1985-05-20'),
('Patient Test 3', 'patient3@example.com', '0123456791', 'inactive', 'M', '1975-11-10')
ON CONFLICT DO NOTHING;

import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export function middleware(request: NextRequest) {
  const authSession = request.cookies.get("authSession")?.value
  const userRole = request.cookies.get("userRole")?.value
  const { pathname } = request.nextUrl

  // Ajouter des logs pour le débogage (visibles dans les logs Vercel)
  console.log(`[Middleware] Path: ${pathname}, Auth: ${!!authSession}, Role: ${userRole || "none"}`)

  // Liste des chemins publics qui ne nécessitent pas d'authentification
  const publicPaths = ["/login", "/docs", "/_next", "/api", "/favicon.ico", "/images", "/fonts"]

  const isPublicPath = publicPaths.some((path) => pathname === path || pathname.startsWith(path))

  // Si l'utilisateur n'est pas authentifié et essaie d'accéder à une route protégée
  if (!authSession && !isPublicPath) {
    console.log(`[Middleware] Redirection vers /login depuis ${pathname}`)
    return NextResponse.redirect(new URL("/login", request.url))
  }

  // Si l'utilisateur est authentifié et essaie d'accéder à la page de connexion
  if (authSession && pathname === "/login") {
    console.log(`[Middleware] Redirection vers /dashboard depuis /login`)
    return NextResponse.redirect(new URL("/dashboard", request.url))
  }

  // Si l'utilisateur essaie d'accéder à une route admin sans être admin
  if (authSession && pathname.startsWith("/admin") && userRole !== "admin") {
    console.log(`[Middleware] Accès refusé à ${pathname} pour le rôle ${userRole}`)
    return NextResponse.redirect(new URL("/dashboard", request.url))
  }

  // Autoriser l'accès
  return NextResponse.next()
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
}

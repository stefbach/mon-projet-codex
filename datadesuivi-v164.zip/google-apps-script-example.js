// Ce script est un exemple à implémenter dans Google Apps Script
// Ouvrez votre script Google Apps Script et remplacez le contenu par ce code

// ID de votre feuille Google Sheets pour les utilisateurs
const USERS_SHEET_ID = "VOTRE_ID_DE_FEUILLE_GOOGLE_SHEETS"
const USERS_SHEET_NAME = "Utilisateurs"

// Fonction pour gérer les requêtes entrantes
function doGet(e) {
  // Activer CORS
  const output = ContentService.createTextOutput()
  output.setMimeType(ContentService.MimeType.JSON)

  // Récupérer l'action demandée
  const action = e.parameter.action

  // Vérifier si un callback JSONP est fourni
  const callback = e.parameter.callback

  let result

  try {
    // Exécuter l'action appropriée
    switch (action) {
      case "authenticateUser":
        result = authenticateUser(e.parameter.email, e.parameter.password)
        break
      case "getUsers":
        result = getUsers()
        break
      case "createUser":
        result = createUser(e.parameter)
        break
      case "updateUser":
        result = updateUser(e.parameter.userId, e.parameter)
        break
      case "deleteUser":
        result = deleteUser(e.parameter.userId)
        break
      case "changePassword":
        result = changePassword(e.parameter.userId, e.parameter.currentPassword, e.parameter.newPassword)
        break
      case "sendPasswordReset":
        result = sendPasswordReset(e.parameter.email)
        break
      default:
        result = { success: false, message: "Action non reconnue: " + action }
    }
  } catch (error) {
    result = { success: false, message: "Erreur: " + error.toString() }
  }

  // Formater la réponse
  const jsonResponse = JSON.stringify(result)

  // Si un callback est fourni, envelopper la réponse dans le callback (JSONP)
  if (callback) {
    return output.setContent(callback + "(" + jsonResponse + ")")
  } else {
    return output.setContent(jsonResponse)
  }
}

// Fonction pour authentifier un utilisateur
function authenticateUser(email, password) {
  // Ouvrir la feuille des utilisateurs
  const sheet = SpreadsheetApp.openById(USERS_SHEET_ID).getSheetByName(USERS_SHEET_NAME)
  const data = sheet.getDataRange().getValues()

  // Chercher l'utilisateur par email
  for (let i = 1; i < data.length; i++) {
    if (data[i][1] === email) {
      // Colonne B: email
      // Vérifier le mot de passe (en pratique, utilisez un hachage sécurisé)
      if (data[i][3] === password) {
        // Colonne D: password
        // Utilisateur trouvé et mot de passe correct
        return {
          success: true,
          user: {
            id: data[i][0], // Colonne A: id
            email: data[i][1], // Colonne B: email
            name: data[i][2], // Colonne C: name
            role: data[i][4], // Colonne E: role
            active: data[i][5] === "true", // Colonne F: active
            created_at: data[i][6], // Colonne G: created_at
            last_password_change: data[i][7], // Colonne H: last_password_change
          },
        }
      } else {
        // Mot de passe incorrect
        return { success: false, message: "Mot de passe incorrect" }
      }
    }
  }

  // Utilisateur non trouvé
  return { success: false, message: "Utilisateur non trouvé" }
}

// Fonction pour récupérer tous les utilisateurs
function getUsers() {
  // Ouvrir la feuille des utilisateurs
  const sheet = SpreadsheetApp.openById(USERS_SHEET_ID).getSheetByName(USERS_SHEET_NAME)
  const data = sheet.getDataRange().getValues()

  // Ignorer la première ligne (en-têtes)
  const users = []
  for (let i = 1; i < data.length; i++) {
    users.push({
      id: data[i][0], // Colonne A: id
      email: data[i][1], // Colonne B: email
      name: data[i][2], // Colonne C: name
      role: data[i][4], // Colonne E: role
      active: data[i][5] === "true", // Colonne F: active
      created_at: data[i][6], // Colonne G: created_at
      last_password_change: data[i][7], // Colonne H: last_password_change
    })
  }

  return users
}

// Fonction pour créer un nouvel utilisateur
function createUser(userData) {
  // Ouvrir la feuille des utilisateurs
  const sheet = SpreadsheetApp.openById(USERS_SHEET_ID).getSheetByName(USERS_SHEET_NAME)
  const data = sheet.getDataRange().getValues()

  // Vérifier si l'email existe déjà
  for (let i = 1; i < data.length; i++) {
    if (data[i][1] === userData.email) {
      return { success: false, message: "Cet email est déjà utilisé" }
    }
  }

  // Générer un ID unique
  const userId = "user-" + new Date().getTime()

  // Date actuelle
  const now = new Date().toISOString()

  // Ajouter le nouvel utilisateur
  sheet.appendRow([
    userId, // id
    userData.email, // email
    userData.name, // name
    userData.password, // password (en pratique, utilisez un hachage sécurisé)
    userData.role, // role
    userData.active || "true", // active
    now, // created_at
    now, // last_password_change
  ])

  // Retourner le nouvel utilisateur
  return {
    success: true,
    message: "Utilisateur créé avec succès",
    user: {
      id: userId,
      email: userData.email,
      name: userData.name,
      role: userData.role,
      active: userData.active === "true",
      created_at: now,
      last_password_change: now,
    },
  }
}

// Fonction pour mettre à jour un utilisateur
function updateUser(userId, userData) {
  // Ouvrir la feuille des utilisateurs
  const sheet = SpreadsheetApp.openById(USERS_SHEET_ID).getSheetByName(USERS_SHEET_NAME)
  const data = sheet.getDataRange().getValues()

  // Chercher l'utilisateur par ID
  for (let i = 1; i < data.length; i++) {
    if (data[i][0] === userId) {
      // Mettre à jour les champs fournis
      if (userData.email) sheet.getRange(i + 1, 2).setValue(userData.email) // Colonne B: email
      if (userData.name) sheet.getRange(i + 1, 3).setValue(userData.name) // Colonne C: name
      if (userData.role) sheet.getRange(i + 1, 5).setValue(userData.role) // Colonne E: role
      if (userData.active !== undefined) sheet.getRange(i + 1, 6).setValue(userData.active) // Colonne F: active

      return { success: true, message: "Utilisateur mis à jour avec succès" }
    }
  }

  // Utilisateur non trouvé
  return { success: false, message: "Utilisateur non trouvé" }
}

// Fonction pour supprimer un utilisateur
function deleteUser(userId) {
  // Ouvrir la feuille des utilisateurs
  const sheet = SpreadsheetApp.openById(USERS_SHEET_ID).getSheetByName(USERS_SHEET_NAME)
  const data = sheet.getDataRange().getValues()

  // Chercher l'utilisateur par ID
  for (let i = 1; i < data.length; i++) {
    if (data[i][0] === userId) {
      // Supprimer la ligne
      sheet.deleteRow(i + 1)

      return { success: true, message: "Utilisateur supprimé avec succès" }
    }
  }

  // Utilisateur non trouvé
  return { success: false, message: "Utilisateur non trouvé" }
}

// Fonction pour changer le mot de passe d'un utilisateur
function changePassword(userId, currentPassword, newPassword) {
  // Ouvrir la feuille des utilisateurs
  const sheet = SpreadsheetApp.openById(USERS_SHEET_ID).getSheetByName(USERS_SHEET_NAME)
  const data = sheet.getDataRange().getValues()

  // Chercher l'utilisateur par ID
  for (let i = 1; i < data.length; i++) {
    if (data[i][0] === userId) {
      // Vérifier le mot de passe actuel
      if (data[i][3] !== currentPassword) {
        return { success: false, message: "Mot de passe actuel incorrect" }
      }

      // Mettre à jour le mot de passe
      sheet.getRange(i + 1, 4).setValue(newPassword) // Colonne D: password

      // Mettre à jour la date de changement de mot de passe
      const now = new Date().toISOString()
      sheet.getRange(i + 1, 8).setValue(now) // Colonne H: last_password_change

      return { success: true, message: "Mot de passe changé avec succès" }
    }
  }

  // Utilisateur non trouvé
  return { success: false, message: "Utilisateur non trouvé" }
}

// Fonction pour envoyer un email de réinitialisation de mot de passe
function sendPasswordReset(email) {
  // Ouvrir la feuille des utilisateurs
  const sheet = SpreadsheetApp.openById(USERS_SHEET_ID).getSheetByName(USERS_SHEET_NAME)
  const data = sheet.getDataRange().getValues()

  // Chercher l'utilisateur par email
  for (let i = 1; i < data.length; i++) {
    if (data[i][1] === email) {
      // Générer un mot de passe temporaire
      const tempPassword = "temp" + Math.floor(Math.random() * 10000)

      // Mettre à jour le mot de passe
      sheet.getRange(i + 1, 4).setValue(tempPassword) // Colonne D: password

      // Mettre à jour la date de changement de mot de passe
      const now = new Date().toISOString()
      sheet.getRange(i + 1, 8).setValue(now) // Colonne H: last_password_change

      // Envoyer un email (en pratique, utilisez GmailApp)
      // GmailApp.sendEmail(email, "Réinitialisation de mot de passe", "Votre mot de passe temporaire est: " + tempPassword);

      return { success: true, message: "Email de réinitialisation envoyé" }
    }
  }

  // Utilisateur non trouvé
  return { success: false, message: "Utilisateur non trouvé" }
}

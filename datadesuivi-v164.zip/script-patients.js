// Script pour la gestion des patients (à copier dans votre projet Google Apps Script)

// ID de la feuille Google Sheets pour les patients
// IMPORTANT: Remplacez cette valeur par l'ID de votre feuille Google Sheets
const PATIENTS_SHEET_ID = "VOTRE_ID_DE_FEUILLE_GOOGLE_SHEETS"
const PATIENTS_SHEET_NAME = "Patients" // Nom de l'onglet

function doGet(e) {
  // Activer CORS
  const output = ContentService.createTextOutput()
  output.setMimeType(ContentService.MimeType.JSON)

  // Journaliser les paramètres reçus pour le débogage
  console.log("Paramètres reçus:", JSON.stringify(e.parameter))

  // Récupérer l'action demandée
  const action = e.parameter.action

  // Exécuter l'action appropriée
  let result
  try {
    if (action === "addPatient") {
      result = addPatient(e.parameter)
    } else if (action === "getPatients") {
      result = getPatients(e.parameter)
    } else {
      result = { success: false, message: "Action non reconnue: " + action }
    }
  } catch (error) {
    console.error("Erreur dans le script:", error)
    result = { success: false, message: "Erreur: " + error.toString() }
  }

  // Retourner le résultat
  output.setContent(JSON.stringify(result))
  return output
}

// Fonction pour ajouter un patient
function addPatient(params) {
  try {
    // Ouvrir la feuille
    const ss = SpreadsheetApp.openById(PATIENTS_SHEET_ID)
    const sheet = ss.getSheetByName(PATIENTS_SHEET_NAME)

    // Journaliser pour le débogage
    console.log("Ajout d'un patient avec les paramètres:", JSON.stringify(params))

    // Récupérer les en-têtes
    const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0]
    console.log("En-têtes trouvés:", headers)

    // Préparer les données
    const rowData = []
    for (let i = 0; i < headers.length; i++) {
      const header = headers[i]
      if (params[header]) {
        rowData.push(params[header])
      } else {
        rowData.push("") // Valeur vide si le paramètre n'est pas fourni
      }
    }

    console.log("Données à ajouter:", rowData)

    // Ajouter le patient
    sheet.appendRow(rowData)

    // Retourner le succès
    return {
      success: true,
      message: "Patient ajouté avec succès",
    }
  } catch (error) {
    console.error("Erreur lors de l'ajout du patient:", error)
    return { success: false, message: "Erreur lors de l'ajout du patient: " + error.toString() }
  }
}

// Fonction pour récupérer les patients
function getPatients(params) {
  try {
    // Ouvrir la feuille
    const ss = SpreadsheetApp.openById(PATIENTS_SHEET_ID)
    const sheet = ss.getSheetByName(PATIENTS_SHEET_NAME)

    console.log("Récupération des patients avec les paramètres:", JSON.stringify(params))

    // Récupérer les données
    const data = sheet.getDataRange().getValues()
    const headers = data[0]

    console.log("En-têtes trouvés:", headers)

    // Convertir les données en objets
    const patients = []
    for (let i = 1; i < data.length; i++) {
      const patient = {}
      for (let j = 0; j < headers.length; j++) {
        patient[headers[j]] = data[i][j]
      }

      // Filtrer par closer si nécessaire
      if (params.userEmail && params.isAdmin !== "true" && patient.closer !== params.userEmail) {
        continue
      }

      patients.push(patient)
    }

    console.log("Nombre de patients récupérés:", patients.length)

    // Retourner les patients
    return patients
  } catch (error) {
    console.error("Erreur lors de la récupération des patients:", error)
    return { success: false, message: "Erreur lors de la récupération des patients: " + error.toString() }
  }
}

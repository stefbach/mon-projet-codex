-- Vérifier si la table users existe déjà
DO $$
BEGIN
    IF EXISTS (SELECT FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'users') THEN
        -- Vérifier si la colonne password_hash existe déjà
        IF NOT EXISTS (SELECT FROM information_schema.columns 
                       WHERE table_schema = 'public' 
                       AND table_name = 'users' 
                       AND column_name = 'password_hash') THEN
            -- Ajouter la colonne password_hash
            ALTER TABLE public.users ADD COLUMN password_hash VARCHAR(255);
        END IF;
        
        -- Vérifier si la colonne password_updated_at existe déjà
        IF NOT EXISTS (SELECT FROM information_schema.columns 
                       WHERE table_schema = 'public' 
                       AND table_name = 'users' 
                       AND column_name = 'password_updated_at') THEN
            -- Ajouter la colonne password_updated_at
            ALTER TABLE public.users ADD COLUMN password_updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();
        END IF;
    ELSE
        -- Créer la table users complète
        CREATE TABLE public.users (
            id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
            email VARCHAR(255) UNIQUE NOT NULL,
            name VARCHAR(255) NOT NULL,
            role VARCHAR(50) NOT NULL,
            active BOOLEAN DEFAULT true,
            password_hash VARCHAR(255),
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            password_updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );
    END IF;
END $$;

-- Mettre à jour les utilisateurs existants avec un mot de passe par défaut si password_hash est NULL
UPDATE public.users 
SET password_hash = '$2a$10$X7VYHy.iYDVB.J7tgJq5B.D5jS9EVz1gHjzGhpnT7s9k9LJZUUeim' -- Mot de passe: admin123
WHERE password_hash IS NULL;

-- Créer des utilisateurs de test s'ils n'existent pas déjà
INSERT INTO public.users (id, email, name, role, active, password_hash, created_at, password_updated_at)
VALUES 
('00000000-0000-0000-0000-000000000001', 'admin@email.com', 'Administrateur', 'admin', true, '$2a$10$X7VYHy.iYDVB.J7tgJq5B.D5jS9EVz1gHjzGhpnT7s9k9LJZUUeim', NOW(), NOW()),
('00000000-0000-0000-0000-000000000002', 'closer@email.com', 'Closer', 'closer', true, '$2a$10$X7VYHy.iYDVB.J7tgJq5B.D5jS9EVz1gHjzGhpnT7s9k9LJZUUeim', NOW(), NOW())
ON CONFLICT (email) DO NOTHING;

-- Créer des index pour améliorer les performances
CREATE INDEX IF NOT EXISTS users_email_idx ON public.users (email);
CREATE INDEX IF NOT EXISTS users_role_idx ON public.users (role);

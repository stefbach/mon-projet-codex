/** @type {import('next').NextConfig} */
const nextConfig = {
  // L'option swcMinify est supprimée car elle est activée par défaut dans Next.js 15.2.4
  eslint: {
    ignoreDuringBuilds: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: true,
  },
  experimental: {
    // optimizeCss est commenté pour éviter l'erreur liée à critters
    // Si vous souhaitez utiliser cette fonctionnalité, décommentez cette ligne
    // et installez le package critters avec: bun add critters
    // optimizeCss: true,
  },
};

export default nextConfig;

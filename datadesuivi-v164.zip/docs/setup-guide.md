# Guide de configuration de l'application Suivi Patient

Ce guide vous explique comment configurer l'application Suivi Patient pour qu'elle soit entièrement fonctionnelle avec Firebase et Google Sheets.

## 1. Configuration de Firebase

### Créer un projet Firebase

1. Rendez-vous sur [Firebase Console](https://console.firebase.google.com/)
2. Cliquez sur "Ajouter un projet"
3. Donnez un nom à votre projet (ex: "suivi-patient")
4. Suivez les étapes pour créer le projet

### Activer l'authentification

1. Dans la console Firebase, allez dans "Authentication" dans le menu de gauche
2. Cliquez sur "Get started" ou "Commencer"
3. Activez la méthode d'authentification "Email/Password"
4. Activez également "Google" comme fournisseur d'authentification
5. Pour Google, configurez l'email de support et enregistrez

### Obtenir les clés de configuration

1. Dans la console Firebase, cliquez sur l'icône ⚙️ (paramètres) à côté de "Project Overview"
2. Sélectionnez "Project settings" ou "Paramètres du projet"
3. Faites défiler jusqu'à "Your apps" ou "Vos applications"
4. Cliquez sur l'icône Web (</>) pour ajouter une application web
5. Donnez un nom à votre application (ex: "suivi-patient-web")
6. Enregistrez l'application
7. Vous verrez maintenant un objet de configuration Firebase qui ressemble à ceci:

\`\`\`javascript
const firebaseConfig = {
  apiKey: "VOTRE_API_KEY",
  authDomain: "votre-projet.firebaseapp.com",
  projectId: "votre-projet",
  storageBucket: "votre-projet.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:abcdef1234567890"
};
\`\`\`

## 2. Configuration de Google Sheets

### Créer une feuille Google Sheets

1. Rendez-vous sur [Google Sheets](https://sheets.google.com/)
2. Créez une nouvelle feuille
3. Renommez la première feuille en "Feuille 1"
4. Ajoutez les en-têtes suivants dans la première ligne:
   - name
   - email
   - doctor
   - consultationDate
   - income
   - expenses
   - creditScore
   - creditPlatform
   - loanAmount
   - simulationValidated
   - platform
   - status
   - loanRequested
   - nextFollowUp
   - closer
   - comments
   - timestamp

### Configurer Google Apps Script pour le webhook

1. Dans votre feuille Google Sheets, cliquez sur "Extensions" > "Apps Script"
2. Remplacez le code par défaut par le code suivant:

\`\`\`javascript
function doPost(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Feuille 1");
  var data = e.parameter;
  
  // Préparer les données pour l'insertion
  var rowData = [
    data.name || "",
    data.email || "",
    data.doctor || "",
    data.consultationDate || "",
    data.income || "",
    data.expenses || "",
    data.creditScore || "",
    data.creditPlatform || "",
    data.loanAmount || "",
    data.simulationValidated || "",
    data.platform || "",
    data.status || "",
    data.loanRequested || "",
    data.nextFollowUp || "",
    data.closer || "",
    data.comments || "",
    data.timestamp || new Date().toISOString()
  ];
  
  // Ajouter les données à la feuille
  sheet.appendRow(rowData);
  
  // Retourner une réponse
  return ContentService.createTextOutput(JSON.stringify({ success: true }))
    .setMimeType(ContentService.MimeType.JSON);
}

function doGet(e) {
  return ContentService.createTextOutput("Le service est en ligne").setMimeType(ContentService.MimeType.TEXT);
}
\`\`\`

3. Enregistrez le script (Ctrl+S ou Cmd+S)
4. Cliquez sur "Déployer" > "Nouveau déploiement"
5. Sélectionnez "Application web" comme type
6. Configurez comme suit:
   - Description: "API Suivi Patient"
   - Exécuter en tant que: "Moi"
   - Qui a accès: "Tout le monde"
7. Cliquez sur "Déployer"
8. Copiez l'URL du déploiement (elle ressemblera à https://script.google.com/macros/s/VOTRE_ID_DE_DEPLOIEMENT/exec)

## 3. Configuration des variables d'environnement

Créez un fichier `.env.local` à la racine de votre projet avec les variables suivantes:

\`\`\`
# Firebase Configuration
NEXT_PUBLIC_FIREBASE_API_KEY=votre-api-key
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=votre-projet.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=votre-projet
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=votre-projet.appspot.com
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=votre-messaging-sender-id
NEXT_PUBLIC_FIREBASE_APP_ID=votre-app-id

# Google Sheets Configuration
NEXT_PUBLIC_SHEET_ID=votre-id-de-feuille-google
\`\`\`

Pour obtenir l'ID de votre feuille Google, regardez l'URL de votre feuille Google Sheets:
`https://docs.google.com/spreadsheets/d/VOTRE_ID_DE_FEUILLE/edit`

## 4. Mise à jour du code de l'application

Mettez à jour le fichier `lib/sheets-service.ts` avec l'URL de votre webhook Google Apps Script:

\`\`\`typescript
// URL pour l'envoi de données (webhook Google Apps Script)
const WEBHOOK_URL = "https://script.google.com/macros/s/VOTRE_ID_DE_DEPLOIEMENT/exec";
\`\`\`

## 5. Démarrer l'application

1. Installez les dépendances:
\`\`\`bash
npm install
\`\`\`

2. Démarrez l'application en mode développement:
\`\`\`bash
npm run dev
\`\`\`

3. Ouvrez votre navigateur à l'adresse [http://localhost:3000](http://localhost:3000)

## 6. Créer des utilisateurs

1. Accédez à la page de connexion
2. Utilisez l'option "Se connecter avec Google" pour créer un compte
3. Pour définir un utilisateur comme administrateur, modifiez la liste `ADMIN_EMAILS` dans le fichier `contexts/auth-context.tsx`

## Dépannage

- **Mode démo activé**: Assurez-vous que toutes les variables d'environnement Firebase sont correctement définies dans le fichier `.env.local`
- **Erreurs d'authentification**: Vérifiez que les méthodes d'authentification sont bien activées dans la console Firebase
- **Problèmes avec Google Sheets**: Assurez-vous que votre script Apps Script est correctement déployé et que l'URL du webhook est à jour
\`\`\`

Maintenant, mettons à jour le fichier `lib/firebase.ts` pour s'assurer que le mode démo n'est pas activé par défaut :

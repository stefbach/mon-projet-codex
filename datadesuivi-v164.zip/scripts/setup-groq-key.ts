/**
 * Script pour configurer la clé API GROQ dans le fichier .env.local
 *
 * Pour exécuter ce script:
 * 1. Assurez-vous d'avoir Node.js installé
 * 2. Exécutez: npx ts-node scripts/setup-groq-key.ts
 */

import * as fs from "fs"
import * as path from "path"

const GROQ_API_KEY = "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"

// Chemin vers le fichier .env.local à la racine du projet
const envFilePath = path.join(process.cwd(), ".env.local")

// Vérifier si le fichier existe déjà
const fileExists = fs.existsSync(envFilePath)

try {
  let envContent = ""

  // Si le fichier existe, lire son contenu
  if (fileExists) {
    envContent = fs.readFileSync(envFilePath, "utf8")

    // Vérifier si la clé GROQ existe déjà
    if (envContent.includes("GROQ_API_KEY=")) {
      // Remplacer la valeur existante
      envContent = envContent.replace(/GROQ_API_KEY=.*/, `GROQ_API_KEY="${GROQ_API_KEY}"`)
    } else {
      // Ajouter la nouvelle clé à la fin du fichier
      envContent += `\nGROQ_API_KEY="${GROQ_API_KEY}"\n`
    }
  } else {
    // Créer un nouveau fichier avec la clé GROQ
    envContent = `GROQ_API_KEY="${GROQ_API_KEY}"\n`
  }

  // Écrire le contenu dans le fichier
  fs.writeFileSync(envFilePath, envContent)

  console.log("✅ Clé API GROQ configurée avec succès dans .env.local")
  console.log("🔄 Redémarrez votre application pour appliquer les changements")
} catch (error) {
  console.error("❌ Erreur lors de la configuration de la clé API GROQ:", error)
  console.log("📝 Veuillez ajouter manuellement la ligne suivante à votre fichier .env.local:")
  console.log(`GROQ_API_KEY="${GROQ_API_KEY}"`)
}

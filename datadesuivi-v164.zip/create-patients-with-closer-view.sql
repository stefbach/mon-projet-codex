-- Création de la vue patients_with_closer
CREATE OR REPLACE VIEW patients_with_closer AS
SELECT p.*, u.name as closer_name
FROM patients p
LEFT JOIN users u ON p.closer = u.email;

"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Loader2, CheckCircle, XCircle } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { supabase } from "@/lib/supabase"
import { RoleGuard } from "@/components/role-guard"

// Forcer le rendu dynamique pour éviter les problèmes de prérendu
export const dynamic = "force-dynamic"

export default function AutoConfirmPage() {
  const [email, setEmail] = useState("")
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<{
    success?: boolean
    message?: string
  } | null>(null)

  const handleConfirmUser = async () => {
    if (!email.trim()) {
      toast({
        variant: "destructive",
        title: "Erreur",
        description: "Veuillez entrer une adresse email",
      })
      return
    }

    setLoading(true)
    setResult(null)

    try {
      // Vérifier si l'utilisateur existe
      const { data: userData, error: userError } = await supabase.auth.admin.getUserByEmail(email.trim())

      if (userError) {
        console.error("Erreur lors de la recherche de l'utilisateur:", userError)
        setResult({
          success: false,
          message: `Erreur: ${userError.message}`,
        })
        return
      }

      if (!userData || !userData.user) {
        setResult({
          success: false,
          message: "Aucun utilisateur trouvé avec cette adresse email",
        })
        return
      }

      // Confirmer l'utilisateur
      const { error: updateError } = await supabase.auth.admin.updateUserById(userData.user.id, {
        email_confirm: true,
      })

      if (updateError) {
        console.error("Erreur lors de la confirmation de l'utilisateur:", updateError)
        setResult({
          success: false,
          message: `Erreur: ${updateError.message}`,
        })
        return
      }

      setResult({
        success: true,
        message: `L'utilisateur ${email} a été confirmé avec succès`,
      })

      toast({
        title: "Succès",
        description: `L'utilisateur ${email} a été confirmé avec succès`,
      })
    } catch (error: any) {
      console.error("Erreur:", error)
      setResult({
        success: false,
        message: `Erreur: ${error.message || "Une erreur s'est produite"}`,
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <RoleGuard allowedRoles={["admin"]}>
      <div className="container mx-auto py-10">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle>Confirmation automatique d'utilisateur</CardTitle>
            <CardDescription>
              Confirmez un utilisateur sans qu'il ait besoin de cliquer sur le lien d'email
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email de l'utilisateur</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="utilisateur@exemple.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>

              {result && (
                <div
                  className={`p-4 rounded-md ${
                    result.success ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"
                  }`}
                >
                  <div className="flex items-center">
                    {result.success ? (
                      <CheckCircle className="h-5 w-5 mr-2 text-green-500" />
                    ) : (
                      <XCircle className="h-5 w-5 mr-2 text-red-500" />
                    )}
                    <p>{result.message}</p>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
          <CardFooter>
            <Button onClick={handleConfirmUser} disabled={loading} className="w-full">
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Confirmation en cours...
                </>
              ) : (
                "Confirmer l'utilisateur"
              )}
            </Button>
          </CardFooter>
        </Card>
      </div>
    </RoleGuard>
  )
}

"use client"

import type React from "react"

import { SimpleAuthProvider } from "@/contexts/simple-auth-context-fixed"

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return <SimpleAuthProvider>{children}</SimpleAuthProvider>
}

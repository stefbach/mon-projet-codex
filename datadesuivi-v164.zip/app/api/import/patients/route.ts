import { type NextRequest, NextResponse } from "next/server"
import { supabase } from "@/lib/supabase"
import { standardizeDoctorName } from "@/lib/patient-service"

export async function POST(request: NextRequest) {
  try {
    // Check authentication
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Authentification requise" }, { status: 401 })
    }

    // Check if user is admin
    const { data: userData, error: userError } = await supabase.from("users").select("role").eq("id", user.id).single()

    if (userError || userData?.role !== "admin") {
      return NextResponse.json(
        { error: "Accès non autorisé. Seuls les administrateurs peuvent importer des patients." },
        { status: 403 },
      )
    }

    // Get request body
    const patients = await request.json()

    if (!Array.isArray(patients) || patients.length === 0) {
      return NextResponse.json(
        { error: "Format de données invalide. Un tableau de patients est attendu." },
        { status: 400 },
      )
    }

    // Process patients
    const processedPatients = patients.map((patient) => {
      // Add metadata
      const processedPatient = {
        ...patient,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        created_by_admin: user.id,
      }

      // Standardize doctor name if present
      if (processedPatient.doctor) {
        processedPatient.doctor = standardizeDoctorName(processedPatient.doctor)
      }

      return processedPatient
    })

    // Insert patients
    const { data, error } = await supabase.from("patients").insert(processedPatients).select()

    if (error) {
      console.error("Error inserting patients:", error)

      // Try individual inserts if batch fails
      const results = await Promise.all(
        processedPatients.map(async (patient, index) => {
          const { data, error: individualError } = await supabase.from("patients").insert(patient).select()

          return {
            success: !individualError,
            data: data?.[0] || null,
            error: individualError
              ? {
                  message: individualError.message,
                  row: index + 1,
                }
              : null,
          }
        }),
      )

      const successCount = results.filter((r) => r.success).length
      const failedCount = results.filter((r) => !r.success).length
      const errors = results.filter((r) => r.error).map((r) => r.error)

      return NextResponse.json({
        success: successCount,
        failed: failedCount,
        errors,
        message: `Import partiel: ${successCount} patients importés, ${failedCount} échecs.`,
      })
    }

    return NextResponse.json({
      success: data?.length || 0,
      failed: 0,
      errors: [],
      message: `${data?.length || 0} patients importés avec succès.`,
    })
  } catch (error) {
    console.error("Error in import API:", error)
    return NextResponse.json({ error: "Erreur serveur lors de l'import: " + error.message }, { status: 500 })
  }
}

import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

export async function POST() {
  try {
    // Créer un client Supabase avec la clé de service pour avoir les permissions nécessaires
    const supabaseAdmin = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

    // Supprimer la contrainte existante
    await supabaseAdmin.rpc("exec_sql", {
      sql_query: "ALTER TABLE public.patients DROP CONSTRAINT IF EXISTS patients_suite_groupe_check",
    })

    // Créer une nouvelle contrainte qui accepte NULL, chaîne vide, 'NHS', 'CASH' et 'non_specifie'
    await supabaseAdmin.rpc("exec_sql", {
      sql_query:
        "ALTER TABLE public.patients ADD CONSTRAINT patients_suite_groupe_check CHECK (suite_groupe IS NULL OR suite_groupe = '' OR suite_groupe IN ('NHS', 'CASH', 'non_specifie'))",
    })

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error("Erreur lors de la mise à jour de la contrainte:", error)
    return NextResponse.json(
      { error: error.message || "Une erreur est survenue lors de la mise à jour de la contrainte" },
      { status: 500 },
    )
  }
}

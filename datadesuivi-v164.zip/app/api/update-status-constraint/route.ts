import { createClient } from "@supabase/supabase-js"
import { NextResponse } from "next/server"

export async function POST() {
  try {
    // Créer un client Supabase avec la clé de service pour avoir des privilèges élevés
    const supabaseAdmin = createClient(process.env.SUPABASE_URL || "", process.env.SUPABASE_SERVICE_ROLE_KEY || "", {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    })

    // SQL pour mettre à jour la contrainte de statut
    const sql = `
      ALTER TABLE patients DROP CONSTRAINT IF EXISTS patients_status_check;
      
      ALTER TABLE patients ADD CONSTRAINT patients_status_check 
        CHECK (status IN ('en_attente', 'a_contacter', 'rdv_programme', 'vente', 'perdu', 
                         'non_defini', 'en_cours', 'annule', 'a_rappeler', 'non_interesse', 'no_show'));
    `

    // Exécuter le SQL directement
    const { error } = await supabaseAdmin.rpc("exec_sql", { sql_query: sql })

    if (error) {
      // Si exec_sql n'existe pas, essayer de créer la fonction
      if (error.message.includes("function") && error.message.includes("exec_sql")) {
        // Créer la fonction exec_sql
        const createFunctionSql = `
          CREATE OR REPLACE FUNCTION exec_sql(sql_query TEXT) RETURNS VOID AS $$
          BEGIN
            EXECUTE sql_query;
          END;
          $$ LANGUAGE plpgsql SECURITY DEFINER;
        `

        // Exécuter le SQL pour créer la fonction
        const { error: createError } = await supabaseAdmin.rpc("exec_sql", { sql_query: createFunctionSql })

        if (createError) {
          // Si on ne peut toujours pas créer la fonction, utiliser l'API SQL directe
          const { error: directError } = await supabaseAdmin.from("_sql").select("*").eq("query", sql).limit(1)

          if (directError) {
            return NextResponse.json({ error: "Impossible de mettre à jour la contrainte de statut" }, { status: 500 })
          }
        } else {
          // Réessayer d'exécuter le SQL original
          const { error: retryError } = await supabaseAdmin.rpc("exec_sql", { sql_query: sql })

          if (retryError) {
            return NextResponse.json(
              { error: "Impossible de mettre à jour la contrainte de statut après création de la fonction" },
              { status: 500 },
            )
          }
        }
      } else {
        return NextResponse.json({ error: error.message }, { status: 500 })
      }
    }

    return NextResponse.json({
      message: "Contrainte de statut mise à jour avec succès!",
      sql: sql,
    })
  } catch (error: any) {
    console.error("Erreur lors de la mise à jour de la contrainte de statut:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

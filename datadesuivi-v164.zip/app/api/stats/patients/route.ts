import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabase"

export async function GET() {
  try {
    // Créer le client Supabase
    // Nous utilisons directement supabase sans vérification d'authentification côté serveur
    // car les politiques RLS de Supabase s'en chargeront

    // Récupérer tous les patients
    const { data: patients, error } = await supabase.from("patients").select("*")

    if (error) {
      console.error("Erreur lors de la récupération des patients:", error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    // Calculer les statistiques
    const total = patients.length
    const rdvs = patients.filter((p) => p.status === "rdv_programme").length

    // Compter par statut
    const statusCounts = {}
    patients.forEach((patient) => {
      const status = patient.status || "non_defini"
      statusCounts[status] = (statusCounts[status] || 0) + 1
    })

    const statuses = Object.entries(statusCounts).map(([status, count]) => ({
      status,
      count,
    }))

    // Compter par closer
    const closerCounts = {}
    patients.forEach((patient) => {
      if (patient.closer) {
        closerCounts[patient.closer] = (closerCounts[patient.closer] || 0) + 1
      }
    })

    const closers = Object.entries(closerCounts).map(([name, total]) => ({
      name,
      total,
    }))

    // Compter par médecin
    const doctorCounts = {}
    patients.forEach((patient) => {
      if (patient.doctor) {
        doctorCounts[patient.doctor] = (doctorCounts[patient.doctor] || 0) + 1
      }
    })

    const doctors = Object.entries(doctorCounts).map(([name, total]) => ({
      name,
      total,
    }))

    // Compter par plateforme de crédit
    const platformCounts = {}
    patients.forEach((patient) => {
      if (patient.platform) {
        platformCounts[patient.platform] = (platformCounts[patient.platform] || 0) + 1
      }
    })

    const creditPlatforms = Object.entries(platformCounts).map(([platform, total]) => ({
      platform,
      total,
    }))

    // Trier les données pour une meilleure présentation
    statuses.sort((a, b) => b.count - a.count)
    closers.sort((a, b) => b.total - a.total)
    doctors.sort((a, b) => b.total - a.total)
    creditPlatforms.sort((a, b) => b.total - a.total)

    return NextResponse.json({
      total,
      rdvs,
      statuses,
      closers,
      doctors,
      creditPlatforms,
    })
  } catch (error) {
    console.error("Erreur lors du calcul des statistiques:", error)
    return NextResponse.json({ error: "Erreur lors du calcul des statistiques" }, { status: 500 })
  }
}

"use client"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Cookies from "js-cookie"

export default function HomePage() {
  const router = useRouter()

  // Fonction pour définir un cookie d'authentification et accéder à l'application
  const accessApplication = (role: string) => {
    // Définir un cookie d'authentification
    Cookies.set("simpleAuth", JSON.stringify({ role, isAuthenticated: true }), { expires: 7 })

    // Rediriger vers le tableau de bord
    router.push("/dashboard")
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-neutral-50">
      <div className="w-full max-w-md px-4">
        <Card className="w-full shadow-lg border-t-4 border-t-primary-500">
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-primary-700 text-center">
              Accès d'urgence à l'application
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <p className="text-center text-gray-600">
              Cliquez sur l'un des boutons ci-dessous pour accéder directement à l'application:
            </p>

            <div className="grid grid-cols-2 gap-4">
              <Button onClick={() => accessApplication("admin")} className="w-full bg-blue-600 hover:bg-blue-700">
                Accéder en tant qu'Admin
              </Button>

              <Button onClick={() => accessApplication("closer")} className="w-full bg-green-600 hover:bg-green-700">
                Accéder en tant que Closer
              </Button>
            </div>

            <div className="text-center text-sm text-gray-500 mt-4">
              <p>Cette page contourne le système d'authentification normal.</p>
              <p>Utilisez-la uniquement pour accéder temporairement à l'application.</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { supabase } from "@/lib/supabase"
import { Loader2 } from "lucide-react"

export default function CreateExecSqlFunction() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const createFunction = async () => {
    setLoading(true)
    setResult(null)
    setError(null)

    try {
      // Create the exec_sql function
      const { error } = await supabase.rpc("create_exec_sql_function")

      if (error) {
        throw error
      }

      // If the function doesn't exist, create it manually
      const sql = `
      CREATE OR REPLACE FUNCTION exec_sql(sql_query TEXT) RETURNS VOID AS $$
      BEGIN
        EXECUTE sql_query;
      END;
      $$ LANGUAGE plpgsql SECURITY DEFINER;
      `

      const { error: execError } = await supabase.rpc("exec_sql", { sql_query: sql })

      if (execError) {
        // If the function doesn't exist yet, create it directly
        const { error: directError } = await supabase.from("_exec_sql").select("*").limit(1)

        if (directError) {
          const { error: createError } = await supabase.rpc("create_exec_sql_function")
          if (createError) throw createError
        }
      }

      setResult("Fonction exec_sql créée avec succès!")
    } catch (err: any) {
      console.error("Erreur lors de la création de la fonction:", err)
      setError(err.message || "Une erreur s'est produite")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-10">
      <Card>
        <CardHeader>
          <CardTitle>Création de la fonction exec_sql</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">
            Cette page va créer une fonction SQL qui permet d'exécuter des requêtes SQL dynamiques dans Supabase.
          </p>
          <Button onClick={createFunction} disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Création en cours...
              </>
            ) : (
              "Créer la fonction exec_sql"
            )}
          </Button>

          {result && <div className="mt-4 p-4 bg-green-100 text-green-800 rounded">{result}</div>}
          {error && <div className="mt-4 p-4 bg-red-100 text-red-800 rounded">{error}</div>}
        </CardContent>
      </Card>
    </div>
  )
}

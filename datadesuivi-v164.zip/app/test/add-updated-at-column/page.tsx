"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Loader2, CheckCircle, AlertTriangle } from "lucide-react"
import { supabase } from "@/lib/supabase"

export default function AddUpdatedAtColumnPage() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<{ success: boolean; message: string } | null>(null)

  async function addUpdatedAtColumn() {
    setLoading(true)
    setResult(null)

    try {
      // Vérifier si la colonne existe déjà
      const { data: columnExists, error: checkError } = await supabase.rpc("check_column_exists", {
        table_name: "patients",
        column_name: "updated_at",
      })

      if (checkError) {
        throw new Error(`Erreur lors de la vérification de la colonne: ${checkError.message}`)
      }

      if (columnExists) {
        setResult({
          success: true,
          message: "La colonne updated_at existe déjà dans la table patients.",
        })
        return
      }

      // Ajouter la colonne updated_at
      const { error: addError } = await supabase.rpc("exec_sql", {
        sql_query: `
          ALTER TABLE patients ADD COLUMN updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();
          UPDATE patients SET updated_at = created_at WHERE updated_at IS NULL;
        `,
      })

      if (addError) {
        throw new Error(`Erreur lors de l'ajout de la colonne: ${addError.message}`)
      }

      // Rafraîchir le cache du schéma
      const { error: refreshError } = await supabase.rpc("refresh_schema_cache")

      if (refreshError) {
        throw new Error(`Erreur lors du rafraîchissement du cache: ${refreshError.message}`)
      }

      setResult({
        success: true,
        message:
          "La colonne updated_at a été ajoutée avec succès à la table patients et le cache du schéma a été rafraîchi.",
      })
    } catch (error: any) {
      console.error("Erreur:", error)
      setResult({
        success: false,
        message: error.message || "Une erreur s'est produite lors de l'ajout de la colonne updated_at.",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-10">
      <Card className="max-w-md mx-auto">
        <CardHeader>
          <CardTitle>Ajouter la colonne updated_at</CardTitle>
          <CardDescription>
            Cette page vous permet d'ajouter la colonne updated_at à la table patients si elle n'existe pas déjà.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-gray-500 mb-4">
            Cette opération va vérifier si la colonne updated_at existe dans la table patients. Si elle n'existe pas,
            elle sera ajoutée avec la valeur par défaut NOW().
          </p>

          {result && (
            <Alert variant={result.success ? "default" : "destructive"} className="mt-4">
              {result.success ? <CheckCircle className="h-4 w-4" /> : <AlertTriangle className="h-4 w-4" />}
              <AlertTitle>{result.success ? "Succès" : "Erreur"}</AlertTitle>
              <AlertDescription>{result.message}</AlertDescription>
            </Alert>
          )}
        </CardContent>
        <CardFooter>
          <Button onClick={addUpdatedAtColumn} disabled={loading} className="w-full">
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Traitement en cours...
              </>
            ) : (
              "Ajouter la colonne updated_at"
            )}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

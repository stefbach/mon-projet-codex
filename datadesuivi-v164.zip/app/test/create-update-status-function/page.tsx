"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { supabase } from "@/lib/supabase"
import { Loader2 } from "lucide-react"

export default function CreateUpdateStatusFunction() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const createFunction = async () => {
    setLoading(true)
    setResult(null)
    setError(null)

    try {
      // SQL pour créer la fonction
      const sql = `
      -- Fonction pour créer une fonction temporaire qui met à jour la contrainte de statut
      CREATE OR REPLACE FUNCTION create_temp_update_function(function_name TEXT)
      RETURNS void AS $$
      BEGIN
        EXECUTE format('
          CREATE OR REPLACE FUNCTION %I()
          RETURNS void AS $func$
          BEGIN
            IF EXISTS (
              SELECT 1 FROM pg_constraint 
              WHERE conname = ''patients_status_check'' 
              AND conrelid = ''patients''::regclass
            ) THEN
              -- Supprimer la contrainte existante
              ALTER TABLE patients DROP CONSTRAINT patients_status_check;
            END IF;
            
            -- Ajouter la nouvelle contrainte avec no_show
            ALTER TABLE patients ADD CONSTRAINT patients_status_check 
              CHECK (status IN (''en_attente'', ''a_contacter'', ''rdv_programme'', ''vente'', ''perdu'', 
                              ''non_defini'', ''en_cours'', ''annule'', ''a_rappeler'', ''non_interesse'', ''no_show''));
          END;
          $func$ LANGUAGE plpgsql SECURITY DEFINER;
        ', function_name);
      END;
      $$ LANGUAGE plpgsql SECURITY DEFINER;

      -- Créer la fonction update_status_constraint
      SELECT create_temp_update_function('update_status_constraint');
      `

      // Exécuter le SQL directement
      const { error: sqlError } = await supabase.rpc("exec_sql", { sql_query: sql })

      if (sqlError) {
        // Si exec_sql échoue, essayer une autre approche
        const { error: directError } = await supabase.from("_direct_sql").select("*").limit(1)

        if (directError) {
          throw new Error(`Impossible d'exécuter le SQL: ${directError.message}`)
        }
      }

      // Tester la fonction
      const { error: testError } = await supabase.rpc("update_status_constraint")

      if (testError) {
        throw new Error(`La fonction a été créée mais son exécution a échoué: ${testError.message}`)
      }

      setResult("Fonction update_status_constraint créée et exécutée avec succès!")
    } catch (err: any) {
      console.error("Erreur lors de la création de la fonction:", err)
      setError(err.message || "Une erreur s'est produite")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-10">
      <Card>
        <CardHeader>
          <CardTitle>Création de la fonction update_status_constraint</CardTitle>
          <CardDescription>
            Cette page va créer une fonction qui permet de mettre à jour la contrainte de statut pour inclure "no_show".
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="mb-4">
            Cette opération va créer une fonction SQL qui permet de mettre à jour la contrainte de vérification sur la
            colonne "status" de la table "patients" pour accepter la valeur "no_show".
          </p>

          {result && <div className="mt-4 p-4 bg-green-100 text-green-800 rounded">{result}</div>}
          {error && <div className="mt-4 p-4 bg-red-100 text-red-800 rounded">{error}</div>}
        </CardContent>
        <CardFooter>
          <Button onClick={createFunction} disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Création en cours...
              </>
            ) : (
              "Créer et exécuter la fonction"
            )}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

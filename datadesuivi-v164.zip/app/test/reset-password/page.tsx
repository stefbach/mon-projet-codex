"use client"

import type React from "react"

import { useState } from "react"
import { supabase } from "@/lib/supabase"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2 } from "lucide-react"

export default function ResetPasswordPage() {
  const [email, setEmail] = useState("")
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)

  const [userId, setUserId] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [adminLoading, setAdminLoading] = useState(false)
  const [adminResult, setAdminResult] = useState<any>(null)

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setResult(null)

    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password-confirmation`,
      })

      if (error) {
        setResult({
          success: false,
          message: error.message,
          details: JSON.stringify(error, null, 2),
        })
      } else {
        setResult({
          success: true,
          message: `Email de réinitialisation envoyé à ${email}`,
          details: "Vérifiez votre boîte de réception pour le lien de réinitialisation.",
        })
      }
    } catch (error: any) {
      setResult({
        success: false,
        message: error.message,
        details: JSON.stringify(error, null, 2),
      })
    } finally {
      setLoading(false)
    }
  }

  const handleAdminResetPassword = async (e: React.FormEvent) => {
    e.preventDefault()
    setAdminLoading(true)
    setAdminResult(null)

    try {
      // Cette fonction nécessite des droits d'administrateur dans Supabase
      const { error } = await supabase.auth.admin.updateUserById(userId, {
        password: newPassword,
      })

      if (error) {
        setAdminResult({
          success: false,
          message: error.message,
          details: JSON.stringify(error, null, 2),
        })
      } else {
        setAdminResult({
          success: true,
          message: `Mot de passe réinitialisé pour l'utilisateur ${userId}`,
          details: "Le mot de passe a été modifié avec succès.",
        })
      }
    } catch (error: any) {
      setAdminResult({
        success: false,
        message: error.message,
        details: JSON.stringify(error, null, 2),
      })
    } finally {
      setAdminLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-10 space-y-8">
      <h1 className="text-2xl font-bold">Réinitialisation de mot de passe</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Réinitialiser par email</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleResetPassword} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
              </div>

              <Button type="submit" disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Envoi...
                  </>
                ) : (
                  "Envoyer l'email de réinitialisation"
                )}
              </Button>

              {result && (
                <div className={`mt-4 p-4 rounded-md ${result.success ? "bg-green-50" : "bg-red-50"}`}>
                  <p className={result.success ? "text-green-700" : "text-red-700"}>{result.message}</p>
                  <details className="mt-2">
                    <summary className="cursor-pointer text-sm">Détails techniques</summary>
                    <pre className="text-xs mt-2 p-2 bg-gray-100 rounded overflow-auto max-h-40">{result.details}</pre>
                  </details>
                </div>
              )}
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Réinitialiser par administrateur</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAdminResetPassword} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="userId">ID Utilisateur</Label>
                <Input id="userId" value={userId} onChange={(e) => setUserId(e.target.value)} required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="newPassword">Nouveau mot de passe (min. 6 caractères)</Label>
                <Input
                  id="newPassword"
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  required
                  minLength={6}
                />
              </div>

              <Button type="submit" disabled={adminLoading}>
                {adminLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Réinitialisation...
                  </>
                ) : (
                  "Réinitialiser le mot de passe"
                )}
              </Button>

              {adminResult && (
                <div className={`mt-4 p-4 rounded-md ${adminResult.success ? "bg-green-50" : "bg-red-50"}`}>
                  <p className={adminResult.success ? "text-green-700" : "text-red-700"}>{adminResult.message}</p>
                  <details className="mt-2">
                    <summary className="cursor-pointer text-sm">Détails techniques</summary>
                    <pre className="text-xs mt-2 p-2 bg-gray-100 rounded overflow-auto max-h-40">
                      {adminResult.details}
                    </pre>
                  </details>
                </div>
              )}
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

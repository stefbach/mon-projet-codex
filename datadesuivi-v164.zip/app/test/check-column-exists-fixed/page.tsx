"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { supabase } from "@/lib/supabase"

export default function CheckColumnExistsFixedPage() {
  const [tableName, setTableName] = useState("patients")
  const [columnName, setColumnName] = useState("full_name")
  const [result, setResult] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const checkColumnExists = async () => {
    setLoading(true)
    setError(null)
    try {
      // Utiliser la fonction RPC correcte
      const { data, error } = await supabase.rpc("check_column_exists_fixed", {
        p_table_name: tableName,
        p_column_name: columnName,
      })

      if (error) {
        throw error
      }

      setResult({
        exists: data,
        details: { exists: data },
      })
    } catch (err: any) {
      console.error("Erreur:", err)
      setError(err.message || "Une erreur est survenue")
      setResult(null)
    } finally {
      setLoading(false)
    }
  }

  // Alternative utilisant une requête SQL brute
  const checkColumnExistsRaw = async () => {
    setLoading(true)
    setError(null)
    try {
      // Utiliser une requête SQL brute pour accéder correctement à information_schema.columns
      const { data, error } = await supabase.rpc("exec_sql", {
        sql_query: `
          SELECT EXISTS (
            SELECT 1
            FROM information_schema.columns
            WHERE table_name = '${tableName}'
            AND column_name = '${columnName}'
          ) as exists
        `,
      })

      if (error) {
        throw error
      }

      setResult({
        exists: data?.[0]?.exists || false,
        details: data?.[0] || { exists: false },
      })
    } catch (err: any) {
      console.error("Erreur:", err)
      setError(err.message || "Une erreur est survenue")
      setResult(null)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-10">
      <Card>
        <CardHeader>
          <CardTitle>Vérifier l'existence d'une colonne (Corrigé)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Nom de la table</label>
              <Input value={tableName} onChange={(e) => setTableName(e.target.value)} placeholder="Nom de la table" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Nom de la colonne</label>
              <Input
                value={columnName}
                onChange={(e) => setColumnName(e.target.value)}
                placeholder="Nom de la colonne"
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={checkColumnExists} disabled={loading}>
                {loading ? "Vérification..." : "Vérifier avec RPC"}
              </Button>
              <Button onClick={checkColumnExistsRaw} disabled={loading} variant="outline">
                {loading ? "Vérification..." : "Vérifier avec SQL brut"}
              </Button>
            </div>

            {error && (
              <div className="mt-4 p-4 bg-red-50 text-red-700 rounded-md">
                <p className="font-semibold">Erreur:</p>
                <p>{error}</p>
              </div>
            )}

            {result && (
              <div className="mt-4 p-4 bg-gray-50 rounded-md">
                <p className="font-semibold">Résultat:</p>
                <p>
                  La colonne <code>{columnName}</code> dans la table <code>{tableName}</code>{" "}
                  {result.exists ? "existe" : "n'existe pas"}.
                </p>
                <pre className="mt-2 p-2 bg-gray-100 rounded overflow-auto">
                  {JSON.stringify(result.details, null, 2)}
                </pre>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

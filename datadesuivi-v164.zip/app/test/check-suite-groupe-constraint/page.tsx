"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { supabase } from "@/lib/supabase"
import { Loader2 } from "lucide-react"

export default function CheckSuiteGroupeConstraintPage() {
  const [constraint, setConstraint] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchConstraint = async () => {
    setLoading(true)
    setError(null)

    try {
      const { data, error } = await supabase.rpc("get_suite_groupe_constraint")

      if (error) {
        throw error
      }

      setConstraint(data)
    } catch (err: any) {
      console.error("Erreur lors de la récupération de la contrainte:", err)
      setError(err.message || "Une erreur est survenue lors de la récupération de la contrainte")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchConstraint()
  }, [])

  return (
    <div className="container mx-auto py-10">
      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle>Vérification de la contrainte suite_groupe</CardTitle>
          <CardDescription>
            Cette page affiche la définition actuelle de la contrainte de vérification sur la colonne suite_groupe de la
            table patients.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center p-8">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : error ? (
            <div className="bg-destructive/10 text-destructive p-4 rounded-md">
              <p className="font-medium">Erreur</p>
              <p>{error}</p>
            </div>
          ) : constraint ? (
            <div className="bg-muted p-4 rounded-md overflow-auto">
              <pre className="whitespace-pre-wrap">{constraint}</pre>
            </div>
          ) : (
            <p>Aucune contrainte trouvée pour la colonne suite_groupe.</p>
          )}

          <div className="mt-4">
            <Button onClick={fetchConstraint} disabled={loading}>
              {loading ? "Chargement..." : "Rafraîchir"}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

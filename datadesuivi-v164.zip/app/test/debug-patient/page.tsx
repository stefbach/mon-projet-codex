"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Loader2 } from "lucide-react"

export default function DebugPatientPage() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)
  const [patientData, setPatientData] = useState({
    name: "Patient Test",
    email: "patient@example.com",
    doctor: "Dr Test",
    consultationDate: "2023-05-15",
    income: "3500",
    expenses: "2000",
    creditScore: "720",
    creditPlatform: "Experian",
    loanAmount: "15000",
    simulationValidated: "Oui",
    platform: "Zopa",
    status: "En attente",
    loanRequested: "Oui",
    nextFollowUp: "2023-06-15",
    closer: "closer@email.com",
    comments: "Client test",
  })
  const [scriptUrl, setScriptUrl] = useState(
    "https://script.google.com/macros/s/AKfycbzoXMgXrF9tDU6Twfr5dr2qJB-bepbfybNzD0YxrxbWYaECCHOmQKTyvpxOLn-syS5U_w/exec",
  )

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setPatientData({ ...patientData, [name]: value })
  }

  const handleScriptUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setScriptUrl(e.target.value)
  }

  const testDirectFetch = async () => {
    setLoading(true)
    setResult(null)
    setError(null)

    try {
      // Utiliser URLSearchParams pour les requêtes GET
      const params = new URLSearchParams({
        action: "addPatient",
        ...patientData,
        timestamp: new Date().toISOString(),
      })

      const url = `${scriptUrl}?${params.toString()}`
      console.log("URL de requête:", url)

      try {
        // Essayer d'abord avec fetch normal
        const response = await fetch(url)
        const text = await response.text()
        console.log("Réponse brute:", text)

        try {
          const json = JSON.parse(text)
          setResult(json)
        } catch (e) {
          setResult({ rawText: text })
        }
      } catch (fetchError) {
        console.error("Erreur fetch standard:", fetchError)
        setError("Erreur fetch standard: " + (fetchError as Error).message)

        // Essayer avec no-cors comme fallback
        try {
          await fetch(url, { mode: "no-cors" })
          setResult({
            info: "Requête no-cors envoyée, mais la réponse ne peut pas être lue en raison des restrictions CORS",
          })
        } catch (noCorsError) {
          console.error("Erreur fetch no-cors:", noCorsError)
          setError("Erreur fetch no-cors: " + (noCorsError as Error).message)
        }
      }
    } catch (error) {
      console.error("Erreur lors du test:", error)
      setError("Erreur: " + (error as Error).message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-8">
      <Card>
        <CardHeader>
          <CardTitle>Débogage de l'ajout de patient</CardTitle>
          <CardDescription>
            Testez la connexion avec votre script Google Apps Script pour l'ajout de patient
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="scriptUrl">URL du script Google Apps Script</Label>
            <Input
              id="scriptUrl"
              value={scriptUrl}
              onChange={handleScriptUrlChange}
              placeholder="URL du script Google Apps Script"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nom</Label>
              <Input
                id="name"
                name="name"
                value={patientData.name}
                onChange={handleInputChange}
                placeholder="Nom du patient"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                name="email"
                value={patientData.email}
                onChange={handleInputChange}
                placeholder="Email du patient"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="doctor">Médecin</Label>
              <Input
                id="doctor"
                name="doctor"
                value={patientData.doctor}
                onChange={handleInputChange}
                placeholder="Médecin"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="consultationDate">Date de consultation</Label>
              <Input
                id="consultationDate"
                name="consultationDate"
                value={patientData.consultationDate}
                onChange={handleInputChange}
                placeholder="YYYY-MM-DD"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="income">Revenus</Label>
              <Input
                id="income"
                name="income"
                value={patientData.income}
                onChange={handleInputChange}
                placeholder="Revenus"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="expenses">Dépenses</Label>
              <Input
                id="expenses"
                name="expenses"
                value={patientData.expenses}
                onChange={handleInputChange}
                placeholder="Dépenses"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="creditScore">Score de crédit</Label>
              <Input
                id="creditScore"
                name="creditScore"
                value={patientData.creditScore}
                onChange={handleInputChange}
                placeholder="Score de crédit"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="creditPlatform">Plateforme de crédit</Label>
              <Input
                id="creditPlatform"
                name="creditPlatform"
                value={patientData.creditPlatform}
                onChange={handleInputChange}
                placeholder="Plateforme de crédit"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="loanAmount">Montant du prêt</Label>
              <Input
                id="loanAmount"
                name="loanAmount"
                value={patientData.loanAmount}
                onChange={handleInputChange}
                placeholder="Montant du prêt"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="simulationValidated">Simulation validée</Label>
              <Input
                id="simulationValidated"
                name="simulationValidated"
                value={patientData.simulationValidated}
                onChange={handleInputChange}
                placeholder="Oui/Non"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="platform">Plateforme</Label>
              <Input
                id="platform"
                name="platform"
                value={patientData.platform}
                onChange={handleInputChange}
                placeholder="Plateforme"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Statut</Label>
              <Input
                id="status"
                name="status"
                value={patientData.status}
                onChange={handleInputChange}
                placeholder="Statut"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="loanRequested">Prêt demandé</Label>
              <Input
                id="loanRequested"
                name="loanRequested"
                value={patientData.loanRequested}
                onChange={handleInputChange}
                placeholder="Oui/Non"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="nextFollowUp">Prochain suivi</Label>
              <Input
                id="nextFollowUp"
                name="nextFollowUp"
                value={patientData.nextFollowUp}
                onChange={handleInputChange}
                placeholder="YYYY-MM-DD"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="closer">Closer</Label>
              <Input
                id="closer"
                name="closer"
                value={patientData.closer}
                onChange={handleInputChange}
                placeholder="Email du closer"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="comments">Commentaires</Label>
            <textarea
              id="comments"
              name="comments"
              value={patientData.comments}
              onChange={handleInputChange}
              placeholder="Commentaires"
              className="w-full min-h-[100px] p-2 border rounded-md"
            />
          </div>

          <Button onClick={testDirectFetch} disabled={loading} className="w-full">
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Test en cours...
              </>
            ) : (
              "Tester l'ajout de patient"
            )}
          </Button>

          {error && (
            <div className="p-4 bg-red-50 border border-red-200 rounded-md text-red-600">
              <p className="font-semibold">Erreur:</p>
              <p>{error}</p>
            </div>
          )}

          {result && (
            <div className="p-4 bg-gray-50 border border-gray-200 rounded-md">
              <p className="font-semibold">Résultat:</p>
              <pre className="mt-2 whitespace-pre-wrap text-sm">{JSON.stringify(result, null, 2)}</pre>
            </div>
          )}

          <div className="p-4 bg-blue-50 border border-blue-200 rounded-md">
            <p className="font-semibold">Instructions:</p>
            <ol className="list-decimal list-inside space-y-2 mt-2">
              <li>
                Assurez-vous que votre script Google Apps Script est déployé en tant qu'application web et que l'URL est
                correcte.
              </li>
              <li>
                Vérifiez que votre script implémente correctement l'action "addPatient" et qu'il renvoie une réponse
                JSON.
              </li>
              <li>
                Si vous rencontrez des erreurs CORS, assurez-vous que votre script renvoie les en-têtes CORS appropriés
                ou qu'il prend en charge JSONP.
              </li>
              <li>
                Consultez les logs d'exécution de votre script Google Apps Script pour identifier les erreurs
                potentielles.
              </li>
            </ol>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { supabase } from "@/lib/supabase"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Loader2, CheckCircle, XCircle, Info } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function FixUserAuthPage() {
  const [formData, setFormData] = useState({
    email: "",
    name: "",
    password: "",
    role: "closer" as "admin" | "closer",
  })

  const [loginData, setLoginData] = useState({
    email: "",
    password: "",
  })

  const [loading, setLoading] = useState(false)
  const [loginLoading, setLoginLoading] = useState(false)
  const [result, setResult] = useState<{
    success?: boolean
    message?: string
    userId?: string
    details?: string
  } | null>(null)

  const [loginResult, setLoginResult] = useState<{
    success?: boolean
    message?: string
    userId?: string
    details?: string
  } | null>(null)

  const [usersList, setUsersList] = useState<any[]>([])
  const [loadingUsers, setLoadingUsers] = useState(false)
  const [activeTab, setActiveTab] = useState("create")

  useEffect(() => {
    if (activeTab === "list") {
      loadUsers()
    }
  }, [activeTab])

  const loadUsers = async () => {
    setLoadingUsers(true)
    try {
      // Récupérer les utilisateurs de Supabase Auth
      const { data: authUsers, error: authError } = await supabase.auth.admin.listUsers()

      if (authError) {
        console.error("Erreur lors de la récupération des utilisateurs Auth:", authError)
      }

      // Récupérer les utilisateurs de la table users
      const { data: dbUsers, error: dbError } = await supabase.from("users").select("*")

      if (dbError) {
        console.error("Erreur lors de la récupération des utilisateurs DB:", dbError)
      }

      // Combiner les données
      const combinedUsers =
        dbUsers?.map((dbUser) => {
          const authUser = authUsers?.users?.find((au) => au.id === dbUser.id)
          return {
            ...dbUser,
            auth_confirmed: authUser?.email_confirmed_at ? true : false,
            auth_created_at: authUser?.created_at,
            auth_last_sign_in: authUser?.last_sign_in_at,
          }
        }) || []

      setUsersList(combinedUsers)
    } catch (error) {
      console.error("Erreur lors du chargement des utilisateurs:", error)
    } finally {
      setLoadingUsers(false)
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleLoginChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setLoginData((prev) => ({ ...prev, [name]: value }))
  }

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setResult(null)

    try {
      console.log("Création d'un utilisateur avec:", formData)

      // 1. Créer l'utilisateur avec Supabase Auth
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: formData.email.trim(),
        password: formData.password,
        options: {
          data: {
            name: formData.name.trim(),
            role: formData.role,
          },
        },
      })

      if (authError) {
        console.error("Erreur lors de la création de l'utilisateur:", authError)
        setResult({
          success: false,
          message: `Erreur: ${authError.message}`,
          details: JSON.stringify(authError, null, 2),
        })
        return
      }

      if (!authData || !authData.user) {
        setResult({
          success: false,
          message: "Erreur: Aucune donnée utilisateur retournée",
        })
        return
      }

      console.log("Utilisateur créé dans Auth:", authData)

      // 2. Confirmer manuellement l'utilisateur
      const { error: confirmError } = await supabase.rpc("admin_confirm_user", {
        user_email: formData.email.trim(),
      })

      if (confirmError) {
        console.warn("Impossible de confirmer automatiquement l'utilisateur:", confirmError)
        setResult({
          success: true,
          message: `Utilisateur créé mais non confirmé: ${confirmError.message}`,
          userId: authData.user.id,
          details: "L'utilisateur a été créé mais n'a pas pu être confirmé automatiquement.",
        })
        return
      }

      console.log("Utilisateur confirmé automatiquement")

      // 3. Vérifier si l'utilisateur a été ajouté à la table users par le trigger
      const { data: userCheck, error: checkError } = await supabase
        .from("users")
        .select("*")
        .eq("id", authData.user.id)
        .single()

      if (checkError) {
        console.warn("L'utilisateur n'existe pas dans la table users:", checkError)

        // 4. Ajouter manuellement l'utilisateur à la table users si nécessaire
        const { error: insertError } = await supabase.from("users").insert([
          {
            id: authData.user.id,
            email: formData.email.trim(),
            name: formData.name.trim(),
            role: formData.role,
            active: true,
          },
        ])

        if (insertError) {
          console.error("Erreur lors de l'insertion dans la table users:", insertError)
          setResult({
            success: true,
            message: `Utilisateur créé et confirmé, mais non ajouté à la table users: ${insertError.message}`,
            userId: authData.user.id,
            details: "L'utilisateur a été créé dans Auth mais n'a pas pu être ajouté à la table users.",
          })
          return
        }

        console.log("Utilisateur ajouté manuellement à la table users")
      } else {
        console.log("Utilisateur déjà présent dans la table users:", userCheck)
      }

      setResult({
        success: true,
        message: `Utilisateur ${formData.email} créé avec succès et prêt à se connecter`,
        userId: authData.user.id,
        details: "L'utilisateur a été créé, confirmé et ajouté à la table users.",
      })

      // Réinitialiser le formulaire
      setFormData({
        email: "",
        name: "",
        password: "",
        role: "closer",
      })

      // Mettre à jour la liste des utilisateurs si on est sur cet onglet
      if (activeTab === "list") {
        loadUsers()
      }

      // Préremplir les données de connexion pour faciliter le test
      setLoginData({
        email: formData.email.trim(),
        password: formData.password,
      })
    } catch (error: any) {
      console.error("Erreur:", error)
      setResult({
        success: false,
        message: `Erreur: ${error.message || "Une erreur s'est produite"}`,
        details: JSON.stringify(error, null, 2),
      })
    } finally {
      setLoading(false)
    }
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoginLoading(true)
    setLoginResult(null)

    try {
      console.log("Tentative de connexion avec:", loginData)

      // Utiliser Supabase Auth pour la connexion
      const { data, error } = await supabase.auth.signInWithPassword({
        email: loginData.email.trim(),
        password: loginData.password,
      })

      if (error) {
        console.error("Erreur lors de la connexion:", error)
        setLoginResult({
          success: false,
          message: `Erreur: ${error.message}`,
          details: JSON.stringify(error, null, 2),
        })
        return
      }

      if (!data || !data.user) {
        setLoginResult({
          success: false,
          message: "Erreur: Aucune donnée utilisateur retournée",
        })
        return
      }

      console.log("Connexion réussie:", data)

      setLoginResult({
        success: true,
        message: `Connexion réussie pour ${loginData.email}`,
        userId: data.user.id,
        details: `Session valide jusqu'au ${new Date(data.session?.expires_at || 0).toLocaleString()}`,
      })
    } catch (error: any) {
      console.error("Erreur lors de la connexion:", error)
      setLoginResult({
        success: false,
        message: `Erreur: ${error.message || "Une erreur s'est produite"}`,
        details: JSON.stringify(error, null, 2),
      })
    } finally {
      setLoginLoading(false)
    }
  }

  const confirmUser = async (email: string) => {
    try {
      const { error } = await supabase.rpc("admin_confirm_user", {
        user_email: email,
      })

      if (error) {
        console.error("Erreur lors de la confirmation de l'utilisateur:", error)
        alert(`Erreur: ${error.message}`)
        return
      }

      alert(`Utilisateur ${email} confirmé avec succès`)
      loadUsers()
    } catch (error: any) {
      console.error("Erreur:", error)
      alert(`Erreur: ${error.message || "Une erreur s'est produite"}`)
    }
  }

  const resetPassword = async (email: string) => {
    try {
      const newPassword = prompt("Entrez le nouveau mot de passe (min. 6 caractères):")

      if (!newPassword || newPassword.length < 6) {
        alert("Le mot de passe doit contenir au moins 6 caractères")
        return
      }

      // Récupérer l'ID de l'utilisateur
      const { data: userData, error: userError } = await supabase.from("users").select("id").eq("email", email).single()

      if (userError || !userData) {
        alert(`Erreur: Impossible de trouver l'utilisateur`)
        return
      }

      // Réinitialiser le mot de passe via l'API admin
      const { error } = await supabase.auth.admin.updateUserById(userData.id, { password: newPassword })

      if (error) {
        console.error("Erreur lors de la réinitialisation du mot de passe:", error)
        alert(`Erreur: ${error.message}`)
        return
      }

      alert(`Mot de passe réinitialisé pour ${email}`)
    } catch (error: any) {
      console.error("Erreur:", error)
      alert(`Erreur: ${error.message || "Une erreur s'est produite"}`)
    }
  }

  return (
    <div className="container mx-auto py-10">
      <h1 className="text-2xl font-bold mb-6">Outil de diagnostic et réparation des utilisateurs</h1>

      <Alert className="mb-6">
        <Info className="h-4 w-4" />
        <AlertTitle>Information</AlertTitle>
        <AlertDescription>
          Cet outil vous permet de créer des utilisateurs, tester la connexion et gérer les utilisateurs existants. Il
          est conçu pour diagnostiquer et résoudre les problèmes d'authentification.
        </AlertDescription>
      </Alert>

      <Tabs defaultValue="create" onValueChange={setActiveTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="create">Créer un utilisateur</TabsTrigger>
          <TabsTrigger value="login">Tester la connexion</TabsTrigger>
          <TabsTrigger value="list">Gérer les utilisateurs</TabsTrigger>
        </TabsList>

        <TabsContent value="create">
          <Card>
            <CardHeader>
              <CardTitle>Créer un nouvel utilisateur</CardTitle>
              <CardDescription>
                Créez un utilisateur avec confirmation automatique pour tester la connexion
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleCreateUser} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    required
                    placeholder="utilisateur@exemple.com"
                    value={formData.email}
                    onChange={handleChange}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="name">Nom</Label>
                  <Input
                    id="name"
                    name="name"
                    required
                    placeholder="Nom de l'utilisateur"
                    value={formData.name}
                    onChange={handleChange}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">Mot de passe (min. 6 caractères)</Label>
                  <Input
                    id="password"
                    name="password"
                    type="password"
                    required
                    placeholder="Mot de passe"
                    value={formData.password}
                    onChange={handleChange}
                    minLength={6}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Rôle</Label>
                  <div className="flex space-x-4">
                    <div className="flex items-center">
                      <input
                        type="radio"
                        id="role-admin"
                        name="role"
                        value="admin"
                        checked={formData.role === "admin"}
                        onChange={() => setFormData((prev) => ({ ...prev, role: "admin" }))}
                        className="mr-2"
                      />
                      <Label htmlFor="role-admin">Administrateur</Label>
                    </div>
                    <div className="flex items-center">
                      <input
                        type="radio"
                        id="role-closer"
                        name="role"
                        value="closer"
                        checked={formData.role === "closer"}
                        onChange={() => setFormData((prev) => ({ ...prev, role: "closer" }))}
                        className="mr-2"
                      />
                      <Label htmlFor="role-closer">Closer</Label>
                    </div>
                  </div>
                </div>

                {result && (
                  <div
                    className={`p-4 rounded-md ${result.success ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"}`}
                  >
                    <div className="flex items-center">
                      {result.success ? (
                        <CheckCircle className="h-5 w-5 mr-2 text-green-500" />
                      ) : (
                        <XCircle className="h-5 w-5 mr-2 text-red-500" />
                      )}
                      <p>{result.message}</p>
                    </div>
                    {result.userId && <p className="mt-2 text-sm">ID utilisateur: {result.userId}</p>}
                    {result.details && (
                      <div className="mt-2 text-sm p-2 bg-gray-100 rounded">
                        <pre className="whitespace-pre-wrap">{result.details}</pre>
                      </div>
                    )}
                  </div>
                )}

                <Button type="submit" disabled={loading} className="w-full">
                  {loading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Création en cours...
                    </>
                  ) : (
                    "Créer l'utilisateur"
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="login">
          <Card>
            <CardHeader>
              <CardTitle>Tester la connexion</CardTitle>
              <CardDescription>Testez la connexion avec un utilisateur existant</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="login-email">Email</Label>
                  <Input
                    id="login-email"
                    name="email"
                    type="email"
                    required
                    placeholder="utilisateur@exemple.com"
                    value={loginData.email}
                    onChange={handleLoginChange}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="login-password">Mot de passe</Label>
                  <Input
                    id="login-password"
                    name="password"
                    type="password"
                    required
                    placeholder="Mot de passe"
                    value={loginData.password}
                    onChange={handleLoginChange}
                  />
                </div>

                {loginResult && (
                  <div
                    className={`p-4 rounded-md ${loginResult.success ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"}`}
                  >
                    <div className="flex items-center">
                      {loginResult.success ? (
                        <CheckCircle className="h-5 w-5 mr-2 text-green-500" />
                      ) : (
                        <XCircle className="h-5 w-5 mr-2 text-red-500" />
                      )}
                      <p>{loginResult.message}</p>
                    </div>
                    {loginResult.userId && <p className="mt-2 text-sm">ID utilisateur: {loginResult.userId}</p>}
                    {loginResult.details && (
                      <div className="mt-2 text-sm p-2 bg-gray-100 rounded">
                        <pre className="whitespace-pre-wrap">{loginResult.details}</pre>
                      </div>
                    )}
                  </div>
                )}

                <Button type="submit" disabled={loginLoading} className="w-full">
                  {loginLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Connexion en cours...
                    </>
                  ) : (
                    "Se connecter"
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="list">
          <Card>
            <CardHeader>
              <CardTitle>Gérer les utilisateurs</CardTitle>
              <CardDescription>Liste des utilisateurs existants</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <Button onClick={loadUsers} disabled={loadingUsers} variant="outline" size="sm">
                  {loadingUsers ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Chargement...
                    </>
                  ) : (
                    "Actualiser la liste"
                  )}
                </Button>
              </div>

              {loadingUsers ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin" />
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="bg-gray-100">
                        <th className="border p-2 text-left">Email</th>
                        <th className="border p-2 text-left">Nom</th>
                        <th className="border p-2 text-left">Rôle</th>
                        <th className="border p-2 text-left">Statut</th>
                        <th className="border p-2 text-left">Confirmé</th>
                        <th className="border p-2 text-left">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {usersList.length > 0 ? (
                        usersList.map((user) => (
                          <tr key={user.id} className="border-b hover:bg-gray-50">
                            <td className="border p-2">{user.email}</td>
                            <td className="border p-2">{user.name}</td>
                            <td className="border p-2">{user.role}</td>
                            <td className="border p-2">
                              <span
                                className={`px-2 py-1 rounded-full text-xs ${user.active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`}
                              >
                                {user.active ? "Actif" : "Inactif"}
                              </span>
                            </td>
                            <td className="border p-2">
                              <span
                                className={`px-2 py-1 rounded-full text-xs ${user.auth_confirmed ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`}
                              >
                                {user.auth_confirmed ? "Confirmé" : "Non confirmé"}
                              </span>
                            </td>
                            <td className="border p-2">
                              <div className="flex space-x-2">
                                {!user.auth_confirmed && (
                                  <Button onClick={() => confirmUser(user.email)} variant="outline" size="sm">
                                    Confirmer
                                  </Button>
                                )}
                                <Button onClick={() => resetPassword(user.email)} variant="outline" size="sm">
                                  Réinitialiser MDP
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={6} className="border p-4 text-center text-gray-500">
                            Aucun utilisateur trouvé
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

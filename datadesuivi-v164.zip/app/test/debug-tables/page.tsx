"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { debugSupabaseTables, debugClosers, createRpcFunctions } from "@/lib/debug-supabase"

export default function DebugTablesPage() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [closers, setClosers] = useState<any[]>([])

  async function handleDebugTables() {
    setLoading(true)
    try {
      const data = await debugSupabaseTables()
      setResult(data)
    } catch (error) {
      console.error("Erreur:", error)
    } finally {
      setLoading(false)
    }
  }

  async function handleDebugClosers() {
    setLoading(true)
    try {
      const data = await debugClosers()
      if (data) {
        setClosers(data)
      }
    } catch (error) {
      console.error("Erreur:", error)
    } finally {
      setLoading(false)
    }
  }

  async function handleCreateRpcFunctions() {
    setLoading(true)
    try {
      await createRpcFunctions()
    } catch (error) {
      console.error("Erreur:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-6">Débogage des tables Supabase</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <Card>
          <CardHeader>
            <CardTitle>Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button onClick={handleCreateRpcFunctions} disabled={loading}>
              Créer les fonctions RPC
            </Button>

            <Button onClick={handleDebugTables} disabled={loading} className="ml-4">
              Déboguer les tables
            </Button>

            <Button onClick={handleDebugClosers} disabled={loading} className="ml-4">
              Déboguer les closers
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Closers disponibles</CardTitle>
          </CardHeader>
          <CardContent>
            {closers.length > 0 ? (
              <ul className="space-y-2">
                {closers.map((closer) => (
                  <li key={closer.id} className="border-b pb-2">
                    <div>
                      <strong>ID:</strong> {closer.id}
                    </div>
                    <div>
                      <strong>Nom:</strong> {closer.full_name}
                    </div>
                    <div>
                      <strong>Email:</strong> {closer.email}
                    </div>
                    <div>
                      <strong>Rôle:</strong> {closer.role}
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <p>Aucun closer trouvé ou cliquez sur "Déboguer les closers"</p>
            )}
          </CardContent>
        </Card>
      </div>

      {result && (
        <Card>
          <CardHeader>
            <CardTitle>Résultat du débogage</CardTitle>
          </CardHeader>
          <CardContent>
            <pre className="bg-gray-100 p-4 rounded overflow-auto max-h-96">{JSON.stringify(result, null, 2)}</pre>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

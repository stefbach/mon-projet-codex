"use client"

import { useState } from "react"
import { supabase } from "@/lib/supabase"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2 } from "lucide-react"

// Emails prédéfinis pour chaque rôle
const ROLE_EMAILS = {
  admin: "admin@obesitycareclinic.com",
  closer: "closer@obesitycareclinic.com",
}

export default function SetupRoleAccountsPage() {
  const [adminPassword, setAdminPassword] = useState("")
  const [closerPassword, setCloserPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)

  const setupRoleAccounts = async () => {
    setLoading(true)
    setResult(null)

    try {
      // Créer ou mettre à jour le compte admin
      const adminResult = await createOrUpdateAccount("admin", adminPassword)

      // Créer ou mettre à jour le compte closer
      const closerResult = await createOrUpdateAccount("closer", closerPassword)

      setResult({
        success: adminResult.success && closerResult.success,
        message: "Configuration des comptes terminée",
        details: {
          admin: adminResult,
          closer: closerResult,
        },
      })
    } catch (error: any) {
      setResult({
        success: false,
        message: "Erreur lors de la configuration des comptes",
        error: error.message,
      })
    } finally {
      setLoading(false)
    }
  }

  const createOrUpdateAccount = async (role: "admin" | "closer", password: string) => {
    const email = ROLE_EMAILS[role]

    // Vérifier si l'utilisateur existe déjà
    const { data: existingUsers } = await supabase.auth.admin.listUsers({
      filter: {
        email: email,
      },
    })

    if (existingUsers && existingUsers.users.length > 0) {
      // Mettre à jour le mot de passe de l'utilisateur existant
      const userId = existingUsers.users[0].id
      const { error: updateError } = await supabase.auth.admin.updateUserById(userId, {
        password: password,
      })

      if (updateError) {
        return {
          success: false,
          message: `Erreur lors de la mise à jour du mot de passe pour ${role}`,
          error: updateError.message,
        }
      }

      return {
        success: true,
        message: `Mot de passe mis à jour pour ${role}`,
        userId: userId,
      }
    } else {
      // Créer un nouvel utilisateur
      const { data, error } = await supabase.auth.admin.createUser({
        email: email,
        password: password,
        email_confirm: true,
        user_metadata: { role: role },
      })

      if (error) {
        // Si l'API admin n'est pas disponible, essayer avec l'API standard
        const { data: standardData, error: standardError } = await supabase.auth.signUp({
          email: email,
          password: password,
          options: {
            data: { role: role },
          },
        })

        if (standardError) {
          return {
            success: false,
            message: `Erreur lors de la création du compte ${role}`,
            error: standardError.message,
          }
        }

        // Confirmer manuellement l'utilisateur
        await supabase.rpc("confirm_user", { email_to_confirm: email })

        return {
          success: true,
          message: `Compte ${role} créé avec succès (API standard)`,
          userId: standardData.user?.id,
        }
      }

      return {
        success: true,
        message: `Compte ${role} créé avec succès (API admin)`,
        userId: data.user.id,
      }
    }
  }

  return (
    <div className="container mx-auto py-10">
      <h1 className="text-2xl font-bold mb-6">Configuration des comptes par rôle</h1>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Configurer les comptes</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="adminPassword">Mot de passe Admin</Label>
            <Input
              id="adminPassword"
              type="password"
              value={adminPassword}
              onChange={(e) => setAdminPassword(e.target.value)}
              placeholder="Mot de passe pour le compte admin"
              minLength={6}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="closerPassword">Mot de passe Closer</Label>
            <Input
              id="closerPassword"
              type="password"
              value={closerPassword}
              onChange={(e) => setCloserPassword(e.target.value)}
              placeholder="Mot de passe pour le compte closer"
              minLength={6}
            />
          </div>

          <Button
            onClick={setupRoleAccounts}
            disabled={loading || !adminPassword || !closerPassword}
            className="w-full"
          >
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Configuration en cours...
              </>
            ) : (
              "Configurer les comptes"
            )}
          </Button>

          {result && (
            <div className={`mt-4 p-4 rounded-md ${result.success ? "bg-green-50" : "bg-red-50"}`}>
              <p className={result.success ? "text-green-700" : "text-red-700"}>{result.message}</p>
              <details className="mt-2">
                <summary className="cursor-pointer text-sm">Détails techniques</summary>
                <pre className="text-xs mt-2 p-2 bg-gray-100 rounded overflow-auto max-h-40">
                  {JSON.stringify(result.details || result.error, null, 2)}
                </pre>
              </details>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="bg-blue-50 p-4 rounded-md">
        <h2 className="text-lg font-semibold text-blue-700 mb-2">Instructions</h2>
        <p className="text-blue-700 mb-2">
          Cette page vous permet de configurer les comptes par rôle pour votre application:
        </p>
        <ul className="list-disc list-inside text-blue-700 space-y-1">
          <li>
            <strong>Admin:</strong> Utilisera l'email {ROLE_EMAILS.admin} avec le mot de passe que vous définissez
          </li>
          <li>
            <strong>Closer:</strong> Utilisera l'email {ROLE_EMAILS.closer} avec le mot de passe que vous définissez
          </li>
        </ul>
        <p className="text-blue-700 mt-2">
          Une fois configurés, les utilisateurs pourront se connecter en sélectionnant leur rôle et en entrant le mot de
          passe correspondant.
        </p>
      </div>
    </div>
  )
}

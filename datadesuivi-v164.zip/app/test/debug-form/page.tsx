"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Loader2 } from "lucide-react"

export default function DebugFormPage() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<string>("")
  const [scriptUrl, setScriptUrl] = useState(
    process.env.NEXT_PUBLIC_PATIENT_SCRIPT_URL ||
      "https://script.google.com/macros/s/AKfycbzoXMgXrF9tDU6Twfr5dr2qJB-bepbfybNzD0YxrxbWYaECCHOmQKTyvpxOLn-syS5U_w/exec",
  )

  const [formData, setFormData] = useState({
    name: "Patient Test",
    email: "patient@example.com",
    doctor: "Dr Test",
    consultationDate: "2023-05-15",
    income: "3500",
    expenses: "2000",
    creditScore: "720",
    creditPlatform: "Experian",
    loanAmount: "15000",
    simulationValidated: "Oui",
    platform: "Zopa",
    status: "En attente",
    loanRequested: "Non",
    nextFollowUp: "2023-06-15",
    comments: "Test de formulaire",
    closer: "test@example.com",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setResult("")

    try {
      // Construire l'URL avec les paramètres
      const params = new URLSearchParams({
        action: "addPatient",
        ...formData,
        timestamp: new Date().toISOString(),
      })

      const url = `${scriptUrl}?${params.toString()}`
      setResult(`Envoi de la requête à: ${url}\n\n`)

      // Utiliser l'API fetch pour envoyer la requête
      const response = await fetch(url, {
        method: "GET",
        mode: "no-cors", // Important pour éviter les problèmes CORS
      })

      setResult((prev) => prev + "Requête envoyée avec succès!\n\n")
      setResult((prev) => prev + "Note: En raison du mode 'no-cors', nous ne pouvons pas voir la réponse du serveur.\n")
      setResult((prev) => prev + "Vérifiez votre feuille Google Sheets pour voir si les données ont été ajoutées.")
    } catch (error) {
      console.error("Erreur lors de l'envoi:", error)
      setResult((prev) => prev + `Erreur: ${(error as Error).message}`)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-8">
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Formulaire de test complet</CardTitle>
          <CardDescription>
            Ce formulaire envoie directement les données au script Google Apps Script sans passer par les services de
            l'application.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <Label htmlFor="scriptUrl">URL du script Google Apps Script</Label>
            <Input id="scriptUrl" value={scriptUrl} onChange={(e) => setScriptUrl(e.target.value)} className="mb-4" />
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Informations personnelles */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Informations personnelles</h3>

                <div className="space-y-2">
                  <Label htmlFor="name">Nom complet</Label>
                  <Input id="name" name="name" value={formData.name} onChange={handleChange} />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="doctor">Médecin</Label>
                  <Input id="doctor" name="doctor" value={formData.doctor} onChange={handleChange} />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="consultationDate">Date de consultation</Label>
                  <Input
                    id="consultationDate"
                    name="consultationDate"
                    type="date"
                    value={formData.consultationDate}
                    onChange={handleChange}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="closer">Closer</Label>
                  <Input id="closer" name="closer" value={formData.closer} onChange={handleChange} />
                </div>
              </div>

              {/* Informations financières */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Informations financières</h3>

                <div className="space-y-2">
                  <Label htmlFor="income">Revenus (€)</Label>
                  <Input id="income" name="income" value={formData.income} onChange={handleChange} />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="expenses">Dépenses (€)</Label>
                  <Input id="expenses" name="expenses" value={formData.expenses} onChange={handleChange} />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="creditScore">Score de crédit</Label>
                  <Input id="creditScore" name="creditScore" value={formData.creditScore} onChange={handleChange} />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="creditPlatform">Plateforme de crédit</Label>
                  <Input
                    id="creditPlatform"
                    name="creditPlatform"
                    value={formData.creditPlatform}
                    onChange={handleChange}
                  />
                </div>
              </div>
            </div>

            {/* Informations de prêt */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium">Informations de prêt</h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="loanAmount">Montant du prêt (€)</Label>
                  <Input id="loanAmount" name="loanAmount" value={formData.loanAmount} onChange={handleChange} />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="simulationValidated">Simulation validée</Label>
                  <Input
                    id="simulationValidated"
                    name="simulationValidated"
                    value={formData.simulationValidated}
                    onChange={handleChange}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="platform">Plateforme de prêt</Label>
                  <Input id="platform" name="platform" value={formData.platform} onChange={handleChange} />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="status">Statut</Label>
                  <Input id="status" name="status" value={formData.status} onChange={handleChange} />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="loanRequested">Prêt demandé</Label>
                  <Input
                    id="loanRequested"
                    name="loanRequested"
                    value={formData.loanRequested}
                    onChange={handleChange}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="nextFollowUp">Prochain suivi</Label>
                  <Input
                    id="nextFollowUp"
                    name="nextFollowUp"
                    type="date"
                    value={formData.nextFollowUp}
                    onChange={handleChange}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="comments">Commentaires</Label>
                <Textarea id="comments" name="comments" value={formData.comments} onChange={handleChange} rows={4} />
              </div>
            </div>

            <Button type="submit" disabled={loading} className="w-full">
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Envoi en cours...
                </>
              ) : (
                "Envoyer"
              )}
            </Button>

            {result && (
              <div className="mt-4 p-4 bg-gray-100 rounded-md">
                <pre className="whitespace-pre-wrap text-sm">{result}</pre>
              </div>
            )}
          </form>
        </CardContent>
      </Card>
    </div>
  )
}

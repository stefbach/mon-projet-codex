"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { supabase } from "@/lib/supabase"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"

export default function EmailPasswordLoginTest() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [existingUsers, setExistingUsers] = useState<any[]>([])
  const [loadingUsers, setLoadingUsers] = useState(false)

  // Charger les utilisateurs existants au chargement de la page
  useEffect(() => {
    loadUsers()
  }, [])

  const loadUsers = async () => {
    setLoadingUsers(true)
    try {
      // Récupérer les utilisateurs depuis la table auth.users via une fonction RPC
      const { data, error } = await supabase.rpc("get_all_users")

      if (error) {
        console.error("Erreur lors du chargement des utilisateurs:", error)
        return
      }

      setExistingUsers(data || [])
    } catch (err) {
      console.error("Erreur:", err)
    } finally {
      setLoadingUsers(false)
    }
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setResult(null)

    try {
      console.log(`Tentative de connexion avec email: ${email} et mot de passe: ${password.replace(/./g, "*")}`)

      // Connexion avec email et mot de passe
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (error) {
        throw error
      }

      setResult({
        success: true,
        message: `Connexion réussie pour ${data.user.email}`,
        user: data.user,
        session: data.session,
      })

      console.log("Connexion réussie:", data)
    } catch (error) {
      console.error("Erreur de connexion:", error)

      setResult({
        success: false,
        message: error.message,
        details: JSON.stringify(error, null, 2),
      })
    } finally {
      setLoading(false)
    }
  }

  const selectUser = (user: any) => {
    setEmail(user.email)
    // Ne pas définir le mot de passe car nous ne le connaissons pas
  }

  return (
    <div className="container mx-auto py-10">
      <h1 className="text-2xl font-bold mb-6">Test de connexion avec Email et Mot de passe</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Connexion</CardTitle>
            <CardDescription>Connectez-vous avec votre email et mot de passe</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Mot de passe</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>

              <Button type="submit" disabled={loading}>
                {loading ? "Connexion..." : "Se connecter"}
              </Button>

              {result && (
                <Alert className={result.success ? "bg-green-50" : "bg-red-50"}>
                  <AlertDescription className={result.success ? "text-green-700" : "text-red-700"}>
                    {result.message}

                    {result.success && result.user && (
                      <div className="mt-2">
                        <p>
                          <strong>ID:</strong> {result.user.id}
                        </p>
                        <p>
                          <strong>Email:</strong> {result.user.email}
                        </p>
                        <p>
                          <strong>Rôle:</strong> {result.user.role || "Non défini"}
                        </p>
                      </div>
                    )}

                    {!result.success && (
                      <details className="mt-2">
                        <summary className="cursor-pointer">Détails de l'erreur</summary>
                        <pre className="text-xs mt-2 p-2 bg-gray-100 rounded overflow-auto max-h-40">
                          {result.details}
                        </pre>
                      </details>
                    )}
                  </AlertDescription>
                </Alert>
              )}
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Utilisateurs existants</CardTitle>
            <CardDescription>Sélectionnez un utilisateur pour préremplir l'email</CardDescription>
          </CardHeader>
          <CardContent>
            {loadingUsers ? (
              <p>Chargement des utilisateurs...</p>
            ) : existingUsers.length > 0 ? (
              <div className="space-y-2">
                {existingUsers.map((user) => (
                  <div
                    key={user.id}
                    className="p-3 border rounded cursor-pointer hover:bg-gray-50"
                    onClick={() => selectUser(user)}
                  >
                    <p>
                      <strong>Email:</strong> {user.email}
                    </p>
                    <p>
                      <strong>Confirmé:</strong> {user.confirmed ? "Oui" : "Non"}
                    </p>
                    <p>
                      <strong>Créé le:</strong> {new Date(user.created_at).toLocaleString()}
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <p>Aucun utilisateur trouvé</p>
            )}

            <Button variant="outline" className="mt-4" onClick={loadUsers} disabled={loadingUsers}>
              Rafraîchir la liste
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

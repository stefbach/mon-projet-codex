"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { supabase } from "@/lib/supabase"
import { Loader2, CheckCircle, XCircle, Calendar } from "lucide-react"

export default function AddCreatedAtColumnPage() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<{ success: boolean; message: string } | null>(null)

  const checkColumnExists = async () => {
    try {
      setLoading(true)

      const { data, error } = await supabase.rpc("check_column_exists", {
        table_name: "patients",
        column_name: "created_at",
      })

      if (error) {
        throw error
      }

      return data
    } catch (error: any) {
      console.error("Erreur lors de la vérification de la colonne:", error)
      throw error
    } finally {
      setLoading(false)
    }
  }

  const addCreatedAtColumn = async () => {
    try {
      setLoading(true)
      setResult(null)

      // Vérifier d'abord si la colonne existe
      const columnExists = await checkColumnExists()

      if (columnExists) {
        setResult({
          success: true,
          message: "La colonne 'created_at' existe déjà dans la table 'patients'.",
        })
        return
      }

      // Ajouter la colonne
      const { data, error } = await supabase.rpc("add_created_at_column")

      if (error) {
        throw error
      }

      setResult({
        success: true,
        message: data || "Colonne 'created_at' ajoutée avec succès à la table 'patients'.",
      })
    } catch (error: any) {
      console.error("Erreur lors de l'ajout de la colonne:", error)
      setResult({
        success: false,
        message: `Erreur: ${error.message || "Une erreur s'est produite lors de l'ajout de la colonne."}`,
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-10">
      <Card className="max-w-md mx-auto">
        <CardHeader>
          <CardTitle>Ajouter la colonne 'created_at' à la table 'patients'</CardTitle>
          <CardDescription>
            Cette page vous permet d'ajouter la colonne 'created_at' à la table 'patients' dans votre base de données
            Supabase.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="mb-4 text-sm text-neutral-600">
            La colonne 'created_at' est utilisée pour stocker la date de création de chaque patient. Cette colonne est
            nécessaire pour le bon fonctionnement du tableau de bord et de la page des patients.
          </p>

          {result && (
            <div
              className={`p-4 rounded-md mb-4 ${result.success ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"}`}
            >
              <div className="flex items-center">
                {result.success ? (
                  <CheckCircle className="h-5 w-5 mr-2 text-green-500" />
                ) : (
                  <XCircle className="h-5 w-5 mr-2 text-red-500" />
                )}
                <p>{result.message}</p>
              </div>
            </div>
          )}
        </CardContent>
        <CardFooter>
          <Button onClick={addCreatedAtColumn} disabled={loading} className="w-full">
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Vérification...
              </>
            ) : (
              <>
                <Calendar className="mr-2 h-4 w-4" />
                Ajouter la colonne 'created_at'
              </>
            )}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

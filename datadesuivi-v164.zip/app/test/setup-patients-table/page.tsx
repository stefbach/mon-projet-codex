"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { supabase } from "@/lib/supabase"
import { Loader2 } from "lucide-react"

export default function SetupPatientsTable() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const setupTable = async () => {
    setLoading(true)
    setResult(null)
    setError(null)

    try {
      // Create the uuid-ossp extension if it doesn't exist
      await supabase.rpc("create_uuid_extension")

      // Execute the SQL from the migration file
      const sql = `
      -- Create patients table with updated field names
      CREATE TABLE IF NOT EXISTS public.patients (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        full_name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT,
        doctor TEXT,
        registration_date DATE,
        consultation_date DATE,
        revenue NUMERIC,
        expenses NUMERIC,
        credit_score INTEGER,
        credit_score_platform TEXT,
        loan_amount NUMERIC,
        loan_simulation_validated BOOLEAN DEFAULT false,
        loan_platform TEXT,
        loan_requested BOOLEAN DEFAULT false,
        assigned_closer TEXT,
        status TEXT DEFAULT 'En attente',
        next_follow_up DATE,
        comments TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      );

      -- Create an update trigger to set updated_at on row update
      CREATE OR REPLACE FUNCTION update_modified_column()
      RETURNS TRIGGER AS $$
      BEGIN
        NEW.updated_at = NOW();
        RETURN NEW;
      END;
      $$ LANGUAGE plpgsql;

      DROP TRIGGER IF EXISTS set_patients_updated_at ON patients;
      CREATE TRIGGER set_patients_updated_at
      BEFORE UPDATE ON patients
      FOR EACH ROW
      EXECUTE FUNCTION update_modified_column();
      `

      // Execute the SQL
      const { error } = await supabase.rpc("exec_sql", { sql_query: sql })

      if (error) {
        throw error
      }

      setResult("Table des patients créée avec succès!")
    } catch (err: any) {
      console.error("Erreur lors de la création de la table:", err)
      setError(err.message || "Une erreur s'est produite")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-10">
      <Card>
        <CardHeader>
          <CardTitle>Configuration de la table des patients</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">
            Cette page va créer la table des patients avec la structure mise à jour dans votre base de données Supabase.
          </p>
          <Button onClick={setupTable} disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Configuration en cours...
              </>
            ) : (
              "Configurer la table des patients"
            )}
          </Button>

          {result && <div className="mt-4 p-4 bg-green-100 text-green-800 rounded">{result}</div>}
          {error && <div className="mt-4 p-4 bg-red-100 text-red-800 rounded">{error}</div>}
        </CardContent>
      </Card>
    </div>
  )
}

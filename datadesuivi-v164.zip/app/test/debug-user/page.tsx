"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Loader2 } from "lucide-react"

export default function DebugUserPage() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)
  const [userData, setUserData] = useState({
    email: "test@example.com",
    name: "Test User",
    role: "closer" as "admin" | "closer",
    password: "password123",
  })
  const [scriptUrl, setScriptUrl] = useState(
    "https://script.google.com/macros/s/AKfycbxoKRN-Py4XlMqC9yiCXhT4iT6229V9VT-kHxaUvlqoGNgaOwW_HKTgbYD2qsy3I8WJ/exec",
  )

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setUserData({ ...userData, [name]: value })
  }

  const handleRoleChange = (value: "admin" | "closer") => {
    setUserData({ ...userData, role: value })
  }

  const handleScriptUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setScriptUrl(e.target.value)
  }

  const testDirectFetch = async () => {
    setLoading(true)
    setResult(null)
    setError(null)

    try {
      // Utiliser URLSearchParams pour les requêtes GET
      const params = new URLSearchParams({
        action: "createUser",
        email: userData.email,
        name: userData.name,
        role: userData.role,
        password: userData.password,
        active: "true",
      })

      const url = `${scriptUrl}?${params.toString()}`
      console.log("URL de requête:", url)

      try {
        // Essayer d'abord avec fetch normal
        const response = await fetch(url)
        const text = await response.text()
        console.log("Réponse brute:", text)

        try {
          const json = JSON.parse(text)
          setResult(json)
        } catch (e) {
          setResult({ rawText: text })
        }
      } catch (fetchError) {
        console.error("Erreur fetch standard:", fetchError)
        setError("Erreur fetch standard: " + (fetchError as Error).message)

        // Essayer avec no-cors comme fallback
        try {
          await fetch(url, { mode: "no-cors" })
          setResult({
            info: "Requête no-cors envoyée, mais la réponse ne peut pas être lue en raison des restrictions CORS",
          })
        } catch (noCorsError) {
          console.error("Erreur fetch no-cors:", noCorsError)
          setError("Erreur fetch no-cors: " + (noCorsError as Error).message)
        }
      }
    } catch (error) {
      console.error("Erreur lors du test:", error)
      setError("Erreur: " + (error as Error).message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-8">
      <Card>
        <CardHeader>
          <CardTitle>Débogage de la création d'utilisateur</CardTitle>
          <CardDescription>
            Testez la connexion avec votre script Google Apps Script pour la création d'utilisateur
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="scriptUrl">URL du script Google Apps Script</Label>
            <Input
              id="scriptUrl"
              value={scriptUrl}
              onChange={handleScriptUrlChange}
              placeholder="URL du script Google Apps Script"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              name="email"
              value={userData.email}
              onChange={handleInputChange}
              placeholder="Email de l'utilisateur"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="name">Nom</Label>
            <Input
              id="name"
              name="name"
              value={userData.name}
              onChange={handleInputChange}
              placeholder="Nom de l'utilisateur"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="password">Mot de passe</Label>
            <Input
              id="password"
              name="password"
              type="password"
              value={userData.password}
              onChange={handleInputChange}
              placeholder="Mot de passe"
            />
          </div>

          <div className="space-y-2">
            <Label>Rôle</Label>
            <RadioGroup value={userData.role} onValueChange={handleRoleChange as any}>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="admin" id="role-admin" />
                <Label htmlFor="role-admin">Administrateur</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="closer" id="role-closer" />
                <Label htmlFor="role-closer">Closer</Label>
              </div>
            </RadioGroup>
          </div>

          <Button onClick={testDirectFetch} disabled={loading} className="w-full">
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Test en cours...
              </>
            ) : (
              "Tester la connexion directe"
            )}
          </Button>

          {error && (
            <div className="p-4 bg-red-50 border border-red-200 rounded-md text-red-600">
              <p className="font-semibold">Erreur:</p>
              <p>{error}</p>
            </div>
          )}

          {result && (
            <div className="p-4 bg-gray-50 border border-gray-200 rounded-md">
              <p className="font-semibold">Résultat:</p>
              <pre className="mt-2 whitespace-pre-wrap text-sm">{JSON.stringify(result, null, 2)}</pre>
            </div>
          )}

          <div className="p-4 bg-blue-50 border border-blue-200 rounded-md">
            <p className="font-semibold">Instructions:</p>
            <ol className="list-decimal list-inside space-y-2 mt-2">
              <li>
                Assurez-vous que votre script Google Apps Script est déployé en tant qu'application web et que l'URL est
                correcte.
              </li>
              <li>
                Vérifiez que votre script implémente correctement l'action "createUser" et qu'il renvoie une réponse
                JSON.
              </li>
              <li>
                Si vous rencontrez des erreurs CORS, assurez-vous que votre script renvoie les en-têtes CORS appropriés
                ou qu'il prend en charge JSONP.
              </li>
              <li>
                Consultez les logs d'exécution de votre script Google Apps Script pour identifier les erreurs
                potentielles.
              </li>
            </ol>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

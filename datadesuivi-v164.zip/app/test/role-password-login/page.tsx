"use client"

import { useState, useEffect } from "react"
import { supabase } from "@/lib/supabase"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2 } from "lucide-react"

export default function RolePasswordLoginPage() {
  const [adminPassword, setAdminPassword] = useState("")
  const [closerPassword, setCloserPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [rolePasswords, setRolePasswords] = useState<any>(null)

  // Fonction pour configurer les mots de passe par rôle
  const setupRolePasswords = async () => {
    setLoading(true)
    try {
      // Créer ou mettre à jour les mots de passe par rôle
      const { error } = await supabase.from("role_passwords").upsert([
        { role: "admin", password: adminPassword },
        { role: "closer", password: closerPassword },
      ])

      if (error) throw error

      setResult({
        success: true,
        message: "Mots de passe par rôle configurés avec succès",
      })

      // Recharger les mots de passe
      loadRolePasswords()
    } catch (error) {
      setResult({
        success: false,
        message: "Erreur lors de la configuration des mots de passe",
        details: error.message,
      })
    } finally {
      setLoading(false)
    }
  }

  // Fonction pour charger les mots de passe par rôle
  const loadRolePasswords = async () => {
    try {
      const { data, error } = await supabase.from("role_passwords").select("*")
      if (error) throw error

      setRolePasswords(data)
    } catch (error) {
      console.error("Erreur lors du chargement des mots de passe:", error)
    }
  }

  // Fonction pour tester la connexion avec un mot de passe et un rôle
  const testLogin = async (role: string, password: string) => {
    setLoading(true)
    setResult(null)

    try {
      // Vérifier si le mot de passe correspond au rôle
      const { data, error } = await supabase
        .from("role_passwords")
        .select("*")
        .eq("role", role)
        .eq("password", password)
        .single()

      if (error || !data) {
        setResult({
          success: false,
          message: `Mot de passe incorrect pour le rôle ${role}`,
        })
        setLoading(false)
        return
      }

      // Créer un utilisateur temporaire pour ce rôle si nécessaire
      const email = `${role}@example.com`
      const tempPassword = "TemporaryPassword123!"

      // Vérifier si l'utilisateur existe déjà
      const { data: existingUser, error: userError } = await supabase.auth.signInWithPassword({
        email,
        password: tempPassword,
      })

      if (userError && userError.message.includes("Invalid login credentials")) {
        // L'utilisateur n'existe pas, le créer
        const { data: newUser, error: createError } = await supabase.auth.signUp({
          email,
          password: tempPassword,
          options: {
            data: {
              name: role.charAt(0).toUpperCase() + role.slice(1),
              role: role,
            },
          },
        })

        if (createError) throw createError

        // Confirmer l'utilisateur
        await supabase.rpc("confirm_user", { email_to_confirm: email })

        // Se connecter avec le nouvel utilisateur
        const { data: signInData, error: signInError } = await supabase.auth.signInWithPassword({
          email,
          password: tempPassword,
        })

        if (signInError) throw signInError

        setResult({
          success: true,
          message: `Connexion réussie en tant que ${role}`,
          user: signInData.user,
        })
      } else if (existingUser) {
        // L'utilisateur existe déjà, connexion réussie
        setResult({
          success: true,
          message: `Connexion réussie en tant que ${role}`,
          user: existingUser.user,
        })
      }
    } catch (error) {
      setResult({
        success: false,
        message: "Erreur lors de la connexion",
        details: error.message,
      })
    } finally {
      setLoading(false)
    }
  }

  // Charger les mots de passe au chargement de la page
  useEffect(() => {
    loadRolePasswords()
  }, [])

  return (
    <div className="container mx-auto py-10 space-y-8">
      <h1 className="text-2xl font-bold">Configuration et test de connexion par rôle</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Configurer les mots de passe par rôle</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="adminPassword">Mot de passe Admin</Label>
                <Input
                  id="adminPassword"
                  type="password"
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  placeholder="Entrez le mot de passe admin"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="closerPassword">Mot de passe Closer</Label>
                <Input
                  id="closerPassword"
                  type="password"
                  value={closerPassword}
                  onChange={(e) => setCloserPassword(e.target.value)}
                  placeholder="Entrez le mot de passe closer"
                />
              </div>

              <Button onClick={setupRolePasswords} disabled={loading || !adminPassword || !closerPassword}>
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Configuration...
                  </>
                ) : (
                  "Configurer les mots de passe"
                )}
              </Button>

              {result && (
                <div className={`mt-4 p-4 rounded-md ${result.success ? "bg-green-50" : "bg-red-50"}`}>
                  <p className={result.success ? "text-green-700" : "text-red-700"}>{result.message}</p>
                  {result.details && <p className="text-sm mt-2 text-gray-600">Détails: {result.details}</p>}
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Tester la connexion par rôle</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <Button
                  onClick={() => testLogin("admin", adminPassword)}
                  disabled={loading || !adminPassword}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  Tester Admin
                </Button>
                <Button
                  onClick={() => testLogin("closer", closerPassword)}
                  disabled={loading || !closerPassword}
                  className="bg-green-600 hover:bg-green-700"
                >
                  Tester Closer
                </Button>
              </div>

              {rolePasswords && (
                <div className="mt-4 border rounded-md p-4">
                  <h3 className="font-medium mb-2">Mots de passe actuels:</h3>
                  <ul className="space-y-1 text-sm">
                    {rolePasswords.map((item) => (
                      <li key={item.role}>
                        <span className="font-medium">{item.role}:</span> {item.password}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

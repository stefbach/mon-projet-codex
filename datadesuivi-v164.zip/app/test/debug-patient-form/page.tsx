"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Loader2 } from "lucide-react"
import { supabase } from "@/lib/supabase"

export default function DebugPatientForm() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [tableInfo, setTableInfo] = useState<any>(null)
  const [formData, setFormData] = useState({
    name: "Patient Test",
    email: `test${Date.now()}@example.com`,
    doctor: "Dr Test",
    status: "En attente",
    simulationValidated: "Oui",
    loanRequested: "Non",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleRadioChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setResult(null)

    try {
      // Préparation des données
      const dataToInsert = {
        name: formData.name,
        email: formData.email,
        doctor: formData.doctor,
        status: formData.status,
        simulation_validated: formData.simulationValidated === "Oui" ? true : false,
        loan_requested: formData.loanRequested === "Oui" ? true : false,
        closer: "debug@example.com",
      }

      console.log("Données à insérer:", dataToInsert)

      // Insertion directe dans Supabase
      const { data, error } = await supabase.from("patients").insert([dataToInsert])

      if (error) {
        setResult({
          success: false,
          message: `Erreur: ${error.message}`,
          error,
        })
      } else {
        setResult({
          success: true,
          message: "Patient ajouté avec succès",
          data,
        })
      }
    } catch (error: any) {
      setResult({
        success: false,
        message: `Exception: ${error.message}`,
        error,
      })
    } finally {
      setLoading(false)
    }
  }

  const checkTable = async () => {
    setLoading(true)
    setTableInfo(null)

    try {
      // Vérifier la structure de la table
      const { data: columns, error: columnsError } = await supabase
        .rpc("get_table_columns", { table_name: "patients" })
        .select("*")

      if (columnsError) {
        setTableInfo({
          success: false,
          message: `Erreur lors de la récupération des colonnes: ${columnsError.message}`,
          error: columnsError,
        })
        return
      }

      // Vérifier les politiques RLS
      const { data: policies, error: policiesError } = await supabase
        .rpc("get_table_policies", { table_name: "patients" })
        .select("*")

      if (policiesError) {
        setTableInfo({
          success: false,
          message: `Erreur lors de la récupération des politiques: ${policiesError.message}`,
          error: policiesError,
          columns,
        })
        return
      }

      // Vérifier si la table existe
      const { data: tableExists, error: tableError } = await supabase
        .from("patients")
        .select("count(*)", { count: "exact", head: true })

      if (tableError) {
        setTableInfo({
          success: false,
          message: `Erreur lors de la vérification de la table: ${tableError.message}`,
          error: tableError,
          columns,
          policies,
        })
        return
      }

      setTableInfo({
        success: true,
        message: "Informations sur la table récupérées avec succès",
        columns,
        policies,
        tableExists: tableError ? false : true,
        rowCount: tableExists,
      })
    } catch (error: any) {
      setTableInfo({
        success: false,
        message: `Exception: ${error.message}`,
        error,
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-6">Débogage du formulaire patient</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-4">Formulaire de test</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nom *</Label>
                <Input id="name" name="name" value={formData.name} onChange={handleChange} required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email *</Label>
                <Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="doctor">Médecin *</Label>
                <Input id="doctor" name="doctor" value={formData.doctor} onChange={handleChange} required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="status">Statut *</Label>
                <Input id="status" name="status" value={formData.status} onChange={handleChange} required />
              </div>

              <div className="space-y-2">
                <Label>Simulation validée</Label>
                <RadioGroup
                  value={formData.simulationValidated}
                  onValueChange={(value) => handleRadioChange("simulationValidated", value)}
                  className="flex space-x-4"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="Oui" id="sim-yes" />
                    <Label htmlFor="sim-yes">Oui</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="Non" id="sim-no" />
                    <Label htmlFor="sim-no">Non</Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <Label>Prêt demandé</Label>
                <RadioGroup
                  value={formData.loanRequested}
                  onValueChange={(value) => handleRadioChange("loanRequested", value)}
                  className="flex space-x-4"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="Oui" id="loan-yes" />
                    <Label htmlFor="loan-yes">Oui</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="Non" id="loan-no" />
                    <Label htmlFor="loan-no">Non</Label>
                  </div>
                </RadioGroup>
              </div>

              <Button type="submit" disabled={loading} className="w-full">
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Enregistrement...
                  </>
                ) : (
                  "Enregistrer le patient"
                )}
              </Button>
            </form>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-4">Vérifier la structure de la table</h2>
            <Button onClick={checkTable} disabled={loading} className="w-full">
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Vérification...
                </>
              ) : (
                "Vérifier la table patients"
              )}
            </Button>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-4">Résultat de l'insertion</h2>
            {result ? (
              <div className={`p-4 rounded-md ${result.success ? "bg-green-50" : "bg-red-50"}`}>
                <p className={`font-semibold ${result.success ? "text-green-700" : "text-red-700"}`}>
                  {result.message}
                </p>
                {result.error && (
                  <div className="mt-2">
                    <p className="font-semibold text-red-700">Détails de l'erreur:</p>
                    <pre className="mt-1 p-2 bg-gray-100 rounded text-xs overflow-auto">
                      {JSON.stringify(result.error, null, 2)}
                    </pre>
                  </div>
                )}
                {result.data && (
                  <div className="mt-2">
                    <p className="font-semibold text-green-700">Données insérées:</p>
                    <pre className="mt-1 p-2 bg-gray-100 rounded text-xs overflow-auto">
                      {JSON.stringify(result.data, null, 2)}
                    </pre>
                  </div>
                )}
              </div>
            ) : (
              <p className="text-gray-500">Aucun résultat à afficher</p>
            )}
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-4">Informations sur la table</h2>
            {tableInfo ? (
              <div className={`p-4 rounded-md ${tableInfo.success ? "bg-green-50" : "bg-red-50"}`}>
                <p className={`font-semibold ${tableInfo.success ? "text-green-700" : "text-red-700"}`}>
                  {tableInfo.message}
                </p>

                {tableInfo.columns && (
                  <div className="mt-4">
                    <p className="font-semibold text-gray-700">Colonnes de la table:</p>
                    <div className="mt-1 p-2 bg-gray-100 rounded text-xs overflow-auto max-h-60">
                      <table className="w-full">
                        <thead>
                          <tr className="border-b">
                            <th className="text-left p-1">Nom</th>
                            <th className="text-left p-1">Type</th>
                            <th className="text-left p-1">Nullable</th>
                          </tr>
                        </thead>
                        <tbody>
                          {tableInfo.columns.map((col: any, i: number) => (
                            <tr key={i} className="border-b">
                              <td className="p-1">{col.column_name}</td>
                              <td className="p-1">{col.data_type}</td>
                              <td className="p-1">{col.is_nullable ? "Oui" : "Non"}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {tableInfo.policies && (
                  <div className="mt-4">
                    <p className="font-semibold text-gray-700">Politiques RLS:</p>
                    <div className="mt-1 p-2 bg-gray-100 rounded text-xs overflow-auto max-h-60">
                      {tableInfo.policies.length > 0 ? (
                        <table className="w-full">
                          <thead>
                            <tr className="border-b">
                              <th className="text-left p-1">Nom</th>
                              <th className="text-left p-1">Action</th>
                              <th className="text-left p-1">Définition</th>
                            </tr>
                          </thead>
                          <tbody>
                            {tableInfo.policies.map((policy: any, i: number) => (
                              <tr key={i} className="border-b">
                                <td className="p-1">{policy.policy_name}</td>
                                <td className="p-1">{policy.operation}</td>
                                <td className="p-1">{policy.definition}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      ) : (
                        <p>Aucune politique RLS définie</p>
                      )}
                    </div>
                  </div>
                )}

                {tableInfo.error && (
                  <div className="mt-2">
                    <p className="font-semibold text-red-700">Détails de l'erreur:</p>
                    <pre className="mt-1 p-2 bg-gray-100 rounded text-xs overflow-auto">
                      {JSON.stringify(tableInfo.error, null, 2)}
                    </pre>
                  </div>
                )}
              </div>
            ) : (
              <p className="text-gray-500">Aucune information à afficher</p>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

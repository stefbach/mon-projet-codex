"use client"

import { useState, useEffect } from "react"
import { supabase } from "@/lib/supabase"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { CheckCircle, AlertCircle, Loader2, Database, RefreshCw } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function FixUsersTablePage() {
  const [loading, setLoading] = useState(false)
  const [checking, setChecking] = useState(true)
  const [tableStatus, setTableStatus] = useState<{
    exists: boolean
    columns: string[]
    missingColumns: string[]
  }>({
    exists: false,
    columns: [],
    missingColumns: [],
  })
  const [result, setResult] = useState<{
    success: boolean
    message: string
    details?: string
  } | null>(null)

  // Colonnes requises pour la table users
  const requiredColumns = [
    "id",
    "email",
    "name",
    "role",
    "active",
    "password_hash",
    "created_at",
    "password_updated_at",
  ]

  // Vérifier l'état de la table users
  const checkTableStatus = async () => {
    setChecking(true)
    try {
      // Vérifier si la table users existe
      const { data: tables, error: tablesError } = await supabase
        .from("information_schema.tables")
        .select("table_name")
        .eq("table_schema", "public")
        .eq("table_name", "users")

      if (tablesError) {
        console.error("Erreur lors de la vérification des tables:", tablesError)
        setTableStatus({
          exists: false,
          columns: [],
          missingColumns: requiredColumns,
        })
        setChecking(false)
        return
      }

      const tableExists = tables && tables.length > 0

      if (!tableExists) {
        setTableStatus({
          exists: false,
          columns: [],
          missingColumns: requiredColumns,
        })
        setChecking(false)
        return
      }

      // Vérifier les colonnes de la table users
      const { data: columns, error: columnsError } = await supabase
        .from("information_schema.columns")
        .select("column_name")
        .eq("table_schema", "public")
        .eq("table_name", "users")

      if (columnsError) {
        console.error("Erreur lors de la vérification des colonnes:", columnsError)
        setTableStatus({
          exists: true,
          columns: [],
          missingColumns: requiredColumns,
        })
        setChecking(false)
        return
      }

      const existingColumns = columns.map((col) => col.column_name)
      const missingColumns = requiredColumns.filter((col) => !existingColumns.includes(col))

      setTableStatus({
        exists: true,
        columns: existingColumns,
        missingColumns,
      })
    } catch (error) {
      console.error("Erreur lors de la vérification de la table:", error)
      setTableStatus({
        exists: false,
        columns: [],
        missingColumns: requiredColumns,
      })
    } finally {
      setChecking(false)
    }
  }

  // Exécuter la vérification au chargement de la page
  useEffect(() => {
    checkTableStatus()
  }, [])

  // Fonction pour réparer la table users
  const fixUsersTable = async () => {
    setLoading(true)
    setResult(null)

    try {
      // Vérifier si l'extension uuid-ossp existe
      const { error: extensionError } = await supabase.rpc("create_uuid_extension")

      if (extensionError && !extensionError.message.includes("already exists")) {
        setResult({
          success: false,
          message: "Erreur lors de la création de l'extension uuid-ossp",
          details: extensionError.message,
        })
        setLoading(false)
        return
      }

      // Si la table n'existe pas, la créer
      if (!tableStatus.exists) {
        const { error: createTableError } = await supabase.rpc("execute_sql", {
          sql: `
            CREATE TABLE public.users (
              id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
              email VARCHAR(255) UNIQUE NOT NULL,
              name VARCHAR(255) NOT NULL,
              role VARCHAR(50) NOT NULL,
              active BOOLEAN DEFAULT true,
              password_hash VARCHAR(255),
              created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
              password_updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
            );
          `,
        })

        if (createTableError) {
          setResult({
            success: false,
            message: "Erreur lors de la création de la table users",
            details: createTableError.message,
          })
          setLoading(false)
          return
        }
      } else {
        // Ajouter les colonnes manquantes
        for (const column of tableStatus.missingColumns) {
          let sql = ""
          switch (column) {
            case "password_hash":
              sql = "ALTER TABLE public.users ADD COLUMN password_hash VARCHAR(255);"
              break
            case "password_updated_at":
              sql = "ALTER TABLE public.users ADD COLUMN password_updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();"
              break
            case "active":
              sql = "ALTER TABLE public.users ADD COLUMN active BOOLEAN DEFAULT true;"
              break
            case "created_at":
              sql = "ALTER TABLE public.users ADD COLUMN created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();"
              break
            default:
              continue
          }

          const { error: addColumnError } = await supabase.rpc("execute_sql", { sql })

          if (addColumnError) {
            setResult({
              success: false,
              message: `Erreur lors de l'ajout de la colonne ${column}`,
              details: addColumnError.message,
            })
            setLoading(false)
            return
          }
        }
      }

      // Mettre à jour les utilisateurs existants avec un mot de passe par défaut
      const { error: updateError } = await supabase.rpc("execute_sql", {
        sql: `
          UPDATE public.users 
          SET password_hash = '$2a$10$X7VYHy.iYDVB.J7tgJq5B.D5jS9EVz1gHjzGhpnT7s9k9LJZUUeim' -- Mot de passe: admin123
          WHERE password_hash IS NULL;
        `,
      })

      if (updateError) {
        setResult({
          success: false,
          message: "Erreur lors de la mise à jour des mots de passe",
          details: updateError.message,
        })
        setLoading(false)
        return
      }

      // Créer des utilisateurs de test
      const { error: insertError } = await supabase.rpc("execute_sql", {
        sql: `
          INSERT INTO public.users (id, email, name, role, active, password_hash, created_at, password_updated_at)
          VALUES 
          ('00000000-0000-0000-0000-000000000001', 'admin@email.com', 'Administrateur', 'admin', true, '$2a$10$X7VYHy.iYDVB.J7tgJq5B.D5jS9EVz1gHjzGhpnT7s9k9LJZUUeim', NOW(), NOW()),
          ('00000000-0000-0000-0000-000000000002', 'closer@email.com', 'Closer', 'closer', true, '$2a$10$X7VYHy.iYDVB.J7tgJq5B.D5jS9EVz1gHjzGhpnT7s9k9LJZUUeim', NOW(), NOW())
          ON CONFLICT (email) DO NOTHING;
        `,
      })

      if (insertError) {
        setResult({
          success: false,
          message: "Erreur lors de la création des utilisateurs de test",
          details: insertError.message,
        })
        setLoading(false)
        return
      }

      // Créer des index
      const { error: indexError } = await supabase.rpc("execute_sql", {
        sql: `
          CREATE INDEX IF NOT EXISTS users_email_idx ON public.users (email);
          CREATE INDEX IF NOT EXISTS users_role_idx ON public.users (role);
        `,
      })

      if (indexError) {
        setResult({
          success: false,
          message: "Erreur lors de la création des index",
          details: indexError.message,
        })
        setLoading(false)
        return
      }

      // Vérifier que tout est bien configuré
      const { data: finalCheck, error: finalCheckError } = await supabase
        .from("users")
        .select("id, email, name, role, password_hash")
        .limit(1)

      if (finalCheckError) {
        setResult({
          success: false,
          message: "La structure a été mise à jour mais une erreur est survenue lors de la vérification finale",
          details: finalCheckError.message,
        })
        setLoading(false)
        return
      }

      setResult({
        success: true,
        message: "La structure de la base de données a été mise à jour avec succès",
        details: `${finalCheck.length} utilisateur(s) trouvé(s)`,
      })

      // Mettre à jour le statut de la table
      await checkTableStatus()
    } catch (error: any) {
      setResult({
        success: false,
        message: "Une erreur inattendue s'est produite",
        details: error.message || "Erreur inconnue",
      })
    } finally {
      setLoading(false)
    }
  }

  // Fonction pour tester la création d'un utilisateur
  const testCreateUser = async () => {
    setLoading(true)
    setResult(null)

    try {
      // Générer un email unique
      const testEmail = `test-${Date.now()}@example.com`

      // Créer un utilisateur de test
      const { data, error } = await supabase
        .from("users")
        .insert([
          {
            email: testEmail,
            name: "Utilisateur Test",
            role: "closer",
            active: true,
            password_hash: "$2a$10$X7VYHy.iYDVB.J7tgJq5B.D5jS9EVz1gHjzGhpnT7s9k9LJZUUeim", // admin123
            created_at: new Date().toISOString(),
            password_updated_at: new Date().toISOString(),
          },
        ])
        .select()

      if (error) {
        setResult({
          success: false,
          message: "Erreur lors de la création de l'utilisateur de test",
          details: error.message,
        })
        return
      }

      // Supprimer l'utilisateur de test
      const { error: deleteError } = await supabase.from("users").delete().eq("email", testEmail)

      if (deleteError) {
        setResult({
          success: false,
          message: "L'utilisateur a été créé mais n'a pas pu être supprimé",
          details: deleteError.message,
        })
        return
      }

      setResult({
        success: true,
        message: "Test de création d'utilisateur réussi",
        details: "Un utilisateur a été créé puis supprimé avec succès",
      })
    } catch (error: any) {
      setResult({
        success: false,
        message: "Une erreur inattendue s'est produite",
        details: error.message || "Erreur inconnue",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-8">
      <Card className="max-w-3xl mx-auto">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Database className="mr-2 h-6 w-6" />
            Vérification et réparation de la table users
          </CardTitle>
          <CardDescription>
            Cette page vous permet de vérifier et de réparer la structure de la table 'users' dans Supabase.
          </CardDescription>
        </CardHeader>

        <CardContent>
          <Tabs defaultValue="status">
            <TabsList className="mb-4">
              <TabsTrigger value="status">État actuel</TabsTrigger>
              <TabsTrigger value="fix">Réparation</TabsTrigger>
              <TabsTrigger value="test">Test</TabsTrigger>
            </TabsList>

            <TabsContent value="status">
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-medium">État de la table users</h3>
                  <Button variant="outline" size="sm" onClick={checkTableStatus} disabled={checking}>
                    {checking ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Vérification...
                      </>
                    ) : (
                      <>
                        <RefreshCw className="mr-2 h-4 w-4" />
                        Actualiser
                      </>
                    )}
                  </Button>
                </div>

                {checking ? (
                  <div className="flex justify-center py-4">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : (
                  <>
                    <Alert variant={tableStatus.exists ? "default" : "destructive"}>
                      <AlertTitle className="flex items-center">
                        {tableStatus.exists ? (
                          <>
                            <CheckCircle className="mr-2 h-4 w-4" />
                            La table users existe
                          </>
                        ) : (
                          <>
                            <AlertCircle className="mr-2 h-4 w-4" />
                            La table users n'existe pas
                          </>
                        )}
                      </AlertTitle>
                      <AlertDescription>
                        {tableStatus.exists
                          ? "La table users existe dans la base de données."
                          : "La table users doit être créée dans la base de données."}
                      </AlertDescription>
                    </Alert>

                    {tableStatus.exists && (
                      <div className="space-y-4">
                        <h4 className="font-medium">Colonnes existantes:</h4>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                          {tableStatus.columns.map((column) => (
                            <div
                              key={column}
                              className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm flex items-center"
                            >
                              <CheckCircle className="mr-1 h-3 w-3" />
                              {column}
                            </div>
                          ))}
                        </div>

                        {tableStatus.missingColumns.length > 0 && (
                          <>
                            <h4 className="font-medium">Colonnes manquantes:</h4>
                            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                              {tableStatus.missingColumns.map((column) => (
                                <div
                                  key={column}
                                  className="px-3 py-1 bg-red-100 text-red-800 rounded-full text-sm flex items-center"
                                >
                                  <AlertCircle className="mr-1 h-3 w-3" />
                                  {column}
                                </div>
                              ))}
                            </div>
                          </>
                        )}
                      </div>
                    )}

                    {tableStatus.missingColumns.length > 0 && (
                      <Alert variant="warning" className="mt-4">
                        <AlertCircle className="h-4 w-4" />
                        <AlertTitle>Action requise</AlertTitle>
                        <AlertDescription>
                          {tableStatus.exists
                            ? `Il manque ${tableStatus.missingColumns.length} colonne(s) dans la table users. Utilisez l'onglet "Réparation" pour les ajouter.`
                            : "La table users n'existe pas. Utilisez l'onglet \"Réparation\" pour la créer."}
                        </AlertDescription>
                      </Alert>
                    )}

                    {tableStatus.exists && tableStatus.missingColumns.length === 0 && (
                      <Alert variant="success" className="mt-4 bg-green-50 text-green-800 border-green-200">
                        <CheckCircle className="h-4 w-4" />
                        <AlertTitle>Tout est en ordre</AlertTitle>
                        <AlertDescription>
                          La table users existe et contient toutes les colonnes requises.
                        </AlertDescription>
                      </Alert>
                    )}
                  </>
                )}
              </div>
            </TabsContent>

            <TabsContent value="fix">
              <div className="space-y-4">
                <p>
                  Cette opération va {!tableStatus.exists ? "créer la table users et " : ""}
                  {tableStatus.missingColumns.length > 0
                    ? `ajouter les colonnes manquantes (${tableStatus.missingColumns.join(", ")})`
                    : "vérifier que tout est en ordre"}
                  .
                </p>

                {result && (
                  <Alert variant={result.success ? "default" : "destructive"} className="mb-4">
                    <div className="flex items-center">
                      {result.success ? (
                        <CheckCircle className="h-4 w-4 mr-2" />
                      ) : (
                        <AlertCircle className="h-4 w-4 mr-2" />
                      )}
                      <AlertTitle>{result.success ? "Succès" : "Erreur"}</AlertTitle>
                    </div>
                    <AlertDescription>
                      <p>{result.message}</p>
                      {result.details && (
                        <p className="text-sm mt-2 font-mono bg-gray-100 p-2 rounded">{result.details}</p>
                      )}
                    </AlertDescription>
                  </Alert>
                )}

                <Button onClick={fixUsersTable} disabled={loading}>
                  {loading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Réparation en cours...
                    </>
                  ) : (
                    "Réparer la table users"
                  )}
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="test">
              <div className="space-y-4">
                <p>
                  Cette opération va tester la création d'un utilisateur dans la table users pour vérifier que tout
                  fonctionne correctement.
                </p>

                {result && (
                  <Alert variant={result.success ? "default" : "destructive"} className="mb-4">
                    <div className="flex items-center">
                      {result.success ? (
                        <CheckCircle className="h-4 w-4 mr-2" />
                      ) : (
                        <AlertCircle className="h-4 w-4 mr-2" />
                      )}
                      <AlertTitle>{result.success ? "Succès" : "Erreur"}</AlertTitle>
                    </div>
                    <AlertDescription>
                      <p>{result.message}</p>
                      {result.details && (
                        <p className="text-sm mt-2 font-mono bg-gray-100 p-2 rounded">{result.details}</p>
                      )}
                    </AlertDescription>
                  </Alert>
                )}

                <Button onClick={testCreateUser} disabled={loading || tableStatus.missingColumns.length > 0}>
                  {loading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Test en cours...
                    </>
                  ) : (
                    "Tester la création d'utilisateur"
                  )}
                </Button>

                {tableStatus.missingColumns.length > 0 && (
                  <Alert variant="warning">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Réparation requise</AlertTitle>
                    <AlertDescription>
                      Vous devez d'abord réparer la table users avant de pouvoir tester la création d'utilisateur.
                    </AlertDescription>
                  </Alert>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>

        <CardFooter className="flex justify-between">
          <p className="text-sm text-gray-500">Dernière vérification: {new Date().toLocaleString()}</p>
          <Button variant="outline" size="sm" asChild>
            <a href="/admin/accounts">Aller à la gestion des comptes</a>
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

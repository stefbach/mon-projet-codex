"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Loader2, AlertTriangle, CheckCircle, Database, RefreshCw, Code, Wrench } from "lucide-react"
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"

export default function EmergencyFixPage() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<string>("")
  const [error, setError] = useState<string>("")
  const [success, setSuccess] = useState<string>("")
  const [customQuery, setCustomQuery] = useState<string>(`
-- Vérifier la structure de la table patients
SELECT 
  column_name, 
  data_type, 
  is_nullable
FROM 
  information_schema.columns
WHERE 
  table_name = 'patients'
ORDER BY 
  ordinal_position;
`)

  const supabase = createClientComponentClient()

  const executeRadicalReset = async () => {
    setLoading(true)
    setError("")
    setSuccess("")
    setResult("")

    try {
      // Étape 1: Vérifier si la colonne closer_id existe
      const { data: columnsCheck, error: columnsError } = await supabase.from("patients").select("closer_id").limit(1)

      if (columnsError) {
        // La colonne n'existe probablement pas, on va la créer
        setResult((prev) => prev + "La colonne closer_id n'existe pas ou pose problème. Création en cours...\n")

        // Étape 2: Sauvegarder les relations existantes
        const { data: relationships, error: relError } = await supabase.rpc("get_patient_closer_relationships")

        if (relError) {
          setResult(
            (prev) =>
              prev +
              "Impossible de récupérer les relations existantes. Création d'une fonction temporaire...\n" +
              relError.message +
              "\n",
          )

          // Créer une fonction pour récupérer les relations
          await supabase.rpc("create_get_relationships_function")
          const { data: backupRelationships, error: backupError } = await supabase.rpc("get_relationships_backup")

          if (backupError) {
            setResult(
              (prev) => prev + "Échec de la récupération des relations de secours: " + backupError.message + "\n",
            )
          } else {
            setResult((prev) => prev + "Relations récupérées avec succès via la méthode de secours.\n")
            setResult((prev) => prev + JSON.stringify(backupRelationships, null, 2) + "\n")
          }
        } else {
          setResult((prev) => prev + "Relations existantes récupérées avec succès.\n")
          setResult((prev) => prev + JSON.stringify(relationships, null, 2) + "\n")
        }

        // Étape 3: Supprimer les contraintes problématiques
        const { error: dropError } = await supabase.rpc("drop_problematic_constraints")
        if (dropError) {
          setResult((prev) => prev + "Erreur lors de la suppression des contraintes: " + dropError.message + "\n")
        } else {
          setResult((prev) => prev + "Contraintes problématiques supprimées avec succès.\n")
        }

        // Étape 4: Ajouter la colonne closer_id si elle n'existe pas
        const { error: addColumnError } = await supabase.rpc("add_closer_id_column")
        if (addColumnError) {
          setResult((prev) => prev + "Erreur lors de l'ajout de la colonne: " + addColumnError.message + "\n")
        } else {
          setResult((prev) => prev + "Colonne closer_id ajoutée ou mise à jour avec succès.\n")
        }

        // Étape 5: Restaurer les relations
        const { error: restoreError } = await supabase.rpc("restore_patient_closer_relationships")
        if (restoreError) {
          setResult((prev) => prev + "Erreur lors de la restauration des relations: " + restoreError.message + "\n")
        } else {
          setResult((prev) => prev + "Relations restaurées avec succès.\n")
        }

        // Étape 6: Ajouter la contrainte de clé étrangère
        const { error: fkError } = await supabase.rpc("add_foreign_key_constraint")
        if (fkError) {
          setResult((prev) => prev + "Erreur lors de l'ajout de la contrainte: " + fkError.message + "\n")
        } else {
          setResult((prev) => prev + "Contrainte de clé étrangère ajoutée avec succès.\n")
        }

        // Étape 7: Rafraîchir le cache du schéma
        const { error: refreshError } = await supabase.rpc("refresh_schema_cache")
        if (refreshError) {
          setResult((prev) => prev + "Erreur lors du rafraîchissement du cache: " + refreshError.message + "\n")
        } else {
          setResult((prev) => prev + "Cache du schéma rafraîchi avec succès.\n")
        }

        // Étape 8: Tester une requête avec relation
        const { data: testData, error: testError } = await supabase
          .from("patients")
          .select("*, users!patients_closer_id_fkey(*)")
          .limit(1)

        if (testError) {
          setResult((prev) => prev + "Erreur lors du test de la relation: " + testError.message + "\n")
          setError("La réparation a échoué. Veuillez essayer une autre approche.")
        } else {
          setResult((prev) => prev + "Test de la relation réussi!\n")
          setSuccess("La réparation a réussi! Les relations fonctionnent maintenant correctement.")
        }
      } else {
        // La colonne existe, vérifions si elle fonctionne correctement
        const { data: testData, error: testError } = await supabase
          .from("patients")
          .select("*, users!patients_closer_id_fkey(*)")
          .limit(1)

        if (testError) {
          setResult((prev) => prev + "La colonne closer_id existe mais la relation ne fonctionne pas.\n")
          setResult((prev) => prev + "Erreur: " + testError.message + "\n")
          setResult((prev) => prev + "Tentative de réparation...\n")

          // Étape 3-7: Réparer la relation
          await supabase.rpc("drop_problematic_constraints")
          await supabase.rpc("add_foreign_key_constraint")
          await supabase.rpc("refresh_schema_cache")

          // Tester à nouveau
          const { data: retestData, error: retestError } = await supabase
            .from("patients")
            .select("*, users!patients_closer_id_fkey(*)")
            .limit(1)

          if (retestError) {
            setResult((prev) => prev + "La réparation a échoué: " + retestError.message + "\n")
            setError("La réparation a échoué. Veuillez essayer une autre approche.")
          } else {
            setResult((prev) => prev + "Réparation réussie!\n")
            setSuccess("La réparation a réussi! Les relations fonctionnent maintenant correctement.")
          }
        } else {
          setResult((prev) => prev + "La colonne closer_id existe et la relation fonctionne correctement.\n")
          setSuccess("Tout fonctionne correctement! Aucune réparation nécessaire.")
        }
      }
    } catch (err) {
      console.error("Erreur lors de la réinitialisation radicale:", err)
      setError("Une erreur inattendue s'est produite. Veuillez consulter la console pour plus de détails.")
    } finally {
      setLoading(false)
    }
  }

  const executeCustomQuery = async () => {
    setLoading(true)
    setError("")
    setSuccess("")
    setResult("")

    try {
      const { data, error } = await supabase.rpc("execute_custom_query", {
        query_text: customQuery,
      })

      if (error) {
        setError("Erreur lors de l'exécution de la requête: " + error.message)
        setResult("Erreur: " + error.message)
      } else {
        setSuccess("Requête exécutée avec succès!")
        setResult(JSON.stringify(data, null, 2))
      }
    } catch (err) {
      console.error("Erreur lors de l'exécution de la requête personnalisée:", err)
      setError("Une erreur inattendue s'est produite. Veuillez consulter la console pour plus de détails.")
    } finally {
      setLoading(false)
    }
  }

  const createMaterializedView = async () => {
    setLoading(true)
    setError("")
    setSuccess("")
    setResult("")

    try {
      const { data, error } = await supabase.rpc("create_patients_with_closers_view")

      if (error) {
        setError("Erreur lors de la création de la vue matérialisée: " + error.message)
        setResult("Erreur: " + error.message)
      } else {
        setSuccess("Vue matérialisée créée avec succès!")
        setResult(
          "Vue matérialisée 'patients_with_closers' créée avec succès. Vous pouvez maintenant l'utiliser pour vos requêtes.",
        )
      }
    } catch (err) {
      console.error("Erreur lors de la création de la vue matérialisée:", err)
      setError("Une erreur inattendue s'est produite. Veuillez consulter la console pour plus de détails.")
    } finally {
      setLoading(false)
    }
  }

  const refreshSchemaCache = async () => {
    setLoading(true)
    setError("")
    setSuccess("")
    setResult("")

    try {
      const { data, error } = await supabase.rpc("refresh_schema_cache")

      if (error) {
        setError("Erreur lors du rafraîchissement du cache: " + error.message)
        setResult("Erreur: " + error.message)
      } else {
        setSuccess("Cache du schéma rafraîchi avec succès!")
        setResult("Le cache du schéma a été rafraîchi avec succès.")
      }
    } catch (err) {
      console.error("Erreur lors du rafraîchissement du cache:", err)
      setError("Une erreur inattendue s'est produite. Veuillez consulter la console pour plus de détails.")
    } finally {
      setLoading(false)
    }
  }

  const testRelationQuery = async () => {
    setLoading(true)
    setError("")
    setSuccess("")
    setResult("")

    try {
      const { data, error } = await supabase.from("patients").select("*, users!patients_closer_id_fkey(*)").limit(5)

      if (error) {
        setError("Erreur lors du test de la relation: " + error.message)
        setResult("Erreur: " + error.message)
      } else {
        setSuccess("Test de la relation réussi!")
        setResult(JSON.stringify(data, null, 2))
      }
    } catch (err) {
      console.error("Erreur lors du test de la relation:", err)
      setError("Une erreur inattendue s'est produite. Veuillez consulter la console pour plus de détails.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Réparation d'urgence du schéma</h1>
      <p className="text-gray-600 mb-8">
        Cette page vous permet de réparer les problèmes de relations dans votre base de données Supabase.
      </p>

      <Tabs defaultValue="radical-reset">
        <TabsList className="mb-6">
          <TabsTrigger value="radical-reset">
            <Wrench className="h-4 w-4 mr-2" />
            Réinitialisation radicale
          </TabsTrigger>
          <TabsTrigger value="custom-query">
            <Code className="h-4 w-4 mr-2" />
            Requête personnalisée
          </TabsTrigger>
          <TabsTrigger value="alternatives">
            <Database className="h-4 w-4 mr-2" />
            Solutions alternatives
          </TabsTrigger>
        </TabsList>

        <TabsContent value="radical-reset">
          <Card>
            <CardHeader>
              <CardTitle>Réinitialisation radicale des relations</CardTitle>
              <CardDescription>
                Cette option va effectuer une restauration complète de votre schéma en supprimant toutes les contraintes
                problématiques, en sauvegardant les données existantes, puis en recréant les colonnes et les relations
                correctement.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Alert variant="warning" className="mb-4">
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Attention</AlertTitle>
                <AlertDescription>
                  Cette opération est potentiellement destructive. Assurez-vous d'avoir une sauvegarde de vos données
                  avant de continuer.
                </AlertDescription>
              </Alert>

              <div className="space-y-4">
                <h3 className="font-semibold">Étapes qui seront exécutées :</h3>
                <ol className="list-decimal list-inside space-y-2">
                  <li>Vérification de l'existence de la colonne closer_id</li>
                  <li>Sauvegarde des relations existantes</li>
                  <li>Suppression des contraintes problématiques</li>
                  <li>Ajout ou mise à jour de la colonne closer_id</li>
                  <li>Restauration des relations sauvegardées</li>
                  <li>Ajout de la contrainte de clé étrangère</li>
                  <li>Rafraîchissement du cache du schéma</li>
                  <li>Test de la relation</li>
                </ol>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={refreshSchemaCache} disabled={loading}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Rafraîchir le cache du schéma
              </Button>
              <Button variant="default" onClick={executeRadicalReset} disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Exécution en cours...
                  </>
                ) : (
                  "Exécuter la réinitialisation radicale"
                )}
              </Button>
            </CardFooter>
          </Card>

          <div className="mt-4">
            <Button variant="outline" onClick={testRelationQuery} disabled={loading} className="mb-4">
              <Database className="h-4 w-4 mr-2" />
              Tester une requête avec relation
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="custom-query">
          <Card>
            <CardHeader>
              <CardTitle>Exécuter une requête SQL personnalisée</CardTitle>
              <CardDescription>
                Utilisez cette option pour exécuter vos propres requêtes SQL afin de diagnostiquer ou de réparer des
                problèmes spécifiques.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Textarea
                value={customQuery}
                onChange={(e) => setCustomQuery(e.target.value)}
                className="font-mono h-64"
                placeholder="Entrez votre requête SQL ici..."
              />
            </CardContent>
            <CardFooter>
              <Button variant="default" onClick={executeCustomQuery} disabled={loading} className="ml-auto">
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Exécution en cours...
                  </>
                ) : (
                  "Exécuter la requête"
                )}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="alternatives">
          <Card>
            <CardHeader>
              <CardTitle>Solutions alternatives</CardTitle>
              <CardDescription>
                Si les méthodes précédentes ne fonctionnent pas, voici quelques approches alternatives pour contourner
                les problèmes de relations.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-2">1. Utiliser des requêtes directes sans relations</h3>
                  <p className="text-gray-600 mb-2">
                    Au lieu d'utiliser des relations, vous pouvez récupérer les données en plusieurs requêtes et les
                    combiner côté client.
                  </p>
                  <pre className="bg-gray-100 p-4 rounded-md text-sm overflow-x-auto">
                    {`// Récupérer les patients
const { data: patients } = await supabase.from('patients').select('*')

// Récupérer les utilisateurs (closers)
const { data: users } = await supabase.from('users').select('*')

// Combiner les données
const patientsWithClosers = patients.map(patient => ({
  ...patient,
  closer: users.find(user => user.id === patient.closer_id)
}))`}
                  </pre>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-2">2. Créer une vue matérialisée</h3>
                  <p className="text-gray-600 mb-2">
                    Vous pouvez créer une vue matérialisée qui combine déjà les données des patients et des closers.
                  </p>
                  <pre className="bg-gray-100 p-4 rounded-md text-sm overflow-x-auto">
                    {`CREATE MATERIALIZED VIEW patients_with_closers AS
SELECT 
  p.*,
  u.id as closer_user_id,
  u.email as closer_email,
  u.name as closer_name,
  u.role as closer_role
FROM 
  patients p
LEFT JOIN 
  users u ON p.closer_id = u.id;`}
                  </pre>
                  <Button variant="outline" onClick={createMaterializedView} disabled={loading} className="mt-2">
                    Créer cette vue matérialisée
                  </Button>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-2">3. Utiliser des fonctions RPC</h3>
                  <p className="text-gray-600 mb-2">
                    Vous pouvez créer des fonctions PostgreSQL qui retournent les données combinées et les appeler via
                    RPC.
                  </p>
                  <pre className="bg-gray-100 p-4 rounded-md text-sm overflow-x-auto">
                    {`// Exemple d'utilisation d'une fonction RPC
const { data } = await supabase.rpc('get_patients_with_closers')`}
                  </pre>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {(error || success || result) && (
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Résultat</CardTitle>
          </CardHeader>
          <CardContent>
            {error && (
              <Alert variant="destructive" className="mb-4">
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Erreur</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {success && (
              <Alert variant="success" className="mb-4">
                <CheckCircle className="h-4 w-4" />
                <AlertTitle>Succès</AlertTitle>
                <AlertDescription>{success}</AlertDescription>
              </Alert>
            )}

            {result && (
              <div className="bg-gray-100 p-4 rounded-md">
                <pre className="whitespace-pre-wrap text-sm">{result}</pre>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}

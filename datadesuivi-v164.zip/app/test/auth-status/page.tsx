"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useAuth } from "@/contexts/auth-context"
import Cookies from "js-cookie"

export default function AuthStatusPage() {
  const { user, isAuthenticated, isLoading } = useAuth()
  const [cookies, setCookies] = useState<Record<string, string>>({})

  useEffect(() => {
    // Récupérer tous les cookies
    const allCookies: Record<string, string> = {}
    document.cookie.split(";").forEach((cookie) => {
      const [name, value] = cookie.trim().split("=")
      allCookies[name] = value
    })
    setCookies(allCookies)
  }, [])

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">État de l'authentification</h1>

      <div className="grid gap-4">
        <Card>
          <CardHeader>
            <CardTitle>État de chargement</CardTitle>
          </CardHeader>
          <CardContent>
            <p>isLoading: {isLoading ? "Oui" : "Non"}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>État d'authentification</CardTitle>
          </CardHeader>
          <CardContent>
            <p>isAuthenticated: {isAuthenticated ? "Oui" : "Non"}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Informations utilisateur</CardTitle>
          </CardHeader>
          <CardContent>
            {user ? (
              <div>
                <p>ID: {user.id || "N/A"}</p>
                <p>Email: {user.email}</p>
                <p>Nom: {user.name}</p>
                <p>Rôle: {user.role}</p>
                <p>Actif: {user.active ? "Oui" : "Non"}</p>
              </div>
            ) : (
              <p>Aucun utilisateur connecté</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Cookies</CardTitle>
          </CardHeader>
          <CardContent>
            <p>authSession: {Cookies.get("authSession") || "Non défini"}</p>
            <p>userRole: {Cookies.get("userRole") || "Non défini"}</p>
            <pre className="bg-gray-100 p-2 rounded mt-2 text-xs overflow-auto">{JSON.stringify(cookies, null, 2)}</pre>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

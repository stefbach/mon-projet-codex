"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Loader2, RefreshCw, CheckCircle, Database, AlertTriangle } from "lucide-react"
import { diagnoseAndRepairSchema } from "@/lib/schema-repair"
import { supabase } from "@/lib/supabase"

export default function SchemaDiagnosticPage() {
  const [loading, setLoading] = useState(false)
  const [diagnosing, setDiagnosing] = useState(false)
  const [diagnosticResult, setDiagnosticResult] = useState<any>(null)
  const [schemaInfo, setSchemaInfo] = useState<any>(null)

  // Exécuter un diagnostic initial au chargement de la page
  useEffect(() => {
    getSchemaInfo()
  }, [])

  async function getSchemaInfo() {
    try {
      setLoading(true)

      // Récupérer les informations sur les tables
      const { data: tables, error: tablesError } = await supabase.rpc("get_tables")

      // Récupérer les informations sur les contraintes
      const { data: constraints, error: constraintsError } = await supabase.rpc("exec_sql", {
        sql_query: `
          SELECT 
              tc.constraint_name, 
              tc.table_name, 
              kcu.column_name, 
              ccu.table_name AS foreign_table_name,
              ccu.column_name AS foreign_column_name
          FROM 
              information_schema.table_constraints AS tc 
              JOIN information_schema.key_column_usage AS kcu
                ON tc.constraint_name = kcu.constraint_name
                AND tc.table_schema = kcu.table_schema
              JOIN information_schema.constraint_column_usage AS ccu
                ON ccu.constraint_name = tc.constraint_name
                AND ccu.table_schema = tc.table_schema
          WHERE tc.constraint_type = 'FOREIGN KEY' 
              AND tc.table_name = 'patients';
        `,
      })

      // Récupérer les colonnes de la table patients
      const { data: columns, error: columnsError } = await supabase.rpc("exec_sql", {
        sql_query: `
          SELECT column_name, data_type, is_nullable
          FROM information_schema.columns
          WHERE table_name = 'patients'
          ORDER BY ordinal_position;
        `,
      })

      setSchemaInfo({
        tables: tables || [],
        constraints: constraints?.rows || [],
        columns: columns?.rows || [],
        errors: {
          tables: tablesError?.message,
          constraints: constraintsError?.message,
          columns: columnsError?.message,
        },
      })
    } catch (error: any) {
      console.error("Erreur lors de la récupération des informations du schéma:", error)
    } finally {
      setLoading(false)
    }
  }

  async function runDiagnostic() {
    try {
      setDiagnosing(true)
      const result = await diagnoseAndRepairSchema()
      setDiagnosticResult(result)

      // Rafraîchir les informations du schéma après le diagnostic
      await getSchemaInfo()
    } catch (error: any) {
      console.error("Erreur lors du diagnostic:", error)
      setDiagnosticResult({
        success: false,
        error: error.message || "Erreur inconnue",
      })
    } finally {
      setDiagnosing(false)
    }
  }

  async function testQuery() {
    try {
      setLoading(true)

      // Tester une requête simple avec la relation
      const { data, error } = await supabase
        .from("patients")
        .select(`
          id,
          full_name,
          closer:closer_id (id, full_name)
        `)
        .limit(5)

      setDiagnosticResult({
        ...diagnosticResult,
        testQuery: {
          success: !error,
          data,
          error: error?.message,
        },
      })
    } catch (error: any) {
      console.error("Erreur lors du test de requête:", error)
      setDiagnosticResult({
        ...diagnosticResult,
        testQuery: {
          success: false,
          error: error.message || "Erreur inconnue",
        },
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-10">
      <Card className="w-full max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-6 w-6" />
            Diagnostic et réparation du schéma Supabase
          </CardTitle>
          <CardDescription>
            Cet outil analyse et répare les problèmes de relations dans le schéma de la base de données
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Informations sur le schéma */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Informations sur le schéma</h3>

            {loading ? (
              <div className="flex justify-center py-4">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : (
              <>
                {/* Tables */}
                <div className="space-y-2">
                  <h4 className="font-medium">Tables disponibles</h4>
                  {schemaInfo?.tables?.length > 0 ? (
                    <ul className="list-disc pl-5">
                      {schemaInfo.tables.map((table: string, index: number) => (
                        <li key={index}>{table}</li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-gray-500">Aucune table trouvée ou erreur: {schemaInfo?.errors?.tables}</p>
                  )}
                </div>

                {/* Contraintes */}
                <div className="space-y-2">
                  <h4 className="font-medium">Contraintes de clé étrangère sur la table patients</h4>
                  {schemaInfo?.constraints?.length > 0 ? (
                    <div className="overflow-x-auto">
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead>
                          <tr>
                            <th className="px-4 py-2 text-left">Nom</th>
                            <th className="px-4 py-2 text-left">Colonne</th>
                            <th className="px-4 py-2 text-left">Table référencée</th>
                            <th className="px-4 py-2 text-left">Colonne référencée</th>
                          </tr>
                        </thead>
                        <tbody>
                          {schemaInfo.constraints.map((constraint: any, index: number) => (
                            <tr key={index} className={index % 2 === 0 ? "bg-gray-50" : ""}>
                              <td className="px-4 py-2">{constraint.constraint_name}</td>
                              <td className="px-4 py-2">{constraint.column_name}</td>
                              <td className="px-4 py-2">{constraint.foreign_table_name}</td>
                              <td className="px-4 py-2">{constraint.foreign_column_name}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <p className="text-gray-500">
                      Aucune contrainte trouvée ou erreur: {schemaInfo?.errors?.constraints}
                    </p>
                  )}
                </div>

                {/* Colonnes */}
                <div className="space-y-2">
                  <h4 className="font-medium">Colonnes de la table patients</h4>
                  {schemaInfo?.columns?.length > 0 ? (
                    <div className="overflow-x-auto">
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead>
                          <tr>
                            <th className="px-4 py-2 text-left">Nom</th>
                            <th className="px-4 py-2 text-left">Type</th>
                            <th className="px-4 py-2 text-left">Nullable</th>
                          </tr>
                        </thead>
                        <tbody>
                          {schemaInfo.columns.map((column: any, index: number) => (
                            <tr key={index} className={index % 2 === 0 ? "bg-gray-50" : ""}>
                              <td className="px-4 py-2">{column.column_name}</td>
                              <td className="px-4 py-2">{column.data_type}</td>
                              <td className="px-4 py-2">{column.is_nullable}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <p className="text-gray-500">Aucune colonne trouvée ou erreur: {schemaInfo?.errors?.columns}</p>
                  )}
                </div>
              </>
            )}
          </div>

          {/* Résultat du diagnostic */}
          {diagnosticResult && (
            <Alert variant={diagnosticResult.success ? "default" : "destructive"}>
              <AlertTitle className="flex items-center gap-2">
                {diagnosticResult.success ? <CheckCircle className="h-4 w-4" /> : <AlertTriangle className="h-4 w-4" />}
                Résultat du diagnostic
              </AlertTitle>
              <AlertDescription className="mt-2">
                <div className="space-y-2">
                  <p>
                    {diagnosticResult.success
                      ? "Le schéma est correctement configuré ou a été réparé avec succès."
                      : "Des problèmes ont été détectés dans le schéma."}
                  </p>

                  {diagnosticResult.message && <p className="font-medium">{diagnosticResult.message}</p>}

                  {diagnosticResult.initialStatus && (
                    <div>
                      <p className="font-medium">Statut initial:</p>
                      <pre className="mt-1 p-2 bg-gray-100 rounded-md text-xs overflow-auto max-h-20">
                        {JSON.stringify(diagnosticResult.initialStatus, null, 2)}
                      </pre>
                    </div>
                  )}

                  {diagnosticResult.repairResult && (
                    <div>
                      <p className="font-medium">Résultat de la réparation:</p>
                      <pre className="mt-1 p-2 bg-gray-100 rounded-md text-xs overflow-auto max-h-20">
                        {JSON.stringify(diagnosticResult.repairResult, null, 2)}
                      </pre>
                    </div>
                  )}

                  {diagnosticResult.finalStatus && (
                    <div>
                      <p className="font-medium">Statut final:</p>
                      <pre className="mt-1 p-2 bg-gray-100 rounded-md text-xs overflow-auto max-h-20">
                        {JSON.stringify(diagnosticResult.finalStatus, null, 2)}
                      </pre>
                    </div>
                  )}

                  {diagnosticResult.testQuery && (
                    <div>
                      <p className="font-medium">Résultat du test de requête:</p>
                      <pre className="mt-1 p-2 bg-gray-100 rounded-md text-xs overflow-auto max-h-40">
                        {JSON.stringify(diagnosticResult.testQuery, null, 2)}
                      </pre>
                    </div>
                  )}
                </div>
              </AlertDescription>
            </Alert>
          )}
        </CardContent>

        <CardFooter className="flex justify-between">
          <div className="flex gap-2">
            <Button variant="default" onClick={runDiagnostic} disabled={diagnosing}>
              {diagnosing ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Diagnostic en cours...
                </>
              ) : (
                <>
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Diagnostiquer et réparer
                </>
              )}
            </Button>

            <Button variant="outline" onClick={getSchemaInfo} disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Chargement...
                </>
              ) : (
                <>
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Rafraîchir les informations
                </>
              )}
            </Button>
          </div>

          <Button variant="secondary" onClick={testQuery} disabled={loading || diagnosing}>
            Tester une requête
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

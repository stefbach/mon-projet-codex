"use client"

import type React from "react"

import { useState } from "react"
import { supabase } from "@/lib/supabase"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2 } from "lucide-react"

export default function CreateTestUserPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [name, setName] = useState("")
  const [role, setRole] = useState("closer")
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setResult(null)

    try {
      // 1. Créer l'utilisateur dans Supabase Auth
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            name,
            role,
          },
        },
      })

      if (error) {
        setResult({
          success: false,
          message: error.message,
          details: JSON.stringify(error, null, 2),
        })
        return
      }

      // 2. Confirmer l'utilisateur manuellement
      await supabase.auth.updateUser({
        data: {
          email_confirmed: true,
        },
      })

      // 3. Ajouter l'utilisateur à la table users
      if (data.user) {
        const { error: insertError } = await supabase.from("users").insert({
          id: data.user.id,
          email,
          name,
          role,
          active: true,
        })

        if (insertError) {
          setResult({
            success: false,
            message: "Utilisateur créé mais erreur lors de l'ajout à la table users",
            details: JSON.stringify(insertError, null, 2),
          })
          return
        }
      }

      setResult({
        success: true,
        message: "Utilisateur créé avec succès",
        details: JSON.stringify(data, null, 2),
        user: data.user,
      })
    } catch (error: any) {
      setResult({
        success: false,
        message: error.message,
        details: JSON.stringify(error, null, 2),
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-10">
      <Card className="max-w-md mx-auto">
        <CardHeader>
          <CardTitle>Créer un utilisateur de test</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleCreateUser} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="name">Nom</Label>
              <Input id="name" value={name} onChange={(e) => setName(e.target.value)} required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Mot de passe (min. 6 caractères)</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={6}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="role">Rôle</Label>
              <select
                id="role"
                value={role}
                onChange={(e) => setRole(e.target.value)}
                className="w-full p-2 border rounded"
              >
                <option value="closer">Closer</option>
                <option value="admin">Admin</option>
              </select>
            </div>

            <Button type="submit" disabled={loading} className="w-full">
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Création...
                </>
              ) : (
                "Créer l'utilisateur"
              )}
            </Button>

            {result && (
              <div className={`mt-4 p-4 rounded-md ${result.success ? "bg-green-50" : "bg-red-50"}`}>
                <p className={result.success ? "text-green-700" : "text-red-700"}>{result.message}</p>
                {result.user && (
                  <p className="text-sm mt-2">
                    ID utilisateur: <code>{result.user.id}</code>
                  </p>
                )}
                <details className="mt-2">
                  <summary className="cursor-pointer text-sm">Détails techniques</summary>
                  <pre className="text-xs mt-2 p-2 bg-gray-100 rounded overflow-auto max-h-40">{result.details}</pre>
                </details>
              </div>
            )}
          </form>
        </CardContent>
      </Card>
    </div>
  )
}

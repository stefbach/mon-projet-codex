"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2, CheckCircle, AlertCircle } from "lucide-react"
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"

export default function UpdateStatusConstraintPage() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<{ success: boolean; message: string } | null>(null)
  const supabase = createClientComponentClient()

  const updateStatusConstraint = async () => {
    setLoading(true)
    setResult(null)

    try {
      // SQL pour mettre à jour la contrainte de statut
      const sql = `
      DO $$
      BEGIN
          -- Supprimer la contrainte existante si elle existe
          BEGIN
              ALTER TABLE patients DROP CONSTRAINT IF EXISTS patients_status_check;
          EXCEPTION
              WHEN undefined_object THEN
                  RAISE NOTICE 'La contrainte patients_status_check n''existe pas, aucune suppression nécessaire';
          END;

          -- Ajouter la nouvelle contrainte avec les statuts supplémentaires
          ALTER TABLE patients ADD CONSTRAINT patients_status_check 
          CHECK (status IN (
              'en_attente', 
              'a_contacter', 
              'rdv_programme', 
              'vente', 
              'perdu', 
              'non_defini', 
              'en_cours', 
              'annule', 
              'a_rappeler', 
              'non_interesse', 
              'no_show',
              'invoice_sent',
              'refus_credit',
              'no_answer',
              'en_attente_paiement',
              'simulation_a_faire',
              'process_depasse',
              'phone_not_available',
              'paiement_fait',
              'credit_approuval_en_cours',
              'hors_cible',
              'simulation_faite_refus'
          ));
      END $$;
      `

      // Exécuter le SQL
      const { error } = await supabase.rpc("exec_sql", { sql_query: sql })

      if (error) {
        throw error
      }

      setResult({
        success: true,
        message: "La contrainte de statut a été mise à jour avec succès.",
      })
    } catch (error) {
      console.error("Erreur lors de la mise à jour de la contrainte:", error)
      setResult({
        success: false,
        message: `Erreur: ${error.message || "Une erreur s'est produite"}`,
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-10">
      <Card className="max-w-md mx-auto">
        <CardHeader>
          <CardTitle>Mise à jour de la contrainte de statut</CardTitle>
          <CardDescription>
            Cette page permet de mettre à jour la contrainte de vérification pour le statut des patients afin d'inclure
            les nouveaux statuts.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-gray-500 mb-4">Les nouveaux statuts suivants seront ajoutés à la contrainte:</p>
          <ul className="list-disc pl-5 text-sm text-gray-500 space-y-1">
            <li>Facture envoyée (invoice_sent)</li>
            <li>Refus crédit (refus_credit)</li>
            <li>Pas de réponse (no_answer)</li>
            <li>En attente paiement (en_attente_paiement)</li>
            <li>Simulation à faire (simulation_a_faire)</li>
            <li>Process dépassé (process_depasse)</li>
            <li>Téléphone non disponible (phone_not_available)</li>
            <li>Paiement fait (paiement_fait)</li>
            <li>Approbation crédit en cours (credit_approuval_en_cours)</li>
            <li>Hors cible (hors_cible)</li>
            <li>Simulation faite, refus (simulation_faite_refus)</li>
          </ul>

          {result && (
            <div
              className={`mt-4 p-3 rounded-md ${
                result.success ? "bg-green-50 text-green-800" : "bg-red-50 text-red-800"
              }`}
            >
              <div className="flex items-center">
                {result.success ? (
                  <CheckCircle className="h-5 w-5 mr-2 text-green-500" />
                ) : (
                  <AlertCircle className="h-5 w-5 mr-2 text-red-500" />
                )}
                <p className="text-sm">{result.message}</p>
              </div>
            </div>
          )}
        </CardContent>
        <CardFooter>
          <Button onClick={updateStatusConstraint} disabled={loading} className="w-full">
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Mise à jour en cours...
              </>
            ) : (
              "Mettre à jour la contrainte"
            )}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

"use client"

import { useState, useEffect } from "react"
import { supabase } from "@/lib/supabase"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { XCircle, RefreshCw, Users } from "lucide-react"

interface PatientWithCloser {
  id: string
  name: string
  email: string
  closer: string
  closer_name?: string
  status: string
  created_at: string
}

export default function PatientsList() {
  const [patients, setPatients] = useState<PatientWithCloser[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  async function loadPatients() {
    setLoading(true)
    setError(null)

    try {
      // Vérifier que la vue existe
      const { data: viewCheck, error: viewError } = await supabase
        .from("pg_views")
        .select("viewname")
        .eq("viewname", "patients_with_closer")
        .limit(1)

      if (viewError) {
        console.error("Erreur lors de la vérification de la vue:", viewError)
        setError(`Erreur lors de la vérification de la vue: ${viewError.message}`)
        setLoading(false)
        return
      }

      // Si la vue n'existe pas, créer la vue
      if (!viewCheck || viewCheck.length === 0) {
        const createViewQuery = `
          CREATE OR REPLACE VIEW patients_with_closer AS
          SELECT p.*, u.name as closer_name
          FROM patients p
          LEFT JOIN users u ON p.closer = u.email;
        `

        const { error: createError } = await supabase.rpc("exec", { query: createViewQuery })

        if (createError) {
          console.error("Erreur lors de la création de la vue:", createError)
          setError(
            `Erreur lors de la création de la vue: ${createError.message}. Vous devez créer la vue manuellement.`,
          )
          setLoading(false)
          return
        }
      }

      // Charger les patients depuis la vue
      const { data, error: fetchError } = await supabase.from("patients_with_closer").select("*")

      if (fetchError) {
        console.error("Erreur lors du chargement des patients:", fetchError)
        setError(`Erreur lors du chargement des patients: ${fetchError.message}`)
        setLoading(false)
        return
      }

      setPatients(data || [])
    } catch (err) {
      console.error("Erreur inattendue:", err)
      setError(`Erreur inattendue: ${(err as Error).message}`)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadPatients()
  }, [])

  return (
    <div className="container mx-auto py-8">
      <Card className="max-w-3xl mx-auto">
        <CardHeader>
          <CardTitle className="text-2xl flex items-center gap-2">
            <Users className="h-6 w-6" /> Liste des Patients – Supabase
          </CardTitle>
          <CardDescription>
            Cette page affiche les patients enregistrés dans la base de données Supabase.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {loading ? (
            <div className="flex items-center justify-center p-6">
              <RefreshCw className="h-8 w-8 animate-spin text-primary-500" />
              <span className="ml-2">Chargement des patients...</span>
            </div>
          ) : error ? (
            <Alert variant="destructive">
              <XCircle className="h-4 w-4" />
              <AlertTitle>Erreur</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          ) : patients.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-neutral-500">Aucun patient trouvé.</p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="bg-neutral-100">
                      <th className="px-4 py-2 text-left">Nom</th>
                      <th className="px-4 py-2 text-left">Email</th>
                      <th className="px-4 py-2 text-left">Closer</th>
                      <th className="px-4 py-2 text-left">Statut</th>
                    </tr>
                  </thead>
                  <tbody>
                    {patients.map((patient) => (
                      <tr key={patient.id} className="border-t">
                        <td className="px-4 py-2">{patient.name}</td>
                        <td className="px-4 py-2">{patient.email || "—"}</td>
                        <td className="px-4 py-2">{patient.closer_name || "Non assigné"}</td>
                        <td className="px-4 py-2">
                          <span
                            className={`px-2 py-1 rounded text-xs ${
                              patient.status === "Accepté"
                                ? "bg-green-100 text-green-800"
                                : patient.status === "Refusé"
                                  ? "bg-red-100 text-red-800"
                                  : "bg-amber-100 text-amber-800"
                            }`}
                          >
                            {patient.status || "En attente"}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={() => window.history.back()}>
            Retour
          </Button>
          <Button onClick={loadPatients} disabled={loading}>
            {loading ? (
              <>
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> Chargement...
              </>
            ) : (
              <>
                <RefreshCw className="mr-2 h-4 w-4" /> Actualiser
              </>
            )}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

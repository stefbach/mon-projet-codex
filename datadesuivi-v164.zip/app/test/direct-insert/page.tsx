"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Loader2 } from "lucide-react"
import { supabase } from "@/lib/supabase"

export default function DirectInsertPage() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [formData, setFormData] = useState({
    name: "Patient Test Direct",
    email: `test${Date.now()}@example.com`,
    doctor: "Dr Test Direct",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setResult(null)

    try {
      // Insertion directe dans Supabase
      const { data, error } = await supabase.from("patients").insert([
        {
          name: formData.name,
          email: formData.email,
          doctor: formData.doctor,
          status: "En attente",
          closer: "direct@example.com",
        },
      ])

      if (error) {
        setResult({
          success: false,
          message: `Erreur: ${error.message}`,
          error,
        })
      } else {
        setResult({
          success: true,
          message: "Patient ajouté avec succès",
          data,
        })

        // Vérifier que le patient a bien été ajouté
        const { data: patients, error: fetchError } = await supabase
          .from("patients")
          .select("*")
          .eq("email", formData.email)
          .limit(1)

        if (fetchError) {
          setResult((prev: any) => ({
            ...prev,
            verificationError: fetchError.message,
          }))
        } else {
          setResult((prev: any) => ({
            ...prev,
            verification: patients,
          }))
        }
      }
    } catch (error: any) {
      setResult({
        success: false,
        message: `Exception: ${error.message}`,
        error,
      })
    } finally {
      setLoading(false)
    }
  }

  const checkTable = async () => {
    setLoading(true)
    try {
      // Vérifier si la table existe
      const { data, error } = await supabase.from("patients").select("count(*)", { count: "exact", head: true })

      if (error) {
        setResult({
          success: false,
          message: `Erreur lors de la vérification de la table: ${error.message}`,
          error,
        })
      } else {
        // Récupérer les 5 derniers patients
        const { data: recentPatients, error: fetchError } = await supabase
          .from("patients")
          .select("*")
          .order("created_at", { ascending: false })
          .limit(5)

        if (fetchError) {
          setResult({
            success: false,
            message: `Erreur lors de la récupération des patients: ${fetchError.message}`,
            error: fetchError,
            tableExists: true,
          })
        } else {
          setResult({
            success: true,
            message: "Table patients vérifiée avec succès",
            count: data,
            recentPatients,
          })
        }
      }
    } catch (error: any) {
      setResult({
        success: false,
        message: `Exception: ${error.message}`,
        error,
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-6">Insertion directe de patient</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-4">Formulaire simplifié</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nom *</Label>
                <Input id="name" name="name" value={formData.name} onChange={handleChange} required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email *</Label>
                <Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="doctor">Médecin *</Label>
                <Input id="doctor" name="doctor" value={formData.doctor} onChange={handleChange} required />
              </div>

              <Button type="submit" disabled={loading} className="w-full">
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Enregistrement...
                  </>
                ) : (
                  "Insérer directement"
                )}
              </Button>
            </form>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-4">Actions sur la table</h2>
            <div className="space-y-4">
              <Button onClick={checkTable} disabled={loading} className="w-full">
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Vérification...
                  </>
                ) : (
                  "Vérifier la table patients"
                )}
              </Button>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-4">Résultat</h2>
            {result ? (
              <div className={`p-4 rounded-md ${result.success ? "bg-green-50" : "bg-red-50"}`}>
                <p className={`font-semibold ${result.success ? "text-green-700" : "text-red-700"}`}>
                  {result.message}
                </p>

                {result.count && (
                  <p className="mt-2 text-gray-700">
                    Nombre de patients dans la table: <span className="font-semibold">{result.count}</span>
                  </p>
                )}

                {result.verification && (
                  <div className="mt-2">
                    <p className="font-semibold text-green-700">Vérification de l'insertion:</p>
                    <pre className="mt-1 p-2 bg-gray-100 rounded text-xs overflow-auto max-h-40">
                      {JSON.stringify(result.verification, null, 2)}
                    </pre>
                  </div>
                )}

                {result.recentPatients && (
                  <div className="mt-2">
                    <p className="font-semibold text-gray-700">Patients récents:</p>
                    <pre className="mt-1 p-2 bg-gray-100 rounded text-xs overflow-auto max-h-60">
                      {JSON.stringify(result.recentPatients, null, 2)}
                    </pre>
                  </div>
                )}

                {result.error && (
                  <div className="mt-2">
                    <p className="font-semibold text-red-700">Détails de l'erreur:</p>
                    <pre className="mt-1 p-2 bg-gray-100 rounded text-xs overflow-auto max-h-40">
                      {JSON.stringify(result.error, null, 2)}
                    </pre>
                  </div>
                )}
              </div>
            ) : (
              <p className="text-gray-500">Aucun résultat à afficher</p>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

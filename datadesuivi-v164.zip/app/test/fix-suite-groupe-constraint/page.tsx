"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { supabase } from "@/lib/supabase"
import { Loader2, CheckCircle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function FixSuiteGroupeConstraintPage() {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)

  async function fixConstraint() {
    setLoading(true)
    setError(null)
    setSuccess(false)
    try {
      // Méthode 1: Utiliser la fonction SQL personnalisée
      try {
        const { error } = await supabase.rpc("update_suite_groupe_constraint", {
          allowed_values: ["NHS", "CASH", ""],
        })
        if (!error) {
          setSuccess(true)
          return
        }
      } catch (err) {
        console.error("Erreur avec la méthode 1:", err)
      }

      // Méthode 2: Exécuter du SQL brut
      try {
        // Supprimer la contrainte existante
        await supabase.rpc("exec_sql", {
          sql_query: "ALTER TABLE public.patients DROP CONSTRAINT IF EXISTS patients_suite_groupe_check",
        })

        // Créer une nouvelle contrainte
        await supabase.rpc("exec_sql", {
          sql_query:
            "ALTER TABLE public.patients ADD CONSTRAINT patients_suite_groupe_check CHECK (suite_groupe IS NULL OR suite_groupe = '' OR suite_groupe IN ('NHS', 'CASH'))",
        })

        setSuccess(true)
        return
      } catch (err) {
        console.error("Erreur avec la méthode 2:", err)
      }

      // Méthode 3: Utiliser l'API REST
      try {
        const response = await fetch("/api/fix-suite-groupe-constraint", {
          method: "POST",
        })

        if (response.ok) {
          setSuccess(true)
          return
        } else {
          const errorData = await response.json()
          throw new Error(errorData.message || "Erreur lors de la mise à jour de la contrainte")
        }
      } catch (err: any) {
        console.error("Erreur avec la méthode 3:", err)
        throw err
      }
    } catch (err: any) {
      console.error("Toutes les méthodes ont échoué:", err)
      setError(err.message || "Une erreur est survenue lors de la mise à jour de la contrainte")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-10">
      <Card className="w-full max-w-3xl mx-auto">
        <CardHeader>
          <CardTitle>Correction de la contrainte suite_groupe</CardTitle>
          <CardDescription>
            Cette page permet de corriger la contrainte de vérification sur la colonne suite_groupe de la table
            patients.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Alert>
              <AlertTitle>Information</AlertTitle>
              <AlertDescription>
                Cette page va mettre à jour la contrainte suite_groupe pour accepter les valeurs suivantes : "NHS",
                "CASH" et "" (chaîne vide).
              </AlertDescription>
            </Alert>

            {error && (
              <Alert variant="destructive">
                <AlertTitle>Erreur</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {success && (
              <Alert className="bg-green-50 border-green-200">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <AlertTitle className="text-green-800">Succès</AlertTitle>
                <AlertDescription className="text-green-700">
                  La contrainte a été mise à jour avec succès.
                </AlertDescription>
              </Alert>
            )}
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={fixConstraint} disabled={loading} className="w-full">
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Mise à jour...
              </>
            ) : (
              "Corriger la contrainte"
            )}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

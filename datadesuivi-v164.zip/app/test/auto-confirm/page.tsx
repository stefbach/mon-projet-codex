"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { supabase } from "@/lib/supabase"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { CheckCircle, XCircle } from "lucide-react"

export default function AutoConfirmPage() {
  const [email, setEmail] = useState("")
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<{ success: boolean; message: string } | null>(null)

  const handleConfirm = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!email || !email.includes("@")) {
      setResult({
        success: false,
        message: "Veuillez entrer une adresse email valide",
      })
      return
    }

    setLoading(true)
    setResult(null)

    try {
      // Appeler une fonction RPC Supabase pour confirmer l'utilisateur
      const { data, error } = await supabase.rpc("admin_confirm_user", {
        user_email: email.trim(),
      })

      if (error) {
        throw error
      }

      if (data === true) {
        setResult({
          success: true,
          message: "L'utilisateur a été confirmé avec succès. Vous pouvez maintenant vous connecter.",
        })
      } else {
        setResult({
          success: false,
          message: "Impossible de confirmer l'utilisateur. Vérifiez que l'email est correct.",
        })
      }
    } catch (error: any) {
      console.error("Erreur lors de la confirmation de l'utilisateur:", error)
      setResult({
        success: false,
        message: `Erreur: ${error.message || "Une erreur s'est produite"}`,
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-10">
      <Card className="max-w-md mx-auto">
        <CardHeader>
          <CardTitle>Confirmation manuelle d'utilisateur</CardTitle>
          <CardDescription>
            Utilisez cet outil pour confirmer manuellement un utilisateur sans qu'il ait besoin de cliquer sur le lien
            d'email.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleConfirm}>
            <div className="grid w-full items-center gap-4">
              <div className="flex flex-col space-y-1.5">
                <Label htmlFor="email">Email de l'utilisateur</Label>
                <Input
                  id="email"
                  placeholder="utilisateur@exemple.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
            </div>

            {result && (
              <Alert className={`mt-4 ${result.success ? "bg-green-50" : "bg-red-50"}`}>
                {result.success ? (
                  <CheckCircle className="h-4 w-4 text-green-600" />
                ) : (
                  <XCircle className="h-4 w-4 text-red-600" />
                )}
                <AlertTitle>{result.success ? "Succès" : "Erreur"}</AlertTitle>
                <AlertDescription>{result.message}</AlertDescription>
              </Alert>
            )}
          </form>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={() => window.history.back()}>
            Retour
          </Button>
          <Button onClick={handleConfirm} disabled={loading}>
            {loading ? "Confirmation..." : "Confirmer l'utilisateur"}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

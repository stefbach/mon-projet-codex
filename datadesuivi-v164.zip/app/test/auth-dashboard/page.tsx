"use client"

import { useState, useEffect } from "react"
import { supabase } from "@/lib/supabase"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Loader2 } from "lucide-react"

export default function AuthDashboardPage() {
  const [session, setSession] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [users, setUsers] = useState<any[]>([])
  const [loadingUsers, setLoadingUsers] = useState(false)

  useEffect(() => {
    async function getSession() {
      const { data, error } = await supabase.auth.getSession()
      if (!error && data.session) {
        setSession(data.session)
      }
      setLoading(false)
    }

    getSession()

    const { data: authListener } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session)
    })

    return () => {
      authListener.subscription.unsubscribe()
    }
  }, [])

  const handleSignOut = async () => {
    await supabase.auth.signOut()
  }

  const loadUsers = async () => {
    setLoadingUsers(true)
    try {
      const { data, error } = await supabase.from("users").select("*")
      if (error) {
        console.error("Erreur lors du chargement des utilisateurs:", error)
      } else {
        setUsers(data || [])
      }
    } catch (error) {
      console.error("Erreur lors du chargement des utilisateurs:", error)
    } finally {
      setLoadingUsers(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-gray-500" />
      </div>
    )
  }

  return (
    <div className="container mx-auto py-10 space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Tableau de bord d'authentification</h1>
        {session && (
          <Button variant="outline" onClick={handleSignOut}>
            Se déconnecter
          </Button>
        )}
      </div>

      <Tabs defaultValue={session ? "profile" : "login"}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="profile">Profil</TabsTrigger>
          <TabsTrigger value="users">Utilisateurs</TabsTrigger>
          <TabsTrigger value="debug">Débogage</TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Profil utilisateur</CardTitle>
            </CardHeader>
            <CardContent>
              {session ? (
                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Email</h3>
                    <p>{session.user.email}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">ID</h3>
                    <p className="font-mono text-sm">{session.user.id}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Dernière connexion</h3>
                    <p>{new Date(session.user.last_sign_in_at).toLocaleString()}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Métadonnées</h3>
                    <pre className="bg-gray-100 p-2 rounded text-xs overflow-auto">
                      {JSON.stringify(session.user.user_metadata, null, 2)}
                    </pre>
                  </div>
                </div>
              ) : (
                <div className="text-center py-4">
                  <p className="text-gray-500">Vous n'êtes pas connecté</p>
                  <Button className="mt-4" onClick={() => (window.location.href = "/login")}>
                    Se connecter
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="users" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Liste des utilisateurs</CardTitle>
            </CardHeader>
            <CardContent>
              <Button onClick={loadUsers} disabled={loadingUsers} className="mb-4">
                {loadingUsers ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Chargement...
                  </>
                ) : (
                  "Charger les utilisateurs"
                )}
              </Button>

              {users.length > 0 && (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          ID
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Email
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Nom
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Rôle
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Actif
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {users.map((user) => (
                        <tr key={user.id}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{user.id}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{user.email}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{user.name || "-"}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{user.role || "-"}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {user.active ? "Oui" : "Non"}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {users.length === 0 && !loadingUsers && (
                <p className="text-gray-500">Cliquez sur "Charger les utilisateurs" pour voir la liste.</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="debug" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Informations de débogage</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Session actuelle</h3>
                  <pre className="bg-gray-100 p-2 rounded text-xs overflow-auto mt-2">
                    {JSON.stringify(session, null, 2) || "Aucune session"}
                  </pre>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-gray-500">Liens utiles</h3>
                  <ul className="list-disc pl-5 mt-2 space-y-2">
                    <li>
                      <a href="/test/supabase-direct-auth" className="text-blue-600 hover:underline">
                        Test d'authentification directe
                      </a>
                    </li>
                    <li>
                      <a href="/test/fix-login" className="text-blue-600 hover:underline">
                        Réparer les problèmes de connexion
                      </a>
                    </li>
                    <li>
                      <a href="/test/reset-password" className="text-blue-600 hover:underline">
                        Réinitialisation de mot de passe
                      </a>
                    </li>
                    <li>
                      <a href="/login" className="text-blue-600 hover:underline">
                        Page de connexion principale
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

"use client"

import type React from "react"

import { useState } from "react"
import { supabase } from "@/lib/supabase"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2 } from "lucide-react"
import { toast } from "@/components/ui/use-toast"

export default function CreateUserPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [name, setName] = useState("")
  const [role, setRole] = useState("closer")
  const [loading, setLoading] = useState(false)
  const [users, setUsers] = useState<any[]>([])
  const [loadingUsers, setLoadingUsers] = useState(false)

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      // 1. Créer l'utilisateur dans Supabase Auth
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            name,
            role,
          },
        },
      })

      if (error) {
        toast({
          variant: "destructive",
          title: "Erreur",
          description: error.message,
        })
        return
      }

      // 2. Confirmer l'utilisateur manuellement
      await supabase.rpc("confirm_user", { email_to_confirm: email })

      // 3. Ajouter l'utilisateur à la table users
      if (data.user) {
        const { error: insertError } = await supabase.from("users").insert({
          id: data.user.id,
          email,
          name,
          role,
          active: true,
        })

        if (insertError) {
          toast({
            variant: "destructive",
            title: "Erreur",
            description: "Utilisateur créé mais erreur lors de l'ajout à la table users",
          })
          return
        }
      }

      toast({
        title: "Succès",
        description: "Utilisateur créé avec succès",
      })

      // Réinitialiser le formulaire
      setEmail("")
      setPassword("")
      setName("")

      // Recharger la liste des utilisateurs
      loadUsers()
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Erreur",
        description: error.message,
      })
    } finally {
      setLoading(false)
    }
  }

  const loadUsers = async () => {
    setLoadingUsers(true)
    try {
      // Utiliser la fonction RPC pour récupérer tous les utilisateurs
      const { data, error } = await supabase.rpc("get_all_users")

      if (error) {
        toast({
          variant: "destructive",
          title: "Erreur",
          description: error.message,
        })
        return
      }

      setUsers(data || [])
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Erreur",
        description: error.message,
      })
    } finally {
      setLoadingUsers(false)
    }
  }

  return (
    <div className="container mx-auto py-10">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Créer un utilisateur</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleCreateUser} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="name">Nom</Label>
                <Input id="name" value={name} onChange={(e) => setName(e.target.value)} required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Mot de passe (min. 6 caractères)</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  minLength={6}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="role">Rôle</Label>
                <select
                  id="role"
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                  className="w-full p-2 border rounded"
                >
                  <option value="closer">Closer</option>
                  <option value="admin">Admin</option>
                </select>
              </div>

              <Button type="submit" disabled={loading} className="w-full">
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Création...
                  </>
                ) : (
                  "Créer l'utilisateur"
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex justify-between items-center">
              <span>Utilisateurs existants</span>
              <Button onClick={loadUsers} disabled={loadingUsers} variant="outline" size="sm">
                {loadingUsers ? <Loader2 className="h-4 w-4 animate-spin" /> : "Rafraîchir"}
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {users.length > 0 ? (
              <div className="space-y-2">
                {users.map((user) => (
                  <div key={user.id} className="p-3 border rounded">
                    <div className="font-medium">{user.email}</div>
                    <div className="text-sm text-gray-500">
                      Confirmé: {user.confirmed ? "Oui" : "Non"} | Créé le:{" "}
                      {new Date(user.created_at).toLocaleDateString()}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-4 text-gray-500">
                {loadingUsers ? "Chargement..." : "Cliquez sur Rafraîchir pour voir les utilisateurs"}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

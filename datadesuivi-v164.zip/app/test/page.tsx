import Link from "next/link"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export default function TestPage() {
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-6">Page de test</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Test de connexion Supabase</CardTitle>
            <CardDescription>Vérifier la connexion à la base de données</CardDescription>
          </CardHeader>
          <CardContent>
            <p>Cette page teste la connexion à Supabase et affiche les tables disponibles.</p>
          </CardContent>
          <CardFooter>
            <Button asChild>
              <Link href="/test/supabase-connection">Tester la connexion</Link>
            </Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Liste des patients</CardTitle>
            <CardDescription>Afficher les patients depuis Supabase</CardDescription>
          </CardHeader>
          <CardContent>
            <p>Cette page affiche les patients depuis la vue patients_with_closer.</p>
          </CardContent>
          <CardFooter>
            <Button asChild>
              <Link href="/test/patients-list">Voir les patients</Link>
            </Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Version HTML</CardTitle>
            <CardDescription>Version HTML de la liste des patients</CardDescription>
          </CardHeader>
          <CardContent>
            <p>Cette page affiche les patients avec le code HTML fourni.</p>
          </CardContent>
          <CardFooter>
            <Button asChild>
              <Link href="/test/html-patients-list">Voir la version HTML</Link>
            </Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Test de création d'utilisateur</CardTitle>
            <CardDescription>Tester la fonction createUser</CardDescription>
          </CardHeader>
          <CardContent>
            <p>Cette page permet de tester la création d'un nouvel utilisateur dans Supabase.</p>
          </CardContent>
          <CardFooter>
            <Button asChild>
              <Link href="/test/create-user">Tester la création</Link>
            </Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Formulaire simple</CardTitle>
            <CardDescription>Test de formulaire simple</CardDescription>
          </CardHeader>
          <CardContent>
            <p>Cette page contient un formulaire simple pour tester les composants.</p>
          </CardContent>
          <CardFooter>
            <Button asChild>
              <Link href="/test/simple-form">Voir le formulaire</Link>
            </Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Debug utilisateur</CardTitle>
            <CardDescription>Déboguer les informations utilisateur</CardDescription>
          </CardHeader>
          <CardContent>
            <p>Cette page affiche les informations de débogage pour l'utilisateur connecté.</p>
          </CardContent>
          <CardFooter>
            <Button asChild>
              <Link href="/test/debug-user">Déboguer utilisateur</Link>
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

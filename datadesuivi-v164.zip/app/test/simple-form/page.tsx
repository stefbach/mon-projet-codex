"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Loader2 } from "lucide-react"

export default function SimpleFormPage() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<string>("")
  const [formData, setFormData] = useState({
    name: "Patient Test",
    email: "patient@example.com",
    doctor: "Dr Test",
  })

  // URL du script Google Apps Script pour les patients
  const PATIENT_SCRIPT_URL =
    "https://script.google.com/macros/s/AKfycbzoXMgXrF9tDU6Twfr5dr2qJB-bepbfybNzD0YxrxbWYaECCHOmQKTyvpxOLn-syS5U_w/exec"

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setResult("")

    try {
      // Construire l'URL avec les paramètres
      const params = new URLSearchParams({
        action: "addPatient",
        ...formData,
        timestamp: new Date().toISOString(),
        closer: "test@example.com",
      })

      const url = `${PATIENT_SCRIPT_URL}?${params.toString()}`
      setResult(`Envoi de la requête à: ${url}\n\n`)

      // Utiliser l'API fetch pour envoyer la requête
      const response = await fetch(url, {
        method: "GET",
        mode: "no-cors", // Important pour éviter les problèmes CORS
      })

      setResult((prev) => prev + "Requête envoyée avec succès!\n\n")
      setResult((prev) => prev + "Note: En raison du mode 'no-cors', nous ne pouvons pas voir la réponse du serveur.\n")
      setResult((prev) => prev + "Vérifiez votre feuille Google Sheets pour voir si les données ont été ajoutées.")
    } catch (error) {
      console.error("Erreur lors de l'envoi:", error)
      setResult((prev) => prev + `Erreur: ${(error as Error).message}`)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-8">
      <Card>
        <CardHeader>
          <CardTitle>Formulaire de test simplifié</CardTitle>
          <CardDescription>
            Ce formulaire envoie directement les données au script Google Apps Script sans passer par les services de
            l'application.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nom</Label>
              <Input id="name" name="name" value={formData.name} onChange={handleChange} required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="doctor">Médecin</Label>
              <Input id="doctor" name="doctor" value={formData.doctor} onChange={handleChange} required />
            </div>

            <Button type="submit" disabled={loading} className="w-full">
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Envoi en cours...
                </>
              ) : (
                "Envoyer"
              )}
            </Button>

            {result && (
              <div className="mt-4 p-4 bg-gray-100 rounded-md">
                <pre className="whitespace-pre-wrap text-sm">{result}</pre>
              </div>
            )}
          </form>
        </CardContent>
      </Card>
    </div>
  )
}

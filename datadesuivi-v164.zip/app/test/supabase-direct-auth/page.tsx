"use client"

import type React from "react"

import { useState } from "react"
import { supabase } from "@/lib/supabase"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2 } from "lucide-react"

export default function SupabaseDirectAuthPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [name, setName] = useState("")
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [loginEmail, setLoginEmail] = useState("")
  const [loginPassword, setLoginPassword] = useState("")
  const [loginLoading, setLoginLoading] = useState(false)
  const [loginResult, setLoginResult] = useState<any>(null)

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setResult(null)

    try {
      // Créer l'utilisateur directement avec l'API Supabase
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            name,
          },
        },
      })

      if (error) {
        setResult({
          success: false,
          message: error.message,
          details: JSON.stringify(error, null, 2),
        })
      } else {
        // Confirmer manuellement l'utilisateur
        await supabase.rpc("admin_confirm_user", { user_email: email })

        // Ajouter l'utilisateur à la table users
        const { error: insertError } = await supabase.from("users").insert([
          {
            id: data.user?.id,
            email,
            name,
            role: "closer",
            active: true,
          },
        ])

        setResult({
          success: !insertError,
          message: insertError ? insertError.message : "Utilisateur créé avec succès",
          details: JSON.stringify(data, null, 2),
          user: data.user,
        })

        // Préremplir les champs de connexion
        setLoginEmail(email)
        setLoginPassword(password)
      }
    } catch (error: any) {
      setResult({
        success: false,
        message: error.message,
        details: JSON.stringify(error, null, 2),
      })
    } finally {
      setLoading(false)
    }
  }

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoginLoading(true)
    setLoginResult(null)

    try {
      // Connexion directe avec l'API Supabase
      const { data, error } = await supabase.auth.signInWithPassword({
        email: loginEmail,
        password: loginPassword,
      })

      if (error) {
        setLoginResult({
          success: false,
          message: error.message,
          details: JSON.stringify(error, null, 2),
        })
      } else {
        setLoginResult({
          success: true,
          message: "Connexion réussie",
          details: JSON.stringify(data, null, 2),
          user: data.user,
          session: data.session,
        })
      }
    } catch (error: any) {
      setLoginResult({
        success: false,
        message: error.message,
        details: JSON.stringify(error, null, 2),
      })
    } finally {
      setLoginLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-10 space-y-8">
      <h1 className="text-2xl font-bold">Test direct de l'authentification Supabase</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Créer un utilisateur</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSignUp} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="name">Nom</Label>
                <Input id="name" value={name} onChange={(e) => setName(e.target.value)} required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Mot de passe (min. 6 caractères)</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  minLength={6}
                />
              </div>

              <Button type="submit" disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Création...
                  </>
                ) : (
                  "Créer l'utilisateur"
                )}
              </Button>

              {result && (
                <div className={`mt-4 p-4 rounded-md ${result.success ? "bg-green-50" : "bg-red-50"}`}>
                  <p className={result.success ? "text-green-700" : "text-red-700"}>{result.message}</p>
                  {result.user && (
                    <p className="text-sm mt-2">
                      ID utilisateur: <code>{result.user.id}</code>
                    </p>
                  )}
                  <details className="mt-2">
                    <summary className="cursor-pointer text-sm">Détails techniques</summary>
                    <pre className="text-xs mt-2 p-2 bg-gray-100 rounded overflow-auto max-h-40">{result.details}</pre>
                  </details>
                </div>
              )}
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Se connecter</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSignIn} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="loginEmail">Email</Label>
                <Input
                  id="loginEmail"
                  type="email"
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="loginPassword">Mot de passe</Label>
                <Input
                  id="loginPassword"
                  type="password"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  required
                />
              </div>

              <Button type="submit" disabled={loginLoading}>
                {loginLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Connexion...
                  </>
                ) : (
                  "Se connecter"
                )}
              </Button>

              {loginResult && (
                <div className={`mt-4 p-4 rounded-md ${loginResult.success ? "bg-green-50" : "bg-red-50"}`}>
                  <p className={loginResult.success ? "text-green-700" : "text-red-700"}>{loginResult.message}</p>
                  {loginResult.user && (
                    <p className="text-sm mt-2">
                      ID utilisateur: <code>{loginResult.user.id}</code>
                    </p>
                  )}
                  <details className="mt-2">
                    <summary className="cursor-pointer text-sm">Détails techniques</summary>
                    <pre className="text-xs mt-2 p-2 bg-gray-100 rounded overflow-auto max-h-40">
                      {loginResult.details}
                    </pre>
                  </details>
                </div>
              )}
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { supabase } from "@/lib/supabase"
import { refreshSchemaCache } from "@/lib/supabase"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle, CheckCircle2, RefreshCw } from "lucide-react"
import Link from "next/link"

export default function AddNoShowStatusPage() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [needsExecSql, setNeedsExecSql] = useState(false)
  const [refreshing, setRefreshing] = useState(false)

  const refreshCache = async () => {
    setRefreshing(true)
    try {
      const result = await refreshSchemaCache()
      if (result.success) {
        setResult("Cache du schéma rafraîchi avec succès. Veuillez réessayer l'opération.")
        setError(null)
        setNeedsExecSql(false)
      } else {
        setError(`Erreur lors du rafraîchissement du cache: ${result.error}`)
      }
    } catch (err: any) {
      setError(`Erreur lors du rafraîchissement du cache: ${err.message}`)
    } finally {
      setRefreshing(false)
    }
  }

  const checkExecSqlFunction = async () => {
    try {
      // Essayer d'appeler la fonction exec_sql avec une requête simple
      const { error } = await supabase.rpc("exec_sql", { sql_query: "SELECT 1" })

      if (error && (error.message.includes("function") || error.message.includes("not found"))) {
        setNeedsExecSql(true)
        return false
      }

      return !error
    } catch (err) {
      setNeedsExecSql(true)
      return false
    }
  }

  const runMigration = async () => {
    setLoading(true)
    setResult(null)
    setError(null)
    setNeedsExecSql(false)

    try {
      // Vérifier d'abord si la fonction exec_sql existe
      const execSqlExists = await checkExecSqlFunction()

      if (!execSqlExists) {
        setError("La fonction exec_sql n'est pas disponible. Veuillez d'abord la créer.")
        setNeedsExecSql(true)
        return
      }

      // SQL pour mettre à jour la contrainte de vérification
      const sql = `
        DO $$
        BEGIN
          IF EXISTS (
            SELECT 1 FROM pg_constraint 
            WHERE conname = 'patients_status_check' 
            AND conrelid = 'patients'::regclass
          ) THEN
            -- Supprimer la contrainte existante
            ALTER TABLE patients DROP CONSTRAINT patients_status_check;
          END IF;
          
          -- Ajouter la nouvelle contrainte avec no_show
          ALTER TABLE patients ADD CONSTRAINT patients_status_check 
            CHECK (status IN ('en_attente', 'a_contacter', 'rdv_programme', 'vente', 'perdu', 
                             'non_defini', 'en_cours', 'annule', 'a_rappeler', 'non_interesse', 'no_show'));
        END $$;
      `

      const { error } = await supabase.rpc("exec_sql", { sql_query: sql })

      if (error) {
        throw error
      }

      setResult("Migration exécutée avec succès. Le statut 'no_show' est maintenant accepté dans la base de données.")
    } catch (err: any) {
      console.error("Erreur lors de l'exécution de la migration:", err)
      setError(`Erreur: ${err.message || "Une erreur s'est produite"}`)

      // Vérifier si l'erreur est liée à la fonction manquante
      if (
        err.message &&
        (err.message.includes("function") || err.message.includes("not found") || err.message.includes("schema cache"))
      ) {
        setNeedsExecSql(true)
      }
    } finally {
      setLoading(false)
    }
  }

  // Méthode alternative utilisant une requête directe
  const runDirectMigration = async () => {
    setLoading(true)
    setResult(null)
    setError(null)

    try {
      // Vérifier d'abord si la table patients existe
      const { data: tableExists, error: tableError } = await supabase.from("patients").select("id").limit(1)

      if (tableError) {
        throw new Error(`La table patients n'existe pas ou n'est pas accessible: ${tableError.message}`)
      }

      // Vérifier les colonnes de la table patients
      const { data: columns, error: columnsError } = await supabase
        .from("information_schema.columns")
        .select("column_name")
        .eq("table_name", "patients")
        .eq("column_name", "status")

      if (columnsError) {
        throw new Error(`Erreur lors de la vérification des colonnes: ${columnsError.message}`)
      }

      if (!columns || columns.length === 0) {
        throw new Error("La colonne 'status' n'existe pas dans la table patients")
      }

      // Créer une fonction temporaire pour mettre à jour la contrainte
      const { error: functionError } = await supabase.rpc("create_temp_update_function", {
        function_name: "update_status_constraint",
      })

      if (functionError) {
        throw new Error(`Erreur lors de la création de la fonction temporaire: ${functionError.message}`)
      }

      // Exécuter la fonction temporaire
      const { error: execError } = await supabase.rpc("update_status_constraint")

      if (execError) {
        throw new Error(`Erreur lors de l'exécution de la fonction temporaire: ${execError.message}`)
      }

      setResult(
        "Migration exécutée avec succès via la méthode alternative. Le statut 'no_show' est maintenant accepté dans la base de données.",
      )
    } catch (err: any) {
      console.error("Erreur lors de l'exécution de la migration alternative:", err)
      setError(`Erreur (méthode alternative): ${err.message || "Une erreur s'est produite"}`)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-10">
      <Card>
        <CardHeader>
          <CardTitle>Ajouter le statut "No Show"</CardTitle>
          <CardDescription>
            Cette page permet d'ajouter le statut "no_show" à la liste des statuts valides dans la base de données.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="mb-4">
            Cette migration va mettre à jour la contrainte de vérification sur la colonne "status" de la table
            "patients" pour accepter la valeur "no_show".
          </p>

          {needsExecSql && (
            <Alert variant="destructive" className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Fonction exec_sql manquante</AlertTitle>
              <AlertDescription>
                <p className="mb-2">
                  La fonction exec_sql n'est pas disponible dans votre base de données. Vous devez d'abord créer cette
                  fonction.
                </p>
                <Link href="/test/create-exec-sql-function" className="text-blue-600 hover:underline">
                  Cliquez ici pour créer la fonction exec_sql
                </Link>
              </AlertDescription>
            </Alert>
          )}

          {result && (
            <Alert variant="default" className="mb-4 bg-green-50 border-green-200">
              <CheckCircle2 className="h-4 w-4 text-green-600" />
              <AlertTitle className="text-green-600">Succès</AlertTitle>
              <AlertDescription className="text-green-700">{result}</AlertDescription>
            </Alert>
          )}

          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Erreur</AlertTitle>
              <AlertDescription>
                {error}
                {error.includes("schema cache") && (
                  <div className="mt-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={refreshCache}
                      disabled={refreshing}
                      className="flex items-center"
                    >
                      {refreshing ? (
                        <>
                          <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                          Rafraîchissement en cours...
                        </>
                      ) : (
                        <>
                          <RefreshCw className="mr-2 h-4 w-4" />
                          Rafraîchir le cache du schéma
                        </>
                      )}
                    </Button>
                  </div>
                )}
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
        <CardFooter className="flex flex-col items-start gap-4 sm:flex-row sm:items-center">
          <Button onClick={runMigration} disabled={loading}>
            {loading ? "Exécution en cours..." : "Exécuter la migration"}
          </Button>

          <Button variant="outline" onClick={runDirectMigration} disabled={loading} className="w-full sm:w-auto">
            Méthode alternative
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

"use client"

import { useState } from "react"
import { supabase } from "@/lib/supabase"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { CheckCircle, AlertCircle, Loader2 } from "lucide-react"

export default function UpdateSchemaPage() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<{
    success: boolean
    message: string
    details?: string
  } | null>(null)

  const updateSchema = async () => {
    setLoading(true)
    setResult(null)

    try {
      // Vérifier si l'extension uuid-ossp existe
      const { error: extensionError } = await supabase.rpc("create_uuid_extension")

      if (extensionError && !extensionError.message.includes("already exists")) {
        setResult({
          success: false,
          message: "Erreur lors de la création de l'extension uuid-ossp",
          details: extensionError.message,
        })
        return
      }

      // Vérifier si la table users existe
      const { data: tableExists, error: tableCheckError } = await supabase
        .from("information_schema.tables")
        .select("table_name")
        .eq("table_schema", "public")
        .eq("table_name", "users")
        .maybeSingle()

      if (tableCheckError) {
        setResult({
          success: false,
          message: "Erreur lors de la vérification de la table users",
          details: tableCheckError.message,
        })
        return
      }

      if (!tableExists) {
        // Créer la table users
        const { error: createTableError } = await supabase.rpc("execute_sql", {
          sql: `
            CREATE TABLE public.users (
              id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
              email VARCHAR(255) UNIQUE NOT NULL,
              name VARCHAR(255) NOT NULL,
              role VARCHAR(50) NOT NULL,
              active BOOLEAN DEFAULT true,
              password_hash VARCHAR(255),
              created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
              password_updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
            );
          `,
        })

        if (createTableError) {
          setResult({
            success: false,
            message: "Erreur lors de la création de la table users",
            details: createTableError.message,
          })
          return
        }
      } else {
        // Vérifier si les colonnes nécessaires existent
        const { data: columns, error: columnsError } = await supabase
          .from("information_schema.columns")
          .select("column_name")
          .eq("table_schema", "public")
          .eq("table_name", "users")

        if (columnsError) {
          setResult({
            success: false,
            message: "Erreur lors de la vérification des colonnes",
            details: columnsError.message,
          })
          return
        }

        const columnNames = columns.map((col) => col.column_name)

        // Ajouter les colonnes manquantes
        if (!columnNames.includes("password_hash")) {
          const { error: addColumnError } = await supabase.rpc("execute_sql", {
            sql: "ALTER TABLE public.users ADD COLUMN password_hash VARCHAR(255);",
          })

          if (addColumnError) {
            setResult({
              success: false,
              message: "Erreur lors de l'ajout de la colonne password_hash",
              details: addColumnError.message,
            })
            return
          }
        }

        if (!columnNames.includes("password_updated_at")) {
          const { error: addColumnError } = await supabase.rpc("execute_sql", {
            sql: "ALTER TABLE public.users ADD COLUMN password_updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();",
          })

          if (addColumnError) {
            setResult({
              success: false,
              message: "Erreur lors de l'ajout de la colonne password_updated_at",
              details: addColumnError.message,
            })
            return
          }
        }
      }

      // Mettre à jour les utilisateurs existants avec un mot de passe par défaut
      const { error: updateError } = await supabase.rpc("execute_sql", {
        sql: `
          UPDATE public.users 
          SET password_hash = '$2a$10$X7VYHy.iYDVB.J7tgJq5B.D5jS9EVz1gHjzGhpnT7s9k9LJZUUeim' -- Mot de passe: admin123
          WHERE password_hash IS NULL;
        `,
      })

      if (updateError) {
        setResult({
          success: false,
          message: "Erreur lors de la mise à jour des mots de passe",
          details: updateError.message,
        })
        return
      }

      // Créer des utilisateurs de test
      const { error: insertError } = await supabase.rpc("execute_sql", {
        sql: `
          INSERT INTO public.users (id, email, name, role, active, password_hash, created_at, password_updated_at)
          VALUES 
          ('00000000-0000-0000-0000-000000000001', 'admin@email.com', 'Administrateur', 'admin', true, '$2a$10$X7VYHy.iYDVB.J7tgJq5B.D5jS9EVz1gHjzGhpnT7s9k9LJZUUeim', NOW(), NOW()),
          ('00000000-0000-0000-0000-000000000002', 'closer@email.com', 'Closer', 'closer', true, '$2a$10$X7VYHy.iYDVB.J7tgJq5B.D5jS9EVz1gHjzGhpnT7s9k9LJZUUeim', NOW(), NOW())
          ON CONFLICT (email) DO NOTHING;
        `,
      })

      if (insertError) {
        setResult({
          success: false,
          message: "Erreur lors de la création des utilisateurs de test",
          details: insertError.message,
        })
        return
      }

      // Créer des index
      const { error: indexError } = await supabase.rpc("execute_sql", {
        sql: `
          CREATE INDEX IF NOT EXISTS users_email_idx ON public.users (email);
          CREATE INDEX IF NOT EXISTS users_role_idx ON public.users (role);
        `,
      })

      if (indexError) {
        setResult({
          success: false,
          message: "Erreur lors de la création des index",
          details: indexError.message,
        })
        return
      }

      // Vérifier que tout est bien configuré
      const { data: finalCheck, error: finalCheckError } = await supabase
        .from("users")
        .select("id, email, name, role, password_hash")
        .limit(1)

      if (finalCheckError) {
        setResult({
          success: false,
          message: "La structure a été mise à jour mais une erreur est survenue lors de la vérification finale",
          details: finalCheckError.message,
        })
        return
      }

      setResult({
        success: true,
        message: "La structure de la base de données a été mise à jour avec succès",
        details: `${finalCheck.length} utilisateur(s) trouvé(s)`,
      })
    } catch (error: any) {
      setResult({
        success: false,
        message: "Une erreur inattendue s'est produite",
        details: error.message || "Erreur inconnue",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-8">
      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle>Mise à jour du schéma de la base de données</CardTitle>
          <CardDescription>
            Cette page vous permet de mettre à jour la structure de la table 'users' pour ajouter les colonnes
            manquantes.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="mb-4">
            L'erreur <code>Could not find the 'password_hash' column of 'users'</code> indique que la colonne
            'password_hash' n'existe pas dans la table 'users'. Cette opération va:
          </p>
          <ul className="list-disc pl-6 mb-4 space-y-1">
            <li>Vérifier si la table 'users' existe et la créer si nécessaire</li>
            <li>Ajouter les colonnes 'password_hash' et 'password_updated_at' si elles n'existent pas</li>
            <li>Mettre à jour les utilisateurs existants avec un mot de passe par défaut</li>
            <li>Créer des utilisateurs de test si nécessaire</li>
            <li>Créer des index pour améliorer les performances</li>
          </ul>

          {result && (
            <Alert variant={result.success ? "default" : "destructive"} className="mb-4">
              <div className="flex items-center">
                {result.success ? <CheckCircle className="h-4 w-4 mr-2" /> : <AlertCircle className="h-4 w-4 mr-2" />}
                <AlertTitle>{result.success ? "Succès" : "Erreur"}</AlertTitle>
              </div>
              <AlertDescription>
                <p>{result.message}</p>
                {result.details && <p className="text-sm mt-2 font-mono bg-gray-100 p-2 rounded">{result.details}</p>}
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
        <CardFooter>
          <Button onClick={updateSchema} disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Mise à jour en cours...
              </>
            ) : (
              "Mettre à jour le schéma"
            )}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

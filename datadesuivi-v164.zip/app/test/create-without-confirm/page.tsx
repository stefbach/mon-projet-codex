"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Loader2, CheckCircle, XCircle } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { supabase } from "@/lib/supabase"

export default function CreateWithoutConfirmPage() {
  const [formData, setFormData] = useState({
    email: "",
    name: "",
    password: "",
    role: "closer" as "admin" | "closer",
  })
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<{
    success?: boolean
    message?: string
    userId?: string
  } | null>(null)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleRoleChange = (value: string) => {
    setFormData((prev) => ({ ...prev, role: value as "admin" | "closer" }))
  }

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setResult(null)

    try {
      // 1. Créer l'utilisateur avec l'API d'administration
      const { data: authData, error: authError } = await supabase.auth.admin.createUser({
        email: formData.email.trim(),
        password: formData.password,
        email_confirm: true, // Confirmer automatiquement l'email
        user_metadata: {
          name: formData.name.trim(),
          role: formData.role,
        },
      })

      if (authError) {
        console.error("Erreur lors de la création de l'utilisateur:", authError)
        setResult({
          success: false,
          message: `Erreur: ${authError.message}`,
        })
        return
      }

      if (!authData || !authData.user) {
        setResult({
          success: false,
          message: "Erreur: Aucune donnée utilisateur retournée",
        })
        return
      }

      // 2. Ajouter l'utilisateur à la table users
      const { error: insertError } = await supabase.from("users").insert([
        {
          id: authData.user.id,
          email: formData.email.trim(),
          name: formData.name.trim(),
          role: formData.role,
          active: true,
        },
      ])

      if (insertError) {
        console.error("Erreur lors de l'insertion dans la table users:", insertError)
        setResult({
          success: true,
          message: `Utilisateur créé avec succès, mais non ajouté à la table users: ${insertError.message}`,
          userId: authData.user.id,
        })
        return
      }

      setResult({
        success: true,
        message: `Utilisateur ${formData.email} créé avec succès et prêt à se connecter`,
        userId: authData.user.id,
      })

      toast({
        title: "Succès",
        description: `Utilisateur ${formData.email} créé avec succès`,
      })

      // Réinitialiser le formulaire
      setFormData({
        email: "",
        name: "",
        password: "",
        role: "closer",
      })
    } catch (error: any) {
      console.error("Erreur:", error)
      setResult({
        success: false,
        message: `Erreur: ${error.message || "Une erreur s'est produite"}`,
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-10">
      <Card className="max-w-md mx-auto">
        <CardHeader>
          <CardTitle>Créer un utilisateur sans confirmation</CardTitle>
          <CardDescription>
            Créez un utilisateur qui pourra se connecter immédiatement sans confirmation d'email
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleCreateUser} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                name="email"
                type="email"
                required
                placeholder="utilisateur@exemple.com"
                value={formData.email}
                onChange={handleChange}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="name">Nom</Label>
              <Input
                id="name"
                name="name"
                required
                placeholder="Nom de l'utilisateur"
                value={formData.name}
                onChange={handleChange}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Mot de passe</Label>
              <Input
                id="password"
                name="password"
                type="password"
                required
                placeholder="Mot de passe"
                value={formData.password}
                onChange={handleChange}
              />
            </div>

            <div className="space-y-2">
              <Label>Rôle</Label>
              <RadioGroup value={formData.role} onValueChange={handleRoleChange}>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="admin" id="role-admin" />
                  <Label htmlFor="role-admin">Administrateur</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="closer" id="role-closer" />
                  <Label htmlFor="role-closer">Closer</Label>
                </div>
              </RadioGroup>
            </div>

            {result && (
              <div
                className={`p-4 rounded-md ${result.success ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"}`}
              >
                <div className="flex items-center">
                  {result.success ? (
                    <CheckCircle className="h-5 w-5 mr-2 text-green-500" />
                  ) : (
                    <XCircle className="h-5 w-5 mr-2 text-red-500" />
                  )}
                  <p>{result.message}</p>
                </div>
                {result.success && result.userId && <p className="mt-2 text-sm">ID utilisateur: {result.userId}</p>}
              </div>
            )}

            <Button type="submit" disabled={loading} className="w-full">
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Création en cours...
                </>
              ) : (
                "Créer l'utilisateur"
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}

export default function HtmlPatientsList() {
  return (
    <div className="container mx-auto py-8">
      <div className="bg-white p-8 rounded-lg shadow-md">
        <h1 className="text-2xl font-bold mb-6">Patients enregistrés</h1>
        <ul id="patients-list" className="list-disc pl-5">
          Chargement...
        </ul>

        <script
          type="text/javascript"
          dangerouslySetInnerHTML={{
            __html: `
          document.addEventListener('DOMContentLoaded', async function() {
            // Chargement dynamique de Supabase
            const { createClient } = await import('https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm');

            // Identifiants Supabase (sécurisé pour usage public uniquement avec anon key)
            const supabaseUrl = 'https://gllhemdeucwaxbmoyzee.supabase.co';
            const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdsbGhlbWRldWN3YXhibW95emVlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDY5ODk3OTEsImV4cCI6MjA2MjU2NTc5MX0.F492Qh8X-BbyiytBTc2vFPyeu8sBhQR5ivAfpzlXoo0';

            const supabase = createClient(supabaseUrl, supabaseKey);

            // Fonction pour charger les patients depuis la vue
            async function loadPatients() {
              const { data, error } = await supabase
                .from('patients_with_closer')
                .select('*');

              const list = document.getElementById('patients-list');
              list.innerHTML = '';

              if (error) {
                console.error('Erreur :', error.message);
                list.innerHTML = \`<li>Erreur lors du chargement : \${error.message}</li>\`;
                return;
              }

              if (!data || data.length === 0) {
                list.innerHTML = '<li>Aucun patient trouvé.</li>';
                return;
              }

              data.forEach(patient => {
                const li = document.createElement('li');
                li.textContent = \`\${patient.name} (\${patient.email || 'sans email'}) – Closer : \${patient.closer_name || 'non assigné'}\`;
                list.appendChild(li);
              });
            }

            loadPatients();
          });
        `,
          }}
        />
      </div>
    </div>
  )
}

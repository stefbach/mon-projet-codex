"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle, CheckCircle2 } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"

export default function DirectSqlUpdatePage() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [sqlOutput, setSqlOutput] = useState<string | null>(null)
  const [customSql, setCustomSql] = useState<string>("")

  // Fonction pour exécuter du SQL directement via l'API REST de Supabase
  const executeSql = async (sql: string, description: string) => {
    setLoading(true)
    setResult(null)
    setError(null)
    setSqlOutput(null)

    try {
      // Utiliser l'API REST de Supabase pour exécuter du SQL directement
      const response = await fetch(`${process.env.NEXT_PUBLIC_SUPABASE_URL}/rest/v1/rpc/exec_sql`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          apikey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "",
          Authorization: `Bearer ${process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ""}`,
          Prefer: "return=minimal",
        },
        body: JSON.stringify({ sql_query: sql }),
      })

      if (!response.ok) {
        const errorText = await response.text()
        throw new Error(`Erreur HTTP ${response.status}: ${errorText}`)
      }

      setResult(`${description} exécuté avec succès!`)
      setSqlOutput(`SQL exécuté avec succès: ${sql}`)
    } catch (err: any) {
      console.error("Erreur lors de l'exécution du SQL:", err)
      setError(`Erreur: ${err.message || "Une erreur s'est produite"}`)

      // Si l'erreur est due à l'absence de la fonction exec_sql, essayons de la créer
      if (err.message && err.message.includes("function") && err.message.includes("exec_sql")) {
        await createExecSqlFunction()
      }
    } finally {
      setLoading(false)
    }
  }

  // Fonction pour créer la fonction exec_sql
  const createExecSqlFunction = async () => {
    setLoading(true)
    setResult(null)
    setError(null)
    setSqlOutput(null)

    try {
      // Utiliser l'API SQL de Supabase pour créer la fonction exec_sql
      const response = await fetch(`${process.env.NEXT_PUBLIC_SUPABASE_URL}/rest/v1/`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          apikey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "",
          Authorization: `Bearer ${process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ""}`,
          Prefer: "return=minimal",
        },
        body: JSON.stringify({
          query: `
            CREATE OR REPLACE FUNCTION exec_sql(sql_query TEXT) RETURNS VOID AS $$
            BEGIN
              EXECUTE sql_query;
            END;
            $$ LANGUAGE plpgsql SECURITY DEFINER;
          `,
        }),
      })

      if (!response.ok) {
        const errorText = await response.text()
        throw new Error(`Erreur HTTP ${response.status}: ${errorText}`)
      }

      setResult("Fonction exec_sql créée avec succès!")
      setSqlOutput("Fonction exec_sql créée avec succès!")
    } catch (err: any) {
      console.error("Erreur lors de la création de la fonction exec_sql:", err)
      setError(`Erreur: ${err.message || "Une erreur s'est produite"}`)
    } finally {
      setLoading(false)
    }
  }

  // Fonction pour mettre à jour la contrainte de statut
  const updateStatusConstraint = async () => {
    const sql = `
      DO $$
      BEGIN
        IF EXISTS (
          SELECT 1 FROM pg_constraint 
          WHERE conname = 'patients_status_check' 
          AND conrelid = 'patients'::regclass
        ) THEN
          -- Supprimer la contrainte existante
          ALTER TABLE patients DROP CONSTRAINT patients_status_check;
        END IF;
        
        -- Ajouter la nouvelle contrainte avec no_show
        ALTER TABLE patients ADD CONSTRAINT patients_status_check 
          CHECK (status IN ('en_attente', 'a_contacter', 'rdv_programme', 'vente', 'perdu', 
                           'non_defini', 'en_cours', 'annule', 'a_rappeler', 'non_interesse', 'no_show'));
      END $$;
    `

    await executeSql(sql, "Mise à jour de la contrainte de statut")
  }

  // Fonction pour exécuter du SQL personnalisé
  const executeCustomSql = async () => {
    if (!customSql.trim()) {
      setError("Veuillez entrer du SQL à exécuter")
      return
    }

    await executeSql(customSql, "SQL personnalisé")
  }

  // Fonction pour utiliser l'API SQL directe de Supabase
  const useDirectSqlApi = async () => {
    setLoading(true)
    setResult(null)
    setError(null)
    setSqlOutput(null)

    try {
      // Utiliser l'API SQL de Supabase pour exécuter du SQL directement
      const sql = `
        ALTER TABLE patients DROP CONSTRAINT IF EXISTS patients_status_check;
        
        ALTER TABLE patients ADD CONSTRAINT patients_status_check 
          CHECK (status IN ('en_attente', 'a_contacter', 'rdv_programme', 'vente', 'perdu', 
                           'non_defini', 'en_cours', 'annule', 'a_rappeler', 'non_interesse', 'no_show'));
      `

      // Utiliser l'API REST de Supabase pour exécuter du SQL directement
      const response = await fetch(`${process.env.NEXT_PUBLIC_SUPABASE_URL}/rest/v1/`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          apikey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "",
          Authorization: `Bearer ${process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ""}`,
          Prefer: "return=minimal",
        },
        body: JSON.stringify({
          query: sql,
        }),
      })

      if (!response.ok) {
        const errorText = await response.text()
        throw new Error(`Erreur HTTP ${response.status}: ${errorText}`)
      }

      setResult("Contrainte de statut mise à jour avec succès via l'API SQL directe!")
      setSqlOutput(`SQL exécuté avec succès: ${sql}`)
    } catch (err: any) {
      console.error("Erreur lors de l'exécution du SQL direct:", err)
      setError(`Erreur: ${err.message || "Une erreur s'est produite"}`)
    } finally {
      setLoading(false)
    }
  }

  // Fonction pour utiliser l'API de service de Supabase
  const useServiceApi = async () => {
    setLoading(true)
    setResult(null)
    setError(null)
    setSqlOutput(null)

    try {
      // Utiliser l'API de service de Supabase pour exécuter du SQL
      const response = await fetch("/api/update-status-constraint", {
        method: "POST",
      })

      if (!response.ok) {
        const errorText = await response.text()
        throw new Error(`Erreur HTTP ${response.status}: ${errorText}`)
      }

      const data = await response.json()
      setResult(data.message || "Contrainte de statut mise à jour avec succès via l'API de service!")
      setSqlOutput(data.sql || "SQL exécuté avec succès")
    } catch (err: any) {
      console.error("Erreur lors de l'utilisation de l'API de service:", err)
      setError(`Erreur: ${err.message || "Une erreur s'est produite"}`)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-10">
      <Card>
        <CardHeader>
          <CardTitle>Mise à jour directe de la base de données</CardTitle>
          <CardDescription>
            Cette page permet de mettre à jour directement la base de données sans utiliser de fonctions SQL
            personnalisées.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="update-constraint">
            <TabsList className="mb-4">
              <TabsTrigger value="update-constraint">Mettre à jour la contrainte de statut</TabsTrigger>
              <TabsTrigger value="create-function">Créer la fonction exec_sql</TabsTrigger>
              <TabsTrigger value="direct-api">API SQL directe</TabsTrigger>
              <TabsTrigger value="service-api">API de service</TabsTrigger>
              <TabsTrigger value="custom-sql">SQL personnalisé</TabsTrigger>
            </TabsList>

            <TabsContent value="update-constraint">
              <p className="mb-4">
                Cette action va mettre à jour la contrainte de vérification sur la colonne "status" de la table
                "patients" pour accepter la valeur "no_show".
              </p>
              <Button onClick={updateStatusConstraint} disabled={loading}>
                {loading ? "Exécution en cours..." : "Mettre à jour la contrainte de statut"}
              </Button>
            </TabsContent>

            <TabsContent value="create-function">
              <p className="mb-4">Cette action va créer la fonction exec_sql qui permet d'exécuter du SQL dynamique.</p>
              <Button onClick={createExecSqlFunction} disabled={loading}>
                {loading ? "Création en cours..." : "Créer la fonction exec_sql"}
              </Button>
            </TabsContent>

            <TabsContent value="direct-api">
              <p className="mb-4">
                Cette action va utiliser l'API SQL directe de Supabase pour mettre à jour la contrainte de statut.
              </p>
              <Button onClick={useDirectSqlApi} disabled={loading}>
                {loading ? "Exécution en cours..." : "Utiliser l'API SQL directe"}
              </Button>
            </TabsContent>

            <TabsContent value="service-api">
              <p className="mb-4">
                Cette action va utiliser une API de service côté serveur pour mettre à jour la contrainte de statut.
              </p>
              <Button onClick={useServiceApi} disabled={loading}>
                {loading ? "Exécution en cours..." : "Utiliser l'API de service"}
              </Button>
            </TabsContent>

            <TabsContent value="custom-sql">
              <p className="mb-4">Cette action permet d'exécuter du SQL personnalisé.</p>
              <Textarea
                value={customSql}
                onChange={(e) => setCustomSql(e.target.value)}
                placeholder="Entrez votre SQL ici..."
                className="mb-4"
                rows={5}
              />
              <Button onClick={executeCustomSql} disabled={loading}>
                {loading ? "Exécution en cours..." : "Exécuter le SQL personnalisé"}
              </Button>
            </TabsContent>
          </Tabs>

          {result && (
            <Alert variant="default" className="mt-4 bg-green-50 border-green-200">
              <CheckCircle2 className="h-4 w-4 text-green-600" />
              <AlertTitle className="text-green-600">Succès</AlertTitle>
              <AlertDescription className="text-green-700">{result}</AlertDescription>
            </Alert>
          )}

          {error && (
            <Alert variant="destructive" className="mt-4">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Erreur</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {sqlOutput && (
            <div className="mt-4 p-4 bg-gray-100 rounded overflow-auto">
              <pre className="text-sm">{sqlOutput}</pre>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

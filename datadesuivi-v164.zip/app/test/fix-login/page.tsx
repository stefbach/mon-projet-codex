"use client"

import type React from "react"

import { useState } from "react"
import { supabase } from "@/lib/supabase"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2 } from "lucide-react"

export default function FixLoginPage() {
  const [email, setEmail] = useState("")
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [users, setUsers] = useState<any[]>([])
  const [loadingUsers, setLoadingUsers] = useState(false)

  const confirmUser = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setResult(null)

    try {
      // Confirmer l'utilisateur
      await supabase.rpc("admin_confirm_user", { user_email: email })

      // Vérifier le statut de l'utilisateur
      const { data: userData, error: userError } = await supabase.auth.admin.getUserByEmail(email)

      if (userError) {
        setResult({
          success: false,
          message: userError.message,
          details: JSON.stringify(userError, null, 2),
        })
      } else {
        setResult({
          success: true,
          message: `Utilisateur ${email} confirmé avec succès`,
          details: JSON.stringify(userData, null, 2),
          user: userData,
        })
      }
    } catch (error: any) {
      setResult({
        success: false,
        message: error.message,
        details: JSON.stringify(error, null, 2),
      })
    } finally {
      setLoading(false)
    }
  }

  const loadUsers = async () => {
    setLoadingUsers(true)
    try {
      // Charger les utilisateurs de auth.users
      const { data: authUsers, error: authError } = await supabase.from("auth.users").select("*")

      // Charger les utilisateurs de public.users
      const { data: publicUsers, error: publicError } = await supabase.from("users").select("*")

      setUsers([
        ...(authUsers || []).map((user: any) => ({ ...user, source: "auth.users" })),
        ...(publicUsers || []).map((user: any) => ({ ...user, source: "public.users" })),
      ])

      if (authError || publicError) {
        console.error("Erreur lors du chargement des utilisateurs:", authError || publicError)
      }
    } catch (error) {
      console.error("Erreur lors du chargement des utilisateurs:", error)
    } finally {
      setLoadingUsers(false)
    }
  }

  return (
    <div className="container mx-auto py-10 space-y-8">
      <h1 className="text-2xl font-bold">Réparer les problèmes de connexion</h1>

      <Card>
        <CardHeader>
          <CardTitle>Confirmer un utilisateur existant</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={confirmUser} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email de l'utilisateur</Label>
              <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
            </div>

            <Button type="submit" disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Confirmation...
                </>
              ) : (
                "Confirmer l'utilisateur"
              )}
            </Button>

            {result && (
              <div className={`mt-4 p-4 rounded-md ${result.success ? "bg-green-50" : "bg-red-50"}`}>
                <p className={result.success ? "text-green-700" : "text-red-700"}>{result.message}</p>
                <details className="mt-2">
                  <summary className="cursor-pointer text-sm">Détails techniques</summary>
                  <pre className="text-xs mt-2 p-2 bg-gray-100 rounded overflow-auto max-h-40">{result.details}</pre>
                </details>
              </div>
            )}
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Liste des utilisateurs</CardTitle>
        </CardHeader>
        <CardContent>
          <Button onClick={loadUsers} disabled={loadingUsers} className="mb-4">
            {loadingUsers ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Chargement...
              </>
            ) : (
              "Charger les utilisateurs"
            )}
          </Button>

          {users.length > 0 && (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Source
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      ID
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Email
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Nom
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Rôle
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Statut
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {users.map((user, index) => (
                    <tr key={`${user.id}-${user.source}-${index}`}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{user.source}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{user.id}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{user.email}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {user.name || (user.raw_user_meta_data && user.raw_user_meta_data.name) || "-"}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {user.role || (user.raw_user_meta_data && user.raw_user_meta_data.role) || "-"}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {user.email_confirmed_at ? "Confirmé" : "Non confirmé"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {users.length === 0 && !loadingUsers && (
            <p className="text-gray-500">Cliquez sur "Charger les utilisateurs" pour voir la liste.</p>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

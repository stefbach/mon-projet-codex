"use client"

import { useState } from "react"
import { supabase } from "@/lib/supabase"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function SimpleAuthTest() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [name, setName] = useState("")
  const [message, setMessage] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)

  const [loginEmail, setLoginEmail] = useState("")
  const [loginPassword, setLoginPassword] = useState("")
  const [loginMessage, setLoginMessage] = useState("")
  const [loginError, setLoginError] = useState("")
  const [loginLoading, setLoginLoading] = useState(false)

  const createUser = async (e) => {
    e.preventDefault()
    setLoading(true)
    setMessage("")
    setError("")

    try {
      // 1. Créer l'utilisateur dans Supabase Auth
      const { data, error: signUpError } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            name,
          },
        },
      })

      if (signUpError) throw signUpError

      // 2. Confirmer l'utilisateur manuellement
      await supabase.rpc("confirm_user", { email_to_confirm: email })

      // 3. Ajouter l'utilisateur à la table users si nécessaire
      if (data.user) {
        const { error: insertError } = await supabase.from("users").insert({
          id: data.user.id,
          email: email,
          name: name,
          role: "closer",
          active: true,
        })

        if (insertError) {
          console.warn("Erreur lors de l'insertion dans la table users:", insertError)
        }
      }

      setMessage(`Utilisateur ${email} créé avec succès!`)

      // Préremplir les champs de connexion
      setLoginEmail(email)
      setLoginPassword(password)
    } catch (err) {
      console.error("Erreur:", err)
      setError(err.message || "Erreur lors de la création de l'utilisateur")
    } finally {
      setLoading(false)
    }
  }

  const loginUser = async (e) => {
    e.preventDefault()
    setLoginLoading(true)
    setLoginMessage("")
    setLoginError("")

    try {
      const { data, error: signInError } = await supabase.auth.signInWithPassword({
        email: loginEmail,
        password: loginPassword,
      })

      if (signInError) throw signInError

      setLoginMessage(`Connexion réussie! Utilisateur: ${data.user.email}`)
    } catch (err) {
      console.error("Erreur de connexion:", err)
      setLoginError(err.message || "Erreur lors de la connexion")
    } finally {
      setLoginLoading(false)
    }
  }

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-6">Test d'authentification simplifié</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Créer un utilisateur</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={createUser} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="name">Nom</Label>
                <Input id="name" value={name} onChange={(e) => setName(e.target.value)} required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Mot de passe (min. 6 caractères)</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  minLength={6}
                />
              </div>

              <Button type="submit" disabled={loading}>
                {loading ? "Création..." : "Créer l'utilisateur"}
              </Button>

              {message && <p className="text-green-600 mt-2">{message}</p>}
              {error && <p className="text-red-600 mt-2">{error}</p>}
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Se connecter</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={loginUser} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="loginEmail">Email</Label>
                <Input
                  id="loginEmail"
                  type="email"
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="loginPassword">Mot de passe</Label>
                <Input
                  id="loginPassword"
                  type="password"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  required
                />
              </div>

              <Button type="submit" disabled={loginLoading}>
                {loginLoading ? "Connexion..." : "Se connecter"}
              </Button>

              {loginMessage && <p className="text-green-600 mt-2">{loginMessage}</p>}
              {loginError && <p className="text-red-600 mt-2">{loginError}</p>}
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

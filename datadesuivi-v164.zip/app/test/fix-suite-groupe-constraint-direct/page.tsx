"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle, CheckCircle2 } from "lucide-react"

export default function FixSuiteGroupeConstraintPage() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<{ success: boolean; message: string } | null>(null)

  const fixConstraint = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/fix-suite-groupe-constraint", {
        method: "POST",
      })

      const data = await response.json()

      if (response.ok) {
        setResult({
          success: true,
          message:
            "La contrainte a été mise à jour avec succès. Les valeurs autorisées sont maintenant: NULL, '', 'NHS', 'CASH', 'non_specifie'",
        })
      } else {
        setResult({
          success: false,
          message: data.error || "Une erreur est survenue lors de la mise à jour de la contrainte",
        })
      }
    } catch (error: any) {
      setResult({
        success: false,
        message: error.message || "Une erreur est survenue lors de la mise à jour de la contrainte",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-10">
      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle>Correction de la contrainte suite_groupe</CardTitle>
          <CardDescription>
            Cette page permet de corriger la contrainte de vérification sur la colonne suite_groupe de la table
            patients.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="mb-4">
            La contrainte actuelle n&apos;accepte que les valeurs NULL, &apos;&apos; (chaîne vide), &apos;NHS&apos; et
            &apos;CASH&apos;. Nous allons la modifier pour accepter également la valeur &apos;non_specifie&apos;.
          </p>

          {result && (
            <Alert variant={result.success ? "default" : "destructive"} className="mt-4">
              {result.success ? <CheckCircle2 className="h-4 w-4" /> : <AlertCircle className="h-4 w-4" />}
              <AlertTitle>{result.success ? "Succès" : "Erreur"}</AlertTitle>
              <AlertDescription>{result.message}</AlertDescription>
            </Alert>
          )}
        </CardContent>
        <CardFooter>
          <Button onClick={fixConstraint} disabled={loading}>
            {loading ? "Mise à jour en cours..." : "Corriger la contrainte"}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

"use client"

import { useState } from "react"
import { supabase } from "@/lib/supabase"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Loader2, CheckCircle2, AlertCircle } from "lucide-react"

export default function SetupSupabaseAuthPage() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<{
    success: boolean
    message: string
    details?: string
  } | null>(null)
  const [sqlScript, setSqlScript] = useState(`
-- Création de la fonction de trigger pour insérer automatiquement les utilisateurs dans la table users
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.users (id, email, name, role, active, created_at)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)),
    COALESCE(NEW.raw_user_meta_data->>'role', 'closer'),
    TRUE,
    NEW.created_at
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Suppression du trigger s'il existe déjà
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- Création du trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Mise à jour de la structure de la table users si nécessaire
-- Suppression de la colonne password_hash si elle existe
DO $$
BEGIN
  IF EXISTS (
    SELECT FROM information_schema.columns 
    WHERE table_schema = 'public' 
    AND table_name = 'users' 
    AND column_name = 'password_hash'
  ) THEN
    ALTER TABLE public.users DROP COLUMN password_hash;
  END IF;
END $$;

-- Ajout de la colonne password_updated_at si elle n'existe pas
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT FROM information_schema.columns 
    WHERE table_schema = 'public' 
    AND table_name = 'users' 
    AND column_name = 'password_updated_at'
  ) THEN
    ALTER TABLE public.users ADD COLUMN password_updated_at TIMESTAMP WITH TIME ZONE;
  END IF;
END $$;
  `)

  // Fonction pour tester la création d'un utilisateur
  const testCreateUser = async () => {
    setLoading(true)
    setResult(null)

    try {
      // Générer un email unique
      const testEmail = `test-${Date.now()}@example.com`
      const testPassword = "Password123!"
      const testName = "Utilisateur Test"

      // Créer un utilisateur de test avec Supabase Auth
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: testEmail,
        password: testPassword,
        options: {
          data: {
            name: testName,
            role: "closer",
          },
        },
      })

      if (authError) {
        setResult({
          success: false,
          message: "Erreur lors de la création de l'utilisateur de test",
          details: authError.message,
        })
        setLoading(false)
        return
      }

      if (!authData || !authData.user) {
        setResult({
          success: false,
          message: "Erreur lors de la création de l'utilisateur de test: aucune donnée retournée",
        })
        setLoading(false)
        return
      }

      // Attendre un peu pour que le trigger s'exécute
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Vérifier si l'utilisateur a été ajouté à la table users
      const { data: userData, error: userError } = await supabase
        .from("users")
        .select("*")
        .eq("id", authData.user.id)
        .single()

      if (userError) {
        setResult({
          success: false,
          message: "L'utilisateur a été créé dans Auth mais n'a pas été ajouté à la table users",
          details: `Erreur: ${userError.message}. Cela peut indiquer que le trigger n'est pas correctement configuré.`,
        })
        setLoading(false)
        return
      }

      setResult({
        success: true,
        message: "Test de création d'utilisateur réussi",
        details: `L'utilisateur a été créé dans Auth et ajouté automatiquement à la table users avec le rôle "${userData.role}".`,
      })
    } catch (error: any) {
      setResult({
        success: false,
        message: "Une erreur inattendue s'est produite",
        details: error.message || "Erreur inconnue",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-8">
      <Card className="max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle>Configuration de Supabase Auth</CardTitle>
          <CardDescription>
            Cette page vous aide à configurer Supabase Auth et à créer le trigger nécessaire pour synchroniser les
            utilisateurs.
          </CardDescription>
        </CardHeader>

        <CardContent>
          <Tabs defaultValue="instructions">
            <TabsList className="mb-4">
              <TabsTrigger value="instructions">Instructions</TabsTrigger>
              <TabsTrigger value="sql">Script SQL</TabsTrigger>
              <TabsTrigger value="test">Test</TabsTrigger>
            </TabsList>

            <TabsContent value="instructions">
              <div className="space-y-4">
                <Alert>
                  <AlertTitle>Configuration requise</AlertTitle>
                  <AlertDescription>
                    Pour utiliser Supabase Auth avec votre table users personnalisée, vous devez créer un trigger
                    PostgreSQL qui ajoutera automatiquement les nouveaux utilisateurs à votre table.
                  </AlertDescription>
                </Alert>

                <h3 className="text-lg font-medium">Étapes à suivre :</h3>

                <ol className="list-decimal pl-5 space-y-2">
                  <li>Connectez-vous à votre compte Supabase et accédez à votre projet.</li>
                  <li>Allez dans la section "SQL Editor" (Éditeur SQL).</li>
                  <li>Copiez le script SQL de l'onglet "Script SQL".</li>
                  <li>Collez-le dans l'éditeur SQL de Supabase et exécutez-le.</li>
                  <li>
                    Revenez à cette page et utilisez l'onglet "Test" pour vérifier que tout fonctionne correctement.
                  </li>
                </ol>

                <Alert className="bg-yellow-50 border-yellow-200">
                  <AlertCircle className="h-4 w-4 text-yellow-800" />
                  <AlertTitle className="text-yellow-800">Important</AlertTitle>
                  <AlertDescription className="text-yellow-800">
                    Ce script supprimera la colonne password_hash de votre table users si elle existe, car elle n'est
                    plus nécessaire avec Supabase Auth.
                  </AlertDescription>
                </Alert>
              </div>
            </TabsContent>

            <TabsContent value="sql">
              <div className="space-y-4">
                <p>
                  Copiez ce script SQL et exécutez-le dans l'éditeur SQL de Supabase pour configurer le trigger et
                  mettre à jour la structure de votre table users.
                </p>

                <Textarea
                  value={sqlScript}
                  onChange={(e) => setSqlScript(e.target.value)}
                  className="font-mono text-sm h-96"
                />

                <Button
                  variant="outline"
                  onClick={() => {
                    navigator.clipboard.writeText(sqlScript)
                    alert("Script SQL copié dans le presse-papiers !")
                  }}
                >
                  Copier le script
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="test">
              <div className="space-y-4">
                <p>
                  Ce test va créer un utilisateur de test avec Supabase Auth et vérifier si le trigger l'ajoute
                  automatiquement à votre table users.
                </p>

                {result && (
                  <Alert variant={result.success ? "default" : "destructive"} className="mb-4">
                    <div className="flex items-center">
                      {result.success ? (
                        <CheckCircle2 className="h-4 w-4 mr-2" />
                      ) : (
                        <AlertCircle className="h-4 w-4 mr-2" />
                      )}
                      <AlertTitle>{result.success ? "Succès" : "Erreur"}</AlertTitle>
                    </div>
                    <AlertDescription>
                      <p>{result.message}</p>
                      {result.details && (
                        <p className="text-sm mt-2 font-mono bg-gray-100 p-2 rounded">{result.details}</p>
                      )}
                    </AlertDescription>
                  </Alert>
                )}

                <Button onClick={testCreateUser} disabled={loading}>
                  {loading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Test en cours...
                    </>
                  ) : (
                    "Tester la création d'utilisateur"
                  )}
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>

        <CardFooter className="flex justify-between">
          <p className="text-sm text-gray-500">
            Cette configuration est nécessaire pour utiliser Supabase Auth avec votre application.
          </p>
          <Button variant="outline" size="sm" asChild>
            <a href="/admin/accounts">Aller à la gestion des comptes</a>
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

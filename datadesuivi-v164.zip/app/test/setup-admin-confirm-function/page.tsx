"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { supabase } from "@/lib/supabase"
import { Loader2 } from "lucide-react"

export default function SetupAdminConfirmFunctionPage() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const setupFunction = async () => {
    setLoading(true)
    setResult(null)
    setError(null)

    try {
      // Exécuter le SQL pour créer la fonction admin_confirm_user améliorée
      const { error } = await supabase.rpc("exec_sql", {
        sql_query: `
        -- Fonction pour confirmer automatiquement un utilisateur par email
        -- Cette fonction peut être appelée par un administrateur pour confirmer un utilisateur
        -- sans que celui-ci n'ait à cliquer sur le lien de confirmation

        CREATE OR REPLACE FUNCTION admin_confirm_user(user_email TEXT)
        RETURNS VOID AS $$
        DECLARE
          _user_id UUID;
        BEGIN
          -- Récupérer l'ID de l'utilisateur à partir de son email
          SELECT id INTO _user_id FROM auth.users WHERE email = user_email;
          
          -- Vérifier si l'utilisateur existe
          IF _user_id IS NULL THEN
            RAISE EXCEPTION 'Utilisateur avec l''email % non trouvé', user_email;
          END IF;
          
          -- Mettre à jour le statut de confirmation de l'utilisateur
          UPDATE auth.users
          SET email_confirmed_at = NOW(),
              confirmed_at = NOW(),
              updated_at = NOW()
          WHERE id = _user_id;
          
          -- Ajouter un log si la table existe
          BEGIN
            INSERT INTO public.system_action_logs (action, details, status, user_id)
            VALUES (
              'admin_confirm_user',
              json_build_object('email', user_email),
              'success',
              _user_id
            );
          EXCEPTION WHEN undefined_table THEN
            -- La table n'existe pas, ignorer cette étape
            NULL;
          END;
          
        END;
        $$ LANGUAGE plpgsql SECURITY DEFINER;

        -- Accorder les privilèges d'exécution à la fonction
        GRANT EXECUTE ON FUNCTION admin_confirm_user(TEXT) TO authenticated;
        GRANT EXECUTE ON FUNCTION admin_confirm_user(TEXT) TO anon;
        GRANT EXECUTE ON FUNCTION admin_confirm_user(TEXT) TO service_role;
        `,
      })

      if (error) {
        throw error
      }

      setResult("La fonction admin_confirm_user a été créée ou mise à jour avec succès.")
    } catch (err: any) {
      console.error("Erreur lors de la création de la fonction:", err)
      setError(`Erreur: ${err.message || "Une erreur inconnue s'est produite"}`)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-10">
      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle>Configuration de la fonction admin_confirm_user améliorée</CardTitle>
          <CardDescription>
            Cette page permet de créer ou mettre à jour la fonction admin_confirm_user qui permet de confirmer
            automatiquement un utilisateur sans qu'il n'ait à cliquer sur le lien de confirmation.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-gray-500 mb-4">
            Cette fonction est utilisée par le système pour confirmer automatiquement les utilisateurs lors de leur
            création, ce qui évite les problèmes liés aux emails de confirmation.
          </p>

          {result && <div className="p-4 mb-4 bg-green-50 text-green-700 rounded-md">{result}</div>}
          {error && <div className="p-4 mb-4 bg-red-50 text-red-700 rounded-md">{error}</div>}
        </CardContent>
        <CardFooter>
          <Button onClick={setupFunction} disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Configuration en cours...
              </>
            ) : (
              "Configurer la fonction"
            )}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

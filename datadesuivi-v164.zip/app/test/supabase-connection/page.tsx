"use client"

import { useState, useEffect } from "react"
import { supabase, getAppMode } from "@/lib/supabase"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { CheckCircle, XCircle, Database, RefreshCw, Info } from "lucide-react"

export default function SupabaseConnectionTest() {
  const [isConnected, setIsConnected] = useState<boolean | null>(null)
  const [tables, setTables] = useState<string[]>([])
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [supabaseUrl, setSupabaseUrl] = useState<string>("")
  const [testResult, setTestResult] = useState<any>(null)
  const { isDemoMode, isSupabaseConfigured } = getAppMode()

  async function testConnection() {
    setLoading(true)
    setError(null)
    setIsConnected(null)
    setTables([])
    setTestResult(null)

    try {
      // Récupérer l'URL de Supabase
      const url = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://gllhemdeucwaxbmoyzee.supabase.co"
      setSupabaseUrl(url)

      // Tester la connexion en récupérant la liste des tables
      const { data, error } = await supabase.from("pg_tables").select("tablename").eq("schemaname", "public")

      if (error) {
        console.error("Erreur lors de la connexion à Supabase:", error)
        setError(`Erreur de connexion: ${error.message}`)
        setIsConnected(false)
        return
      }

      // Connexion réussie
      setIsConnected(true)

      // Extraire les noms des tables
      const tableNames = data.map((table) => table.tablename)
      setTables(tableNames)

      // Tester une requête sur la table users si elle existe
      if (tableNames.includes("users")) {
        const { data: usersData, error: usersError } = await supabase
          .from("users")
          .select("id, email, name, role")
          .limit(5)

        if (usersError) {
          setTestResult({
            success: false,
            message: `Erreur lors de la requête sur la table users: ${usersError.message}`,
          })
        } else {
          setTestResult({
            success: true,
            message: "Requête sur la table users réussie",
            data: usersData,
          })
        }
      } else if (tableNames.includes("patients")) {
        // Tester une requête sur la table patients si elle existe
        const { data: patientsData, error: patientsError } = await supabase
          .from("patients")
          .select("id, name, email, status")
          .limit(5)

        if (patientsError) {
          setTestResult({
            success: false,
            message: `Erreur lors de la requête sur la table patients: ${patientsError.message}`,
          })
        } else {
          setTestResult({
            success: true,
            message: "Requête sur la table patients réussie",
            data: patientsData,
          })
        }
      }
    } catch (err) {
      console.error("Erreur inattendue:", err)
      setError(`Erreur inattendue: ${(err as Error).message}`)
      setIsConnected(false)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    testConnection()
  }, [])

  return (
    <div className="container mx-auto py-8">
      <Card className="max-w-3xl mx-auto">
        <CardHeader>
          <CardTitle className="text-2xl flex items-center gap-2">
            <Database className="h-6 w-6" /> Test de connexion Supabase
          </CardTitle>
          <CardDescription>
            Cette page vérifie si votre application est correctement connectée à Supabase.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {loading ? (
            <div className="flex items-center justify-center p-6">
              <RefreshCw className="h-8 w-8 animate-spin text-primary-500" />
              <span className="ml-2">Test de connexion en cours...</span>
            </div>
          ) : (
            <>
              <div className="grid gap-4">
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <h3 className="font-medium">URL Supabase</h3>
                    <p className="text-sm text-neutral-500">{supabaseUrl}</p>
                  </div>
                  <Info className="h-5 w-5 text-neutral-400" />
                </div>

                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <h3 className="font-medium">Statut de connexion</h3>
                    <p className="text-sm text-neutral-500">
                      {isConnected === null
                        ? "Vérification..."
                        : isConnected
                          ? "Connecté à Supabase"
                          : "Non connecté à Supabase"}
                    </p>
                  </div>
                  {isConnected === null ? (
                    <RefreshCw className="h-5 w-5 animate-spin text-neutral-400" />
                  ) : isConnected ? (
                    <CheckCircle className="h-5 w-5 text-green-500" />
                  ) : (
                    <XCircle className="h-5 w-5 text-red-500" />
                  )}
                </div>

                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <h3 className="font-medium">Mode de l'application</h3>
                    <p className="text-sm text-neutral-500">
                      {isDemoMode ? "Mode démo (données simulées)" : "Mode production (données réelles)"}
                    </p>
                  </div>
                  {isDemoMode ? (
                    <Database className="h-5 w-5 text-amber-500" />
                  ) : (
                    <CheckCircle className="h-5 w-5 text-green-500" />
                  )}
                </div>
              </div>

              {error && (
                <Alert variant="destructive">
                  <XCircle className="h-4 w-4" />
                  <AlertTitle>Erreur de connexion</AlertTitle>
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              {isConnected && (
                <div className="space-y-4">
                  <h3 className="font-medium">Tables disponibles ({tables.length})</h3>
                  {tables.length > 0 ? (
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                      {tables.map((table) => (
                        <div
                          key={table}
                          className="p-2 bg-neutral-100 rounded text-sm flex items-center justify-between"
                        >
                          <span>{table}</span>
                          <Database className="h-3 w-3 text-neutral-500" />
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-neutral-500">Aucune table trouvée dans le schéma public.</p>
                  )}
                </div>
              )}

              {testResult && (
                <div className="mt-6">
                  <h3 className="font-medium mb-2">Résultat du test de requête</h3>
                  <Alert variant={testResult.success ? "default" : "destructive"}>
                    {testResult.success ? (
                      <CheckCircle className="h-4 w-4 text-green-500" />
                    ) : (
                      <XCircle className="h-4 w-4" />
                    )}
                    <AlertTitle>{testResult.success ? "Succès" : "Échec"}</AlertTitle>
                    <AlertDescription>{testResult.message}</AlertDescription>
                  </Alert>

                  {testResult.success && testResult.data && (
                    <div className="mt-4 overflow-x-auto">
                      <h4 className="text-sm font-medium mb-2">Données récupérées:</h4>
                      <pre className="bg-neutral-100 p-3 rounded text-xs overflow-auto max-h-60">
                        {JSON.stringify(testResult.data, null, 2)}
                      </pre>
                    </div>
                  )}
                </div>
              )}
            </>
          )}
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={() => window.history.back()}>
            Retour
          </Button>
          <Button onClick={testConnection} disabled={loading}>
            {loading ? (
              <>
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> Test en cours...
              </>
            ) : (
              <>
                <RefreshCw className="mr-2 h-4 w-4" /> Tester à nouveau
              </>
            )}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

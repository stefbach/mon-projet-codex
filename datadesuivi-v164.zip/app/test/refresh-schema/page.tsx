"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Loader2, RefreshCw, CheckCircle, XCircle, Database, Link2 } from "lucide-react"
import { refreshSchemaCache, verifyPatientUserRelationship, supabase } from "@/lib/supabase"

export default function RefreshSchemaPage() {
  const [loading, setLoading] = useState(false)
  const [verifying, setVerifying] = useState(false)
  const [status, setStatus] = useState<{
    checked: boolean
    relationshipOk: boolean
    message: string
    details?: any
  }>({
    checked: false,
    relationshipOk: false,
    message: "Vérification non effectuée",
  })

  // Check relationship on page load
  useEffect(() => {
    checkRelationship()
  }, [])

  async function checkRelationship() {
    setVerifying(true)
    try {
      const result = await verifyPatientUserRelationship()

      setStatus({
        checked: true,
        relationshipOk: result.success,
        message: result.success
          ? "La relation entre patients et utilisateurs fonctionne correctement"
          : `Erreur de relation: ${result.error}`,
        details: result.data || result.error,
      })

      if (!result.success && result.needsRefresh) {
        // Automatically refresh if needed
        await handleRefreshSchema()
      }
    } catch (error: any) {
      setStatus({
        checked: true,
        relationshipOk: false,
        message: `Erreur lors de la vérification: ${error.message}`,
        details: error,
      })
    } finally {
      setVerifying(false)
    }
  }

  async function handleRefreshSchema() {
    setLoading(true)
    try {
      const result = await refreshSchemaCache()

      if (result.success) {
        setStatus((prev) => ({
          ...prev,
          message: prev.message + " | Schéma rafraîchi avec succès",
        }))

        // Verify again after refresh
        await checkRelationship()
      } else {
        setStatus((prev) => ({
          ...prev,
          message: `${prev.message} | Échec du rafraîchissement: ${result.error}`,
        }))
      }
    } catch (error: any) {
      setStatus((prev) => ({
        ...prev,
        message: `${prev.message} | Erreur: ${error.message}`,
      }))
    } finally {
      setLoading(false)
    }
  }

  async function testPatientQuery() {
    setLoading(true)
    try {
      // Test a simple query
      const { data, error } = await supabase
        .from("patients")
        .select(`
          id,
          full_name,
          email,
          closer:closer_id (id, full_name, email)
        `)
        .limit(5)

      if (error) {
        setStatus((prev) => ({
          ...prev,
          message: `Erreur de requête: ${error.message}`,
          details: error,
        }))
      } else {
        setStatus((prev) => ({
          ...prev,
          message: "Requête réussie",
          details: data,
        }))
      }
    } catch (error: any) {
      setStatus((prev) => ({
        ...prev,
        message: `Erreur: ${error.message}`,
        details: error,
      }))
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-10">
      <Card className="w-full max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-6 w-6" />
            Diagnostic et rafraîchissement du schéma Supabase
          </CardTitle>
          <CardDescription>
            Utilisez cet outil pour diagnostiquer et résoudre les problèmes de cache de schéma Supabase
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 border rounded-md">
            <div className="flex items-center gap-2">
              <Link2 className="h-5 w-5 text-blue-500" />
              <span className="font-medium">Relation patients-utilisateurs:</span>
            </div>
            <div className="flex items-center gap-2">
              {!status.checked ? (
                <span className="text-gray-500">Non vérifiée</span>
              ) : status.relationshipOk ? (
                <span className="flex items-center text-green-600">
                  <CheckCircle className="h-5 w-5 mr-1" /> Fonctionnelle
                </span>
              ) : (
                <span className="flex items-center text-red-600">
                  <XCircle className="h-5 w-5 mr-1" /> Problème détecté
                </span>
              )}
            </div>
          </div>

          {status.checked && (
            <Alert variant={status.relationshipOk ? "default" : "destructive"}>
              <AlertTitle>Statut de la vérification</AlertTitle>
              <AlertDescription className="mt-2">
                {status.message}
                {status.details && (
                  <pre className="mt-2 p-2 bg-gray-100 rounded-md text-xs overflow-auto max-h-40">
                    {JSON.stringify(status.details, null, 2)}
                  </pre>
                )}
              </AlertDescription>
            </Alert>
          )}
        </CardContent>

        <CardFooter className="flex justify-between">
          <div className="flex gap-2">
            <Button variant="outline" onClick={checkRelationship} disabled={verifying}>
              {verifying ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Vérification...
                </>
              ) : (
                <>
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Vérifier la relation
                </>
              )}
            </Button>

            <Button variant="default" onClick={handleRefreshSchema} disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Rafraîchissement...
                </>
              ) : (
                <>
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Rafraîchir le schéma
                </>
              )}
            </Button>
          </div>

          <Button variant="secondary" onClick={testPatientQuery} disabled={loading}>
            Tester une requête
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

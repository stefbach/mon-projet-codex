"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { supabase } from "@/lib/supabase"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { CheckCircle, XCircle, Info } from "lucide-react"

interface UserStatus {
  exists: boolean
  confirmed: boolean
  created_at?: string
  last_sign_in?: string
}

export default function CheckUserStatusPage() {
  const [email, setEmail] = useState("")
  const [loading, setLoading] = useState(false)
  const [status, setStatus] = useState<UserStatus | null>(null)
  const [error, setError] = useState<string | null>(null)

  const handleCheck = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!email || !email.includes("@")) {
      setError("Veuillez entrer une adresse email valide")
      setStatus(null)
      return
    }

    setLoading(true)
    setError(null)

    try {
      // Appeler une fonction RPC Supabase pour vérifier le statut de l'utilisateur
      const { data, error } = await supabase.rpc("get_user_status", {
        user_email: email.trim(),
      })

      if (error) {
        throw error
      }

      setStatus(data)
    } catch (error: any) {
      console.error("Erreur lors de la vérification du statut de l'utilisateur:", error)
      setError(`Erreur: ${error.message || "Une erreur s'est produite"}`)
      setStatus(null)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-10">
      <Card className="max-w-md mx-auto">
        <CardHeader>
          <CardTitle>Vérifier le statut d'un utilisateur</CardTitle>
          <CardDescription>Vérifiez si un utilisateur existe et s'il a confirmé son email.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleCheck}>
            <div className="grid w-full items-center gap-4">
              <div className="flex flex-col space-y-1.5">
                <Label htmlFor="email">Email de l'utilisateur</Label>
                <Input
                  id="email"
                  placeholder="utilisateur@exemple.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
            </div>

            {error && (
              <Alert className="mt-4 bg-red-50">
                <XCircle className="h-4 w-4 text-red-600" />
                <AlertTitle>Erreur</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {status && (
              <Alert className="mt-4 bg-blue-50">
                <Info className="h-4 w-4 text-blue-600" />
                <AlertTitle>Statut de l'utilisateur</AlertTitle>
                <AlertDescription>
                  <div className="mt-2 space-y-2">
                    <div className="flex items-center">
                      <span className="font-medium mr-2">Existe:</span>
                      {status.exists ? (
                        <CheckCircle className="h-4 w-4 text-green-600" />
                      ) : (
                        <XCircle className="h-4 w-4 text-red-600" />
                      )}
                    </div>

                    {status.exists && (
                      <>
                        <div className="flex items-center">
                          <span className="font-medium mr-2">Email confirmé:</span>
                          {status.confirmed ? (
                            <CheckCircle className="h-4 w-4 text-green-600" />
                          ) : (
                            <XCircle className="h-4 w-4 text-red-600" />
                          )}
                        </div>

                        {status.created_at && (
                          <div>
                            <span className="font-medium">Créé le:</span> {new Date(status.created_at).toLocaleString()}
                          </div>
                        )}

                        {status.last_sign_in && (
                          <div>
                            <span className="font-medium">Dernière connexion:</span>{" "}
                            {new Date(status.last_sign_in).toLocaleString()}
                          </div>
                        )}
                      </>
                    )}
                  </div>
                </AlertDescription>
              </Alert>
            )}
          </form>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={() => window.history.back()}>
            Retour
          </Button>
          <Button onClick={handleCheck} disabled={loading}>
            {loading ? "Vérification..." : "Vérifier le statut"}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

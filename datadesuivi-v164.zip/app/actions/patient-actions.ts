"use server"

import { supabase } from "@/lib/supabase"

export async function registerPatient(formData: FormData) {
  try {
    const data = {
      full_name: formData.get("name") as string,
      email: formData.get("email") as string,
      doctor: formData.get("doctor") as string,
      registration_date: formData.get("registrationDate") as string,
      consultation_date: (formData.get("consultationDate") as string) || null,
      revenue: formData.get("income") ? Number(formData.get("income")) : null,
      expenses: formData.get("expenses") ? Number(formData.get("expenses")) : null,
      credit_score: formData.get("creditScore") ? Number(formData.get("creditScore")) : null,
      credit_score_platform: (formData.get("creditPlatform") as string) || null,
      loan_amount: formData.get("loanAmount") ? Number(formData.get("loanAmount")) : null,
      loan_simulation_validated: formData.get("simulationValidated") === "Oui",
      loan_platform: (formData.get("platform") as string) || null,
      loan_requested: formData.get("loanRequested") === "Oui",
      assigned_closer: (formData.get("closer") as string) || null,
      status: (formData.get("status") as string) || "En attente",
      next_follow_up: (formData.get("nextFollowUp") as string) || null,
      comments: (formData.get("comments") as string) || null,
    }

    const { error } = await supabase.from("patients").insert([data])

    if (error) {
      return { success: false, message: error.message }
    }

    return { success: true, message: "Patient ajouté avec succès" }
  } catch (error: any) {
    console.error("Erreur lors de l'enregistrement du patient:", error)
    return { success: false, message: error.message || "Une erreur s'est produite" }
  }
}

"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/contexts/auth-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Loader2, Users, Clock, Filter, Upload } from "lucide-react"
import { getPatients } from "@/lib/patient-service"
import { getStatusBadgeClass, getStatusLabel, PATIENT_STATUSES } from "@/lib/constants"
import Link from "next/link"
import { format } from "date-fns"
import { fr } from "date-fns/locale"
import { PatientImportModal } from "@/components/patient-import/import-modal"

export default function DashboardPage() {
  const { user } = useAuth()
  const [loading, setLoading] = useState(true)
  const [patients, setPatients] = useState([])
  const [statusCounts, setStatusCounts] = useState({})
  const [recentPatients, setRecentPatients] = useState([])
  const [importModalOpen, setImportModalOpen] = useState(false)

  useEffect(() => {
    async function fetchData() {
      try {
        setLoading(true)

        // Récupérer les patients
        const patientsData = await getPatients(user?.id || "", user?.role || "closer")
        const allPatients = Array.isArray(patientsData) ? patientsData : []
        setPatients(allPatients)

        // Calculer le nombre de patients par statut
        const counts = {}

        // Initialiser tous les statuts à 0
        PATIENT_STATUSES.forEach((status) => {
          counts[status.value] = 0
        })

        // Compter les patients par statut
        allPatients.forEach((patient) => {
          const status = patient.status || "non_defini"
          counts[status] = (counts[status] || 0) + 1
        })

        // Ajouter le total
        counts.total = allPatients.length

        setStatusCounts(counts)

        // Récupérer les 20 derniers patients
        const sortedPatients = [...allPatients].sort((a, b) => {
          // Trier par date de création décroissante
          const dateA = a.created_at ? new Date(a.created_at) : new Date(0)
          const dateB = b.created_at ? new Date(b.created_at) : new Date(0)
          return dateB.getTime() - dateA.getTime()
        })

        setRecentPatients(sortedPatients.slice(0, 20))
      } catch (error) {
        console.error("Erreur lors de la récupération des données:", error)
      } finally {
        setLoading(false)
      }
    }

    if (user) {
      fetchData()
    }
  }, [user])

  const formatDate = (dateString) => {
    if (!dateString) return "Non défini"
    try {
      return format(new Date(dateString), "dd/MM/yyyy", { locale: fr })
    } catch (e) {
      return dateString
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Tableau de bord</h1>
          <p className="text-gray-600">Bienvenue dans votre espace de gestion</p>
        </div>

        {user?.role === "admin" && (
          <Button onClick={() => setImportModalOpen(true)}>
            <Upload className="h-4 w-4 mr-2" />
            Importer patients (Excel/CSV)
          </Button>
        )}
      </div>

      {/* Carte pour le total des patients */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
        <CardHeader className="pb-2">
          <CardTitle className="text-xl">Total des patients</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center">
            <Users className="h-5 w-5 text-blue-500 mr-2" />
            <span className="text-3xl font-bold text-blue-700">{statusCounts.total || 0}</span>
          </div>
        </CardContent>
      </Card>

      {/* Grille de cartes pour tous les statuts */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {PATIENT_STATUSES.map((status) => (
          <Link
            key={status.value}
            href={`/patients?status=${status.value}`}
            className="transition-transform hover:scale-105"
          >
            <Card
              className="h-full cursor-pointer hover:shadow-md border-l-4"
              style={{ borderLeftColor: getStatusBadgeClass(status.value).split("bg-")[1]?.split(" ")[0] }}
            >
              <CardHeader className="pb-2">
                <CardTitle className="text-base">{status.label}</CardTitle>
                <CardDescription>
                  <Badge className={getStatusBadgeClass(status.value)}>{status.value}</Badge>
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{statusCounts[status.value] || 0}</div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      <Tabs defaultValue="recent">
        <TabsList>
          <TabsTrigger value="recent">
            <Clock className="h-4 w-4 mr-2" />
            20 derniers patients
          </TabsTrigger>
          <TabsTrigger value="overview">
            <Filter className="h-4 w-4 mr-2" />
            Vue d'ensemble
          </TabsTrigger>
        </TabsList>

        <TabsContent value="recent" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Les 20 derniers patients</CardTitle>
              <CardDescription>Patients les plus récemment ajoutés</CardDescription>
            </CardHeader>
            <CardContent>
              {recentPatients.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">Aucun patient trouvé</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-2 px-2">Nom</th>
                        <th className="text-left py-2 px-2">Statut</th>
                        <th className="text-left py-2 px-2">Closer</th>
                        <th className="text-left py-2 px-2">Date RDV</th>
                        <th className="text-left py-2 px-2">Créé le</th>
                        <th className="text-right py-2 px-2">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {recentPatients.map((patient) => (
                        <tr key={patient.id} className="border-b hover:bg-gray-50">
                          <td className="py-2 px-2 font-medium">{patient.name || "Sans nom"}</td>
                          <td className="py-2 px-2">
                            <Badge className={getStatusBadgeClass(patient.status)}>
                              {getStatusLabel(patient.status)}
                            </Badge>
                          </td>
                          <td className="py-2 px-2">{patient.closer || "Non assigné"}</td>
                          <td className="py-2 px-2">{formatDate(patient.consultationDate)}</td>
                          <td className="py-2 px-2">{formatDate(patient.created_at)}</td>
                          <td className="py-2 px-2 text-right">
                            <Link href={`/patients/${patient.id}`}>
                              <Button variant="outline" size="sm">
                                Voir
                              </Button>
                            </Link>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="overview">
          <Card>
            <CardHeader>
              <CardTitle>Bienvenue dans votre tableau de bord</CardTitle>
              <CardDescription>Gérez vos patients et suivez votre activité depuis cette interface</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>Utilisez le menu de navigation pour accéder aux différentes fonctionnalités:</p>
              <ul className="list-disc pl-5 space-y-2">
                <li>Consultez la liste de vos patients</li>
                <li>Enregistrez de nouveaux patients</li>
                <li>Gérez vos appels</li>
                <li>Accédez à votre profil</li>
              </ul>
              <div className="flex justify-center mt-4">
                <Button asChild>
                  <a href="/patients">Voir tous mes patients</a>
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Modal d'importation de patients */}
      <PatientImportModal open={importModalOpen} onOpenChange={setImportModalOpen} />
    </div>
  )
}

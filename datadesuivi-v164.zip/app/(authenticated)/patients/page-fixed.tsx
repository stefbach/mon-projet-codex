"use client"

import { useEffect, useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import { getPatients, type Patient, deletePatient } from "@/lib/patient-service"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Loader2,
  Plus,
  Search,
  Calendar,
  Phone,
  FileText,
  Edit,
  Trash2,
  AlertTriangle,
  Eye,
  Filter,
  Copy,
  Weight,
  Activity,
  Building,
  User,
  Mail,
  MessageSquare,
} from "lucide-react"
import Link from "next/link"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { useToast } from "@/components/ui/use-toast"
import { PATIENT_STATUSES, getStatusBadgeClass, getStatusLabel, formatPhoneNumberE164 } from "@/lib/constants"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { SchemaRefreshAlert } from "@/components/schema-refresh-alert"

export default function PatientsPage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [patients, setPatients] = useState<Patient[]>([])
  const [filteredPatients, setFilteredPatients] = useState<Patient[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [activeTab, setActiveTab] = useState("all")
  const [closerFilter, setCloserFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")
  const [dateFilter, setDateFilter] = useState("all")
  const [callCountFilter, setCallCountFilter] = useState("all")
  const [bmiFilter, setBmiFilter] = useState("all")
  const [suiteGroupeFilter, setSuiteGroupeFilter] = useState("all")
  const [rdvObtenuParFilter, setRdvObtenuParFilter] = useState("all")
  const [closers, setClosers] = useState<{ id: string; name: string }[]>([])
  const [suiteGroupes, setSuiteGroupes] = useState<string[]>([])
  const [rdvObtenuPars, setRdvObtenuPars] = useState<string[]>([])
  const [patientToDelete, setPatientToDelete] = useState<string | null>(null)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [deletingPatient, setDeletingPatient] = useState(false)

  const isAdmin = user?.role === "admin"
  const isCloser = user?.role === "closer"

  // Fonction sécurisée pour vérifier si une chaîne contient une sous-chaîne
  const safeIncludes = (str: string | null | undefined, searchStr: string): boolean => {
    if (!str) return false
    return str.toLowerCase().includes(searchStr.toLowerCase())
  }

  useEffect(() => {
    async function fetchPatients() {
      try {
        // Récupérer les patients en fonction du rôle
        const data = await getPatients(user?.id || "", user?.role || "closer")

        // S'assurer que data est un tableau
        const safeData = Array.isArray(data) ? data : []

        setPatients(safeData)
        setFilteredPatients(safeData)

        // Extraire la liste des closers pour le filtre (admin uniquement)
        if (isAdmin) {
          const uniqueClosers = Array.from(new Set(safeData.map((patient) => patient?.closer).filter(Boolean))).map(
            (closerName) => {
              const patient = safeData.find((p) => p?.closer === closerName)
              return {
                id: patient?.closerId || "",
                name: closerName || "Non assigné",
              }
            },
          )
          setClosers(uniqueClosers)
        }

        // Extraire les valeurs uniques pour les nouveaux filtres
        const uniqueSuiteGroupes = Array.from(new Set(safeData.map((patient) => patient?.suiteGroupe).filter(Boolean)))
        setSuiteGroupes(uniqueSuiteGroupes as string[])

        const uniqueRdvObtenuPars = Array.from(
          new Set(safeData.map((patient) => patient?.rdvObtenuPar).filter(Boolean)),
        )
        setRdvObtenuPars(uniqueRdvObtenuPars as string[])
      } catch (error) {
        console.error("Erreur lors de la récupération des patients:", error)
        // En cas d'erreur, initialiser avec des tableaux vides
        setPatients([])
        setFilteredPatients([])
        setClosers([])
        setSuiteGroupes([])
        setRdvObtenuPars([])
      } finally {
        setLoading(false)
      }
    }

    fetchPatients()
  }, [user, isAdmin])

  useEffect(() => {
    // Filtrer les patients en fonction des critères
    let filtered = [...patients]

    // Filtrer par terme de recherche
    if (searchTerm) {
      const lowerSearchTerm = searchTerm.toLowerCase()
      filtered = filtered.filter(
        (patient) =>
          safeIncludes(patient?.name, searchTerm) ||
          safeIncludes(patient?.email, searchTerm) ||
          safeIncludes(patient?.doctor, searchTerm) ||
          safeIncludes(patient?.notes, searchTerm) ||
          safeIncludes(patient?.phone, searchTerm),
      )
    }

    // Filtrer par statut (onglet)
    if (activeTab !== "all") {
      filtered = filtered.filter((patient) => patient?.status === activeTab)
    }

    // Filtrer par statut (filtre déroulant)
    if (statusFilter !== "all") {
      // Correction du filtre par statut
      if (statusFilter === "non_defini") {
        // Filtrer les statuts non définis (null, undefined, chaîne vide)
        filtered = filtered.filter((patient) => !patient?.status || patient.status === "")
      } else {
        // Recherche exacte pour les statuts
        filtered = filtered.filter((patient) => patient?.status === statusFilter)
      }
    }

    // Filtrer par closer (admin uniquement)
    if (isAdmin && closerFilter !== "all") {
      filtered = filtered.filter((patient) => patient?.closerId === closerFilter)
    }

    // Filtrer par nombre d'appels
    if (callCountFilter !== "all") {
      const minCalls = Number.parseInt(callCountFilter, 10)
      filtered = filtered.filter((patient) => (patient?.callCount || 0) >= minCalls)
    }

    // Filtrer par IMC
    if (bmiFilter !== "all") {
      if (bmiFilter === "under18.5") {
        filtered = filtered.filter((patient) => (patient?.bmi || 0) < 18.5)
      } else if (bmiFilter === "18.5-24.9") {
        filtered = filtered.filter((patient) => (patient?.bmi || 0) >= 18.5 && (patient?.bmi || 0) <= 24.9)
      } else if (bmiFilter === "25-29.9") {
        filtered = filtered.filter((patient) => (patient?.bmi || 0) >= 25 && (patient?.bmi || 0) <= 29.9)
      } else if (bmiFilter === "over30") {
        filtered = filtered.filter((patient) => (patient?.bmi || 0) >= 30)
      }
    }

    // Filtrer par Suite/Groupe
    if (suiteGroupeFilter !== "all") {
      filtered = filtered.filter((patient) => patient?.suiteGroupe === suiteGroupeFilter)
    }

    // Filtrer par RDV obtenu par
    if (rdvObtenuParFilter !== "all") {
      filtered = filtered.filter((patient) => patient?.rdvObtenuPar === rdvObtenuParFilter)
    }

    // Filtrer par date
    if (dateFilter !== "all") {
      const now = new Date()
      const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)
      const oneMonthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)

      switch (dateFilter) {
        case "week":
          filtered = filtered.filter((patient) => {
            if (!patient?.created_at) return false
            try {
              const createdAt = new Date(patient.created_at)
              return createdAt >= oneWeekAgo
            } catch (e) {
              return false
            }
          })
          break
        case "month":
          filtered = filtered.filter((patient) => {
            if (!patient?.created_at) return false
            try {
              const createdAt = new Date(patient.created_at)
              return createdAt >= oneMonthAgo
            } catch (e) {
              return false
            }
          })
          break
        case "upcoming":
          filtered = filtered.filter((patient) => {
            if (!patient?.nextFollowUp) return false
            try {
              const nextFollowUp = new Date(patient.nextFollowUp)
              return nextFollowUp > now
            } catch (e) {
              return false
            }
          })
          break
        case "last_call":
          // Trier par date du dernier appel (plus récent d'abord)
          filtered = [...filtered].sort((a, b) => {
            if (!a?.lastCallDate) return 1
            if (!b?.lastCallDate) return -1
            try {
              return new Date(b.lastCallDate).getTime() - new Date(a.lastCallDate).getTime()
            } catch (e) {
              return 0
            }
          })
          break
      }
    }

    setFilteredPatients(filtered)
  }, [
    searchTerm,
    activeTab,
    closerFilter,
    statusFilter,
    dateFilter,
    callCountFilter,
    bmiFilter,
    suiteGroupeFilter,
    rdvObtenuParFilter,
    patients,
    isAdmin,
  ])

  const handleDeleteClick = (patientId: string) => {
    setPatientToDelete(patientId)
    setDeleteDialogOpen(true)
  }

  const handleDeleteConfirm = async () => {
    if (!patientToDelete || !user) return

    setDeletingPatient(true)
    try {
      const result = await deletePatient(patientToDelete, user)

      if (result.success) {
        toast({
          title: "Patient supprimé",
          description: "Le patient a été supprimé avec succès",
        })
        // Mettre à jour la liste des patients
        setPatients(patients.filter((p) => p?.id !== patientToDelete))
      } else {
        toast({
          variant: "destructive",
          title: "Erreur",
          description: result.message || "Une erreur s'est produite lors de la suppression",
        })
      }
    } catch (error) {
      console.error("Erreur lors de la suppression:", error)
      toast({
        variant: "destructive",
        title: "Erreur",
        description: "Une erreur s'est produite lors de la suppression",
      })
    } finally {
      setDeletingPatient(false)
      setDeleteDialogOpen(false)
      setPatientToDelete(null)
    }
  }

  const copyPhoneToClipboard = (phone: string) => {
    if (!phone) return

    const formattedPhone = formatPhoneNumberE164(phone)
    navigator.clipboard
      .writeText(formattedPhone)
      .then(() => {
        toast({
          title: "Numéro copié",
          description: "Le numéro de téléphone a été copié dans le presse-papiers",
          duration: 2000,
        })
      })
      .catch((err) => {
        console.error("Erreur lors de la copie:", err)
        toast({
          variant: "destructive",
          title: "Erreur",
          description: "Impossible de copier le numéro",
          duration: 2000,
        })
      })
  }

  // Fonction sécurisée pour formater les dates
  const formatDate = (dateString: string | null | undefined): string => {
    if (!dateString) return "-"
    try {
      return new Date(dateString).toLocaleDateString()
    } catch (e) {
      return dateString
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-gray-500" />
      </div>
    )
  }

  return (
    <div className="space-y-6 w-full overflow-y-auto">
      <SchemaRefreshAlert />
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Patients</h1>
        <Link href="/form">
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Nouveau patient
          </Button>
        </Link>
      </div>

      <div className="flex flex-col space-y-4">
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
            <Input
              type="search"
              placeholder="Rechercher..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="w-full sm:w-auto overflow-x-auto">
            <Tabs defaultValue="all" className="w-full sm:w-auto" onValueChange={setActiveTab}>
              <TabsList>
                <TabsTrigger value="all">Tous</TabsTrigger>
                {PATIENT_STATUSES.map((status) => (
                  <TabsTrigger key={status.value} value={status.value}>
                    {status.label}
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>
          </div>
        </div>

        {/* Filtres supplémentaires */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {/* Filtre par statut */}
          <div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filtrer par statut" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les statuts</SelectItem>
                <SelectItem value="non_defini">Non défini</SelectItem>
                {PATIENT_STATUSES.map((status) => (
                  <SelectItem key={status.value} value={status.value}>
                    {status.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Filtre par nombre d'appels */}
          <div>
            <Select value={callCountFilter} onValueChange={setCallCountFilter}>
              <SelectTrigger>
                <Phone className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filtrer par appels" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les appels</SelectItem>
                <SelectItem value="0">Aucun appel</SelectItem>
                <SelectItem value="1">Au moins 1 appel</SelectItem>
                <SelectItem value="3">Au moins 3 appels</SelectItem>
                <SelectItem value="5">Au moins 5 appels</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Filtre par IMC */}
          <div>
            <Select value={bmiFilter} onValueChange={setBmiFilter}>
              <SelectTrigger>
                <Activity className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filtrer par IMC" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les IMC</SelectItem>
                <SelectItem value="under18.5">Sous-poids (&lt; 18.5)</SelectItem>
                <SelectItem value="18.5-24.9">Normal (18.5-24.9)</SelectItem>
                <SelectItem value="25-29.9">Surpoids (25-29.9)</SelectItem>
                <SelectItem value="over30">Obésité (≥ 30)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Filtre par Suite/Groupe */}
          <div>
            <Select value={suiteGroupeFilter} onValueChange={setSuiteGroupeFilter}>
              <SelectTrigger>
                <Building className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filtrer par Suite/Groupe" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les groupes</SelectItem>
                {suiteGroupes.map((groupe) => (
                  <SelectItem key={groupe} value={groupe}>
                    {groupe}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Filtre par RDV obtenu par */}
          <div>
            <Select value={rdvObtenuParFilter} onValueChange={setRdvObtenuParFilter}>
              <SelectTrigger>
                <User className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filtrer par RDV obtenu par" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous</SelectItem>
                {rdvObtenuPars.map((obtenuPar) => (
                  <SelectItem key={obtenuPar} value={obtenuPar}>
                    {obtenuPar}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Filtres supplémentaires (admin uniquement) */}
          {isAdmin && (
            <div>
              <Select value={closerFilter} onValueChange={setCloserFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filtrer par closer" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tous les closers</SelectItem>
                  {closers.map((closer) => (
                    <SelectItem key={closer.id} value={closer.id}>
                      {closer.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div>
            <Select value={dateFilter} onValueChange={setDateFilter}>
              <SelectTrigger>
                <Calendar className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filtrer par date" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toutes les dates</SelectItem>
                <SelectItem value="week">Cette semaine</SelectItem>
                <SelectItem value="month">Ce mois</SelectItem>
                <SelectItem value="upcoming">Prochains RDV</SelectItem>
                <SelectItem value="last_call">Triés par dernier appel</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Statistiques rapides */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 flex flex-col items-center justify-center">
            <p className="text-sm text-gray-500">Total patients</p>
            <p className="text-2xl font-bold">{filteredPatients.length}</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 flex flex-col items-center justify-center">
            <p className="text-sm text-gray-500">À rappeler</p>
            <p className="text-2xl font-bold">{filteredPatients.filter((p) => p?.status === "a_rappeler").length}</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 flex flex-col items-center justify-center">
            <p className="text-sm text-gray-500">RDV programmés</p>
            <p className="text-2xl font-bold">{filteredPatients.filter((p) => p?.status === "rdv_programme").length}</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 flex flex-col items-center justify-center">
            <p className="text-sm text-gray-500">Ventes</p>
            <p className="text-2xl font-bold">{filteredPatients.filter((p) => p?.status === "vente").length}</p>
          </CardContent>
        </Card>
      </div>

      {filteredPatients.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-900">Aucun patient trouvé</h3>
          <p className="mt-2 text-sm text-gray-500">
            {searchTerm ||
            activeTab !== "all" ||
            statusFilter !== "all" ||
            closerFilter !== "all" ||
            dateFilter !== "all" ||
            callCountFilter !== "all" ||
            bmiFilter !== "all" ||
            suiteGroupeFilter !== "all" ||
            rdvObtenuParFilter !== "all"
              ? "Aucun résultat ne correspond à vos critères de recherche."
              : "Commencez par ajouter un nouveau patient."}
          </p>
          <div className="mt-6">
            <Link href="/form">
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Ajouter un patient
              </Button>
            </Link>
          </div>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filteredPatients.map((patient, index) => (
            <Card key={index} className="overflow-hidden">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>{patient?.name || "Sans nom"}</CardTitle>
                    <CardDescription>{patient?.email || "Pas d'email"}</CardDescription>
                  </div>
                  <Badge className={getStatusBadgeClass(patient?.status)}>{getStatusLabel(patient?.status)}</Badge>
                </div>
              </CardHeader>
              <CardContent className="pb-2">
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-500">Médecin:</span>
                    <span>{patient?.doctor || "-"}</span>
                  </div>

                  {patient?.phone && (
                    <div className="flex justify-between items-center">
                      <span className="text-gray-500">Téléphone:</span>
                      <div className="flex items-center space-x-1">
                        <span>{formatPhoneNumberE164(patient.phone)}</span>
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6"
                                onClick={() => copyPhoneToClipboard(patient.phone || "")}
                              >
                                <Copy className="h-3 w-3" />
                                <span className="sr-only">Copier</span>
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Copier le numéro</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </div>
                    </div>
                  )}

                  {/* Nouvelles colonnes */}
                  {patient?.suiteGroupe && (
                    <div className="flex justify-between">
                      <span className="text-gray-500">Suite/Groupe:</span>
                      <span>{patient.suiteGroupe}</span>
                    </div>
                  )}

                  {patient?.rdvObtenuPar && (
                    <div className="flex justify-between">
                      <span className="text-gray-500">RDV obtenu par:</span>
                      <span>{patient.rdvObtenuPar}</span>
                    </div>
                  )}

                  {(patient?.poids || patient?.taille || patient?.bmi) && (
                    <div className="flex justify-between">
                      <span className="text-gray-500">
                        <Weight className="h-3 w-3 inline mr-1" />
                        Poids/Taille/IMC:
                      </span>
                      <span>
                        {patient?.poids ? `${patient.poids} kg` : "-"} /{patient?.taille ? `${patient.taille} cm` : "-"}{" "}
                        /{patient?.bmi ? patient.bmi : "-"}
                      </span>
                    </div>
                  )}

                  {patient?.lastCallDate && (
                    <div className="flex justify-between">
                      <span className="text-gray-500">
                        <Phone className="h-3 w-3 inline mr-1" />
                        Dernier appel:
                      </span>
                      <span>{formatDate(patient.lastCallDate)}</span>
                    </div>
                  )}

                  {patient?.callCount !== undefined && (
                    <div className="flex justify-between">
                      <span className="text-gray-500">Nombre d'appels:</span>
                      <span>{patient.callCount}</span>
                    </div>
                  )}

                  {patient?.consultationDate && (
                    <div className="flex justify-between">
                      <span className="text-gray-500">
                        <Calendar className="h-3 w-3 inline mr-1" />
                        Consultation:
                      </span>
                      <span>{formatDate(patient.consultationDate)}</span>
                    </div>
                  )}

                  {patient?.platform && (
                    <div className="flex justify-between">
                      <span className="text-gray-500">Plateforme:</span>
                      <span>{patient.platform}</span>
                    </div>
                  )}

                  {patient?.loanAmount && (
                    <div className="flex justify-between">
                      <span className="text-gray-500">Montant prêt:</span>
                      <span>{patient.loanAmount} £</span>
                    </div>
                  )}

                  {patient?.nextFollowUp && (
                    <div className="flex justify-between">
                      <span className="text-gray-500">
                        <Calendar className="h-3 w-3 inline mr-1" />
                        Prochaine relance:
                      </span>
                      <span>{formatDate(patient.nextFollowUp)}</span>
                    </div>
                  )}

                  {/* Affichage des dates d'email et WhatsApp */}
                  {patient?.premierEmail && (
                    <div className="flex justify-between">
                      <span className="text-gray-500">
                        <Mail className="h-3 w-3 inline mr-1" />
                        Premier email:
                      </span>
                      <span>{formatDate(patient.premierEmail)}</span>
                    </div>
                  )}

                  {patient?.premierWhatsapp && (
                    <div className="flex justify-between">
                      <span className="text-gray-500">
                        <MessageSquare className="h-3 w-3 inline mr-1" />
                        Premier WhatsApp:
                      </span>
                      <span>{formatDate(patient.premierWhatsapp)}</span>
                    </div>
                  )}
                </div>
              </CardContent>
              <CardFooter className="pt-2 flex flex-col">
                <div className="w-full text-xs text-gray-500">
                  {/* Afficher le closer seulement s'il est défini et si l'utilisateur est admin */}
                  {isAdmin && patient?.closer && (
                    <div className="mb-1">
                      <span>Closer: </span>
                      <span>{patient.closer}</span>
                    </div>
                  )}
                  {patient?.notes && (
                    <div className="mt-2 pt-2 border-t">
                      <FileText className="h-3 w-3 inline mr-1" />
                      <p className="line-clamp-2">{patient.notes}</p>
                    </div>
                  )}
                </div>

                {/* Actions sur la fiche patient */}
                <div className="flex justify-end gap-2 mt-4 w-full">
                  <Link href={`/patients/${patient?.id || ""}`}>
                    <Button variant="outline" size="sm">
                      <Eye className="h-4 w-4 mr-1" />
                      Voir
                    </Button>
                  </Link>

                  <Link href={`/patients/${patient?.id || ""}/edit`}>
                    <Button variant="outline" size="sm">
                      <Edit className="h-4 w-4 mr-1" />
                      Modifier
                    </Button>
                  </Link>

                  {/* Bouton de suppression (admin uniquement) */}
                  {isAdmin && patient?.id && (
                    <Button variant="destructive" size="sm" onClick={() => handleDeleteClick(patient.id)}>
                      <Trash2 className="h-4 w-4 mr-1" />
                      Supprimer
                    </Button>
                  )}
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}

      {/* Dialog de confirmation de suppression */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-500" />
              Confirmer la suppression
            </DialogTitle>
            <DialogDescription>
              Êtes-vous sûr de vouloir supprimer ce patient ? Cette action est irréversible.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)} disabled={deletingPatient}>
              Annuler
            </Button>
            <Button variant="destructive" onClick={handleDeleteConfirm} disabled={deletingPatient}>
              {deletingPatient ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Suppression...
                </>
              ) : (
                "Supprimer"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

"use client"

import { EnhancedPatientForm } from "@/components/enhanced-patient-form"

export default function NewPatientPage() {
  return (
    <div className="container mx-auto py-6">
      <EnhancedPatientForm />
    </div>
  )
}

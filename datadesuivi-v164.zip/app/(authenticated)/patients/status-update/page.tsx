"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Loader2, RefreshCw, CheckCircle, AlertTriangle } from "lucide-react"
import { supabase, refreshSchemaCache } from "@/lib/supabase"
import { updatePatientStatus } from "@/lib/patient-service-fix"

export default function PatientStatusUpdatePage() {
  const [patients, setPatients] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [updating, setUpdating] = useState(false)
  const [selectedPatient, setSelectedPatient] = useState<string | null>(null)
  const [newStatus, setNewStatus] = useState<string>("")
  const [result, setResult] = useState<{ success: boolean; message: string } | null>(null)
  const [refreshing, setRefreshing] = useState(false)

  useEffect(() => {
    fetchPatients()
  }, [])

  async function fetchPatients() {
    setLoading(true)
    try {
      const { data, error } = await supabase
        .from("patients")
        .select(`
          id,
          full_name,
          email,
          status,
          updated_at,
          closer:closer_id (id, full_name, email)
        `)
        .limit(10)

      if (error) {
        console.error("Error fetching patients:", error)
        throw error
      }

      setPatients(data || [])
    } catch (error) {
      console.error("Failed to fetch patients:", error)
    } finally {
      setLoading(false)
    }
  }

  async function handleStatusUpdate() {
    if (!selectedPatient || !newStatus) return

    setUpdating(true)
    setResult(null)

    try {
      const result = await updatePatientStatus(selectedPatient, newStatus)

      setResult({
        success: true,
        message: `Patient status updated successfully to "${newStatus}"`,
      })

      // Refresh the patient list
      await fetchPatients()
    } catch (error: any) {
      console.error("Error updating patient status:", error)

      setResult({
        success: false,
        message: `Error updating patient status: ${error.message}`,
      })
    } finally {
      setUpdating(false)
    }
  }

  async function handleRefreshSchema() {
    setRefreshing(true)
    try {
      const result = await refreshSchemaCache()

      if (result.success) {
        setResult({
          success: true,
          message: "Schema cache refreshed successfully. Try your operation again.",
        })
      } else {
        setResult({
          success: false,
          message: `Failed to refresh schema: ${result.error}`,
        })
      }
    } catch (error: any) {
      setResult({
        success: false,
        message: `Error refreshing schema: ${error.message}`,
      })
    } finally {
      setRefreshing(false)
    }
  }

  return (
    <div className="container mx-auto py-10">
      <Card className="w-full max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle>Patient Status Management</CardTitle>
          <CardDescription>Update patient status and verify schema functionality</CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          {result && (
            <Alert variant={result.success ? "default" : "destructive"}>
              {result.success ? <CheckCircle className="h-4 w-4" /> : <AlertTriangle className="h-4 w-4" />}
              <AlertTitle>{result.success ? "Success" : "Error"}</AlertTitle>
              <AlertDescription>{result.message}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-4">
            <div>
              <h3 className="text-sm font-medium mb-2">Select Patient</h3>
              <Select value={selectedPatient || ""} onValueChange={setSelectedPatient} disabled={loading}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select a patient" />
                </SelectTrigger>
                <SelectContent>
                  {patients.map((patient) => (
                    <SelectItem key={patient.id} value={patient.id}>
                      {patient.full_name || "Unnamed Patient"}
                      {patient.closer && ` (Closer: ${patient.closer.full_name})`}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <h3 className="text-sm font-medium mb-2">New Status</h3>
              <Select value={newStatus} onValueChange={setNewStatus} disabled={!selectedPatient || updating}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select new status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="new">New</SelectItem>
                  <SelectItem value="contacted">Contacted</SelectItem>
                  <SelectItem value="qualified">Qualified</SelectItem>
                  <SelectItem value="scheduled">Scheduled</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="pt-4">
            <h3 className="text-sm font-medium mb-2">Selected Patient Details</h3>
            {selectedPatient && (
              <div className="border rounded-md p-4 bg-gray-50">
                {patients.find((p) => p.id === selectedPatient) ? (
                  <div className="space-y-2 text-sm">
                    <p>
                      <span className="font-medium">Name:</span>{" "}
                      {patients.find((p) => p.id === selectedPatient)?.full_name}
                    </p>
                    <p>
                      <span className="font-medium">Email:</span>{" "}
                      {patients.find((p) => p.id === selectedPatient)?.email}
                    </p>
                    <p>
                      <span className="font-medium">Current Status:</span>{" "}
                      {patients.find((p) => p.id === selectedPatient)?.status || "Not set"}
                    </p>
                    <p>
                      <span className="font-medium">Last Updated:</span>{" "}
                      {patients.find((p) => p.id === selectedPatient)?.updated_at
                        ? new Date(patients.find((p) => p.id === selectedPatient)?.updated_at).toLocaleString()
                        : "Never"}
                    </p>
                    <p>
                      <span className="font-medium">Closer:</span>{" "}
                      {patients.find((p) => p.id === selectedPatient)?.closer?.full_name || "Not assigned"}
                    </p>
                  </div>
                ) : (
                  <p className="text-gray-500">Loading patient details...</p>
                )}
              </div>
            )}
          </div>
        </CardContent>

        <CardFooter className="flex justify-between">
          <Button variant="default" onClick={handleStatusUpdate} disabled={!selectedPatient || !newStatus || updating}>
            {updating ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Updating...
              </>
            ) : (
              "Update Status"
            )}
          </Button>

          <Button variant="outline" onClick={handleRefreshSchema} disabled={refreshing}>
            {refreshing ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Refreshing Schema...
              </>
            ) : (
              <>
                <RefreshCw className="mr-2 h-4 w-4" />
                Refresh Schema Cache
              </>
            )}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"
import { getPatients, type Patient } from "@/lib/patient-service"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import {
  Loader2,
  ArrowLeft,
  Edit,
  Calendar,
  Phone,
  FileText,
  User,
  CreditCard,
  Building,
  CheckCircle,
  FileCheck,
  Hospital,
  FileTextIcon as FileText2,
  Stethoscope,
  Weight,
  Ruler,
  Activity,
  Mail,
  Copy,
} from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"
import { fr } from "date-fns/locale"
import { useToast } from "@/components/ui/use-toast"
import { CallLogForm } from "@/components/call-log-form"
import { getStatusLabel, formatPhoneNumberE164 } from "@/lib/constants"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

export default function PatientDetailPage() {
  const params = useParams()
  const patientId = params.id as string
  const router = useRouter()
  const { user } = useAuth()
  const { toast } = useToast()
  const [loading, setLoading] = useState(true)
  const [patient, setPatient] = useState<Patient | null>(null)
  const [unauthorized, setUnauthorized] = useState(false)
  const [savingCall, setSavingCall] = useState(false)

  const isAdmin = user?.role === "admin"
  const isCloser = user?.role === "closer"

  useEffect(() => {
    async function fetchPatient() {
      try {
        setLoading(true)
        if (!user) {
          setUnauthorized(true)
          return
        }

        const patients = await getPatients(user.id, user.role)
        const foundPatient = patients.find((p) => p.id === patientId)

        if (!foundPatient) {
          setUnauthorized(true)
          return
        }

        // Add debugging for problematic fields
        console.log("Detail page - Loaded patient with fields:", {
          doctor: foundPatient.doctor,
          rdvObtenuPar: foundPatient.rdvObtenuPar,
          qualification: foundPatient.qualification,
          suiteGroupe: foundPatient.suiteGroupe,
          chirurgie: foundPatient.chirurgie,
        })

        setPatient(foundPatient)
      } catch (error) {
        console.error("Erreur lors de la récupération du patient:", error)
        setUnauthorized(true)
      } finally {
        setLoading(false)
      }
    }

    fetchPatient()
  }, [patientId, user])

  const formatDate = (dateString?: string) => {
    if (!dateString) return "Non défini"
    try {
      return format(new Date(dateString), "dd MMMM yyyy", { locale: fr })
    } catch (e) {
      return dateString
    }
  }

  const formatDateTime = (dateString?: string) => {
    if (!dateString) return "Non défini"
    try {
      return format(new Date(dateString), "dd MMMM yyyy HH:mm", { locale: fr })
    } catch (e) {
      return dateString
    }
  }

  const copyPhoneToClipboard = () => {
    if (patient?.phone) {
      navigator.clipboard
        .writeText(formatPhoneNumberE164(patient.phone))
        .then(() => {
          toast({
            title: "Numéro copié",
            description: "Le numéro de téléphone a été copié dans le presse-papiers",
            duration: 2000,
          })
        })
        .catch((err) => {
          console.error("Erreur lors de la copie:", err)
          toast({
            variant: "destructive",
            title: "Erreur",
            description: "Impossible de copier le numéro",
            duration: 2000,
          })
        })
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-gray-500" />
      </div>
    )
  }

  if (unauthorized) {
    return (
      <div className="text-center py-12 bg-white rounded-lg shadow">
        <h3 className="text-lg font-medium text-red-600">Accès non autorisé</h3>
        <p className="mt-2 text-sm text-gray-500">Vous n'avez pas l'autorisation d'accéder à cette fiche patient.</p>
        <div className="mt-6">
          <Button onClick={() => router.push("/patients")}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Retour à la liste des patients
          </Button>
        </div>
      </div>
    )
  }

  if (!patient) {
    return (
      <div className="text-center py-12 bg-white rounded-lg shadow">
        <h3 className="text-lg font-medium text-gray-900">Patient non trouvé</h3>
        <p className="mt-2 text-sm text-gray-500">Le patient demandé n'existe pas ou a été supprimé.</p>
        <div className="mt-6">
          <Button onClick={() => router.push("/patients")}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Retour à la liste des patients
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6 w-full overflow-y-auto">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="outline" onClick={() => router.push("/patients")}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Retour
          </Button>
          <h1 className="text-2xl font-bold">Détails du patient</h1>
        </div>
        <div className="flex gap-2">
          <Link href={`/patients/${patient.id}/edit`}>
            <Button>
              <Edit className="h-4 w-4 mr-2" />
              Modifier
            </Button>
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Informations principales */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex justify-between items-center">
              <span>Informations patient</span>
              <Badge variant="outline">{getStatusLabel(patient.status)}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="text-lg font-semibold">{patient.name}</h3>
              <p className="text-gray-500">{patient.email}</p>
              {patient.phone && (
                <div className="flex items-center mt-1">
                  <p className="text-gray-500">{formatPhoneNumberE164(patient.phone)}</p>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-6 w-6 ml-1" onClick={copyPhoneToClipboard}>
                          <Copy className="h-3 w-3" />
                          <span className="sr-only">Copier</span>
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Copier le numéro</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
              )}
            </div>

            <Separator />

            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-500">Médecin:</span>
                <span>{patient.doctor || "Non défini"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Date d'enregistrement:</span>
                <span>{formatDate(patient.registrationDate)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Suite/Groupe:</span>
                <span>{patient.suiteGroupe || "Non défini"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Qualification:</span>
                <span>{patient.qualification || "Non défini"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">RDV obtenu par:</span>
                <span>{patient.rdvObtenuPar || "Non défini"}</span>
              </div>
              {isAdmin && (
                <div className="flex justify-between">
                  <span className="text-gray-500">Commercial assigné:</span>
                  <span>{patient.closer || "Non assigné"}</span>
                </div>
              )}
              {isAdmin && (
                <div className="flex justify-between">
                  <span className="text-gray-500">Validé:</span>
                  <span>{patient.validated ? "Oui" : "Non"}</span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Contenu principal avec onglets */}
        <Card className="lg:col-span-2">
          <CardContent className="pt-6">
            <Tabs defaultValue="suivi">
              <TabsList className="w-full">
                <TabsTrigger value="suivi">Suivi</TabsTrigger>
                <TabsTrigger value="medical">Médical</TabsTrigger>
                <TabsTrigger value="financier">Financier</TabsTrigger>
                <TabsTrigger value="documents">Documents</TabsTrigger>
                <TabsTrigger value="nhs">NHS</TabsTrigger>
                <TabsTrigger value="notes">Notes</TabsTrigger>
                {isAdmin && <TabsTrigger value="admin">Admin</TabsTrigger>}
                {isCloser && <TabsTrigger value="actions">Actions rapides</TabsTrigger>}
              </TabsList>

              <TabsContent value="suivi" className="space-y-4 mt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <h3 className="font-medium flex items-center">
                      <Calendar className="h-4 w-4 mr-2" />
                      Dates importantes
                    </h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-500">Consultation:</span>
                        <span>{formatDate(patient.consultationDate)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Dernier appel:</span>
                        <span>{formatDate(patient.lastCallDate)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Prochaine relance:</span>
                        <span>{formatDate(patient.nextFollowUp)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Date d'opération:</span>
                        <span>{formatDate(patient.operationDate)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-medium flex items-center">
                      <Phone className="h-4 w-4 mr-2" />
                      Suivi des communications
                    </h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-500">Nombre d'appels:</span>
                        <span>{patient.callCount || 0}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">RDV programmé:</span>
                        <span>{patient.appointmentScheduled ? "Oui" : "Non"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Premier email:</span>
                        <span>{formatDateTime(patient.premierEmail)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Premier WhatsApp:</span>
                        <span>{formatDateTime(patient.premierWhatsapp)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Second email:</span>
                        <span>{formatDateTime(patient.secondEmail)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Second WhatsApp:</span>
                        <span>{formatDateTime(patient.secondWhatsapp)}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="medical" className="space-y-4 mt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <h3 className="font-medium flex items-center">
                      <Stethoscope className="h-4 w-4 mr-2" />
                      Informations médicales
                    </h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-500">
                          <Weight className="h-3 w-3 inline mr-1" />
                          Poids:
                        </span>
                        <span>{patient.poids ? `${patient.poids} kg` : "Non défini"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">
                          <Ruler className="h-3 w-3 inline mr-1" />
                          Taille:
                        </span>
                        <span>{patient.taille ? `${patient.taille} cm` : "Non défini"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">
                          <Activity className="h-3 w-3 inline mr-1" />
                          IMC:
                        </span>
                        <span>{patient.bmi || "Non défini"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Type de chirurgie:</span>
                        <span>{patient.chirurgie || "Non défini"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Agrément médical:</span>
                        <span>{patient.medicalAgrement ? "Oui" : "Non"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Formulaire de consentement:</span>
                        <span>{patient.consentForm ? "Oui" : "Non"}</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-medium flex items-center">
                      <Hospital className="h-4 w-4 mr-2" />
                      Comptes rendus
                    </h3>
                    <div className="space-y-4">
                      <div>
                        <h4 className="text-sm font-medium text-gray-700">Compte rendu de consultation:</h4>
                        <div className="mt-1 p-2 bg-gray-50 rounded-md text-sm max-h-32 overflow-y-auto">
                          {patient.compteRenduConsultation ? "Disponible" : "Non disponible"}
                        </div>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-gray-700">Compte rendu d'hospitalisation:</h4>
                        <div className="mt-1 p-2 bg-gray-50 rounded-md text-sm max-h-32 overflow-y-auto">
                          {patient.compteRenduHospitalisation ? "Disponible" : "Non disponible"}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="financier" className="space-y-4 mt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <h3 className="font-medium flex items-center">
                      <CreditCard className="h-4 w-4 mr-2" />
                      Informations financières
                    </h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-500">Revenus:</span>
                        <span>{patient.income ? `${patient.income} £` : "Non défini"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Dépenses:</span>
                        <span>{patient.expenses ? `${patient.expenses} £` : "Non défini"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Score de crédit:</span>
                        <span>{patient.creditScore || "Non défini"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Plateforme de crédit:</span>
                        <span>{patient.creditPlatform || "Non défini"}</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-medium flex items-center">
                      <Building className="h-4 w-4 mr-2" />
                      Informations de prêt
                    </h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-500">Montant du prêt:</span>
                        <span>{patient.loanAmount ? `${patient.loanAmount} £` : "Non défini"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Plateforme de prêt:</span>
                        <span>{patient.platform || "Non défini"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Simulation validée:</span>
                        <span>
                          {patient.simulationValidated === "Oui" || patient.simulationValidated === true
                            ? "Oui"
                            : "Non"}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Prêt demandé:</span>
                        <span>{patient.loanRequested === "Oui" || patient.loanRequested === true ? "Oui" : "Non"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Facture envoyée:</span>
                        <span>{patient.factureEnvoye ? "Oui" : "Non"}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="documents" className="space-y-4 mt-4">
                <div className="space-y-4">
                  <h3 className="font-medium flex items-center">
                    <FileCheck className="h-4 w-4 mr-2" />
                    Documents et formulaires
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-500">Email patient GP:</span>
                        <span>{patient.emailPatientGp ? "Oui" : "Non"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Formulaire S2 patient:</span>
                        <span>{patient.patientS2Form ? "Oui" : "Non"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Lettre GP:</span>
                        <span>{patient.lettreGp ? "Oui" : "Non"}</span>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-500">S2 Saint James:</span>
                        <span>{patient.s2SaintJames ? "Oui" : "Non"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Autorisation patient S2:</span>
                        <span>{patient.autorisationPatientS2 ? "Oui" : "Non"}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="nhs" className="space-y-4 mt-4">
                <div className="space-y-2">
                  <h3 className="font-medium flex items-center">
                    <FileText2 className="h-4 w-4 mr-2" />
                    NHS Tier 4
                  </h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-500">
                        <Mail className="h-3 w-3 inline mr-1" />
                        Premier email NHS Tier 4:
                      </span>
                      <span>{formatDateTime(patient.nhsTier4PremierEmail)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">
                        <Mail className="h-3 w-3 inline mr-1" />
                        Second email NHS Tier 4:
                      </span>
                      <span>{formatDateTime(patient.nhsTier4SecondEmail)}</span>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="notes" className="space-y-4 mt-4">
                <div className="space-y-2">
                  <h3 className="font-medium flex items-center">
                    <FileText className="h-4 w-4 mr-2" />
                    Commentaires et notes
                  </h3>
                  <div className="p-4 bg-gray-50 rounded-md min-h-[200px] whitespace-pre-wrap overflow-y-auto max-h-[400px]">
                    {patient.comments || "Aucun commentaire"}
                  </div>
                </div>
              </TabsContent>

              {isAdmin && (
                <TabsContent value="admin" className="space-y-4 mt-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <h3 className="font-medium flex items-center">
                        <User className="h-4 w-4 mr-2" />
                        Informations administratives
                      </h3>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-500">ID:</span>
                          <span>{patient.id}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-500">Créé le:</span>
                          <span>{formatDate(patient.created_at)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-500">Mis à jour le:</span>
                          <span>{formatDate(patient.updated_at)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-500">ID du closer:</span>
                          <span>{patient.closerId || "Non assigné"}</span>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <h3 className="font-medium flex items-center">
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Validation
                      </h3>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-500">Validé:</span>
                          <Badge variant={patient.validated ? "default" : "outline"}>
                            {patient.validated ? "Oui" : "Non"}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>
              )}

              {isCloser && (
                <TabsContent value="actions" className="space-y-4 mt-4">
                  <CallLogForm
                    patientId={patient.id || ""}
                    currentStatus={patient.status}
                    onSuccess={() => {
                      // Rafraîchir les données du patient
                      if (user) {
                        getPatients(user.id, user.role).then((patients) => {
                          const updatedPatient = patients.find((p) => p.id === patientId)
                          if (updatedPatient) {
                            setPatient(updatedPatient)
                          }
                        })
                      }
                    }}
                  />
                </TabsContent>
              )}
            </Tabs>
          </CardContent>
          <CardFooter className="flex justify-end">
            <Link href={`/patients/${patient.id}/edit`}>
              <Button>
                <Edit className="h-4 w-4 mr-2" />
                Modifier
              </Button>
            </Link>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

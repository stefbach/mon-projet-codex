"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import { EnhancedPatientForm } from "@/components/enhanced-patient-form"
import { getPatients, type Patient } from "@/lib/patient-service"
import { useAuth } from "@/contexts/auth-context"
import { Loader2 } from "lucide-react"

export default function EditPatientPage() {
  const params = useParams()
  const patientId = params.id as string
  const { user } = useAuth()
  const [patient, setPatient] = useState<Patient | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchPatient() {
      try {
        setLoading(true)
        if (!user) {
          setError("Vous devez être connecté pour accéder à cette page")
          return
        }

        const patients = await getPatients(user.id, user.role)
        const foundPatient = patients.find((p) => p.id === patientId)

        if (!foundPatient) {
          setError("Patient non trouvé")
          return
        }

        // Add debugging for problematic fields
        console.log("Edit page - Loaded patient with fields:", {
          doctor: foundPatient.doctor,
          rdvObtenuPar: foundPatient.rdvObtenuPar,
          qualification: foundPatient.qualification,
          suiteGroupe: foundPatient.suiteGroupe,
        })

        setPatient(foundPatient)
      } catch (error) {
        console.error("Erreur lors de la récupération du patient:", error)
        setError("Une erreur est survenue lors de la récupération des données du patient")
      } finally {
        setLoading(false)
      }
    }

    fetchPatient()
  }, [patientId, user])

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-gray-500" />
      </div>
    )
  }

  if (error) {
    return (
      <div className="container mx-auto py-6">
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded relative" role="alert">
          <strong className="font-bold">Erreur: </strong>
          <span className="block sm:inline">{error}</span>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-6">
      <EnhancedPatientForm patient={patient} isEditMode={true} />
    </div>
  )
}

"use client"

import { useEffect, useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import { getPatients, type Patient, deletePatient } from "@/lib/patient-service"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import type { DateRange } from "react-day-picker"
import { DatePickerWithRange } from "@/components/ui/date-range-picker"
import {
  Loader2,
  Plus,
  Search,
  Calendar,
  Phone,
  FileText,
  Edit,
  Trash2,
  AlertTriangle,
  Eye,
  Filter,
  Copy,
  Weight,
  Activity,
  Building,
  User,
  Mail,
  MessageSquare,
  FileCheck,
  FileX,
} from "lucide-react"
import Link from "next/link"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { useToast } from "@/components/ui/use-toast"
import { PATIENT_STATUSES, getStatusBadgeClass, getStatusLabel, formatPhoneNumberE164 } from "@/lib/constants"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { SchemaRefreshAlert } from "@/components/schema-refresh-alert"
import { useSearchParams, useRouter } from "next/navigation"

export default function PatientsPage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const router = useRouter()
  const searchParams = useSearchParams()
  const [patients, setPatients] = useState<Patient[]>([])
  const [filteredPatients, setFilteredPatients] = useState<Patient[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [activeTab, setActiveTab] = useState(searchParams.get("status") || "all")
  const [closerFilter, setCloserFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState(searchParams.get("status") || "all")
  const [dateFilter, setDateFilter] = useState("all")
  const [customDateRange, setCustomDateRange] = useState<DateRange | undefined>(undefined)
  const [showCustomDatePicker, setShowCustomDatePicker] = useState(false)
  const [callCountFilter, setCallCountFilter] = useState("all")
  const [bmiFilter, setBmiFilter] = useState("all")
  const [suiteGroupeFilter, setSuiteGroupeFilter] = useState("all")
  const [rdvObtenuParFilter, setRdvObtenuParFilter] = useState("all")
  const [qualificationFilter, setQualificationFilter] = useState("all")
  const [documentFilter, setDocumentFilter] = useState("all")
  const [closers, setClosers] = useState<{ id: string; name: string }[]>([])
  const [suiteGroupes, setSuiteGroupes] = useState<string[]>([])
  const [rdvObtenuPars, setRdvObtenuPars] = useState<string[]>([])
  const [patientToDelete, setPatientToDelete] = useState<string | null>(null)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [deletingPatient, setDeletingPatient] = useState(false)

  const isAdmin = user?.role === "admin"
  const isCloser = user?.role === "closer"

  // Liste des documents pour le filtre
  const documentOptions = [
    { value: "compteRenduConsultation", label: "Compte rendu de consultation" },
    { value: "compteRenduHospitalisation", label: "Compte rendu d'hospitalisation" },
    { value: "medicalAgrement", label: "Agrément médical" },
    { value: "consentForm", label: "Formulaire de consentement" },
    { value: "emailPatientGp", label: "Email patient GP" },
    { value: "patientS2Form", label: "Formulaire S2 patient" },
    { value: "lettreGp", label: "Lettre GP" },
    { value: "s2SaintJames", label: "S2 Saint James" },
    { value: "autorisationPatientS2", label: "Autorisation patient S2" },
  ]

  // Fonction sécurisée pour vérifier si une chaîne contient une sous-chaîne
  const safeIncludes = (str: string | null | undefined, searchStr: string): boolean => {
    if (!str) return false
    return str.toLowerCase().includes(searchStr)
  }

  useEffect(() => {
    async function fetchPatients() {
      try {
        // Récupérer les patients en fonction du rôle
        const data = await getPatients(user?.id || "", user?.role || "closer")

        // S'assurer que data est un tableau
        const safeData = Array.isArray(data) ? data : []

        setPatients(safeData)
        setFilteredPatients(safeData)

        // Extraire la liste des closers pour le filtre (admin uniquement)
        if (isAdmin) {
          const uniqueClosers = Array.from(new Set(safeData.map((patient) => patient?.closer).filter(Boolean))).map(
            (closerName) => {
              const patient = safeData.find((p) => p?.closer === closerName)
              return {
                id: patient?.closerId || "",
                name: closerName || "Non assigné",
              }
            },
          )
          setClosers(uniqueClosers)
        }

        // Extraire les valeurs uniques pour les nouveaux filtres
        const uniqueSuiteGroupes = Array.from(new Set(safeData.map((patient) => patient?.suiteGroupe).filter(Boolean)))
        setSuiteGroupes(uniqueSuiteGroupes as string[])

        const uniqueRdvObtenuPars = Array.from(
          new Set(safeData.map((patient) => patient?.rdvObtenuPar).filter(Boolean)),
        )
        setRdvObtenuPars(uniqueRdvObtenuPars as string[])
      } catch (error) {
        console.error("Erreur lors de la récupération des patients:", error)
        // En cas d'erreur, initialiser avec des tableaux vides
        setPatients([])
        setFilteredPatients([])
        setClosers([])
        setSuiteGroupes([])
        setRdvObtenuPars([])
      } finally {
        setLoading(false)
      }
    }

    fetchPatients()
  }, [user, isAdmin])

  // Mettre à jour l'URL lorsque les filtres changent
  useEffect(() => {
    const params = new URLSearchParams()
    if (statusFilter !== "all") {
      params.set("status", statusFilter)
    }

    const url = params.toString() ? `?${params.toString()}` : window.location.pathname
    window.history.replaceState({}, "", url)
  }, [statusFilter])

  // Mettre à jour les filtres lorsque l'onglet change
  useEffect(() => {
    setStatusFilter(activeTab)
  }, [activeTab])

  useEffect(() => {
    // Filtrer les patients en fonction des critères
    let filtered = [...patients]

    // Filtrer par terme de recherche
    if (searchTerm) {
      const lowerSearchTerm = searchTerm.toLowerCase()
      filtered = filtered.filter(
        (patient) =>
          safeIncludes(patient?.name, lowerSearchTerm) ||
          safeIncludes(patient?.email, lowerSearchTerm) ||
          safeIncludes(patient?.doctor, lowerSearchTerm) ||
          safeIncludes(patient?.notes, lowerSearchTerm) ||
          safeIncludes(patient?.phone, lowerSearchTerm) ||
          safeIncludes(patient?.suiteGroupe, lowerSearchTerm) ||
          safeIncludes(patient?.rdvObtenuPar, lowerSearchTerm) ||
          safeIncludes(patient?.qualification, lowerSearchTerm) ||
          safeIncludes(patient?.platform, lowerSearchTerm) ||
          (patient?.id && patient.id.toLowerCase().includes(lowerSearchTerm)),
      )
    }

    // Filtrer par statut (onglet)
    if (activeTab !== "all") {
      filtered = filtered.filter((patient) => patient?.status === activeTab)
    }

    // Filtrer par statut (filtre déroulant)
    if (statusFilter !== "all") {
      // Correction du filtre par statut
      if (statusFilter === "non_defini") {
        // Filtrer les statuts non définis (null, undefined, chaîne vide)
        filtered = filtered.filter((patient) => !patient?.status || patient.status === "")
      } else {
        // Recherche exacte pour les statuts
        filtered = filtered.filter((patient) => patient?.status === statusFilter)
      }
    }

    // Filtrer par closer (admin uniquement)
    if (isAdmin && closerFilter !== "all") {
      filtered = filtered.filter((patient) => patient?.closerId === closerFilter)
    }

    // Filtrer par nombre d'appels
    if (callCountFilter !== "all") {
      const minCalls = Number.parseInt(callCountFilter, 10)
      filtered = filtered.filter((patient) => (patient?.callCount || 0) >= minCalls)
    }

    // Filtrer par IMC
    if (bmiFilter !== "all") {
      if (bmiFilter === "under18.5") {
        filtered = filtered.filter((patient) => (patient?.bmi || 0) < 18.5)
      } else if (bmiFilter === "18.5-24.9") {
        filtered = filtered.filter((patient) => (patient?.bmi || 0) >= 18.5 && (patient?.bmi || 0) <= 24.9)
      } else if (bmiFilter === "25-29.9") {
        filtered = filtered.filter((patient) => (patient?.bmi || 0) >= 25 && (patient?.bmi || 0) <= 29.9)
      } else if (bmiFilter === "over30") {
        filtered = filtered.filter((patient) => (patient?.bmi || 0) >= 30)
      }
    }

    // Filtrer par Suite/Groupe
    if (suiteGroupeFilter !== "all") {
      filtered = filtered.filter((patient) => patient?.suiteGroupe === suiteGroupeFilter)
    }

    // Filtrer par RDV obtenu par
    if (rdvObtenuParFilter !== "all") {
      filtered = filtered.filter((patient) => patient?.rdvObtenuPar === rdvObtenuParFilter)
    }

    // Filtrer par qualification
    if (qualificationFilter !== "all") {
      filtered = filtered.filter((patient) => patient?.qualification === qualificationFilter)
    }

    // Filtrer par document manquant
    if (documentFilter !== "all") {
      filtered = filtered.filter((patient) => {
        // Vérifier si le document est manquant (false ou null/undefined)
        return patient?.[documentFilter] !== true
      })
    }

    // Filtrer par date
    if (dateFilter !== "all" || (dateFilter === "custom" && customDateRange)) {
      const now = new Date()
      now.setHours(0, 0, 0, 0) // Début de la journée actuelle

      const yesterday = new Date(now)
      yesterday.setDate(yesterday.getDate() - 1)

      const startOfWeek = new Date(now)
      startOfWeek.setDate(now.getDate() - now.getDay() + (now.getDay() === 0 ? -6 : 1)) // Lundi de la semaine courante

      const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1) // Premier jour du mois courant
      const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0) // Dernier jour du mois courant

      switch (dateFilter) {
        case "today":
          filtered = filtered.filter((patient) => {
            if (!patient?.consultationDate) return false
            try {
              const consultDate = new Date(patient.consultationDate)
              consultDate.setHours(0, 0, 0, 0)
              return consultDate.getTime() === now.getTime()
            } catch (e) {
              return false
            }
          })
          break
        case "yesterday":
          filtered = filtered.filter((patient) => {
            if (!patient?.consultationDate) return false
            try {
              const consultDate = new Date(patient.consultationDate)
              consultDate.setHours(0, 0, 0, 0)
              return consultDate.getTime() === yesterday.getTime()
            } catch (e) {
              return false
            }
          })
          break
        case "current_week":
          filtered = filtered.filter((patient) => {
            if (!patient?.consultationDate) return false
            try {
              const consultDate = new Date(patient.consultationDate)
              consultDate.setHours(0, 0, 0, 0)
              return consultDate >= startOfWeek && consultDate <= now
            } catch (e) {
              return false
            }
          })
          break
        case "current_month":
          filtered = filtered.filter((patient) => {
            if (!patient?.consultationDate) return false
            try {
              const consultDate = new Date(patient.consultationDate)
              consultDate.setHours(0, 0, 0, 0)
              return consultDate >= startOfMonth && consultDate <= endOfMonth
            } catch (e) {
              return false
            }
          })
          break
        case "custom":
          if (customDateRange?.from) {
            filtered = filtered.filter((patient) => {
              if (!patient?.consultationDate) return false
              try {
                const consultDate = new Date(patient.consultationDate)
                consultDate.setHours(0, 0, 0, 0)

                // Si seulement from est défini
                if (customDateRange.from && !customDateRange.to) {
                  return consultDate >= customDateRange.from
                }

                // Si from et to sont définis
                if (customDateRange.from && customDateRange.to) {
                  return consultDate >= customDateRange.from && consultDate <= customDateRange.to
                }

                return false
              } catch (e) {
                return false
              }
            })
          }
          break
      }
    }

    setFilteredPatients(filtered)
  }, [
    searchTerm,
    activeTab,
    closerFilter,
    statusFilter,
    dateFilter,
    customDateRange,
    callCountFilter,
    bmiFilter,
    suiteGroupeFilter,
    rdvObtenuParFilter,
    qualificationFilter,
    documentFilter,
    patients,
    isAdmin,
  ])

  const handleDeleteClick = (patientId: string) => {
    setPatientToDelete(patientId)
    setDeleteDialogOpen(true)
  }

  const handleDeleteConfirm = async () => {
    if (!patientToDelete || !user) return

    setDeletingPatient(true)
    try {
      const result = await deletePatient(patientToDelete, user)

      if (result.success) {
        toast({
          title: "Patient supprimé",
          description: "Le patient a été supprimé avec succès",
        })
        // Mettre à jour la liste des patients
        setPatients(patients.filter((p) => p?.id !== patientToDelete))
      } else {
        toast({
          variant: "destructive",
          title: "Erreur",
          description: result.message || "Une erreur s'est produite lors de la suppression",
        })
      }
    } catch (error) {
      console.error("Erreur lors de la suppression:", error)
      toast({
        variant: "destructive",
        title: "Erreur",
        description: "Une erreur s'est produite lors de la suppression",
      })
    } finally {
      setDeletingPatient(false)
      setDeleteDialogOpen(false)
      setPatientToDelete(null)
    }
  }

  const copyPhoneToClipboard = (phone: string) => {
    if (!phone) return

    const formattedPhone = formatPhoneNumberE164(phone)
    navigator.clipboard
      .writeText(formattedPhone)
      .then(() => {
        toast({
          title: "Numéro copié",
          description: "Le numéro de téléphone a été copié dans le presse-papiers",
          duration: 2000,
        })
      })
      .catch((err) => {
        console.error("Erreur lors de la copie:", err)
        toast({
          variant: "destructive",
          title: "Erreur",
          description: "Impossible de copier le numéro",
          duration: 2000,
        })
      })
  }

  // Fonction sécurisée pour formater les dates
  const formatDate = (dateString: string | null | undefined): string => {
    if (!dateString) return "-"
    try {
      return new Date(dateString).toLocaleDateString()
    } catch (e) {
      return dateString
    }
  }

  // Fonction pour obtenir le libellé d'un document à partir de sa valeur
  const getDocumentLabel = (value: string): string => {
    const document = documentOptions.find((doc) => doc.value === value)
    return document ? document.label : value
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-gray-500" />
      </div>
    )
  }

  // Calculer les comptages de statut pour les statistiques rapides
  const statusCounts = {}
  PATIENT_STATUSES.forEach((status) => {
    statusCounts[status.value] = filteredPatients.filter((p) => p?.status === status.value).length
  })

  // Calculer le nombre de patients avec des documents manquants
  const missingDocumentsCounts = {}
  documentOptions.forEach((doc) => {
    missingDocumentsCounts[doc.value] = patients.filter((p) => p?.[doc.value] !== true).length
  })

  return (
    <div className="space-y-6 w-full overflow-y-auto">
      <SchemaRefreshAlert />
      {/* Rest of the component */}
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Patients</h1>
        <Link href="/form">
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Nouveau patient
          </Button>
        </Link>
      </div>

      <div className="flex flex-col space-y-4">
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
            <Input
              type="search"
              placeholder="Rechercher par nom, email, téléphone..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="w-full sm:w-auto overflow-x-auto">
            <Tabs defaultValue={activeTab} className="w-full sm:w-auto" onValueChange={setActiveTab}>
              <TabsList>
                <TabsTrigger value="all">Tous</TabsTrigger>
                {PATIENT_STATUSES.map((status) => (
                  <TabsTrigger key={status.value} value={status.value}>
                    {status.label}
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>
          </div>
        </div>

        {/* Filtres supplémentaires */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {/* Filtre par statut */}
          <div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filtrer par statut" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les statuts</SelectItem>
                <SelectItem value="non_defini">Non défini</SelectItem>
                {PATIENT_STATUSES.map((status) => (
                  <SelectItem key={status.value} value={status.value}>
                    {status.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Filtre par document manquant */}
          <div>
            <Select value={documentFilter} onValueChange={setDocumentFilter}>
              <SelectTrigger>
                <FileX className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filtrer par document manquant" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les documents</SelectItem>
                {documentOptions.map((doc) => (
                  <SelectItem key={doc.value} value={doc.value}>
                    {doc.label} ({missingDocumentsCounts[doc.value] || 0})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Filtre par nombre d'appels */}
          <div>
            <Select value={callCountFilter} onValueChange={setCallCountFilter}>
              <SelectTrigger>
                <Phone className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filtrer par appels" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les appels</SelectItem>
                <SelectItem value="0">Aucun appel</SelectItem>
                <SelectItem value="1">Au moins 1 appel</SelectItem>
                <SelectItem value="3">Au moins 3 appels</SelectItem>
                <SelectItem value="5">Au moins 5 appels</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Filtre par IMC */}
          <div>
            <Select value={bmiFilter} onValueChange={setBmiFilter}>
              <SelectTrigger>
                <Activity className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filtrer par IMC" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les IMC</SelectItem>
                <SelectItem value="under18.5">Sous-poids (&lt; 18.5)</SelectItem>
                <SelectItem value="18.5-24.9">Normal (18.5-24.9)</SelectItem>
                <SelectItem value="25-29.9">Surpoids (25-29.9)</SelectItem>
                <SelectItem value="over30">Obésité (≥ 30)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Filtre par Suite/Groupe */}
          <div>
            <Select value={suiteGroupeFilter} onValueChange={setSuiteGroupeFilter}>
              <SelectTrigger>
                <Building className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filtrer par Suite/Groupe" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les groupes</SelectItem>
                {suiteGroupes.map((groupe) => (
                  <SelectItem key={groupe} value={groupe}>
                    {groupe}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Filtre par RDV obtenu par */}
          <div>
            <Select value={rdvObtenuParFilter} onValueChange={setRdvObtenuParFilter}>
              <SelectTrigger>
                <User className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filtrer par RDV obtenu par" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous</SelectItem>
                {rdvObtenuPars.map((obtenuPar) => (
                  <SelectItem key={obtenuPar} value={obtenuPar}>
                    {obtenuPar}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Filtre par Qualification */}
          <div>
            <Select value={qualificationFilter} onValueChange={setQualificationFilter}>
              <SelectTrigger>
                <Activity className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filtrer par qualification" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toutes les qualifications</SelectItem>
                <SelectItem value="chaud">Chaud</SelectItem>
                <SelectItem value="tiede">Tiède</SelectItem>
                <SelectItem value="froid">Froid</SelectItem>
                <SelectItem value="D/DEAD">D/DEAD</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Filtres supplémentaires (admin uniquement) */}
          {isAdmin && (
            <div>
              <Select value={closerFilter} onValueChange={setCloserFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filtrer par closer" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tous les closers</SelectItem>
                  {closers.map((closer) => (
                    <SelectItem key={closer.id} value={closer.id}>
                      {closer.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div>
            <Select
              value={dateFilter}
              onValueChange={(value) => {
                setDateFilter(value)
                if (value === "custom") {
                  setShowCustomDatePicker(true)
                } else {
                  setShowCustomDatePicker(false)
                }
              }}
            >
              <SelectTrigger>
                <Calendar className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filtrer par date de RDV" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toutes les dates</SelectItem>
                <SelectItem value="today">RDV aujourd'hui</SelectItem>
                <SelectItem value="yesterday">RDV hier</SelectItem>
                <SelectItem value="current_week">RDV cette semaine</SelectItem>
                <SelectItem value="current_month">RDV ce mois-ci</SelectItem>
                <SelectItem value="custom">Période personnalisée</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {showCustomDatePicker && (
            <div className="col-span-full">
              <DatePickerWithRange date={customDateRange} setDate={setCustomDateRange} className="w-full" />
            </div>
          )}
        </div>
      </div>

      {/* Statistiques rapides */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4 flex flex-col items-center justify-center">
            <p className="text-sm text-gray-500">Total patients</p>
            <p className="text-2xl font-bold">{filteredPatients.length}</p>
          </CardContent>
        </Card>

        {/* Afficher les statistiques pour les statuts les plus importants */}
        {["a_rappeler", "rdv_programme", "vente", "no_show"].map((statusValue) => (
          <Card key={statusValue}>
            <CardContent className="p-4 flex flex-col items-center justify-center">
              <p className="text-sm text-gray-500">
                {PATIENT_STATUSES.find((s) => s.value === statusValue)?.label || getStatusLabel(statusValue)}
              </p>
              <p className="text-2xl font-bold">{statusCounts[statusValue] || 0}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Statistiques des documents manquants */}
      {documentFilter !== "all" && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <FileX className="h-5 w-5 mr-2" />
              Documents manquants: {getDocumentLabel(documentFilter)}
            </CardTitle>
            <CardDescription>
              {missingDocumentsCounts[documentFilter] || 0} patient(s) n'ont pas ce document
            </CardDescription>
          </CardHeader>
        </Card>
      )}

      {filteredPatients.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-900">Aucun patient trouvé</h3>
          <p className="mt-2 text-sm text-gray-500">
            {searchTerm ||
            activeTab !== "all" ||
            statusFilter !== "all" ||
            closerFilter !== "all" ||
            dateFilter !== "all" ||
            (dateFilter === "custom" && customDateRange) ||
            callCountFilter !== "all" ||
            bmiFilter !== "all" ||
            suiteGroupeFilter !== "all" ||
            rdvObtenuParFilter !== "all" ||
            qualificationFilter !== "all" ||
            documentFilter !== "all"
              ? "Aucun résultat ne correspond à vos critères de recherche."
              : "Commencez par ajouter un nouveau patient."}
          </p>
          <div className="mt-6">
            <Link href="/form">
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Ajouter un patient
              </Button>
            </Link>
          </div>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filteredPatients.map((patient, index) => (
            <Card key={index} className="overflow-hidden">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>{patient?.name || "Sans nom"}</CardTitle>
                    <CardDescription>{patient?.email || "Pas d'email"}</CardDescription>
                  </div>
                  <Badge className={getStatusBadgeClass(patient?.status)}>{getStatusLabel(patient?.status)}</Badge>
                </div>
              </CardHeader>
              <CardContent className="pb-2">
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-500">Médecin:</span>
                    <span>{patient?.doctor || "-"}</span>
                  </div>

                  {patient?.phone && (
                    <div className="flex justify-between items-center">
                      <span className="text-gray-500">Téléphone:</span>
                      <div className="flex items-center space-x-1">
                        <span>{formatPhoneNumberE164(patient.phone)}</span>
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6"
                                onClick={() => copyPhoneToClipboard(patient.phone || "")}
                              >
                                <Copy className="h-3 w-3" />
                                <span className="sr-only">Copier</span>
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Copier le numéro</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </div>
                    </div>
                  )}

                  {/* Nouvelles colonnes */}
                  {patient?.suiteGroupe && (
                    <div className="flex justify-between">
                      <span className="text-gray-500">Suite/Groupe:</span>
                      <span>{patient.suiteGroupe}</span>
                    </div>
                  )}

                  {patient?.rdvObtenuPar && (
                    <div className="flex justify-between">
                      <span className="text-gray-500">RDV obtenu par:</span>
                      <span>{patient.rdvObtenuPar}</span>
                    </div>
                  )}

                  {patient?.qualification && (
                    <div className="flex justify-between">
                      <span className="text-gray-500">Qualification:</span>
                      <span>{patient.qualification}</span>
                    </div>
                  )}

                  {(patient?.poids || patient?.taille || patient?.bmi) && (
                    <div className="flex justify-between">
                      <span className="text-gray-500">
                        <Weight className="h-3 w-3 inline mr-1" />
                        Poids/Taille/IMC:
                      </span>
                      <span>
                        {patient?.poids ? `${patient.poids} kg` : "-"} /{patient?.taille ? `${patient.taille} cm` : "-"}{" "}
                        /{patient?.bmi ? patient.bmi : "-"}
                      </span>
                    </div>
                  )}

                  {patient?.lastCallDate && (
                    <div className="flex justify-between">
                      <span className="text-gray-500">
                        <Phone className="h-3 w-3 inline mr-1" />
                        Dernier appel:
                      </span>
                      <span>{formatDate(patient.lastCallDate)}</span>
                    </div>
                  )}

                  {patient?.callCount !== undefined && (
                    <div className="flex justify-between">
                      <span className="text-gray-500">Nombre d'appels:</span>
                      <span>{patient.callCount}</span>
                    </div>
                  )}

                  {patient?.consultationDate && (
                    <div className="flex justify-between">
                      <span className="text-gray-500">
                        <Calendar className="h-3 w-3 inline mr-1" />
                        Consultation:
                      </span>
                      <span>{formatDate(patient.consultationDate)}</span>
                    </div>
                  )}

                  {patient?.platform && (
                    <div className="flex justify-between">
                      <span className="text-gray-500">Plateforme:</span>
                      <span>{patient.platform}</span>
                    </div>
                  )}

                  {patient?.loanAmount && (
                    <div className="flex justify-between">
                      <span className="text-gray-500">Montant prêt:</span>
                      <span>{patient.loanAmount} £</span>
                    </div>
                  )}

                  {patient?.nextFollowUp && (
                    <div className="flex justify-between">
                      <span className="text-gray-500">
                        <Calendar className="h-3 w-3 inline mr-1" />
                        Prochaine relance:
                      </span>
                      <span>{formatDate(patient.nextFollowUp)}</span>
                    </div>
                  )}

                  {/* Affichage des dates d'email et WhatsApp */}
                  {patient?.premierEmail && (
                    <div className="flex justify-between">
                      <span className="text-gray-500">
                        <Mail className="h-3 w-3 inline mr-1" />
                        Premier email:
                      </span>
                      <span>{formatDate(patient.premierEmail)}</span>
                    </div>
                  )}

                  {patient?.premierWhatsapp && (
                    <div className="flex justify-between">
                      <span className="text-gray-500">
                        <MessageSquare className="h-3 w-3 inline mr-1" />
                        Premier WhatsApp:
                      </span>
                      <span>{formatDate(patient.premierWhatsapp)}</span>
                    </div>
                  )}

                  {/* Affichage des documents (si un filtre de document est actif) */}
                  {documentFilter !== "all" && (
                    <div className="mt-2 pt-2 border-t">
                      <div className="flex items-center justify-between">
                        <span className="text-gray-500">
                          <FileCheck className="h-3 w-3 inline mr-1" />
                          {getDocumentLabel(documentFilter)}:
                        </span>
                        <Badge variant={patient?.[documentFilter] === true ? "success" : "destructive"}>
                          {patient?.[documentFilter] === true ? "Présent" : "Manquant"}
                        </Badge>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
              <CardFooter className="pt-2 flex flex-col">
                <div className="w-full text-xs text-gray-500">
                  {/* Afficher le closer seulement s'il est défini et si l'utilisateur est admin */}
                  {isAdmin && patient?.closer && (
                    <div className="mb-1">
                      <span>Closer: </span>
                      <span>{patient.closer}</span>
                    </div>
                  )}
                  {patient?.notes && (
                    <div className="mt-2 pt-2 border-t">
                      <FileText className="h-3 w-3 inline mr-1" />
                      <p className="line-clamp-2">{patient.notes}</p>
                    </div>
                  )}
                </div>

                {/* Actions sur la fiche patient */}
                <div className="flex justify-end gap-2 mt-4 w-full">
                  <Link href={`/patients/${patient?.id || ""}`}>
                    <Button variant="outline" size="sm">
                      <Eye className="h-4 w-4 mr-1" />
                      Voir
                    </Button>
                  </Link>

                  <Link href={`/patients/${patient?.id || ""}/edit`}>
                    <Button variant="outline" size="sm">
                      <Edit className="h-4 w-4 mr-1" />
                      Modifier
                    </Button>
                  </Link>

                  {/* Bouton de suppression (admin uniquement) */}
                  {isAdmin && patient?.id && (
                    <Button variant="destructive" size="sm" onClick={() => handleDeleteClick(patient.id)}>
                      <Trash2 className="h-4 w-4 mr-1" />
                      Supprimer
                    </Button>
                  )}
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}

      {/* Dialog de confirmation de suppression */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-500" />
              Confirmer la suppression
            </DialogTitle>
            <DialogDescription>
              Êtes-vous sûr de vouloir supprimer ce patient ? Cette action est irréversible.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)} disabled={deletingPatient}>
              Annuler
            </Button>
            <Button variant="destructive" onClick={handleDeleteConfirm} disabled={deletingPatient}>
              {deletingPatient ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Suppression...
                </>
              ) : (
                "Supprimer"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

"use client"

import { UserManagement } from "@/components/user-management"
import { RoleGuard } from "@/components/role-guard"

export default function UsersManagementPage() {
  return (
    <RoleGuard allowedRoles={["admin"]}>
      <UserManagement />
    </RoleGuard>
  )
}

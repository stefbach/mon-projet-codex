import { SchemaDiagnostic } from "@/components/schema-diagnostic"

export default function SchemaDiagnosticPage() {
  return (
    <div className="container mx-auto py-10">
      <h1 className="text-2xl font-bold mb-6">Database Schema Diagnostic</h1>
      <p className="text-gray-500 mb-8">
        Use this tool to diagnose and fix issues with the database schema, including missing columns and relationship
        problems.
      </p>

      <SchemaDiagnostic />
    </div>
  )
}

import { DashboardStats } from "@/components/dashboard-stats"

export default function DashboardStatsPage() {
  return (
    <div className="container mx-auto py-6">
      <h1 className="text-2xl font-bold mb-6">Tableau de bord statistique</h1>
      <DashboardStats />
    </div>
  )
}

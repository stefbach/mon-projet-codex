"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/contexts/auth-context"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Loader2, Search, Phone, Calendar, Eye } from "lucide-react"
import { getPatients, type Patient } from "@/lib/patient-service"
import { getStatusBadgeClass } from "@/lib/constants"
import Link from "next/link"
import { format } from "date-fns"
import { fr } from "date-fns/locale"

const PATIENT_STATUSES = [
  { value: "pending", label: "En attente" },
  { value: "in_progress", label: "En cours" },
  { value: "completed", label: "Terminé" },
  { value: "canceled", label: "Annulé" },
]

export default function CallsPage() {
  const { user } = useAuth()
  const [patients, setPatients] = useState<Patient[]>([])
  const [filteredPatients, setFilteredPatients] = useState<Patient[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [callFilter, setCallFilter] = useState("all")
  const [sortBy, setSortBy] = useState("last_call")

  useEffect(() => {
    async function fetchPatients() {
      try {
        setLoading(true)
        const data = await getPatients(user?.id || "", user?.role || "closer")
        setPatients(data)
        setFilteredPatients(data)
      } catch (error) {
        console.error("Erreur lors de la récupération des patients:", error)
      } finally {
        setLoading(false)
      }
    }

    if (user) {
      fetchPatients()
    }
  }, [user])

  useEffect(() => {
    // Filtrer les patients
    let filtered = [...patients]

    // Filtrer par terme de recherche
    if (searchTerm) {
      filtered = filtered.filter(
        (patient) =>
          patient.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          patient.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          patient.doctor?.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    // Filtrer par statut
    if (statusFilter !== "all") {
      filtered = filtered.filter((patient) => patient.status === statusFilter)
    }

    // Filtrer par nombre d'appels
    if (callFilter !== "all") {
      switch (callFilter) {
        case "none":
          filtered = filtered.filter((patient) => !patient.callCount || patient.callCount === 0)
          break
        case "one_plus":
          filtered = filtered.filter((patient) => patient.callCount && patient.callCount >= 1)
          break
        case "three_plus":
          filtered = filtered.filter((patient) => patient.callCount && patient.callCount >= 3)
          break
      }
    }

    // Trier les patients
    switch (sortBy) {
      case "last_call":
        filtered.sort((a, b) => {
          if (!a.lastCallDate) return 1
          if (!b.lastCallDate) return -1
          return new Date(b.lastCallDate).getTime() - new Date(a.lastCallDate).getTime()
        })
        break
      case "call_count":
        filtered.sort((a, b) => (b.callCount || 0) - (a.callCount || 0))
        break
      case "name":
        filtered.sort((a, b) => (a.name || "").localeCompare(b.name || ""))
        break
    }

    setFilteredPatients(filtered)
  }, [searchTerm, statusFilter, callFilter, sortBy, patients])

  const formatDate = (dateString?: string) => {
    if (!dateString) return "Non défini"
    try {
      return format(new Date(dateString), "dd/MM/yyyy", { locale: fr })
    } catch (e) {
      return dateString
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-gray-500" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Suivi des appels</h1>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative w-full sm:w-64">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            type="search"
            placeholder="Rechercher..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-[180px]">
            <SelectValue placeholder="Filtrer par statut" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tous les statuts</SelectItem>
            {PATIENT_STATUSES.map((status) => (
              <SelectItem key={status.value} value={status.value}>
                {status.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={callFilter} onValueChange={setCallFilter}>
          <SelectTrigger className="w-full sm:w-[180px]">
            <SelectValue placeholder="Filtrer par appels" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tous les appels</SelectItem>
            <SelectItem value="none">Aucun appel</SelectItem>
            <SelectItem value="one_plus">Au moins 1 appel</SelectItem>
            <SelectItem value="three_plus">Au moins 3 appels</SelectItem>
          </SelectContent>
        </Select>

        <Select value={sortBy} onValueChange={setSortBy}>
          <SelectTrigger className="w-full sm:w-[180px]">
            <SelectValue placeholder="Trier par" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="last_call">Dernier appel</SelectItem>
            <SelectItem value="call_count">Nombre d'appels</SelectItem>
            <SelectItem value="name">Nom</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Historique des appels</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredPatients.length === 0 ? (
            <div className="text-center py-8">
              <Phone className="h-12 w-12 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900">Aucun patient trouvé</h3>
              <p className="mt-2 text-sm text-gray-500">
                {searchTerm || statusFilter !== "all" || callFilter !== "all"
                  ? "Aucun résultat ne correspond à vos critères de recherche."
                  : "Commencez par ajouter des patients et enregistrer des appels."}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Patient</TableHead>
                    <TableHead>Statut</TableHead>
                    <TableHead>Dernier appel</TableHead>
                    <TableHead>Nombre d'appels</TableHead>
                    <TableHead>Médecin</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPatients.map((patient) => (
                    <TableRow key={patient.id}>
                      <TableCell className="font-medium">{patient.name}</TableCell>
                      <TableCell>
                        <Badge className={getStatusBadgeClass(patient.status || "")}>
                          {patient.status || "Non défini"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <Calendar className="h-3 w-3 mr-1 text-gray-500" />
                          {formatDate(patient.lastCallDate)}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <Phone className="h-3 w-3 mr-1 text-gray-500" />
                          {patient.callCount || 0}
                        </div>
                      </TableCell>
                      <TableCell>{patient.doctor}</TableCell>
                      <TableCell className="text-right">
                        <Link href={`/patients/${patient.id}`}>
                          <Button variant="outline" size="sm">
                            <Eye className="h-4 w-4 mr-1" />
                            Voir
                          </Button>
                        </Link>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

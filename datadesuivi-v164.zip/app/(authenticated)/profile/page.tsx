"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/contexts/auth-context"
import {
  updateUserProfile,
  getUserPreferences,
  saveUserPreferences,
  changeUserPassword,
  sendPasswordReset,
  type UserPreferences,
} from "@/lib/user-service"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Loader2, UserIcon, Mail, Bell, Moon, Sun, Monitor, Lock, KeyRound, Eye, EyeOff } from "lucide-react"
import { toast } from "@/components/ui/use-toast"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"
import { useTranslation } from "react-i18next"
import { changeLocale, type Locale } from "@/i18n/settings"

// Schéma de validation pour le formulaire de profil
const profileFormSchema = z.object({
  displayName: z
    .string()
    .min(2, { message: "Le nom doit contenir au moins 2 caractères" })
    .max(50, { message: "Le nom ne peut pas dépasser 50 caractères" }),
  email: z.string().email({ message: "Veuillez entrer une adresse email valide" }),
  photoURL: z.string().url({ message: "Veuillez entrer une URL valide" }).optional().or(z.literal("")),
})

// Schéma de validation pour le formulaire de préférences
const preferencesFormSchema = z.object({
  theme: z.enum(["light", "dark", "system"]),
  notifications: z.boolean(),
  language: z.enum(["fr", "en"]),
})

// Schéma de validation pour le formulaire de changement de mot de passe
const passwordFormSchema = z
  .object({
    currentPassword: z.string().min(1, { message: "Le mot de passe actuel est requis" }),
    newPassword: z
      .string()
      .min(8, { message: "Le nouveau mot de passe doit contenir au moins 8 caractères" })
      .regex(/[A-Z]/, { message: "Le mot de passe doit contenir au moins une majuscule" })
      .regex(/[a-z]/, { message: "Le mot de passe doit contenir au moins une minuscule" })
      .regex(/[0-9]/, { message: "Le mot de passe doit contenir au moins un chiffre" }),
    confirmPassword: z.string().min(1, { message: "Veuillez confirmer votre mot de passe" }),
  })
  .refine((data) => data.newPassword === data.confirmPassword, {
    message: "Les mots de passe ne correspondent pas",
    path: ["confirmPassword"],
  })

export default function ProfilePage() {
  const { user, isDemoMode } = useAuth()
  const [isUpdating, setIsUpdating] = useState(false)
  const [preferences, setPreferences] = useState<UserPreferences>({
    theme: "system",
    notifications: true,
    language: "fr",
  })
  const [showCurrentPassword, setShowCurrentPassword] = useState(false)
  const [showNewPassword, setShowNewPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const { t } = useTranslation()

  // Formulaire de profil
  const profileForm = useForm<z.infer<typeof profileFormSchema>>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      displayName: user?.displayName || "",
      email: user?.email || "",
      photoURL: user?.photoURL || "",
    },
  })

  // Formulaire de préférences
  const preferencesForm = useForm<z.infer<typeof preferencesFormSchema>>({
    resolver: zodResolver(preferencesFormSchema),
    defaultValues: preferences,
  })

  // Formulaire de mot de passe
  const passwordForm = useForm<z.infer<typeof passwordFormSchema>>({
    resolver: zodResolver(passwordFormSchema),
    defaultValues: {
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    },
  })

  // Charger les préférences utilisateur
  useEffect(() => {
    if (user?.uid) {
      const userPrefs = getUserPreferences(user.uid)
      setPreferences(userPrefs)
      preferencesForm.reset(userPrefs)
    }
  }, [user, preferencesForm])

  // Mettre à jour les valeurs du formulaire lorsque l'utilisateur change
  useEffect(() => {
    if (user) {
      profileForm.reset({
        displayName: user.displayName || "",
        email: user.email || "",
        photoURL: user.photoURL || "",
      })
    }
  }, [user, profileForm])

  // Fonction pour mettre à jour le profil
  async function onProfileSubmit(data: z.infer<typeof profileFormSchema>) {
    if (!user) return

    setIsUpdating(true)

    try {
      if (isDemoMode) {
        // En mode démo, simuler la mise à jour
        setTimeout(() => {
          toast({
            title: "Profil mis à jour",
            description: "Vos informations ont été mises à jour avec succès.",
          })
          setIsUpdating(false)
        }, 1000)
        return
      }

      const success = await updateUserProfile(user, {
        displayName: data.displayName,
        email: data.email,
        photoURL: data.photoURL || undefined,
      })

      if (success) {
        toast({
          title: "Profil mis à jour",
          description: "Vos informations ont été mises à jour avec succès.",
        })
      }
    } catch (error) {
      console.error("Erreur lors de la mise à jour du profil:", error)
    } finally {
      setIsUpdating(false)
    }
  }

  // Fonction pour mettre à jour les préférences
  function onPreferencesSubmit(data: z.infer<typeof preferencesFormSchema>) {
    if (!user) return

    setIsUpdating(true)

    try {
      // Enregistrer les préférences
      saveUserPreferences(user.uid, data)
      setPreferences(data)

      toast({
        title: "Préférences mises à jour",
        description: "Vos préférences ont été enregistrées avec succès.",
      })
    } catch (error) {
      console.error("Erreur lors de la mise à jour des préférences:", error)
      toast({
        variant: "destructive",
        title: "Erreur",
        description: "Une erreur s'est produite lors de l'enregistrement des préférences.",
      })
    } finally {
      setIsUpdating(false)
    }
  }

  // Fonction pour changer le mot de passe
  async function onPasswordSubmit(data: z.infer<typeof passwordFormSchema>) {
    if (!user) return

    setIsUpdating(true)

    try {
      if (isDemoMode) {
        // En mode démo, simuler le changement de mot de passe
        setTimeout(() => {
          toast({
            title: "Mot de passe mis à jour",
            description: "Votre mot de passe a été changé avec succès.",
          })
          passwordForm.reset()
          setIsUpdating(false)
        }, 1000)
        return
      }

      const success = await changeUserPassword(user, {
        currentPassword: data.currentPassword,
        newPassword: data.newPassword,
      })

      if (success) {
        passwordForm.reset()
      }
    } catch (error) {
      console.error("Erreur lors du changement de mot de passe:", error)
    } finally {
      setIsUpdating(false)
    }
  }

  // Fonction pour envoyer un email de réinitialisation de mot de passe
  async function handlePasswordReset() {
    if (!user?.email) return

    setIsUpdating(true)

    try {
      if (isDemoMode) {
        // En mode démo, simuler l'envoi d'email
        setTimeout(() => {
          toast({
            title: "Email envoyé",
            description: "Un email de réinitialisation de mot de passe a été envoyé à votre adresse.",
          })
          setIsUpdating(false)
        }, 1000)
        return
      }

      await sendPasswordReset(user.email)
    } catch (error) {
      console.error("Erreur lors de l'envoi de l'email de réinitialisation:", error)
    } finally {
      setIsUpdating(false)
    }
  }

  if (!user) {
    return (
      <div className="flex items-center justify-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-gray-500" />
      </div>
    )
  }

  // Obtenir les initiales pour l'avatar
  const getInitials = () => {
    if (user.displayName) {
      return user.displayName
        .split(" ")
        .map((n) => n[0])
        .join("")
        .toUpperCase()
    }
    return user.email ? user.email[0].toUpperCase() : "U"
  }

  // Vérifier si l'utilisateur est connecté via Google (pas de mot de passe)
  const isGoogleUser = user.providerData?.some((provider) => provider.providerId === "google.com")

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-bold">Profil utilisateur</h1>
        <p className="text-gray-600">Gérez vos informations personnelles et vos préférences</p>
      </div>

      <div className="grid gap-6">
        <div className="flex items-center space-x-4">
          <Avatar className="h-20 w-20">
            <AvatarImage src={user.photoURL || undefined} alt={user.displayName || "Avatar"} />
            <AvatarFallback className="text-lg">{getInitials()}</AvatarFallback>
          </Avatar>
          <div>
            <h2 className="text-xl font-semibold">{user.displayName || "Utilisateur"}</h2>
            <p className="text-gray-500">{user.email}</p>
            {user.emailVerified ? (
              <span className="inline-flex items-center px-2 py-1 mt-1 text-xs font-medium text-green-700 bg-green-100 rounded-full">
                Email vérifié
              </span>
            ) : (
              <span className="inline-flex items-center px-2 py-1 mt-1 text-xs font-medium text-amber-700 bg-amber-100 rounded-full">
                Email non vérifié
              </span>
            )}
          </div>
        </div>

        <Tabs defaultValue="profile" className="mt-6">
          <TabsList>
            <TabsTrigger value="profile">Profil</TabsTrigger>
            <TabsTrigger value="password">Mot de passe</TabsTrigger>
            <TabsTrigger value="preferences">Préférences</TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Informations personnelles</CardTitle>
                <CardDescription>Mettez à jour vos informations personnelles</CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...profileForm}>
                  <form onSubmit={profileForm.handleSubmit(onProfileSubmit)} className="space-y-6">
                    <FormField
                      control={profileForm.control}
                      name="displayName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nom</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <UserIcon className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                              <Input className="pl-10" placeholder="Votre nom" {...field} />
                            </div>
                          </FormControl>
                          <FormDescription>Votre nom tel qu'il apparaîtra dans l'application</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={profileForm.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                              <Input className="pl-10" placeholder="votre.email@exemple.com" {...field} />
                            </div>
                          </FormControl>
                          <FormDescription>
                            Votre adresse email. Un email de vérification sera envoyé si vous la modifiez.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={profileForm.control}
                      name="photoURL"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>URL de la photo de profil</FormLabel>
                          <FormControl>
                            <Input placeholder="https://exemple.com/votre-photo.jpg" {...field} />
                          </FormControl>
                          <FormDescription>
                            Lien vers votre photo de profil. Laissez vide pour utiliser les initiales.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button type="submit" disabled={isUpdating}>
                      {isUpdating ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Mise à jour...
                        </>
                      ) : (
                        "Enregistrer les modifications"
                      )}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="password" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Sécurité du compte</CardTitle>
                <CardDescription>Gérez votre mot de passe et la sécurité de votre compte</CardDescription>
              </CardHeader>
              <CardContent>
                {isGoogleUser ? (
                  <Alert>
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Compte Google</AlertTitle>
                    <AlertDescription>
                      Vous êtes connecté avec Google. La gestion du mot de passe se fait via votre compte Google.
                    </AlertDescription>
                  </Alert>
                ) : (
                  <Form {...passwordForm}>
                    <form onSubmit={passwordForm.handleSubmit(onPasswordSubmit)} className="space-y-6">
                      <FormField
                        control={passwordForm.control}
                        name="currentPassword"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Mot de passe actuel</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <KeyRound className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                                <Input
                                  className="pl-10"
                                  type={showCurrentPassword ? "text" : "password"}
                                  placeholder="Votre mot de passe actuel"
                                  {...field}
                                />
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="icon"
                                  className="absolute right-0 top-0 h-full px-3"
                                  onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                                >
                                  {showCurrentPassword ? (
                                    <EyeOff className="h-4 w-4 text-gray-400" />
                                  ) : (
                                    <Eye className="h-4 w-4 text-gray-400" />
                                  )}
                                </Button>
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={passwordForm.control}
                        name="newPassword"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Nouveau mot de passe</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                                <Input
                                  className="pl-10"
                                  type={showNewPassword ? "text" : "password"}
                                  placeholder="Votre nouveau mot de passe"
                                  {...field}
                                />
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="icon"
                                  className="absolute right-0 top-0 h-full px-3"
                                  onClick={() => setShowNewPassword(!showNewPassword)}
                                >
                                  {showNewPassword ? (
                                    <EyeOff className="h-4 w-4 text-gray-400" />
                                  ) : (
                                    <Eye className="h-4 w-4 text-gray-400" />
                                  )}
                                </Button>
                              </div>
                            </FormControl>
                            <FormDescription>
                              Le mot de passe doit contenir au moins 8 caractères, une majuscule, une minuscule et un
                              chiffre.
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={passwordForm.control}
                        name="confirmPassword"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Confirmer le mot de passe</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                                <Input
                                  className="pl-10"
                                  type={showConfirmPassword ? "text" : "password"}
                                  placeholder="Confirmez votre nouveau mot de passe"
                                  {...field}
                                />
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="icon"
                                  className="absolute right-0 top-0 h-full px-3"
                                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                                >
                                  {showConfirmPassword ? (
                                    <EyeOff className="h-4 w-4 text-gray-400" />
                                  ) : (
                                    <Eye className="h-4 w-4 text-gray-400" />
                                  )}
                                </Button>
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <Button type="submit" disabled={isUpdating}>
                        {isUpdating ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Mise à jour...
                          </>
                        ) : (
                          "Changer le mot de passe"
                        )}
                      </Button>
                    </form>
                  </Form>
                )}
              </CardContent>
              <CardFooter className="flex flex-col items-start">
                <Separator className="my-4 w-full" />
                <div className="space-y-2 w-full">
                  <h3 className="text-sm font-medium">Mot de passe oublié ?</h3>
                  <p className="text-sm text-gray-500">
                    Si vous avez oublié votre mot de passe, vous pouvez demander une réinitialisation par email.
                  </p>
                  <Button
                    variant="outline"
                    onClick={handlePasswordReset}
                    disabled={isUpdating || !user.email}
                    className="mt-2"
                  >
                    {isUpdating ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Envoi en cours...
                      </>
                    ) : (
                      "Réinitialiser le mot de passe"
                    )}
                  </Button>
                </div>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="preferences" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Préférences</CardTitle>
                <CardDescription>Personnalisez votre expérience utilisateur</CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...preferencesForm}>
                  <form onSubmit={preferencesForm.handleSubmit(onPreferencesSubmit)} className="space-y-6">
                    <FormField
                      control={preferencesForm.control}
                      name="theme"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Thème</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              className="flex flex-col space-y-1"
                            >
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="light" id="theme-light" />
                                <Label htmlFor="theme-light" className="flex items-center">
                                  <Sun className="h-4 w-4 mr-2" />
                                  Clair
                                </Label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="dark" id="theme-dark" />
                                <Label htmlFor="theme-dark" className="flex items-center">
                                  <Moon className="h-4 w-4 mr-2" />
                                  Sombre
                                </Label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="system" id="theme-system" />
                                <Label htmlFor="theme-system" className="flex items-center">
                                  <Monitor className="h-4 w-4 mr-2" />
                                  Système
                                </Label>
                              </div>
                            </RadioGroup>
                          </FormControl>
                          <FormDescription>Choisissez le thème de l'interface</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Separator />

                    <FormField
                      control={preferencesForm.control}
                      name="notifications"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between">
                          <div className="space-y-0.5">
                            <FormLabel className="flex items-center">
                              <Bell className="h-4 w-4 mr-2" />
                              Notifications
                            </FormLabel>
                            <FormDescription>Recevoir des notifications pour les relances</FormDescription>
                          </div>
                          <FormControl>
                            <Switch checked={field.value} onCheckedChange={field.onChange} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Separator />

                    <FormField
                      control={preferencesForm.control}
                      name="language"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t("preferences.language")}</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={(value) => {
                                field.onChange(value)
                                // Changer la langue immédiatement
                                changeLocale(value as Locale)
                              }}
                              defaultValue={field.value}
                              className="flex flex-col space-y-1"
                            >
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="fr" id="lang-fr" />
                                <Label htmlFor="lang-fr">Français</Label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="en" id="lang-en" />
                                <Label htmlFor="lang-en">English</Label>
                              </div>
                            </RadioGroup>
                          </FormControl>
                          <FormDescription>{t("preferences.languageDesc")}</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button type="submit" disabled={isUpdating}>
                      {isUpdating ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Enregistrement...
                        </>
                      ) : (
                        "Enregistrer les préférences"
                      )}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

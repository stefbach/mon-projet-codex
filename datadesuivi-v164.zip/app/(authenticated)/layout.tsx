import type React from "react"
import { SchemaRefreshAlert } from "@/components/schema-refresh-alert"
import { AutoSchemaRepair } from "@/components/auto-schema-repair"
import { Sidebar } from "@/components/sidebar"
import { Navbar } from "@/components/navbar"

export default function AuthenticatedLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 bg-gray-50">
          {/* Ajouter le composant de réparation automatique du schéma */}
          <AutoSchemaRepair />
          {/* Garder l'alerte de rafraîchissement du schéma existante */}
          <SchemaRefreshAlert />
          {children}
        </main>
      </div>
    </div>
  )
}

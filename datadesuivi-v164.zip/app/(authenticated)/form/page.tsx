"use client"

import { PatientForm } from "@/components/patient-form"

export default function FormPage() {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-bold">Ajouter un nouveau patient</h1>
        <p className="text-gray-600">Remplissez le formulaire pour ajouter un nouveau patient au suivi</p>
      </div>
      <div className="bg-white shadow-md rounded-lg p-6">
        <PatientForm />
      </div>
    </div>
  )
}

"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useRouter } from "next/navigation"
import { Loader2, Lock } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LanguageSwitcher } from "@/components/language-switcher"
import { useI18n } from "@/lib/i18n"
import Cookies from "js-cookie"

export default function LoginPage() {
  const router = useRouter()
  const [password, setPassword] = useState("")
  const [selectedRole, setSelectedRole] = useState("closer")
  const [isLoading, setIsLoading] = useState(false)
  const { t } = useI18n()

  // Mots de passe prédéfinis pour chaque rôle
  const passwords = {
    admin: "admin123",
    closer: "closer123",
  }

  const handleLogin = () => {
    setIsLoading(true)

    // Vérifier si le mot de passe correspond au rôle sélectionné
    if (password === passwords[selectedRole as keyof typeof passwords]) {
      // Stocker les informations de connexion dans un cookie
      Cookies.set("simpleAuth", "true", { expires: 7 })
      Cookies.set("userRole", selectedRole, { expires: 7 })

      // Rediriger vers le tableau de bord
      router.push("/dashboard")
    } else {
      alert("Mot de passe incorrect")
      setIsLoading(false)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && password) {
      handleLogin()
    }
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-neutral-50">
      <div className="absolute top-0 left-0 w-full h-16 bg-primary-500"></div>
      <div className="absolute bottom-0 left-0 w-full h-16 bg-secondary-500"></div>

      <div className="w-full max-w-md px-4">
        <Card className="w-full shadow-lg border-t-4 border-t-primary-500">
          <CardHeader className="space-y-1">
            <div className="flex justify-between items-center">
              <div>
                <CardTitle className="text-2xl font-bold text-primary-700">Obesity Care Clinic</CardTitle>
                <CardDescription>Suivi des Ventes - Accès au système</CardDescription>
              </div>
              <LanguageSwitcher />
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col space-y-4">
              <Tabs defaultValue="closer" className="w-full" onValueChange={(value) => setSelectedRole(value)}>
                <TabsList className="grid w-full grid-cols-2 bg-neutral-100">
                  <TabsTrigger
                    value="admin"
                    className="data-[state=active]:bg-primary-500 data-[state=active]:text-white"
                  >
                    {t("role.admin")}
                  </TabsTrigger>
                  <TabsTrigger
                    value="closer"
                    className="data-[state=active]:bg-primary-500 data-[state=active]:text-white"
                  >
                    {t("role.closer")}
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="admin" className="mt-4">
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="admin-password" className="text-neutral-700">
                        Mot de passe administrateur
                      </Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="admin-password"
                          type="password"
                          placeholder="Entrez le mot de passe"
                          className="pl-10"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          onKeyDown={handleKeyDown}
                        />
                      </div>
                    </div>
                    <Button
                      onClick={handleLogin}
                      disabled={isLoading || !password}
                      className="w-full bg-primary-500 hover:bg-primary-600"
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          {t("misc.loading")}
                        </>
                      ) : (
                        t("auth.loginAsAdmin")
                      )}
                    </Button>
                    <div className="text-center text-sm text-neutral-500">
                      <p>Pour tester, utilisez le mot de passe: admin123</p>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="closer" className="mt-4">
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="closer-password" className="text-neutral-700">
                        Mot de passe closer
                      </Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="closer-password"
                          type="password"
                          placeholder="Entrez le mot de passe"
                          className="pl-10"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          onKeyDown={handleKeyDown}
                        />
                      </div>
                    </div>
                    <Button
                      onClick={handleLogin}
                      disabled={isLoading || !password}
                      className="w-full bg-primary-500 hover:bg-primary-600"
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          {t("misc.loading")}
                        </>
                      ) : (
                        t("auth.loginAsCloser")
                      )}
                    </Button>
                    <div className="text-center text-sm text-neutral-500">
                      <p>Pour tester, utilisez le mot de passe: closer123</p>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </CardContent>
          <CardFooter className="flex justify-center text-sm text-neutral-500 border-t border-neutral-200 bg-neutral-50">
            <p>Obesity Care Clinic - Suivi des Ventes v1.0</p>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

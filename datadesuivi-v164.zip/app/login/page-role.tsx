"use client"

import type React from "react"

import { useState } from "react"
import { useAuth, type UserRole } from "@/contexts/role-email-auth-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { Loader2, Lock } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { LanguageSwitcher } from "@/components/language-switcher"
import { useI18n } from "@/lib/i18n"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

export default function LoginPage() {
  const { isAuthenticated, login, isLoading } = useAuth()
  const router = useRouter()
  const [role, setRole] = useState<UserRole>("closer")
  const [password, setPassword] = useState("")
  const { t } = useI18n()

  useEffect(() => {
    if (isAuthenticated) {
      router.push("/dashboard")
    }
  }, [isAuthenticated, router])

  const handleLogin = async () => {
    await login(role, password)
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && password) {
      handleLogin()
    }
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-neutral-50">
      <div className="absolute top-0 left-0 w-full h-16 bg-primary-500"></div>
      <div className="absolute bottom-0 left-0 w-full h-16 bg-secondary-500"></div>

      <div className="w-full max-w-md px-4">
        <Card className="w-full shadow-lg border-t-4 border-t-primary-500">
          <CardHeader className="space-y-1">
            <div className="flex justify-between items-center">
              <div>
                <CardTitle className="text-2xl font-bold text-primary-700">Obesity Care Clinic</CardTitle>
                <CardDescription>Suivi des Ventes - Accès au système</CardDescription>
              </div>
              <LanguageSwitcher />
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col space-y-4">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-neutral-700">Rôle</Label>
                  <RadioGroup
                    value={role}
                    onValueChange={(value) => setRole(value as UserRole)}
                    className="flex space-x-4"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="admin" id="admin" />
                      <Label htmlFor="admin">Admin</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="closer" id="closer" />
                      <Label htmlFor="closer">Closer</Label>
                    </div>
                  </RadioGroup>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password" className="text-neutral-700">
                    Mot de passe
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="password"
                      type="password"
                      placeholder="Entrez votre mot de passe"
                      className="pl-10"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      onKeyDown={handleKeyDown}
                    />
                  </div>
                </div>

                <Button
                  onClick={handleLogin}
                  disabled={isLoading || !password}
                  className="w-full bg-primary-500 hover:bg-primary-600"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      {t("misc.loading")}
                    </>
                  ) : (
                    "Se connecter"
                  )}
                </Button>

                <div className="text-center text-sm text-neutral-500">
                  <p>Sélectionnez votre rôle et entrez le mot de passe</p>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-center text-sm text-neutral-500 border-t border-neutral-200 bg-neutral-50">
            <p>Obesity Care Clinic - Suivi des Ventes v1.0</p>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useRouter } from "next/navigation"
import { toast } from "@/components/ui/use-toast"
import { useAuth } from "@/contexts/auth-context"
import { useI18n } from "@/lib/i18n"
import { Loader2, Mail, Lock, Eye, EyeOff } from "lucide-react"
import Cookies from "js-cookie"

export default function LoginPage() {
  const router = useRouter()
  const { t } = useI18n()
  const { login, isAuthenticated, isLoading: authLoading } = useAuth()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)

  useEffect(() => {
    // Vérifier si l'utilisateur est déjà connecté
    const authCookie = Cookies.get("authSession")
    console.log("[LoginPage] Cookie authSession:", authCookie)

    if (authCookie || (isAuthenticated && !authLoading)) {
      console.log("[LoginPage] Redirection vers /dashboard")
      router.push("/dashboard")
    }
  }, [isAuthenticated, authLoading, router])

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!email || !password) {
      toast({
        variant: "destructive",
        title: "Champs requis",
        description: "Veuillez saisir votre email et votre mot de passe",
      })
      return
    }

    setIsLoading(true)

    try {
      const { success, message } = await login(email, password)

      if (success) {
        toast({
          title: "Connexion réussie",
          description: `Bienvenue sur la plateforme`,
        })
        console.log("[LoginPage] Connexion réussie, redirection vers /dashboard")
        router.push("/dashboard")
      } else {
        toast({
          variant: "destructive",
          title: "Erreur de connexion",
          description: message || "Email ou mot de passe incorrect",
        })
      }
    } catch (error: any) {
      console.error("[LoginPage] Erreur lors de la connexion:", error)
      toast({
        variant: "destructive",
        title: "Erreur de connexion",
        description: "Une erreur s'est produite lors de la connexion",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Afficher un indicateur de chargement pendant la vérification de l'authentification
  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-neutral-50">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-500"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      {/* Barre supérieure */}
      <div className="h-2 bg-gradient-to-r from-primary-500 to-secondary-500"></div>

      {/* Contenu principal */}
      <div className="flex-1 flex items-center justify-center p-4 bg-gradient-to-b from-neutral-50 to-neutral-100">
        <div className="w-full max-w-md">
          <Card className="border-none shadow-lg overflow-hidden">
            <div className="h-2 bg-gradient-to-r from-primary-500 to-secondary-500"></div>

            <CardHeader className="space-y-1 pb-2">
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="text-2xl font-bold bg-gradient-to-r from-primary-700 to-secondary-700 bg-clip-text text-transparent">
                    Obesity Care Clinic
                  </CardTitle>
                  <CardDescription>Suivi des Ventes - Accès au système</CardDescription>
                </div>
              </div>
            </CardHeader>

            <CardContent className="pb-3">
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-sm font-medium">
                    Adresse email
                  </Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="exemple@email.com"
                      className="pl-10"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password" className="text-sm font-medium">
                    Mot de passe
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      placeholder="••••••••"
                      className="pl-10 pr-10"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                    />
                    <button
                      type="button"
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>

                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Connexion en cours...
                    </>
                  ) : (
                    "Se connecter"
                  )}
                </Button>
              </form>
            </CardContent>

            <CardFooter className="flex justify-center border-t pt-4 pb-4 bg-neutral-50">
              <p className="text-xs text-neutral-500">Obesity Care Clinic - Suivi des Ventes v1.0</p>
            </CardFooter>
          </Card>
        </div>
      </div>

      {/* Barre inférieure */}
      <div className="h-2 bg-gradient-to-r from-secondary-500 to-primary-500"></div>
    </div>
  )
}

import type React from "react"

export default function DocsLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <div className="min-h-screen bg-neutral-50">{children}</div>
}

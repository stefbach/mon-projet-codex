"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import ReactMarkdown from "react-markdown"

export default function SetupGuidePage() {
  const [markdownContent, setMarkdownContent] = useState("")

  useEffect(() => {
    // Charger le contenu du guide de configuration
    fetch("/docs/setup-guide.md")
      .then((response) => response.text())
      .then((text) => setMarkdownContent(text))
      .catch((error) => console.error("Erreur lors du chargement du guide:", error))
  }, [])

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="mb-6">
        <Link href="/login">
          <Button variant="outline" size="sm" className="mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Retour à la connexion
          </Button>
        </Link>
        <h1 className="text-3xl font-bold text-primary-700">Guide de configuration</h1>
        <p className="text-neutral-600 mt-2">
          Suivez ces instructions pour configurer l'application Suivi Patient et la rendre entièrement fonctionnelle.
        </p>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Configuration requise</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">Pour utiliser l'application en mode fonctionnel, vous aurez besoin de :</p>
          <ul className="list-disc pl-5 space-y-2">
            <li>Un compte Firebase (gratuit)</li>
            <li>Un compte Google pour Google Sheets</li>
            <li>
              Un fichier <code className="bg-neutral-100 px-1 py-0.5 rounded">.env.local</code> avec les variables
              d'environnement
            </li>
          </ul>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="prose max-w-none p-6">
          <ReactMarkdown>{markdownContent}</ReactMarkdown>
        </CardContent>
      </Card>
    </div>
  )
}

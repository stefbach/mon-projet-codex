"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2 } from "lucide-react"

export default function TestConnection() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)

  // URLs des scripts Google Apps Script
  const userScriptUrl =
    "https://script.google.com/macros/s/AKfycbyNkJzPPY3g31garz6DnhgwHKKBA9A1JPL8xDWLtyntymYWrRVStksoB7m_gHMslv7J/exec"
  const patientScriptUrl =
    "https://script.google.com/macros/s/AKfycbxQ65P_8iJFMi8m50IaBf3NGZ6n11RYitDzWIbO_19e3KUyDlvZMXS4dIprgkZW0F-3Tg/exec"

  const testUserScript = async () => {
    setLoading(true)
    setError(null)
    try {
      // Test simple: récupérer la liste des utilisateurs
      const response = await fetch(`${userScriptUrl}?action=getUsers`)
      const text = await response.text()
      console.log("Réponse brute:", text)

      try {
        const data = JSON.parse(text)
        setResult(data)
      } catch (e) {
        setResult({ rawText: text })
      }
    } catch (err: any) {
      console.error("Erreur:", err)
      setError(err.message || "Une erreur s'est produite")
    } finally {
      setLoading(false)
    }
  }

  const testPatientScript = async () => {
    setLoading(true)
    setError(null)
    try {
      // Test simple: récupérer la liste des patients
      const response = await fetch(`${patientScriptUrl}?action=getPatients&userEmail=test@example.com&isAdmin=true`)
      const text = await response.text()
      console.log("Réponse brute:", text)

      try {
        const data = JSON.parse(text)
        setResult(data)
      } catch (e) {
        setResult({ rawText: text })
      }
    } catch (err: any) {
      console.error("Erreur:", err)
      setError(err.message || "Une erreur s'est produite")
    } finally {
      setLoading(false)
    }
  }

  const testCreateUser = async () => {
    setLoading(true)
    setError(null)
    try {
      // Test de création d'utilisateur
      const params = new URLSearchParams({
        action: "createUser",
        email: "test@example.com",
        name: "Utilisateur Test",
        role: "closer",
        password: "password123",
        active: "true",
      })

      const response = await fetch(`${userScriptUrl}?${params.toString()}`)
      const text = await response.text()
      console.log("Réponse brute:", text)

      try {
        const data = JSON.parse(text)
        setResult(data)
      } catch (e) {
        setResult({ rawText: text })
      }
    } catch (err: any) {
      console.error("Erreur:", err)
      setError(err.message || "Une erreur s'est produite")
    } finally {
      setLoading(false)
    }
  }

  const testAddPatient = async () => {
    setLoading(true)
    setError(null)
    try {
      // Test d'ajout de patient
      const params = new URLSearchParams({
        action: "addPatient",
        name: "Patient Test",
        email: "patient@example.com",
        doctor: "Dr Test",
        closer: "closer@email.com",
        status: "À faire",
        timestamp: new Date().toISOString(),
      })

      const response = await fetch(`${patientScriptUrl}?${params.toString()}`)
      const text = await response.text()
      console.log("Réponse brute:", text)

      try {
        const data = JSON.parse(text)
        setResult(data)
      } catch (e) {
        setResult({ rawText: text })
      }
    } catch (err: any) {
      console.error("Erreur:", err)
      setError(err.message || "Une erreur s'est produite")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-6">Test de connexion aux scripts Google Apps Script</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <Card>
          <CardHeader>
            <CardTitle>Script Utilisateurs</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button onClick={testUserScript} disabled={loading} className="w-full">
              {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Tester la connexion (getUsers)
            </Button>
            <Button onClick={testCreateUser} disabled={loading} className="w-full">
              {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Tester la création d'utilisateur
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Script Patients</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button onClick={testPatientScript} disabled={loading} className="w-full">
              {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Tester la connexion (getPatients)
            </Button>
            <Button onClick={testAddPatient} disabled={loading} className="w-full">
              {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Tester l'ajout de patient
            </Button>
          </CardContent>
        </Card>
      </div>

      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
          <p className="font-bold">Erreur</p>
          <p>{error}</p>
        </div>
      )}

      {result && (
        <Card>
          <CardHeader>
            <CardTitle>Résultat</CardTitle>
          </CardHeader>
          <CardContent>
            <pre className="bg-gray-100 p-4 rounded overflow-auto max-h-96">{JSON.stringify(result, null, 2)}</pre>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

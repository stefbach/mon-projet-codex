import { supabase } from "./supabase"

export async function createUser(email: string, password: string, name: string) {
  try {
    // 1. Créer l'utilisateur dans Supabase Auth
    const { data, error: signUpError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          name,
        },
      },
    })

    if (signUpError) throw signUpError

    // 2. Confirmer l'utilisateur manuellement
    await supabase.rpc("confirm_user", { email_to_confirm: email })

    // 3. Ajouter l'utilisateur à la table users si nécessaire
    if (data.user) {
      const { error: insertError } = await supabase.from("users").insert({
        id: data.user.id,
        email: email,
        name: name,
        role: "closer",
        active: true,
      })

      if (insertError) {
        console.warn("Erreur lors de l'insertion dans la table users:", insertError)
      }
    }

    return { success: true, user: data.user }
  } catch (error) {
    console.error("Erreur lors de la création de l'utilisateur:", error)
    return { success: false, error: error.message }
  }
}

export async function loginUser(email: string, password: string) {
  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (error) throw error

    return { success: true, user: data.user, session: data.session }
  } catch (error) {
    console.error("Erreur lors de la connexion:", error)
    return { success: false, error: error.message }
  }
}

export async function getCurrentUser() {
  try {
    const { data, error } = await supabase.auth.getUser()
    if (error) throw error
    return { success: true, user: data.user }
  } catch (error) {
    console.error("Erreur lors de la récupération de l'utilisateur:", error)
    return { success: false, error: error.message }
  }
}

export async function logoutUser() {
  try {
    const { error } = await supabase.auth.signOut()
    if (error) throw error
    return { success: true }
  } catch (error) {
    console.error("Erreur lors de la déconnexion:", error)
    return { success: false, error: error.message }
  }
}

import { supabase } from "./supabase"

export type UserRole = "admin" | "closer"

export async function loginWithRolePassword(role: UserRole, password: string) {
  try {
    // 1. Vérifier si le mot de passe correspond au rôle
    const { data, error } = await supabase
      .from("role_passwords")
      .select("*")
      .eq("role", role)
      .eq("password", password)
      .single()

    if (error || !data) {
      console.error("Mot de passe incorrect pour le rôle:", role)
      return { success: false, error: "Mot de passe incorrect" }
    }

    // 2. Trouver ou créer un utilisateur pour ce rôle
    const email = `${role}@example.com`
    const tempPassword = "TemporaryPassword123!"

    // Essayer de se connecter avec l'utilisateur existant
    const { data: existingUser, error: signInError } = await supabase.auth.signInWithPassword({
      email,
      password: tempPassword,
    })

    if (signInError) {
      // L'utilisateur n'existe pas, le créer
      const { data: newUser, error: createError } = await supabase.auth.signUp({
        email,
        password: tempPassword,
        options: {
          data: {
            name: role.charAt(0).toUpperCase() + role.slice(1),
            role: role,
          },
        },
      })

      if (createError) {
        console.error("Erreur lors de la création de l'utilisateur:", createError)
        return { success: false, error: createError.message }
      }

      // Confirmer l'utilisateur
      await supabase.rpc("confirm_user", { email_to_confirm: email })

      // Se connecter avec le nouvel utilisateur
      const { data: signInData, error: newSignInError } = await supabase.auth.signInWithPassword({
        email,
        password: tempPassword,
      })

      if (newSignInError) {
        console.error("Erreur lors de la connexion avec le nouvel utilisateur:", newSignInError)
        return { success: false, error: newSignInError.message }
      }

      return { success: true, user: signInData.user, role }
    }

    return { success: true, user: existingUser.user, role }
  } catch (error) {
    console.error("Erreur lors de la connexion par rôle:", error)
    return { success: false, error: error.message }
  }
}

export async function updateRolePassword(role: UserRole, password: string) {
  try {
    const { error } = await supabase
      .from("role_passwords")
      .update({ password, updated_at: new Date() })
      .eq("role", role)

    if (error) throw error

    return { success: true }
  } catch (error) {
    console.error("Erreur lors de la mise à jour du mot de passe:", error)
    return { success: false, error: error.message }
  }
}

export async function getRolePasswords() {
  try {
    const { data, error } = await supabase.from("role_passwords").select("*")

    if (error) throw error

    return { success: true, data }
  } catch (error) {
    console.error("Erreur lors de la récupération des mots de passe:", error)
    return { success: false, error: error.message }
  }
}

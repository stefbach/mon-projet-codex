import { supabase } from "./supabase"

export async function debugSupabaseTables() {
  console.log("Débogage des tables Supabase...")

  try {
    // Vérifier la structure de la table patients
    const { data: patientsColumns, error: patientsError } = await supabase.rpc("get_table_columns", {
      table_name: "patients",
    })

    if (patientsError) {
      console.error("Erreur lors de la récupération des colonnes de la table patients:", patientsError)
    } else {
      console.log("Colonnes de la table patients:", patientsColumns)
    }

    // Vérifier la structure de la table users
    const { data: usersColumns, error: usersError } = await supabase.rpc("get_table_columns", {
      table_name: "users",
    })

    if (usersError) {
      console.error("Erreur lors de la récupération des colonnes de la table users:", usersError)
    } else {
      console.log("Colonnes de la table users:", usersColumns)
    }

    // Vérifier les contraintes de clé étrangère
    const { data: foreignKeys, error: fkError } = await supabase.rpc("get_foreign_keys", {
      table_name: "patients",
    })

    if (fkError) {
      console.error("Erreur lors de la récupération des clés étrangères:", fkError)
    } else {
      console.log("Clés étrangères de la table patients:", foreignKeys)
    }

    return {
      patientsColumns,
      usersColumns,
      foreignKeys,
    }
  } catch (error) {
    console.error("Exception lors du débogage des tables:", error)
    return null
  }
}

export async function debugClosers() {
  try {
    const { data, error } = await supabase.from("users").select("id, full_name, email, role").eq("role", "closer")

    if (error) {
      console.error("Erreur lors de la récupération des closers:", error)
      return null
    }

    console.log("Closers disponibles:", data)
    return data
  } catch (error) {
    console.error("Exception lors du débogage des closers:", error)
    return null
  }
}

export async function createRpcFunctions() {
  try {
    // Créer la fonction get_table_columns
    const { error: createColumnsError } = await supabase.rpc("create_get_table_columns_function")

    if (createColumnsError) {
      console.error("Erreur lors de la création de la fonction get_table_columns:", createColumnsError)
    } else {
      console.log("Fonction get_table_columns créée avec succès")
    }

    // Créer la fonction get_foreign_keys
    const { error: createFkError } = await supabase.rpc("create_get_foreign_keys_function")

    if (createFkError) {
      console.error("Erreur lors de la création de la fonction get_foreign_keys:", createFkError)
    } else {
      console.log("Fonction get_foreign_keys créée avec succès")
    }

    return {
      success: !createColumnsError && !createFkError,
    }
  } catch (error) {
    console.error("Exception lors de la création des fonctions RPC:", error)
    return { success: false }
  }
}

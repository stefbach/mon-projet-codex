// Solution d'urgence pour corriger directement les données sans modifier le reste du code

// Fonction à insérer juste avant l'appel à supabase.from("patients").update() ou .insert()
export function fixTimestampFields(data: any): any {
  // Créer une copie pour ne pas modifier l'original
  const fixedData = { ...data }

  // Liste des champs de date à vérifier
  const dateFields = [
    "last_call_date",
    "operation_date",
    "consultation_date",
    "registration_date",
    "next_follow_up",
    "premier_email",
    "premier_whatsapp",
    "second_email",
    "second_whatsapp",
    "nhs_tier4_premier_email",
    "nhs_tier4_second_email",
  ]

  // Convertir explicitement les chaînes vides en null
  dateFields.forEach((field) => {
    if (fixedData[field] === "") {
      console.log(`Correction: ${field} converti de chaîne vide à null`)
      fixedData[field] = null
    }
  })

  return fixedData
}

// Exemple d'utilisation:
// const dataToUpdate = fixTimestampFields(originalData)
// await supabase.from("patients").update(dataToUpdate).eq("id", patientId)

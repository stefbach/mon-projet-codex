import { initializeApp, getApps, type FirebaseApp } from "firebase/app"
import { getAuth, GoogleAuthProvider, type Auth } from "firebase/auth"

// Vérifier si nous sommes en mode prévisualisation/développement
const isPreviewMode = process.env.NODE_ENV === "development" || process.env.VERCEL_ENV === "preview"

// Configuration Firebase
const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
}

// Vérifier si les clés Firebase sont définies et non vides
const isConfigValid =
  !!firebaseConfig.apiKey &&
  !!firebaseConfig.authDomain &&
  !!firebaseConfig.projectId &&
  !!firebaseConfig.storageBucket &&
  !!firebaseConfig.messagingSenderId &&
  !!firebaseConfig.appId

// Mode démo si nous sommes en prévisualisation ou si la configuration est invalide
const isDemoMode = isPreviewMode || !isConfigValid

// Initialiser Firebase seulement si la configuration est valide
let app: FirebaseApp | null = null
let auth: Auth | null = null
let googleProvider: GoogleAuthProvider | null = null

if (isConfigValid) {
  try {
    // Vérifier si Firebase est déjà initialisé
    if (!getApps().length) {
      app = initializeApp(firebaseConfig)
    } else {
      app = getApps()[0]
    }
    auth = getAuth(app)
    googleProvider = new GoogleAuthProvider()

    // Configuration supplémentaire pour Google Provider
    googleProvider.setCustomParameters({
      prompt: "select_account", // Force la sélection du compte à chaque connexion
    })
  } catch (error) {
    console.error("Erreur lors de l'initialisation de Firebase:", error)
    // En cas d'erreur, forcer le mode démo
    app = null
    auth = null
    googleProvider = null
  }
}

export { auth, googleProvider, isConfigValid, isDemoMode }
export default app

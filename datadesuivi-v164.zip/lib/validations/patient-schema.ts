import { z } from "zod"

// Améliorons le schéma de validation pour mieux gérer les dates vides

// Modifiez le préprocesseur pour les champs de date pour qu'il gère correctement les chaînes vides
const dateSchema = z.preprocess((val) => {
  // Si la valeur est une chaîne vide ou null, retourner null explicitement
  if (val === "" || val === null || val === undefined) return null
  // Sinon, essayer de convertir en date
  return val
}, z.coerce.date().nullable().optional())

// Préprocesseur pour les champs booléens - gère les chaînes "true"/"false"
const booleanSchema = z.preprocess((val) => {
  if (val === "true") return true
  if (val === "false") return false
  if (val === "Oui") return true
  if (val === "Non") return false
  return val
}, z.boolean().optional())

// Préprocesseur pour les champs numériques - convertit les chaînes vides en undefined
const numberSchema = z.preprocess((val) => (val === "" || val === null ? undefined : val), z.coerce.number().optional())

// Schéma simplifié pour la validation des patients
const patientSchema = z.object({
  // Champs obligatoires minimaux
  name: z.string().min(1, { message: "Le nom est obligatoire" }),
  email: z.string().email({ message: "Format d'email invalide" }),

  // Champs optionnels avec validation souple
  phone: z.string().optional(),
  doctor: z.string().nullable().optional(),
  registrationDate: dateSchema,
  status: z.string().optional(),

  // Champs financiers avec conversion numérique
  income: numberSchema,
  expenses: numberSchema,
  loanAmount: numberSchema,

  // Champs de date avec conversion
  consultationDate: dateSchema,
  operationDate: dateSchema,
  lastCallDate: dateSchema,
  nextFollowUp: dateSchema,

  // Champs booléens
  appointmentScheduled: booleanSchema,
  simulationValidated: z.union([booleanSchema, z.enum(["Oui", "Non"]).optional()]),
  loanRequested: z.union([booleanSchema, z.enum(["Oui", "Non"]).optional()]),
  validated: booleanSchema,

  // Champs texte
  platform: z.string().optional(),
  notes: z.string().optional(),
  // Suppression du champ "commentaires"
  creditScore: z.string().optional(),
  creditPlatform: z.string().optional(),

  // Champs spécifiques au patient
  suiteGroupe: z.string().nullable().optional(),
  poids: numberSchema,
  taille: numberSchema,
  bmi: numberSchema,
  qualification: z.string().nullable().optional(),
  rdvObtenuPar: z.string().nullable().optional(),
  closer: z.string().optional(),
  closerId: z.string().optional(),
  callCount: numberSchema,

  // Champs timestamp
  premierEmail: dateSchema,
  premierWhatsapp: dateSchema,
  secondEmail: dateSchema,
  secondWhatsapp: dateSchema,
  nhsTier4PremierEmail: dateSchema,
  nhsTier4SecondEmail: dateSchema,

  // Champs booléens avec support Oui/Non
  factureEnvoye: z.union([booleanSchema, z.enum(["Oui", "Non"]).optional()]),
  medicalAgrement: z.union([booleanSchema, z.enum(["Oui", "Non"]).optional()]),
  consentForm: z.union([booleanSchema, z.enum(["Oui", "Non"]).optional()]),
  autorisationPatientS2: z.union([booleanSchema, z.enum(["Oui", "Non"]).optional()]),
  compteRenduHospitalisation: z.union([booleanSchema, z.enum(["Oui", "Non"]).optional()]),
  compteRenduConsultation: z.union([booleanSchema, z.enum(["Oui", "Non"]).optional()]),
  emailPatientGp: z.union([booleanSchema, z.enum(["Oui", "Non"]).optional()]),
  patientS2Form: z.union([booleanSchema, z.enum(["Oui", "Non"]).optional()]),
  lettreGp: z.union([booleanSchema, z.enum(["Oui", "Non"]).optional()]),
  s2SaintJames: z.union([booleanSchema, z.enum(["Oui", "Non"]).optional()]),
})

// Type pour les données du formulaire patient
export type PatientFormData = z.infer<typeof patientSchema>

// Fonction pour valider les données du patient
export function validatePatientData(data: any) {
  try {
    const result = patientSchema.safeParse(data)
    if (result.success) {
      return { success: true, errors: null, data: result.data }
    } else {
      const formattedErrors = result.error.errors.reduce(
        (acc, curr) => {
          const path = curr.path.join(".")
          acc[path] = curr.message
          return acc
        },
        {} as Record<string, string>,
      )
      return { success: false, errors: formattedErrors, data: null }
    }
  } catch (error) {
    return {
      success: false,
      errors: { form: "Une erreur est survenue lors de la validation" },
      data: null,
    }
  }
}

// Assurez-vous que la fonction cleanPatientDataForSupabase traite correctement les dates vides
// Ajoutez ou modifiez cette section dans la fonction

// Fonction pour nettoyer les données avant envoi à Supabase
export function cleanPatientDataForSupabase(data: any) {
  const cleanedData = { ...data }

  // Liste des champs de date à vérifier
  const dateFields = [
    "consultationDate",
    "operationDate",
    "lastCallDate",
    "nextFollowUp",
    "premierEmail",
    "premierWhatsapp",
    "secondEmail",
    "secondWhatsapp",
    "nhsTier4PremierEmail",
    "nhsTier4SecondEmail",
    "registrationDate",
  ]

  // Convertir explicitement les chaînes vides en null pour tous les champs de date
  dateFields.forEach((field) => {
    if (cleanedData[field] === "" || cleanedData[field] === undefined) {
      cleanedData[field] = null
    }
  })

  // IMPORTANT: Préserver explicitement les champs des menus déroulants
  const dropdownFields = ["doctor", "suiteGroupe", "qualification", "rdvObtenuPar"]

  // Convertir les chaînes vides en null SAUF pour les champs des menus déroulants
  Object.keys(cleanedData).forEach((key) => {
    if (cleanedData[key] === "" && !dropdownFields.includes(key)) {
      cleanedData[key] = null
    }
  })

  // S'assurer que les champs des menus déroulants ne sont jamais null ou undefined
  dropdownFields.forEach((field) => {
    // Si le champ est null ou undefined, le définir comme chaîne vide
    if (cleanedData[field] === null || cleanedData[field] === undefined) {
      cleanedData[field] = ""
    }
  })

  // Convertir les valeurs "Oui"/"Non" en booléens
  const booleanFields = [
    "factureEnvoye",
    "medicalAgrement",
    "consentForm",
    "autorisationPatientS2",
    "compteRenduHospitalisation",
    "compteRenduConsultation",
    "emailPatientGp",
    "patientS2Form",
    "lettreGp",
    "s2SaintJames",
    "simulationValidated",
    "loanRequested",
    "appointmentScheduled",
    "validated",
  ]

  booleanFields.forEach((field) => {
    if (cleanedData[field] === "Oui" || cleanedData[field] === "true") {
      cleanedData[field] = true
    } else if (cleanedData[field] === "Non" || cleanedData[field] === "false") {
      cleanedData[field] = false
    }
  })

  // Log des champs critiques après nettoyage
  console.log("APRÈS NETTOYAGE - Champs critiques:")
  console.log("Doctor:", cleanedData.doctor)
  console.log("Suite/Groupe:", cleanedData.suiteGroupe)
  console.log("Qualification:", cleanedData.qualification)
  console.log("RDV Obtenu Par:", cleanedData.rdvObtenuPar)

  return cleanedData
}

export const statusEnum = z.enum([
  "a_rappeler",
  "valide",
  "annule",
  "refuse",
  "non_interesse",
  "en_attente",
  "vente",
  "a_contacter",
  "a_recontacter",
  "en_attente_paiement",
  "rdv_programme",
  "non_defini",
])

// Export du schéma par défaut
export default patientSchema

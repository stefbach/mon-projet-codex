import { supabase } from "./supabase"

/**
 * Utility function to check if a column exists in a table
 */
export async function checkColumnExists(tableName: string, columnName: string) {
  try {
    const { data, error } = await supabase.rpc("check_column_exists", {
      table_name: tableName,
      column_name: columnName,
    })

    if (error) {
      console.error(`Error checking if column ${columnName} exists in ${tableName}:`, error)
      return { exists: false, error: error.message }
    }

    return { exists: data, error: null }
  } catch (error: any) {
    console.error(`Exception checking if column ${columnName} exists in ${tableName}:`, error)
    return { exists: false, error: error.message }
  }
}

/**
 * Utility function to add a column to a table if it doesn't exist
 */
export async function ensureColumnExists(tableName: string, columnName: string, columnDefinition: string) {
  try {
    // First check if the column already exists
    const { exists, error: checkError } = await checkColumnExists(tableName, columnName)

    if (checkError) {
      return { success: false, error: checkError }
    }

    // If the column already exists, return success
    if (exists) {
      return { success: true, message: `Column ${columnName} already exists in ${tableName}` }
    }

    // Add the column if it doesn't exist
    const { error } = await supabase.rpc("exec_sql", {
      sql_query: `ALTER TABLE ${tableName} ADD COLUMN ${columnName} ${columnDefinition};`,
    })

    if (error) {
      console.error(`Error adding column ${columnName} to ${tableName}:`, error)
      return { success: false, error: error.message }
    }

    return { success: true, message: `Column ${columnName} added to ${tableName}` }
  } catch (error: any) {
    console.error(`Exception ensuring column ${columnName} exists in ${tableName}:`, error)
    return { success: false, error: error.message }
  }
}

/**
 * Utility function to ensure the updated_at column exists and has the correct trigger
 */
export async function ensureUpdatedAtColumn(tableName: string) {
  try {
    // First ensure the column exists
    const columnResult = await ensureColumnExists(tableName, "updated_at", "TIMESTAMP WITH TIME ZONE DEFAULT NOW()")

    if (!columnResult.success) {
      return columnResult
    }

    // Then ensure the trigger exists to automatically update it
    const { error } = await supabase.rpc("exec_sql", {
      sql_query: `
        -- Create the function if it doesn't exist
        CREATE OR REPLACE FUNCTION update_modified_column()
        RETURNS TRIGGER AS $$
        BEGIN
            NEW.updated_at = NOW();
            RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;
        
        -- Drop the trigger if it exists
        DROP TRIGGER IF EXISTS set_${tableName}_updated_at ON ${tableName};
        
        -- Create the trigger
        CREATE TRIGGER set_${tableName}_updated_at
        BEFORE UPDATE ON ${tableName}
        FOR EACH ROW
        EXECUTE FUNCTION update_modified_column();
      `,
    })

    if (error) {
      console.error(`Error creating updated_at trigger for ${tableName}:`, error)
      return { success: false, error: error.message }
    }

    return {
      success: true,
      message: `Column updated_at and automatic update trigger added to ${tableName}`,
    }
  } catch (error: any) {
    console.error(`Exception ensuring updated_at column in ${tableName}:`, error)
    return { success: false, error: error.message }
  }
}

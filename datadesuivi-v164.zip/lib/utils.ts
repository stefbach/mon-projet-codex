import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
import { format, parseISO } from "date-fns"
import { fr } from "date-fns/locale"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export const formatDate = (dateString: string | null | undefined): string => {
  if (!dateString) return "-"
  try {
    const date = parseISO(dateString)
    return format(date, "dd MMMM yyyy", { locale: fr })
  } catch (e) {
    return dateString
  }
}

export const formatPhoneNumber = (phoneNumber: string | null | undefined): string => {
  if (!phoneNumber) return ""
  return formatPhoneNumberE164(phoneNumber)
}

// Fonction pour formater un numéro de téléphone au format E.164
const formatPhoneNumberE164 = (phoneNumber: string | null | undefined): string => {
  if (!phoneNumber) return ""

  // Supprimer tous les caractères non numériques sauf le +
  const cleaned = phoneNumber.replace(/[^\d+]/g, "")

  // Si le numéro ne commence pas par +, ajouter +
  if (!cleaned.startsWith("+")) {
    // Supposer que c'est un numéro français si pas de code pays
    return `+33${cleaned.startsWith("0") ? cleaned.substring(1) : cleaned}`
  }

  return cleaned
}

import { createClient } from "@supabase/supabase-js"

// Use environment variables
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || ""
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ""

// Create the Supabase client with schema cache options
export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  db: {
    schema: "public",
  },
  // Set a shorter cache time to ensure schema updates are detected more quickly
  global: {
    headers: { "X-Client-Info": "supabase-js-v2" },
  },
})

// Function to check if Supabase is available
export async function checkSupabaseConnection() {
  try {
    const { data, error } = await supabase.from("patients").select("count").limit(1)
    return { connected: !error, error: error?.message }
  } catch (error: any) {
    return { connected: false, error: error?.message || "Erreur inconnue" }
  }
}

// Function to get the list of tables
export async function getSupabaseTables() {
  try {
    const { data, error } = await supabase.rpc("get_tables")
    if (error) throw error
    return data
  } catch (error: any) {
    console.error("Erreur lors de la récupération des tables:", error)
    return []
  }
}

// Function to get the application mode (demo or production)
export function getAppMode() {
  const isDemoMode =
    process.env.NODE_ENV === "development" ||
    process.env.NEXT_PUBLIC_DEMO_MODE === "true" ||
    process.env.NEXT_PUBLIC_FORCE_DEMO === "true"

  return {
    isDemoMode,
    isSupabaseConfigured: !!supabaseUrl && !!supabaseAnonKey,
  }
}

// Function to check if Supabase is available
export function isSupabaseAvailable() {
  return !!supabase && !!supabaseUrl && !!supabaseAnonKey
}

// Function to create the uuid-ossp extension
export async function createUuidExtension() {
  try {
    const { error } = await supabase.rpc("create_uuid_extension")
    return { success: !error, error: error?.message }
  } catch (error: any) {
    return { success: false, error: error?.message || "Erreur inconnue" }
  }
}

// Function to refresh the schema cache
export async function refreshSchemaCache() {
  try {
    console.log("Refreshing Supabase schema cache...")

    // First, check the current schema by making a simple query
    const { error: checkError } = await supabase.from("patients").select("id").limit(1)

    if (checkError) {
      console.warn("Error checking schema before refresh:", checkError.message)
    }

    // Force a schema refresh by creating a new client instance with unique timestamp
    const timestamp = new Date().getTime()
    let refreshClient

    try {
      refreshClient = createClient(supabaseUrl, supabaseAnonKey, {
        db: {
          schema: "public",
        },
        global: {
          headers: {
            "X-Client-Info": `supabase-js-v2-${timestamp}`,
            "Cache-Control": "no-cache, no-store, must-revalidate",
            Pragma: "no-cache",
            Expires: "0",
          },
        },
      })
    } catch (clientError) {
      console.error("Error creating refresh client:", clientError)
      return { success: false, error: "Erreur lors de la création du client Supabase" }
    }

    // Test the new client with a simple query
    try {
      const { error: refreshError } = await refreshClient.from("patients").select("id").limit(1)

      if (refreshError) {
        console.error("Error after schema refresh:", refreshError.message)
        return { success: false, error: refreshError.message }
      }

      // Replace the global client with the refreshed one
      Object.assign(supabase, refreshClient)

      console.log("Schema cache refreshed successfully")
      return { success: true }
    } catch (queryError) {
      console.error("Error testing refreshed client:", queryError)
      return { success: false, error: "Erreur lors du test du client rafraîchi" }
    }
  } catch (error: any) {
    console.error("Error refreshing schema cache:", error)
    return { success: false, error: error.message || "Unknown error" }
  }
}

// Function to verify the relationship between patients and users
export async function verifyPatientUserRelationship() {
  try {
    console.log("Verifying patient-user relationship...")

    // Test a join query to see if the relationship works
    const { data, error } = await supabase
      .from("patients")
      .select(`
        id,
        full_name,
        closer:closer_id (id, full_name)
      `)
      .limit(1)

    if (error) {
      console.error("Relationship verification failed:", error.message)
      return {
        success: false,
        error: error.message,
        needsRefresh: error.message.includes("missing") || error.message.includes("does not exist"),
      }
    }

    console.log("Relationship verification successful:", data)
    return { success: true, data }
  } catch (error: any) {
    console.error("Error verifying relationship:", error)
    return {
      success: false,
      error: error.message || "Unknown error",
      needsRefresh: true,
    }
  }
}

// Fonction pour réparer la relation entre patients et users
export async function fixPatientUserRelationship() {
  try {
    console.log("Tentative de réparation de la relation patients-users...")

    // Exécuter le script SQL pour réparer la relation
    const { error } = await supabase.rpc("exec_sql", {
      sql_query: `
        -- Vérifier si la contrainte existe et la supprimer si c'est le cas
        DO $$
        BEGIN
          IF EXISTS (
            SELECT 1 FROM information_schema.table_constraints 
            WHERE constraint_name = 'patients_closer_id_fkey' 
            AND table_name = 'patients'
          ) THEN
            ALTER TABLE patients DROP CONSTRAINT patients_closer_id_fkey;
          END IF;
          
          -- Recréer la contrainte
          ALTER TABLE patients ADD CONSTRAINT patients_closer_id_fkey 
          FOREIGN KEY (closer_id) REFERENCES auth.users(id) ON DELETE SET NULL;
          
        EXCEPTION WHEN OTHERS THEN
          RAISE NOTICE 'Erreur lors de la réparation de la relation: %', SQLERRM;
        END $$;
      `,
    })

    if (error) {
      console.error("Erreur lors de la réparation de la relation:", error)
      return { success: false, error: error.message }
    }

    // Rafraîchir le cache après la réparation
    await refreshSchemaCache()

    // Vérifier si la réparation a fonctionné
    const result = await verifyPatientUserRelationship()

    return result
  } catch (error: any) {
    console.error("Exception lors de la réparation de la relation:", error)
    return { success: false, error: error.message || "Erreur inconnue" }
  }
}

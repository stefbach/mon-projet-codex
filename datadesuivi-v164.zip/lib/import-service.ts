import * as XLSX from "xlsx"
import { supabase } from "./supabase"
import { standardizeDoctorName } from "./patient-service"
import { PATIENT_FIELDS } from "./constants"

// Parse Excel or CSV file
export async function parseFile(file: File): Promise<{ data: any[]; headers: string[] }> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()

    reader.onload = (e) => {
      try {
        const data = e.target?.result
        const workbook = XLSX.read(data, { type: "binary" })
        const sheetName = workbook.SheetNames[0]
        const worksheet = workbook.Sheets[sheetName]

        // Convert to JSON
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 })

        if (jsonData.length < 2) {
          throw new Error("Le fichier ne contient pas assez de données")
        }

        // Extract headers (first row)
        const headers = jsonData[0] as string[]

        // Extract data (remaining rows)
        const rows = jsonData.slice(1).map((row) => {
          const obj: Record<string, any> = {}
          headers.forEach((header, index) => {
            obj[header] = (row as any[])[index]
          })
          return obj
        })

        resolve({ data: rows, headers })
      } catch (error) {
        reject(new Error(`Erreur lors de la lecture du fichier: ${error.message}`))
      }
    }

    reader.onerror = () => {
      reject(new Error("Erreur lors de la lecture du fichier"))
    }

    reader.readAsBinaryString(file)
  })
}

// Normalize data based on mapping
export async function normalizeData(data: any[], mapping: Record<string, string>): Promise<any[]> {
  // Get closers for mapping
  const { data: closers, error: closersError } = await supabase
    .from("users")
    .select("id, full_name, email")
    .eq("role", "closer")

  if (closersError) {
    console.error("Error fetching closers:", closersError)
  }

  const closerMap = new Map()
  if (closers) {
    closers.forEach((closer) => {
      closerMap.set(closer.full_name.toLowerCase(), closer.id)
      closerMap.set(closer.email.toLowerCase(), closer.id)
    })
  }

  return data.map((row) => {
    const normalizedRow: Record<string, any> = {}

    // Process each field based on mapping
    Object.entries(mapping).forEach(([sourceField, targetField]) => {
      if (!targetField) return // Skip unmapped fields

      let value = row[sourceField]

      // Skip undefined or null values
      if (value === undefined || value === null) return

      // Convert to string and trim
      if (typeof value === "string") {
        value = value.trim()
      } else {
        value = String(value).trim()
      }

      // Skip empty values
      if (value === "") return

      // Normalize based on field type
      switch (targetField) {
        case "full_name":
          // Capitalize each word
          normalizedRow[targetField] = value
            .split(" ")
            .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
            .join(" ")
          break

        case "email":
          // Convert to lowercase
          normalizedRow[targetField] = value.toLowerCase()
          break

        case "phone":
          // Format phone number
          normalizedRow[targetField] = formatPhoneNumber(value)
          break

        case "status":
          // Normalize status
          normalizedRow[targetField] = normalizeStatus(value)
          break

        case "doctor":
          // Standardize doctor name
          normalizedRow[targetField] = standardizeDoctorName(value)
          break

        case "closer":
          // Try to find closer ID
          const closerKey = value.toLowerCase()
          if (closerMap.has(closerKey)) {
            normalizedRow["closer_id"] = closerMap.get(closerKey)
          } else {
            // Store the name if ID not found
            normalizedRow["closer_name"] = value
          }
          break

        case "consultation_date":
        case "operation_date":
        case "registration_date":
        case "last_call_date":
        case "next_follow_up":
          // Parse date
          try {
            const date = parseDate(value)
            normalizedRow[targetField] = date ? date.toISOString() : null
          } catch (e) {
            normalizedRow[targetField] = null
          }
          break

        case "appointment_scheduled":
        case "loan_simulation_validated":
        case "loan_requested":
          // Convert to boolean
          normalizedRow[targetField] = normalizeBoolean(value)
          break

        case "revenue":
        case "expenses":
        case "loan_amount":
        case "poids":
        case "taille":
        case "bmi":
          // Convert to number
          normalizedRow[targetField] = Number.parseFloat(value) || 0
          break

        default:
          // Default handling
          normalizedRow[targetField] = value
      }
    })

    return normalizedRow
  })
}

// Insert patients into Supabase
export async function insertPatients(patients: any[]): Promise<{
  success: number
  failed: number
  errors: { row: number; message: string }[]
}> {
  let successCount = 0
  let failedCount = 0
  const errors: { row: number; message: string }[] = []

  // Get current user for tracking
  const {
    data: { user },
  } = await supabase.auth.getUser()

  // Add metadata to each patient
  const patientsWithMetadata = patients.map((patient) => ({
    ...patient,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    created_by_admin: user?.id || null,
  }))

  // Insert patients
  const { data, error } = await supabase.from("patients").insert(patientsWithMetadata).select()

  if (error) {
    // If batch insert fails, try individual inserts
    console.error("Batch insert failed, trying individual inserts:", error)

    for (let i = 0; i < patientsWithMetadata.length; i++) {
      const patient = patientsWithMetadata[i]
      const { error: individualError } = await supabase.from("patients").insert(patient)

      if (individualError) {
        failedCount++
        errors.push({
          row: i + 1,
          message: individualError.message || "Erreur inconnue",
        })
      } else {
        successCount++
      }
    }
  } else {
    successCount = data?.length || 0
    failedCount = patientsWithMetadata.length - successCount
  }

  return { success: successCount, failed: failedCount, errors }
}

// Generate template file
export async function generateTemplateFile(): Promise<Blob> {
  // Create template data
  const headers = PATIENT_FIELDS.map((field) => field.label)
  const exampleRow1 = [
    "Jean Dupont",
    "jean.dupont@example.com",
    "0612345678",
    "en_attente",
    "Dr Martin",
    "Commercial 1",
    "Patient intéressé par la chirurgie",
    "2023-05-15",
    "2023-06-20",
    "Oui",
    "1500",
    "800",
    "Excellent",
    "Boursorama",
    "15000",
    "Oui",
    "Non",
    "2023-05-20",
  ]
  const exampleRow2 = [
    "Marie Durand",
    "marie.durand@example.com",
    "0687654321",
    "rdv_programme",
    "Dr Bernard",
    "Commercial 2",
    "A besoin d'informations supplémentaires",
    "2023-05-18",
    "",
    "Non",
    "2000",
    "1200",
    "Bon",
    "BNP",
    "12000",
    "Non",
    "Non",
    "2023-05-25",
  ]

  // Create worksheet
  const ws = XLSX.utils.aoa_to_sheet([headers, exampleRow1, exampleRow2])

  // Create workbook
  const wb = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(wb, ws, "Patients")

  // Generate file
  const wbout = XLSX.write(wb, { bookType: "xlsx", type: "array" })
  return new Blob([wbout], { type: "application/octet-stream" })
}

// Helper functions
function formatPhoneNumber(phone: string): string {
  // Remove all non-digit characters
  const digits = phone.replace(/\D/g, "")

  // Format for French numbers
  if (digits.length === 10 && digits.startsWith("0")) {
    return digits.replace(/(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})/, "$1 $2 $3 $4 $5")
  }

  // International format
  if (digits.length > 10) {
    return "+" + digits.replace(/^0+/, "")
  }

  return digits
}

function normalizeStatus(status: string): string {
  const statusMap: Record<string, string> = {
    "en attente": "en_attente",
    attente: "en_attente",
    "à contacter": "a_contacter",
    "a contacter": "a_contacter",
    "rdv programmé": "rdv_programme",
    "rdv programme": "rdv_programme",
    "rendez-vous programmé": "rdv_programme",
    "rendez-vous": "rdv_programme",
    consultation: "rdv_programme",
    vente: "vente",
    vendu: "vente",
    opéré: "vente",
    opéré: "vente",
    opération: "vente",
    operation: "vente",
    perdu: "perdu",
    abandonné: "perdu",
    abandonne: "perdu",
    refusé: "perdu",
    refus: "perdu",
  }

  const normalized = status.toLowerCase().trim()
  return statusMap[normalized] || normalized
}

function normalizeBoolean(value: string | boolean): boolean {
  if (typeof value === "boolean") return value

  const trueValues = ["oui", "yes", "true", "1", "vrai", "y", "o"]
  return trueValues.includes(value.toLowerCase().trim())
}

function parseDate(dateStr: string): Date | null {
  if (!dateStr) return null

  // Try different date formats
  const formats = [
    // ISO format
    /^(\d{4})-(\d{2})-(\d{2})(?:T.*)?$/,
    // DD/MM/YYYY
    /^(\d{2})\/(\d{2})\/(\d{4})$/,
    // DD-MM-YYYY
    /^(\d{2})-(\d{2})-(\d{4})$/,
    // DD.MM.YYYY
    /^(\d{2})\.(\d{2})\.(\d{4})$/,
  ]

  for (const format of formats) {
    const match = dateStr.match(format)
    if (match) {
      if (format === formats[0]) {
        // ISO format: YYYY-MM-DD
        const [_, year, month, day] = match
        return new Date(Number.parseInt(year), Number.parseInt(month) - 1, Number.parseInt(day))
      } else {
        // Other formats: DD/MM/YYYY, DD-MM-YYYY, DD.MM.YYYY
        const [_, day, month, year] = match
        return new Date(Number.parseInt(year), Number.parseInt(month) - 1, Number.parseInt(day))
      }
    }
  }

  // Try direct parsing
  const date = new Date(dateStr)
  return isNaN(date.getTime()) ? null : date
}

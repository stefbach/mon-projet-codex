import { supabase } from "./supabase"

/**
 * Fonction pour diagnostiquer et réparer les problèmes de schéma
 */
export async function diagnoseAndRepairSchema() {
  try {
    console.log("Démarrage du diagnostic et de la réparation du schéma...")

    // 1. Vérifier si la relation patients-closer fonctionne
    const relationStatus = await checkPatientCloserRelation()
    console.log("Statut de la relation patients-closer:", relationStatus)

    // 2. Si la relation ne fonctionne pas, exécuter le script de réparation
    if (!relationStatus.success) {
      console.log("Tentative de réparation des relations...")
      const repairResult = await repairSchemaRelations()
      console.log("Résultat de la réparation:", repairResult)

      // 3. Rafraîchir le cache du schéma
      const refreshResult = await refreshSchemaCache()
      console.log("Résultat du rafraîchissement du cache:", refreshResult)

      // 4. Vérifier à nouveau la relation
      const newRelationStatus = await checkPatientCloserRelation()
      console.log("Nouveau statut de la relation:", newRelationStatus)

      return {
        initialStatus: relationStatus,
        repairResult,
        refreshResult,
        finalStatus: newRelationStatus,
        success: newRelationStatus.success,
      }
    }

    return {
      initialStatus: relationStatus,
      success: true,
      message: "Les relations fonctionnent correctement, aucune réparation nécessaire.",
    }
  } catch (error: any) {
    console.error("Erreur lors du diagnostic et de la réparation:", error)
    return {
      success: false,
      error: error.message || "Erreur inconnue",
    }
  }
}

/**
 * Vérifier si la relation entre patients et closer fonctionne
 */
async function checkPatientCloserRelation() {
  try {
    // Essayer une requête simple qui utilise la relation
    const { data, error } = await supabase
      .from("patients")
      .select(`
        id,
        full_name,
        closer:closer_id (id, full_name)
      `)
      .limit(1)

    if (error) {
      return {
        success: false,
        error: error.message,
        needsRepair: true,
      }
    }

    return {
      success: true,
      data,
    }
  } catch (error: any) {
    return {
      success: false,
      error: error.message || "Erreur inconnue",
      needsRepair: true,
    }
  }
}

/**
 * Réparer les relations du schéma
 */
async function repairSchemaRelations() {
  try {
    // Lire le contenu du script SQL
    const sqlScript = `
    -- Script complet pour réparer les relations entre tables dans Supabase

    -- 1. Vérifier et corriger la relation entre patients et users
    DO $$
    DECLARE
        constraint_exists BOOLEAN;
    BEGIN
        -- Vérifier si la contrainte existe déjà
        SELECT EXISTS (
            SELECT 1 FROM information_schema.table_constraints 
            WHERE constraint_name = 'patients_closer_id_fkey' 
            AND table_name = 'patients'
        ) INTO constraint_exists;

        -- Si la contrainte existe, la supprimer d'abord
        IF constraint_exists THEN
            EXECUTE 'ALTER TABLE patients DROP CONSTRAINT patients_closer_id_fkey';
            RAISE NOTICE 'Contrainte patients_closer_id_fkey supprimée';
        END IF;

        -- Vérifier si la colonne closer_id existe dans la table patients
        IF EXISTS (
            SELECT 1 FROM information_schema.columns 
            WHERE table_name = 'patients' AND column_name = 'closer_id'
        ) THEN
            -- Essayer d'abord avec auth.users
            BEGIN
                EXECUTE 'ALTER TABLE patients ADD CONSTRAINT patients_closer_id_fkey 
                        FOREIGN KEY (closer_id) REFERENCES auth.users(id) ON DELETE SET NULL';
                RAISE NOTICE 'Contrainte patients_closer_id_fkey créée avec auth.users';
            EXCEPTION WHEN OTHERS THEN
                RAISE NOTICE 'Erreur lors de la création de la contrainte avec auth.users: %', SQLERRM;
                
                -- Essayer ensuite avec la table users
                BEGIN
                    EXECUTE 'ALTER TABLE patients ADD CONSTRAINT patients_closer_id_fkey 
                            FOREIGN KEY (closer_id) REFERENCES users(id) ON DELETE SET NULL';
                    RAISE NOTICE 'Contrainte patients_closer_id_fkey créée avec users';
                EXCEPTION WHEN OTHERS THEN
                    RAISE NOTICE 'Erreur lors de la création de la contrainte avec users: %', SQLERRM;
                END;
            END;
        ELSE
            RAISE NOTICE 'La colonne closer_id n''existe pas dans la table patients';
        END IF;
    END $$;

    -- 2. Vérifier et corriger les autres relations potentiellement problématiques
    DO $$
    BEGIN
        -- Vérifier et corriger la relation created_by_admin
        IF EXISTS (
            SELECT 1 FROM information_schema.columns 
            WHERE table_name = 'patients' AND column_name = 'created_by_admin'
        ) THEN
            -- Supprimer la contrainte si elle existe
            IF EXISTS (
                SELECT 1 FROM information_schema.table_constraints 
                WHERE constraint_name = 'patients_created_by_admin_fkey' 
                AND table_name = 'patients'
            ) THEN
                EXECUTE 'ALTER TABLE patients DROP CONSTRAINT patients_created_by_admin_fkey';
            END IF;
            
            -- Essayer de créer la contrainte
            BEGIN
                EXECUTE 'ALTER TABLE patients ADD CONSTRAINT patients_created_by_admin_fkey 
                        FOREIGN KEY (created_by_admin) REFERENCES users(id) ON DELETE SET NULL';
            EXCEPTION WHEN OTHERS THEN
                RAISE NOTICE 'Erreur lors de la création de la contrainte created_by_admin: %', SQLERRM;
            END;
        END IF;

        -- Vérifier et corriger la relation validated_by_admin
        IF EXISTS (
            SELECT 1 FROM information_schema.columns 
            WHERE table_name = 'patients' AND column_name = 'validated_by_admin'
        ) THEN
            -- Supprimer la contrainte si elle existe
            IF EXISTS (
                SELECT 1 FROM information_schema.table_constraints 
                WHERE constraint_name = 'patients_validated_by_admin_fkey' 
                AND table_name = 'patients'
            ) THEN
                EXECUTE 'ALTER TABLE patients DROP CONSTRAINT patients_validated_by_admin_fkey';
            END IF;
            
            -- Essayer de créer la contrainte
            BEGIN
                EXECUTE 'ALTER TABLE patients ADD CONSTRAINT patients_validated_by_admin_fkey 
                        FOREIGN KEY (validated_by_admin) REFERENCES users(id) ON DELETE SET NULL';
            EXCEPTION WHEN OTHERS THEN
                RAISE NOTICE 'Erreur lors de la création de la contrainte validated_by_admin: %', SQLERRM;
            END;
        END IF;
    END $$;
    `

    // Exécuter le script SQL via la fonction RPC exec_sql
    const { error } = await supabase.rpc("exec_sql", { sql_query: sqlScript })

    if (error) {
      return {
        success: false,
        error: error.message,
      }
    }

    return {
      success: true,
      message: "Script de réparation exécuté avec succès",
    }
  } catch (error: any) {
    return {
      success: false,
      error: error.message || "Erreur inconnue",
    }
  }
}

/**
 * Rafraîchir le cache du schéma
 */
async function refreshSchemaCache() {
  try {
    // Créer un nouveau client avec un timestamp unique pour forcer le rafraîchissement du cache
    const timestamp = new Date().getTime()

    // Exécuter une requête simple pour forcer le rafraîchissement
    const { error } = await supabase
      .from("patients")
      .select("id")
      .limit(1)
      .headers({
        "X-Client-Info": `supabase-js-v2-${timestamp}`,
        "Cache-Control": "no-cache, no-store, must-revalidate",
        Pragma: "no-cache",
        Expires: "0",
      })

    if (error) {
      return {
        success: false,
        error: error.message,
      }
    }

    return {
      success: true,
      message: "Cache du schéma rafraîchi avec succès",
    }
  } catch (error: any) {
    return {
      success: false,
      error: error.message || "Erreur inconnue",
    }
  }
}

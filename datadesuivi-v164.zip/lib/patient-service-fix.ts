import { supabase } from "./supabase"
import { cleanPatientDataForSupabase } from "./validations/patient-schema"

// Fonction corrigée pour vérifier l'existence d'une colonne sans utiliser public.information_schema
async function columnExists(table: string, column: string): Promise<boolean> {
  try {
    // Utiliser une requête SQL brute pour accéder correctement à information_schema.columns
    const { data, error } = await supabase.rpc("check_column_exists_fixed", {
      p_table_name: table,
      p_column_name: column,
    })

    if (error) {
      console.error("Erreur lors de la vérification de l'existence de la colonne:", error)
      return false
    }

    return data || false
  } catch (error) {
    console.error("Exception lors de la vérification de l'existence de la colonne:", error)
    return false
  }
}

// Le reste du fichier reste inchangé...
// Assurons-nous que le service de patient fixé gère également correctement les dates vides

// Ajoutez ou modifiez cette fonction utilitaire pour traiter les dates vides
export function sanitizeDateFields(data: any): any {
  const sanitizedData = { ...data }

  // Liste des champs de date à vérifier
  const dateFields = [
    "consultationDate",
    "operationDate",
    "lastCallDate",
    "nextFollowUp",
    "premierEmail",
    "premierWhatsapp",
    "secondEmail",
    "secondWhatsapp",
    "nhsTier4PremierEmail",
    "nhsTier4SecondEmail",
    "registrationDate",
  ]

  // Convertir explicitement les chaînes vides en null pour tous les champs de date
  dateFields.forEach((field) => {
    if (field in sanitizedData && (sanitizedData[field] === "" || sanitizedData[field] === undefined)) {
      sanitizedData[field] = null
    }
  })

  return sanitizedData
}

// Fonction pour créer un patient avec une gestion améliorée des erreurs
export async function createPatientFixed(patientData: any, shouldValidate = false, user: any) {
  try {
    // Log des données reçues
    console.log("CRÉATION PATIENT - Données reçues:")
    console.log("Doctor:", patientData.doctor)
    console.log("Suite/Groupe:", patientData.suiteGroupe)
    console.log("Qualification:", patientData.qualification)
    console.log("RDV Obtenu Par:", patientData.rdvObtenuPar)

    // Nettoyer les données avant de les envoyer à Supabase
    let cleanedData = cleanPatientDataForSupabase(patientData)

    // Sanitiser spécifiquement les champs de date
    cleanedData = sanitizeDateFields(cleanedData)

    // Préparer les données pour Supabase (conversion des noms de champs camelCase en snake_case)
    const dataToInsert: any = {
      full_name: cleanedData.name, // Utilisation correcte de full_name pour le nom du patient
      email: cleanedData.email,
      phone: cleanedData.phone,
      doctor: patientData.doctor !== undefined ? patientData.doctor : null,
      status: cleanedData.status || "a_rappeler",
      notes: cleanedData.notes,
      // Suppression du champ commentaires
      registration_date: cleanedData.registrationDate,
      consultation_date: cleanedData.consultationDate,

      // Champs financiers
      revenue: cleanedData.income,
      expenses: cleanedData.expenses,
      loan_amount: cleanedData.loanAmount,
      credit_score: cleanedData.creditScore,
      credit_score_platform: cleanedData.creditPlatform,
      loan_platform: cleanedData.platform,
      loan_simulation_validated: cleanedData.simulationValidated,
      loan_requested: cleanedData.loanRequested,

      // Champs de suivi
      next_follow_up: cleanedData.nextFollowUp,
      last_call_date: cleanedData.lastCallDate,
      call_count: cleanedData.callCount,
      appointment_scheduled: cleanedData.appointmentScheduled,
      operation_date: cleanedData.operationDate,

      // Champs spécifiques
      suite_groupe: patientData.suiteGroupe !== undefined ? patientData.suiteGroupe : null,
      poids: cleanedData.poids,
      taille: cleanedData.taille,
      bmi: cleanedData.bmi,
      chirurgie: patientData.chirurgie !== undefined ? patientData.chirurgie : null,
      qualification: patientData.qualification !== undefined ? patientData.qualification : null,
      rdv_obtenu_par: patientData.rdvObtenuPar !== undefined ? patientData.rdvObtenuPar : null,

      // Champs timestamp
      premier_email: cleanedData.premierEmail,
      premier_whatsapp: cleanedData.premierWhatsapp,
      second_email: cleanedData.secondEmail,
      second_whatsapp: cleanedData.secondWhatsapp,
      nhs_tier4_premier_email: cleanedData.nhsTier4PremierEmail,
      nhs_tier4_second_email: cleanedData.nhsTier4SecondEmail,

      // Champs booléens - correction des noms de champs pour correspondre à la base de données
      facture_envoye: cleanedData.factureEnvoye,
      medical_agrement: cleanedData.medicalAgrement,
      consent_form: cleanedData.consentForm,
      autorisation_patient_s2: cleanedData.autorisationPatientS2,
      compte_rendu_hospitalisation: cleanedData.compteRenduHospitalisation,
      compte_rendu_consultation: cleanedData.compteRenduConsultation,
      email_patient_gp: cleanedData.emailPatientGp,
      patient_s2_form: cleanedData.patientS2Form,
      lettre_gp: cleanedData.lettreGp,
      s2_saint_james: cleanedData.s2SaintJames,
    }

    // Log des données préparées pour l'insertion
    console.log("CRÉATION PATIENT - Données préparées:")
    console.log("doctor:", dataToInsert.doctor)
    console.log("suite_groupe:", dataToInsert.suite_groupe)
    console.log("qualification:", dataToInsert.qualification)
    console.log("rdv_obtenu_par:", dataToInsert.rdv_obtenu_par)

    // Si un closer est spécifié, essayer de trouver son ID
    if (cleanedData.closer) {
      // Rechercher le closer par nom
      const { data: closerData } = await supabase
        .from("users")
        .select("id")
        .eq("full_name", cleanedData.closer)
        .eq("role", "closer")
        .single()

      if (closerData) {
        dataToInsert.closer_id = closerData.id
      } else {
        // Si non trouvé par nom, essayer par email
        const { data: closerByEmail } = await supabase
          .from("users")
          .select("id")
          .eq("email", cleanedData.closer)
          .eq("role", "closer")
          .single()

        if (closerByEmail) {
          dataToInsert.closer_id = closerByEmail.id
        } else if (user && user.role === "closer") {
          // Si l'utilisateur est un closer, utiliser son ID
          dataToInsert.closer_id = user.id
        }
      }
    } else if (user && user.role === "closer") {
      // Si aucun closer n'est spécifié et l'utilisateur est un closer, utiliser son ID
      dataToInsert.closer_id = user.id
    }

    // Si l'utilisateur est admin, ajouter son ID comme created_by_admin
    if (user && user.role === "admin") {
      dataToInsert.created_by_admin = user.id

      // Si la validation est demandée, ajouter son ID comme validated_by_admin
      if (shouldValidate) {
        dataToInsert.validated_by_admin = user.id
      }
    }

    console.log("Données à insérer:", dataToInsert)

    // Insérer les données dans Supabase
    const { data, error } = await supabase.from("patients").insert([dataToInsert]).select()

    if (error) {
      console.error("Erreur lors de la création du patient:", error)
      return { success: false, error, message: `Erreur: ${error.message}` }
    }

    // Log des données après création
    console.log("CRÉATION PATIENT - Données après création:", data)

    return { success: true, data, message: "Patient créé avec succès" }
  } catch (error: any) {
    console.error("Exception lors de la création du patient:", error)
    return { success: false, error, message: `Exception: ${error.message}` }
  }
}

// Fonction pour mettre à jour un patient avec une gestion améliorée des erreurs
export async function updatePatientFixed(patientId: string, patientData: any, user: any) {
  try {
    // Log des données reçues
    console.log("MISE À JOUR PATIENT - Données reçues:")
    console.log("Doctor:", patientData.doctor)
    console.log("Suite/Groupe:", patientData.suiteGroupe)
    console.log("Qualification:", patientData.qualification)
    console.log("RDV Obtenu Par:", patientData.rdvObtenuPar)

    // Nettoyer les données avant de les envoyer à Supabase
    let cleanedData = cleanPatientDataForSupabase(patientData)

    // Sanitiser spécifiquement les champs de date
    cleanedData = sanitizeDateFields(cleanedData)

    // Préparer les données pour Supabase (conversion des noms de champs camelCase en snake_case)
    const dataToUpdate: any = {
      full_name: cleanedData.name,
      email: cleanedData.email,
      phone: cleanedData.phone,
      doctor: patientData.doctor !== undefined ? patientData.doctor : null,
      status: cleanedData.status,
      notes: cleanedData.notes,
      // Suppression du champ commentaires
      registration_date: cleanedData.registrationDate,
      consultation_date: cleanedData.consultationDate,

      // Champs financiers
      revenue: cleanedData.income,
      expenses: cleanedData.expenses,
      loan_amount: cleanedData.loanAmount,
      credit_score: cleanedData.creditScore,
      credit_score_platform: cleanedData.creditPlatform,
      loan_platform: cleanedData.platform,
      loan_simulation_validated: cleanedData.simulationValidated,
      loan_requested: cleanedData.loanRequested,

      // Champs de suivi
      next_follow_up: cleanedData.nextFollowUp,
      last_call_date: cleanedData.lastCallDate,
      call_count: cleanedData.callCount,
      appointment_scheduled: cleanedData.appointmentScheduled,
      operation_date: cleanedData.operationDate,

      // Champs spécifiques
      suite_groupe: patientData.suiteGroupe !== undefined ? patientData.suiteGroupe : null,
      poids: cleanedData.poids,
      taille: cleanedData.taille,
      bmi: cleanedData.bmi,
      chirurgie: patientData.chirurgie !== undefined ? patientData.chirurgie : null,
      qualification: patientData.qualification !== undefined ? patientData.qualification : null,
      rdv_obtenu_par: patientData.rdvObtenuPar !== undefined ? patientData.rdvObtenuPar : null,

      // Champs timestamp
      premier_email: cleanedData.premierEmail,
      premier_whatsapp: cleanedData.premierWhatsapp,
      second_email: cleanedData.secondEmail,
      second_whatsapp: cleanedData.secondWhatsapp,
      nhs_tier4_premier_email: cleanedData.nhsTier4PremierEmail,
      nhs_tier4_second_email: cleanedData.nhsTier4SecondEmail,

      // Champs booléens - correction des noms de champs pour correspondre à la base de données
      facture_envoye: cleanedData.factureEnvoye,
      medical_agrement: cleanedData.medicalAgrement,
      consent_form: cleanedData.consentForm,
      autorisation_patient_s2: cleanedData.autorisationPatientS2,
      compte_rendu_hospitalisation: cleanedData.compteRenduHospitalisation,
      compte_rendu_consultation: cleanedData.compteRenduConsultation,
      email_patient_gp: cleanedData.emailPatientGp,
      patient_s2_form: cleanedData.patientS2Form,
      lettre_gp: cleanedData.lettreGp,
      s2_saint_james: cleanedData.s2SaintJames,

      // Vérifier si la colonne updated_at existe avant de l'utiliser
      ...((await columnExists("patients", "updated_at")) ? { updated_at: new Date().toISOString() } : {}),
    }

    // Log des données préparées pour la mise à jour
    console.log("MISE À JOUR PATIENT - Données préparées:")
    console.log("doctor:", dataToUpdate.doctor)
    console.log("suite_groupe:", dataToUpdate.suite_groupe)
    console.log("qualification:", dataToUpdate.qualification)
    console.log("rdv_obtenu_par:", dataToUpdate.rdv_obtenu_par)

    // Si un closer est spécifié, essayer de trouver son ID
    if (cleanedData.closer) {
      // Rechercher le closer par nom
      const { data: closerData } = await supabase
        .from("users")
        .select("id")
        .eq("full_name", cleanedData.closer)
        .eq("role", "closer")
        .single()

      if (closerData) {
        dataToUpdate.closer_id = closerData.id
      } else {
        // Si non trouvé par nom, essayer par email
        const { data: closerByEmail } = await supabase
          .from("users")
          .select("id")
          .eq("email", cleanedData.closer)
          .eq("role", "closer")
          .single()

        if (closerByEmail) {
          dataToUpdate.closer_id = closerByEmail.id
        }
      }
    }

    // Si l'utilisateur est admin et que le patient est validé, ajouter son ID comme validated_by_admin
    if (user && user.role === "admin" && cleanedData.validated) {
      dataToUpdate.validated_by_admin = user.id
    }

    console.log("Données à mettre à jour:", dataToUpdate)

    // Mettre à jour les données dans Supabase
    const { data, error } = await supabase.from("patients").update(dataToUpdate).eq("id", patientId).select()

    if (error) {
      console.error("Erreur lors de la mise à jour du patient:", error)
      return { success: false, error, message: `Erreur: ${error.message}` }
    }

    // Log des données après mise à jour
    console.log("MISE À JOUR PATIENT - Données après mise à jour:", data)

    return { success: true, data, message: "Patient mis à jour avec succès" }
  } catch (error: any) {
    console.error("Exception lors de la mise à jour du patient:", error)
    return { success: false, error, message: `Exception: ${error.message}` }
  }
}

// Remplacer la fonction updatePatientStatus par cette version améliorée
export async function updatePatientStatus(patientId: string, status: string) {
  try {
    // Vérifier si la colonne updated_at existe
    const hasUpdatedAtColumn = await columnExists("patients", "updated_at")

    // Préparer les données à mettre à jour
    const updateData: any = {
      status: status,
    }

    // Ajouter updated_at seulement si la colonne existe
    if (hasUpdatedAtColumn) {
      updateData.updated_at = new Date().toISOString()
    }

    // Update the patient status
    const { data, error } = await supabase.from("patients").update(updateData).eq("id", patientId).select()

    if (error) {
      console.error("Error updating patient status:", error)
      throw new Error(`Database error: ${error.message}`)
    }

    return { success: true, data }
  } catch (error: any) {
    console.error("Failed to update patient status:", error)
    throw error
  }
}

/**
 * Gets a patient by ID with their closer information
 */
export async function getPatientById(patientId: string) {
  try {
    const { data, error } = await supabase
      .from("patients")
      .select(`
        *,
        closer:closer_id (id, full_name, email)
      `)
      .eq("id", patientId)
      .single()

    if (error) {
      console.error("Error fetching patient:", error)
      throw new Error(`Database error: ${error.message}`)
    }

    return data
  } catch (error: any) {
    console.error("Failed to get patient:", error)
    throw error
  }
}

/**
 * Gets all patients with pagination
 */
export async function getPatients(page = 1, pageSize = 10) {
  try {
    const from = (page - 1) * pageSize
    const to = from + pageSize - 1

    const { data, error, count } = await supabase
      .from("patients")
      .select(
        `
        *,
        closer:closer_id (id, full_name, email)
      `,
        { count: "exact" },
      )
      .range(from, to)
      .order("updated_at", { ascending: false })

    if (error) {
      console.error("Error fetching patients:", error)
      throw new Error(`Database error: ${error.message}`)
    }

    return { data, count, page, pageSize }
  } catch (error: any) {
    console.error("Failed to get patients:", error)
    throw error
  }
}

"use client"

import { createContext, useContext, type ReactNode } from "react"

// Interface pour le contexte i18n
interface I18nContextType {
  t: (key: string) => string
}

// Créer le contexte
const I18nContext = createContext<I18nContextType | undefined>(undefined)

// Traductions (uniquement en français)
const translations: Record<string, string> = {
  // Navigation
  "nav.dashboard": "Tableau de bord",
  "nav.patients": "Patients",
  "nav.newPatient": "Nouveau patient",
  "nav.stats": "Statistiques",
  "nav.profile": "Profil",
  "nav.accounts": "Gestion des comptes",

  // Rôles
  "role.admin": "Administrateur",
  "role.closer": "Closer",

  // Auth
  "auth.login": "Connexion",
  "auth.loginWithGoogle": "Se connecter avec Google",
  "auth.loginAsAdmin": "Se connecter en tant qu'Admin",
  "auth.loginAsCloser": "Se connecter en tant que Closer",
  "auth.logout": "Déconnexion",
  "auth.demoMode": "Mode Démo",
  "auth.demoModeDescription": "Vous êtes en mode démo. Choisissez un rôle pour vous connecter.",
  "auth.email": "Email",
  "auth.password": "Mot de passe",
  "auth.forgotPassword": "Mot de passe oublié ?",
  "auth.resetPassword": "Réinitialiser le mot de passe",
  "auth.getLoginLink": "Recevoir un lien de connexion",
  "auth.or": "Ou",

  // Dashboard
  "dashboard.title": "Tableau de bord",
  "dashboard.totalPatients": "Total Patients",
  "dashboard.conversionRate": "Taux de Conversion",
  "dashboard.accepted": "Acceptés",
  "dashboard.pending": "En attente",
  "dashboard.statusTitle": "Statut des dossiers",
  "dashboard.popularPlatforms": "Plateformes populaires",
  "dashboard.popularPlatformsDesc": "Les plateformes les plus utilisées",
  "dashboard.recentPatients": "Patients récents",
  "dashboard.recentPatientsDesc": "Les 5 derniers patients ajoutés",
  "dashboard.viewAllPatients": "Voir tous les patients",
  "dashboard.noData": "Aucune donnée disponible",
  "dashboard.yourPatients": "Vos patients",
  "dashboard.yourPerformance": "Votre performance",
  "dashboard.personalStats": "Statistiques personnelles",
  "dashboard.yourConversionRate": "Votre taux de conversion",
  "dashboard.admin_welcome": "Bienvenue dans votre espace de suivi global",
  "dashboard.closer_welcome": "Bienvenue",
  "dashboard.personal_stats": "voici vos statistiques personnelles",

  // Patients
  "patients.title": "Patients",
  "patients.newPatient": "Nouveau patient",
  "patients.search": "Rechercher...",
  "patients.all": "Tous",
  "patients.todo": "À faire",
  "patients.inProgress": "En cours",
  "patients.accepted": "Acceptés",
  "patients.rejected": "Refusés",
  "patients.noPatients": "Aucun patient trouvé",
  "patients.noSearchResults": "Aucun résultat ne correspond à votre recherche.",
  "patients.startAdding": "Commencez par ajouter un nouveau patient.",
  "patients.addPatient": "Ajouter un patient",
  "patients.doctor": "Médecin",
  "patients.consultation": "Consultation",
  "patients.platform": "Plateforme",
  "patients.loanAmount": "Montant prêt",
  "patients.nextFollowUp": "Prochaine relance",
  "patients.closer": "Closer",
  "patients.comments": "Commentaires",

  // Form
  "form.title": "Ajouter un nouveau patient",
  "form.subtitle": "Remplissez le formulaire pour ajouter un nouveau patient au suivi",
  "form.name": "Nom",
  "form.email": "Email",
  "form.doctor": "Médecin référent",
  "form.consultationDate": "Date téléconsultation",
  "form.selectDate": "Sélectionner une date",
  "form.financialInfo": "Informations financières",
  "form.monthlyIncome": "Revenus mensuels (£)",
  "form.monthlyExpenses": "Dépenses mensuelles (£)",
  "form.creditScore": "Score crédit",
  "form.creditPlatform": "Plateforme de score",
  "form.loanInfo": "Informations de prêt",
  "form.loanAmount": "Montant prêt (£)",
  "form.simulationValidated": "Simulation validée",
  "form.platform": "Plateforme",
  "form.loanRequested": "Demande de prêt faite",
  "form.caseTracking": "Suivi du dossier",
  "form.caseStatus": "Statut dossier",
  "form.followUpDate": "Date de relance",
  "form.comments": "Commentaires",
  "form.commentsPlaceholder": "Ajoutez des notes ou commentaires sur ce dossier",
  "form.submit": "Ajouter le patient",
  "form.submitting": "Envoi en cours...",
  "form.select": "Sélectionner",
  "form.choose": "Choisir",
  "form.yes": "Oui",
  "form.no": "Non",

  // Profile
  "profile.title": "Profil utilisateur",
  "profile.subtitle": "Gérez vos informations personnelles et vos préférences",
  "profile.verified": "Email vérifié",
  "profile.notVerified": "Email non vérifié",
  "profile.personalInfo": "Informations personnelles",
  "profile.personalInfoDesc": "Mettez à jour vos informations personnelles",
  "profile.name": "Nom",
  "profile.nameDesc": "Votre nom tel qu'il apparaîtra dans l'application",
  "profile.emailDesc": "Votre adresse email. Un email de vérification sera envoyé si vous la modifiez.",
  "profile.photoURL": "URL de la photo de profil",
  "profile.photoURLDesc": "Lien vers votre photo de profil. Laissez vide pour utiliser les initiales.",
  "profile.saveChanges": "Enregistrer les modifications",
  "profile.updating": "Mise à jour...",

  // Password
  "password.title": "Sécurité du compte",
  "password.subtitle": "Gérez votre mot de passe et la sécurité de votre compte",
  "password.googleAccount": "Compte Google",
  "password.googleAccountDesc":
    "Vous êtes connecté avec Google. La gestion du mot de passe se fait via votre compte Google.",
  "password.current": "Mot de passe actuel",
  "password.new": "Nouveau mot de passe",
  "password.confirm": "Confirmer le mot de passe",
  "password.requirements":
    "Le mot de passe doit contenir au moins 8 caractères, une majuscule, une minuscule et un chiffre.",
  "password.change": "Changer le mot de passe",
  "password.forgotTitle": "Mot de passe oublié ?",
  "password.forgotDesc": "Si vous avez oublié votre mot de passe, vous pouvez demander une réinitialisation par email.",
  "password.reset": "Réinitialiser le mot de passe",
  "password.sending": "Envoi en cours...",

  // Preferences
  "preferences.title": "Préférences",
  "preferences.subtitle": "Personnalisez votre expérience utilisateur",
  "preferences.theme": "Thème",
  "preferences.themeDesc": "Choisissez le thème de l'interface",
  "preferences.light": "Clair",
  "preferences.dark": "Sombre",
  "preferences.system": "Système",
  "preferences.notifications": "Notifications",
  "preferences.notificationsDesc": "Recevoir des notifications pour les relances",
  "preferences.language": "Langue",
  "preferences.languageDesc": "Choisissez la langue de l'interface",
  "preferences.save": "Enregistrer les préférences",
  "preferences.saving": "Enregistrement...",

  // Stats
  "stats.title": "Statistiques avancées",
  "stats.subtitle": "Vue d'ensemble des performances de l'équipe",
  "stats.totalPatients": "Patients au total",
  "stats.conversionRate": "Taux de conversion",
  "stats.averageAmount": "Montant moyen",
  "stats.averageAmountDesc": "Montant moyen des prêts",
  "stats.topPlatform": "Plateforme principale",
  "stats.topPlatformDesc": "Plateforme la plus utilisée",
  "stats.topCloser": "Meilleur closer",
  "stats.topCloserDesc": "Closer avec le plus de conversions",
  "stats.overview": "Vue d'ensemble",
  "stats.closers": "Performance des closers",
  "stats.platforms": "Plateformes",
  "stats.doctors": "Médecins",
  "stats.caseStatus": "Statut des dossiers",
  "stats.caseStatusDesc": "Répartition des dossiers par statut",
  "stats.conversionRateTitle": "Taux de conversion",
  "stats.conversionRateDesc": "Pourcentage de dossiers acceptés",
  "stats.closerPerformance": "Performance par Closer",
  "stats.closerPerformanceDesc": "Nombre de patients et taux de conversion par closer",
  "stats.platformDistribution": "Répartition par Plateforme",
  "stats.platformDistributionDesc": "Nombre de patients par plateforme de prêt",
  "stats.doctorDistribution": "Répartition par Médecin",
  "stats.doctorDistributionDesc": "Nombre de patients par médecin référent",
  "stats.latestPatients": "Derniers patients ajoutés",
  "stats.latestPatientsDesc": "Les 5 derniers patients enregistrés dans le système",
  "stats.yourPerformance": "Votre performance",
  "stats.yourPatients": "Vos patients",
  "stats.yourConversionRate": "Votre taux de conversion",
  "stats.personalView": "Vue personnelle",
  "stats.adminView": "Vue administrateur",
  "stats.personalTitle": "Vos statistiques personnelles",
  "stats.personalOverview": "Vue d'ensemble de vos performances",
  "stats.averageAmountTitle": "Montant moyen",
  "stats.averageLoanAmountDescription": "Montant moyen des prêts",
  "stats.mainPlatformTitle": "Plateforme principale",
  "stats.mostUsedPlatform": "Votre plateforme la plus utilisée",
  "stats.folderStatusTitle": "Statut des dossiers",
  "stats.folderStatus": "Statut de vos dossiers",
  "stats.folderStatusDescription": "Répartition de vos dossiers par statut",
  "stats.conversionRateDescription": "Pourcentage de vos dossiers vendus",
  "stats.lastPatients": "Vos derniers patients",
  "stats.lastPatientsDescription": "Vos 5 derniers patients enregistrés",
  "stats.noDataAvailable": "Aucune donnée disponible",
  "stats.noPatientsAvailable": "Aucun patient disponible",
  "stats.advancedStats": "Statistiques avancées",
  "stats.teamPerformanceOverview": "Vue d'ensemble des performances de l'équipe",
  "stats.bestCloserTitle": "Meilleur closer",
  "stats.closerWithMostConversions": "Closer avec le plus de conversions",
  "stats.filters": "Filtres",
  "stats.filterData": "Filtrer les données",
  "stats.selectCloser": "Sélectionner un closer",
  "stats.allClosers": "Tous les closers",
  "stats.patients": "patients",
  "stats.conversion": "conversion",
  "stats.detailedPerformance": "Performance détaillée",
  "stats.filterByCloser": "Filtrer par closer",
  "stats.filterByDoctor": "Filtrer par médecin",
  "stats.allDoctors": "Tous les médecins",
  "stats.filterByPlatform": "Filtrer par plateforme",
  "stats.allPlatforms": "Toutes les plateformes",
  "stats.platformPerformance": "Performance par Plateforme",
  "stats.platformPerformanceDescription": "Nombre de patients et taux de conversion par plateforme",
  "stats.doctorPerformance": "Performance par Médecin",
  "stats.doctorPerformanceDescription": "Nombre de patients et taux de conversion par médecin",
  "stats.lastAddedPatients": "Derniers patients ajoutés",
  "stats.lastAddedPatientsDescription": "Les 5 derniers patients enregistrés dans le système",
  "stats.sales": "ventes sur",
  "stats.closerDistribution": "Répartition par Closer",
  "stats.closerDistributionDescription": "Nombre de patients par closer",

  // Status
  "status.accepted": "Acceptés",
  "status.sales": "Ventes",
  "status.inProgress": "En cours",
  "status.refused": "Refusés",
  "status.cancelled": "Annulés",

  // Tabs
  "tabs.overview": "Vue d'ensemble",
  "tabs.byDoctor": "Par médecin",
  "tabs.byPlatform": "Par plateforme",
  "tabs.closerPerformance": "Performance des closers",
  "tabs.doctorPerformance": "Performance par médecin",
  "tabs.platformPerformance": "Performance par plateforme",

  // Table
  "table.name": "Nom",
  "table.doctor": "Médecin",
  "table.platform": "Plateforme",
  "table.amount": "Montant",
  "table.status": "Statut",
  "table.closer": "Closer",
  "table.registration_date": "Date d'enreg.",
  "table.actions": "Actions",

  // Toasts
  "toast.profileUpdated": "Profil mis à jour",
  "toast.profileUpdatedDesc": "Vos informations ont été mises à jour avec succès.",
  "toast.preferencesUpdated": "Préférences mises à jour",
  "toast.preferencesUpdatedDesc": "Vos préférences ont été enregistrées avec succès.",
  "toast.passwordChanged": "Mot de passe mis à jour",
  "toast.passwordChangedDesc": "Votre mot de passe a été changé avec succès.",
  "toast.emailSent": "Email envoyé",
  "toast.emailSentDesc": "Un email de réinitialisation de mot de passe a été envoyé à votre adresse.",
  "toast.loginSuccess": "Connexion réussie",
  "toast.loginSuccessDesc": "Bienvenue, {name}",
  "toast.logoutSuccess": "Déconnexion réussie",
  "toast.logoutSuccessDesc": "Vous avez été déconnecté avec succès",
  "toast.demoLogin": "Connexion en mode démo",
  "toast.demoLoginDesc": "Connecté en tant que {role}",
  "toast.formSubmitted": "Formulaire soumis avec succès",
  "toast.formSubmittedDesc": "Les informations du patient ont été enregistrées.",

  // Errors
  error: "Erreur",
  "error.title": "Erreur",
  "error.configMissing": "Configuration Firebase manquante",
  "error.configMissingDesc":
    "Pour utiliser l'authentification Firebase, vous devez configurer les variables d'environnement.",
  "error.authRequired": "Authentification requise",
  "error.authRequiredDesc": "Veuillez vous reconnecter pour effectuer cette action.",
  "error.emailInUse": "Email déjà utilisé",
  "error.emailInUseDesc": "Cet email est déjà associé à un autre compte.",
  "error.wrongPassword": "Mot de passe incorrect",
  "error.wrongPasswordDesc": "Le mot de passe actuel est incorrect.",
  "error.weakPassword": "Mot de passe trop faible",
  "error.weakPasswordDesc": "Le nouveau mot de passe doit contenir au moins 6 caractères.",
  "error.submissionFailed": "Erreur lors de la soumission",
  "error.submissionFailedDesc": "Veuillez réessayer plus tard.",
  "error.accessDenied": "Accès refusé",
  "error.accessDeniedDesc": "Vous n'avez pas les permissions nécessaires pour accéder à cette ressource.",

  // Misc
  retry: "Réessayer",
  demo_mode: "Mode Démo",
  demo_mode_description: "Vous utilisez actuellement des données de démonstration.",
  total_patients: "Total Patients",
  all_patients: "Tous les patients",
  your_patients: "Vos patients",
  conversion_rate: "Taux de Conversion",
  sales_on: "ventes sur",
  sales: "Ventes",
  of_total: "du total",
  accepted: "Acceptés",
  pending: "En cours",
  refused_cancelled: "Refusés/Annulés",
  refused: "refusés",
  cancelled: "annulés",
  latest_patient_records: "Derniers dossiers patients",
  your_patient_records: "Vos dossiers patients",
  latest_patient_records_description_admin: "Les derniers dossiers patients enregistrés dans le système",
  latest_patient_records_description_closer: "Vos dossiers patients les plus récents",
  view_all: "Voir tous",
  patients: "les patients",
  your_patients: "vos patients",
  name: "Nom",
  doctor: "Médecin",
  registration_date: "Date d'enreg.",
  status: "Statut",
  closer: "Closer",
  actions: "Actions",
  view: "Voir",
  no_patients_available: "Aucun patient disponible",
  "misc.loading": "Chargement...",
  "misc.na": "N/A",
  "misc.patients": "patients",
  "misc.conversion": "conversion",
  "misc.of": "de",
  "misc.on": "sur",
  "misc.demoModeWarning": "Mode démo - Les données ne sont pas persistantes",
  "misc.demoModeAlert":
    "Vous utilisez l'application en mode démo. Les données ne sont pas persistantes et Firebase n'est pas configuré.",
}

// Fonction pour formater les chaînes avec des variables
function formatString(str: string, params: Record<string, string> = {}): string {
  return str.replace(/{(\w+)}/g, (_, key) => params[key] || `{${key}}`)
}

// Provider pour le contexte i18n
export function I18nProvider({ children }: { children: ReactNode }) {
  // Fonction de traduction
  const t = (key: string, params: Record<string, string> = {}): string => {
    const translation = translations[key] || key
    return formatString(translation, params)
  }

  return <I18nContext.Provider value={{ t }}>{children}</I18nContext.Provider>
}

// Hook pour utiliser les traductions
export function useI18n() {
  const context = useContext(I18nContext)
  if (context === undefined) {
    throw new Error("useI18n must be used within an I18nProvider")
  }
  return context
}

// Fonction utilitaire pour obtenir la date formatée
export function formatDate(date: Date | string): string {
  const dateObj = typeof date === "string" ? new Date(date) : date

  if (isNaN(dateObj.getTime())) return typeof date === "string" ? date : "N/A"

  const options: Intl.DateTimeFormatOptions = {
    year: "numeric",
    month: "long",
    day: "numeric",
  }

  return new Intl.DateTimeFormat("fr-FR", options).format(dateObj)
}

// Liste des statuts possibles pour un patient
export const PATIENT_STATUSES = [
  { value: "en_attente", label: "En attente" },
  { value: "a_contacter", label: "À contacter" },
  { value: "rdv_programme", label: "RDV programmé" },
  { value: "vente", label: "Vente" },
  { value: "perdu", label: "Perdu" },
  { value: "non_defini", label: "Non défini" },
  { value: "en_cours", label: "En cours" },
  { value: "annule", label: "Annulé" },
  { value: "a_rappeler", label: "À rappeler" },
  { value: "non_interesse", label: "Non intéressé" },
  { value: "no_show", label: "No Show" },
  { value: "invoice_sent", label: "Facture envoyée" },
  { value: "refus_credit", label: "Refus crédit" },
  { value: "no_answer", label: "Pas de réponse" },
  { value: "en_attente_paiement", label: "En attente paiement" },
  { value: "simulation_a_faire", label: "Simulation à faire" },
  { value: "process_depasse", label: "Process dépassé" },
  { value: "phone_not_available", label: "Téléphone non disponible" },
  { value: "paiement_fait", label: "Paiement fait" },
  { value: "credit_approuval_en_cours", label: "Approbation crédit en cours" },
  { value: "hors_cible", label: "Hors cible" },
  { value: "simulation_faite_refus", label: "Simulation faite, refus" },
]

// Liste des champs disponibles pour un patient
export const PATIENT_FIELDS = [
  { value: "full_name", label: "Nom complet" },
  { value: "email", label: "Email" },
  { value: "phone", label: "Téléphone" },
  { value: "status", label: "Statut" },
  { value: "doctor", label: "Médecin" },
  { value: "closer", label: "Commercial" },
  { value: "notes", label: "Notes" },
  { value: "consultation_date", label: "Date de consultation" },
  { value: "operation_date", label: "Date d'opération" },
  { value: "appointment_scheduled", label: "RDV programmé" },
  { value: "revenue", label: "Revenus" },
  { value: "expenses", label: "Dépenses" },
  { value: "credit_score", label: "Score de crédit" },
  { value: "bank", label: "Banque" },
  { value: "loan_amount", label: "Montant du prêt" },
  { value: "loan_simulation_validated", label: "Simulation de prêt validée" },
  { value: "loan_requested", label: "Prêt demandé" },
  { value: "last_call_date", label: "Date du dernier appel" },
  { value: "next_follow_up", label: "Prochain suivi" },
  { value: "address", label: "Adresse" },
  { value: "city", label: "Ville" },
  { value: "postal_code", label: "Code postal" },
  { value: "country", label: "Pays" },
  { value: "age", label: "Âge" },
  { value: "gender", label: "Genre" },
  { value: "registration_date", label: "Date d'inscription" },
  { value: "source", label: "Source" },
  { value: "poids", label: "Poids" },
  { value: "taille", label: "Taille" },
  { value: "bmi", label: "IMC" },
]

// Fonction pour obtenir la classe de badge en fonction du statut
export const getStatusBadgeClass = (status: string): string => {
  switch (status?.toLowerCase()) {
    case "en_attente":
      return "bg-amber-100 text-amber-800"
    case "a_contacter":
      return "bg-blue-100 text-blue-800"
    case "rdv_programme":
      return "bg-purple-100 text-purple-800"
    case "vente":
      return "bg-green-100 text-green-800"
    case "perdu":
      return "bg-red-100 text-red-800"
    case "non_defini":
      return "bg-gray-100 text-gray-800"
    case "en_cours":
      return "bg-blue-100 text-blue-800"
    case "annule":
      return "bg-red-100 text-red-800"
    case "a_rappeler":
      return "bg-yellow-100 text-yellow-800"
    case "non_interesse":
      return "bg-gray-100 text-gray-800"
    case "no_show":
      return "bg-red-100 text-red-800"
    case "invoice_sent":
      return "bg-blue-100 text-blue-800"
    case "refus_credit":
      return "bg-red-100 text-red-800"
    case "no_answer":
      return "bg-gray-100 text-gray-800"
    case "en_attente_paiement":
      return "bg-amber-100 text-amber-800"
    case "simulation_a_faire":
      return "bg-blue-100 text-blue-800"
    case "process_depasse":
      return "bg-gray-100 text-gray-800"
    case "phone_not_available":
      return "bg-red-100 text-red-800"
    case "paiement_fait":
      return "bg-green-100 text-green-800"
    case "credit_approuval_en_cours":
      return "bg-blue-100 text-blue-800"
    case "hors_cible":
      return "bg-gray-100 text-gray-800"
    case "simulation_faite_refus":
      return "bg-red-100 text-red-800"
    default:
      return "bg-gray-100 text-gray-800"
  }
}

// Fonction pour obtenir le libellé du statut
export const getStatusLabel = (status: string | null | undefined): string => {
  if (!status) return "Non défini"
  const foundStatus = PATIENT_STATUSES.find((s) => s.value === status.toLowerCase())
  return foundStatus?.label || status
}

// Fonction pour vérifier si un statut est valide
export const isValidStatus = (status: string): boolean => {
  return PATIENT_STATUSES.some((s) => s.value === status)
}

// Fonction pour formater un numéro de téléphone au format E.164
export const formatPhoneNumberE164 = (phoneNumber: string | null | undefined): string => {
  if (!phoneNumber) return ""

  // Supprimer tous les caractères non numériques sauf le +
  const cleaned = phoneNumber.replace(/[^\d+]/g, "")

  // Si le numéro ne commence pas par +, ajouter +
  if (!cleaned.startsWith("+")) {
    // Supposer que c'est un numéro français si pas de code pays
    return `+33${cleaned.startsWith("0") ? cleaned.substring(1) : cleaned}`
  }

  return cleaned
}

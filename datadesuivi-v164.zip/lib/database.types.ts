export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      patients: {
        Row: {
          id: string
          name: string
          email: string
          doctor: string
          consultation_date: string | null
          income: number | null
          expenses: number | null
          credit_score: string | null
          credit_platform: string | null
          loan_amount: number | null
          simulation_validated: string | null
          platform: string | null
          status: string | null
          loan_requested: string | null
          next_follow_up: string | null
          closer: string
          comments: string | null
          created_at: string
          updated_at: string | null
          phone: string | null
          notes: string | null
          // New fields
          suite_groupe: string | null
          poids: number | null
          taille: number | null
          BMI: number | null
          chirurgie: string | null
          qualification: string | null
          rdv_obtenu_par: string | null
          premier_email: string | null
          premier_whatsapp: string | null
          second_email: string | null
          second_whatsapp: string | null
          facture_envoye: boolean | null
          medical_agrement: boolean | null
          consent_form: boolean | null
          autorisation_patient_s2: boolean | null
          compte_rendu_hospitalisation: string | null
          compte_rendu_consultation: string | null
          email_patient_gp: string | null
          patient_s2_form: string | null
          lettre_gp: string | null
          s2_saint_james: string | null
          nhs_tier4_premier_email: string | null
          nhs_tier4_second_email: string | null
        }
        Insert: {
          id?: string
          name: string
          email: string
          doctor: string
          consultation_date?: string | null
          income?: number | null
          expenses?: number | null
          credit_score?: string | null
          credit_platform?: string | null
          loan_amount?: number | null
          simulation_validated?: string | null
          platform?: string | null
          status?: string | null
          loan_requested?: string | null
          next_follow_up?: string | null
          closer: string
          comments?: string | null
          created_at?: string
          updated_at?: string | null
          phone?: string | null
          notes?: string | null
          // New fields
          suite_groupe?: string | null
          poids?: number | null
          taille?: number | null
          BMI?: number | null
          chirurgie?: string | null
          qualification?: string | null
          rdv_obtenu_par?: string | null
          premier_email?: string | null
          premier_whatsapp?: string | null
          second_email?: string | null
          second_whatsapp?: string | null
          facture_envoye?: boolean | null
          medical_agrement?: boolean | null
          consent_form?: boolean | null
          autorisation_patient_s2?: boolean | null
          compte_rendu_hospitalisation?: string | null
          compte_rendu_consultation?: string | null
          email_patient_gp?: string | null
          patient_s2_form?: string | null
          lettre_gp?: string | null
          s2_saint_james?: string | null
          nhs_tier4_premier_email?: string | null
          nhs_tier4_second_email?: string | null
        }
        Update: {
          id?: string
          name?: string
          email?: string
          doctor?: string
          consultation_date?: string | null
          income?: number | null
          expenses?: number | null
          credit_score?: string | null
          credit_platform?: string | null
          loan_amount?: number | null
          simulation_validated?: string | null
          platform?: string | null
          status?: string | null
          loan_requested?: string | null
          next_follow_up?: string | null
          closer?: string
          comments?: string | null
          created_at?: string
          updated_at?: string | null
          phone?: string | null
          notes?: string | null
          // New fields
          suite_groupe?: string | null
          poids?: number | null
          taille?: number | null
          BMI?: number | null
          chirurgie?: string | null
          qualification?: string | null
          rdv_obtenu_par?: string | null
          premier_email?: string | null
          premier_whatsapp?: string | null
          second_email?: string | null
          second_whatsapp?: string | null
          facture_envoye?: boolean | null
          medical_agrement?: boolean | null
          consent_form?: string | null
          autorisation_patient_s2?: boolean | null
          compte_rendu_hospitalisation?: string | null
          compte_rendu_consultation?: string | null
          email_patient_gp?: string | null
          patient_s2_form?: string | null
          lettre_gp?: string | null
          s2_saint_james?: string | null
          nhs_tier4_premier_email?: string | null
          nhs_tier4_second_email?: string | null
        }
      }
      users: {
        Row: {
          id: string
          email: string
          name: string
          role: string
          active: boolean
          created_at: string
          last_password_change: string | null
          password_hash: string | null
        }
        Insert: {
          id?: string
          email: string
          name: string
          role: string
          active?: boolean
          created_at?: string
          last_password_change?: string | null
          password_hash?: string | null
        }
        Update: {
          id?: string
          email?: string
          name?: string
          role?: string
          active?: boolean
          created_at?: string
          last_password_change?: string | null
          password_hash?: string | null
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}

import { supabase } from "./supabase"

// Types for roles
export type UserRole = "admin" | "closer"

// Interface for users
export interface User {
  id: string
  email: string
  name: string
  full_name?: string
  role: UserRole
  active?: boolean
  created_at?: string
  last_password_change?: string
}

// Interface for user preferences
export interface UserPreferences {
  theme: "light" | "dark" | "system"
  notifications: boolean
}

// Key for storing user preferences
const USER_PREFERENCES_KEY = "user-preferences"

// Function to validate an email
function isValidEmail(email: string): boolean {
  if (!email) return false
  email = email.trim()

  // Regular expression to validate an email
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

// Function to get all users
export async function getUsers(): Promise<User[]> {
  try {
    console.log("Retrieving user list")

    // In production, use Supabase
    console.log("Retrieving users from Supabase")

    const { data: users, error } = await supabase.from("users").select("*").order("created_at", { ascending: false })

    if (error) {
      console.error("Supabase error when retrieving users:", error)
      throw new Error(`Error retrieving users: ${error.message}`)
    }

    // Convert data to application format
    return users.map((user) => ({
      id: user.id,
      email: user.email,
      name: user.full_name || user.name,
      full_name: user.full_name || user.name,
      role: user.role as UserRole,
      active: user.active,
      created_at: user.created_at,
      last_password_change: user.password_updated_at || user.created_at, // Use password_updated_at or created_at
    }))
  } catch (error) {
    console.error("Error retrieving users:", error)
    return []
  }
}

// Function to authenticate a user
export async function authenticateUser(
  email: string,
  password: string,
): Promise<{
  success: boolean
  message?: string
  user?: User
  token?: string
  emailConfirmationRequired?: boolean
}> {
  try {
    console.log(`Authentication attempt for ${email}`)

    // Email validation
    if (!email) {
      return {
        success: false,
        message: "Email address is required",
      }
    }

    // Clean the email
    email = email.trim()

    if (!isValidEmail(email)) {
      return {
        success: false,
        message: "Email address is invalid",
      }
    }

    // Password validation
    if (!password) {
      return {
        success: false,
        message: "Password is required",
      }
    }

    // In production, use Supabase Auth
    console.log("Authentication via Supabase Auth")

    // Use Supabase Auth for login
    const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (authError) {
      console.error("Supabase Auth error during authentication:", authError)

      // Check if the error is due to an unconfirmed email
      if (authError.message.includes("Email not confirmed")) {
        // Try to automatically confirm the user
        try {
          const { error: confirmError } = await supabase.rpc("admin_confirm_user", {
            user_email: email,
          })

          if (!confirmError) {
            console.log("User automatically confirmed, retrying login")

            // Retry login after confirmation
            const { data: retryData, error: retryError } = await supabase.auth.signInWithPassword({
              email,
              password,
            })

            if (!retryError && retryData && retryData.user) {
              // Get additional user information from the users table
              const { data: userData, error: userError } = await supabase
                .from("users")
                .select("*")
                .eq("id", retryData.user.id)
                .single()

              // Create user object
              const user: User = {
                id: retryData.user.id,
                email: retryData.user.email || "",
                name: userData?.full_name || userData?.name || retryData.user.email?.split("@")[0] || "User",
                full_name: userData?.full_name || userData?.name || retryData.user.email?.split("@")[0] || "User",
                role: (userData?.role as UserRole) || "closer",
                active: userData?.active !== undefined ? userData.active : true,
                created_at: retryData.user.created_at,
                last_password_change: userData?.password_updated_at || retryData.user.created_at,
              }

              return {
                success: true,
                user,
                token: retryData.session?.access_token,
              }
            }
          }
        } catch (confirmError) {
          console.warn("Error during automatic confirmation:", confirmError)
        }

        return {
          success: false,
          message: "Please confirm your email before logging in",
          emailConfirmationRequired: true,
        }
      }

      return {
        success: false,
        message: "Incorrect email or password",
      }
    }

    if (!authData || !authData.user) {
      return {
        success: false,
        message: "Authentication failed",
      }
    }

    // Get additional user information from the users table
    const { data: userData, error: userError } = await supabase
      .from("users")
      .select("*")
      .eq("id", authData.user.id)
      .single()

    if (userError && userError.code !== "PGRST116") {
      // PGRST116 is the code for "No rows found", which is normal if the user doesn't have an entry in the users table yet
      console.error("Supabase error when retrieving user data:", userError)
    }

    // If the user doesn't exist in the users table, add them
    if (userError && userError.code === "PGRST116") {
      console.log("User not found in users table, adding automatically")

      const { error: insertError } = await supabase.from("users").insert([
        {
          id: authData.user.id,
          email: authData.user.email || "",
          full_name: authData.user.email?.split("@")[0] || "User",
          role: "closer", // Default role
          active: true,
        },
      ])

      if (insertError) {
        console.error("Error adding user to users table:", insertError)
      }
    }

    // Create user object
    const user: User = {
      id: authData.user.id,
      email: authData.user.email || "",
      name: userData?.full_name || userData?.name || authData.user.email?.split("@")[0] || "User",
      full_name: userData?.full_name || userData?.name || authData.user.email?.split("@")[0] || "User",
      role: (userData?.role as UserRole) || "closer",
      active: userData?.active !== undefined ? userData.active : true,
      created_at: authData.user.created_at,
      last_password_change: userData?.password_updated_at || authData.user.created_at,
    }

    return {
      success: true,
      user,
      token: authData.session?.access_token,
    }
  } catch (error) {
    console.error("Error during authentication:", error)
    return {
      success: false,
      message: "An error occurred during authentication",
    }
  }
}

// Function to create a new user
export async function createUser(userData: {
  email: string
  name: string
  role: UserRole
  password: string
}): Promise<{
  success: boolean
  message?: string
  user?: User
  emailConfirmationRequired?: boolean
}> {
  try {
    console.log("Creating a new user:", userData)

    // Email validation
    if (!userData.email) {
      return {
        success: false,
        message: "Email address is required",
      }
    }

    // Clean the email
    userData.email = userData.email.trim()

    if (!isValidEmail(userData.email)) {
      return {
        success: false,
        message: "Email address is invalid",
      }
    }

    // Password validation
    if (!userData.password) {
      return {
        success: false,
        message: "Password is required",
      }
    }

    if (userData.password.length < 6) {
      return {
        success: false,
        message: "Password must be at least 6 characters",
      }
    }

    // Name validation
    if (!userData.name) {
      return {
        success: false,
        message: "Name is required",
      }
    }

    userData.name = userData.name.trim()

    // Check if we're in demo mode
    if (process.env.NODE_ENV === "development" && process.env.NEXT_PUBLIC_FORCE_DEMO === "true") {
      console.log("Creating a user in demo mode")

      // Generate a fake ID
      const fakeId = `demo-${Date.now()}-${Math.floor(Math.random() * 1000)}`

      // Create a user object
      const newUser: User = {
        id: fakeId,
        email: userData.email,
        name: userData.name,
        full_name: userData.name,
        role: userData.role,
        active: true,
        created_at: new Date().toISOString(),
        last_password_change: new Date().toISOString(),
      }

      return {
        success: true,
        user: newUser,
        message: "User created successfully in demo mode",
      }
    }

    // In production, use Supabase Auth
    console.log("Creating a user with Supabase Auth")

    // 1. Create the user in Supabase Auth
    const { data: authData, error: authError } = await supabase.auth.admin.createUser({
      email: userData.email,
      password: userData.password,
      email_confirm: true,
      user_metadata: {
        name: userData.name,
        role: userData.role,
      },
    })

    if (authError) {
      console.error("Supabase Auth error when creating user:", authError)

      // If the admin API fails, try the regular signup
      if (authError.message.includes("not authorized")) {
        console.log("Admin API not authorized, trying regular signup")
        return await createUserWithRegularSignup(userData)
      }

      // More specific error messages
      if (authError.message.includes("Email address is invalid")) {
        return {
          success: false,
          message: "Email address is invalid. Please check the format.",
        }
      }

      if (authError.message.includes("Password should be at least")) {
        return {
          success: false,
          message: "Password must be at least 6 characters.",
        }
      }

      if (authError.message.includes("User already registered")) {
        return {
          success: false,
          message: "A user with this email address already exists.",
        }
      }

      return {
        success: false,
        message: `Error creating user: ${authError.message}`,
      }
    }

    if (!authData || !authData.user) {
      return {
        success: false,
        message: "Error creating user: no data returned",
      }
    }

    // 2. Add the user to the users table
    const { error: insertError } = await supabase.from("users").insert([
      {
        id: authData.user.id,
        email: userData.email,
        full_name: userData.name,
        role: userData.role,
        active: true,
      },
    ])

    if (insertError) {
      console.error("Supabase error when inserting into users table:", insertError)
      // Don't fail completely, as the user has been created in Auth
      console.warn("User was created in Auth but not in the users table")
    }

    // Create user object to return
    const newUser: User = {
      id: authData.user.id,
      email: userData.email,
      name: userData.name,
      full_name: userData.name,
      role: userData.role,
      active: true,
      created_at: authData.user.created_at,
      last_password_change: authData.user.created_at,
    }

    return {
      success: true,
      user: newUser,
      message: "User created successfully",
    }
  } catch (error: any) {
    console.error("Error creating user:", error)
    return {
      success: false,
      message: `An error occurred while creating the user: ${error.message || "Unknown error"}`,
    }
  }
}

// Helper function to create a user with regular signup
async function createUserWithRegularSignup(userData: {
  email: string
  name: string
  role: UserRole
  password: string
}): Promise<{
  success: boolean
  message?: string
  user?: User
  emailConfirmationRequired?: boolean
}> {
  try {
    // 1. Create the user in Supabase Auth
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email: userData.email,
      password: userData.password,
      options: {
        data: {
          name: userData.name,
          role: userData.role,
        },
      },
    })

    if (authError) {
      console.error("Supabase Auth error when creating user:", authError)

      // More specific error messages
      if (authError.message.includes("Email address is invalid")) {
        return {
          success: false,
          message: "Email address is invalid. Please check the format.",
        }
      }

      if (authError.message.includes("Password should be at least")) {
        return {
          success: false,
          message: "Password must be at least 6 characters.",
        }
      }

      if (authError.message.includes("User already registered")) {
        return {
          success: false,
          message: "A user with this email address already exists.",
        }
      }

      return {
        success: false,
        message: `Error creating user: ${authError.message}`,
      }
    }

    if (!authData || !authData.user) {
      return {
        success: false,
        message: "Error creating user: no data returned",
      }
    }

    // Check if email requires confirmation
    const emailConfirmationRequired = !authData.session

    // If email requires confirmation, try to automatically confirm the user
    if (emailConfirmationRequired) {
      try {
        // Try to use the admin API to confirm the user
        const { error: confirmError } = await supabase.rpc("admin_confirm_user", {
          user_email: userData.email,
        })

        if (confirmError) {
          console.warn("Unable to automatically confirm user:", confirmError)
        } else {
          console.log("User automatically confirmed")
        }
      } catch (confirmError) {
        console.warn("Error during automatic confirmation:", confirmError)
      }
    }

    // 2. Add the user to the users table
    const { error: insertError } = await supabase.from("users").insert([
      {
        id: authData.user.id,
        email: userData.email,
        full_name: userData.name,
        role: userData.role,
        active: true,
      },
    ])

    if (insertError) {
      console.error("Supabase error when inserting into users table:", insertError)
      // Don't fail completely, as the user has been created in Auth
      console.warn("User was created in Auth but not in the users table")
    }

    // Create user object to return
    const newUser: User = {
      id: authData.user.id,
      email: userData.email,
      name: userData.name,
      full_name: userData.name,
      role: userData.role,
      active: true,
      created_at: authData.user.created_at,
      last_password_change: authData.user.created_at,
    }

    return {
      success: true,
      user: newUser,
      message: emailConfirmationRequired
        ? "User created successfully. Please check your email to confirm your account."
        : "User created successfully",
      emailConfirmationRequired,
    }
  } catch (error: any) {
    console.error("Error creating user with regular signup:", error)
    return {
      success: false,
      message: `An error occurred while creating the user: ${error.message || "Unknown error"}`,
    }
  }
}

// Function to update a user
export async function updateUser(
  userId: string,
  userData: Partial<User>,
): Promise<{ success: boolean; message?: string }> {
  try {
    console.log(`Updating user ${userId} with data:`, userData)

    // Email validation if provided
    if (userData.email !== undefined) {
      if (!userData.email) {
        return {
          success: false,
          message: "Email address is required",
        }
      }

      userData.email = userData.email.trim()

      if (!isValidEmail(userData.email)) {
        return {
          success: false,
          message: "Email address is invalid",
        }
      }
    }

    // Name validation if provided
    if (userData.name !== undefined) {
      if (!userData.name) {
        return {
          success: false,
          message: "Name is required",
        }
      }

      userData.name = userData.name.trim()
    }

    // In production, use Supabase
    console.log("Updating a user in Supabase")

    const updateData: any = {}

    if (userData.name !== undefined) updateData.full_name = userData.name
    if (userData.full_name !== undefined) updateData.full_name = userData.full_name
    if (userData.email !== undefined) {
      updateData.email = userData.email

      // Update email in Supabase Auth
      const { error: authError } = await supabase.auth.updateUser({
        email: userData.email,
      })

      if (authError) {
        console.error("Supabase Auth error when updating email:", authError)

        // More specific error messages
        if (authError.message.includes("Email address is invalid")) {
          return {
            success: false,
            message: "Email address is invalid. Please check the format.",
          }
        }

        return {
          success: false,
          message: `Error updating email: ${authError.message}`,
        }
      }
    }
    if (userData.role !== undefined) updateData.role = userData.role
    if (userData.active !== undefined) updateData.active = userData.active

    const { error } = await supabase.from("users").update(updateData).eq("id", userId)

    if (error) {
      console.error("Supabase error when updating user:", error)
      return {
        success: false,
        message: `Error updating user: ${error.message}`,
      }
    }

    return {
      success: true,
      message: "User updated successfully",
    }
  } catch (error: any) {
    console.error("Error updating user:", error)
    return {
      success: false,
      message: `An error occurred while updating the user: ${error.message || "Unknown error"}`,
    }
  }
}

// Function to delete a user
export async function deleteUser(userId: string): Promise<{ success: boolean; message?: string }> {
  try {
    console.log(`Deleting user with ID: ${userId}`)

    // In production, use Supabase
    console.log("Deleting a user in Supabase")

    // 1. Delete the user from the users table
    const { error: deleteError } = await supabase.from("users").delete().eq("id", userId)

    if (deleteError) {
      console.error("Supabase error when deleting user:", deleteError)
      return {
        success: false,
        message: `Error deleting user: ${deleteError.message}`,
      }
    }

    // 2. Delete the user from Supabase Auth (requires admin rights)
    // This operation usually needs to be done via a Supabase Edge function
    // or a server-side webhook with admin rights

    // For now, we don't delete the user from Auth as it requires admin rights
    // You'll need to implement this part according to your architecture

    return {
      success: true,
      message: "User deleted successfully",
    }
  } catch (error: any) {
    console.error("Error deleting user:", error)
    return {
      success: false,
      message: `An error occurred while deleting the user: ${error.message || "Unknown error"}`,
    }
  }
}

// Function to get user preferences
export function getUserPreferences(role: string): any {
  try {
    const prefsString = localStorage.getItem(`userPrefs_${role}`)
    if (prefsString) {
      return JSON.parse(prefsString)
    }
  } catch (error) {
    console.error("Error retrieving preferences:", error)
  }

  // Default values
  return {
    theme: "system",
    notifications: true,
  }
}

// Function to save user preferences
export function saveUserPreferences(role: string, prefs: any): void {
  try {
    localStorage.setItem(`userPrefs_${role}`, JSON.stringify(prefs))
  } catch (error) {
    console.error("Error saving preferences:", error)
  }
}

// Function to change a user's password
export async function changeUserPassword(
  userId: string,
  passwordData: { currentPassword: string; newPassword: string },
): Promise<{ success: boolean; message?: string }> {
  try {
    console.log(`Changing password for user ${userId}`)

    // Password validation
    if (!passwordData.currentPassword) {
      return {
        success: false,
        message: "Current password is required",
      }
    }

    if (!passwordData.newPassword) {
      return {
        success: false,
        message: "New password is required",
      }
    }

    if (passwordData.newPassword.length < 6) {
      return {
        success: false,
        message: "New password must be at least 6 characters",
      }
    }

    // In production, use Supabase Auth
    console.log("Changing password with Supabase Auth")

    // 1. Sign in with the old password to verify it's correct
    // First get the user's email
    const { data: userData, error: userError } = await supabase.from("users").select("email").eq("id", userId).single()

    if (userError) {
      console.error("Error retrieving user's email:", userError)
      return {
        success: false,
        message: "Unable to retrieve user information",
      }
    }

    if (!userData || !userData.email) {
      return {
        success: false,
        message: "User email not found",
      }
    }

    // Verify current password
    const { error: signInError } = await supabase.auth.signInWithPassword({
      email: userData.email,
      password: passwordData.currentPassword,
    })

    if (signInError) {
      console.error("Error verifying current password:", signInError)
      return {
        success: false,
        message: "Current password is incorrect",
      }
    }

    // 2. Update the password
    const { error: updateError } = await supabase.auth.updateUser({
      password: passwordData.newPassword,
    })

    if (updateError) {
      console.error("Error updating password:", updateError)

      // More specific error messages
      if (updateError.message.includes("Password should be at least")) {
        return {
          success: false,
          message: "New password must be at least 6 characters",
        }
      }

      return {
        success: false,
        message: `Error updating password: ${updateError.message}`,
      }
    }

    // 3. Update the last password change date in the users table
    const { error: userUpdateError } = await supabase
      .from("users")
      .update({
        password_updated_at: new Date().toISOString(),
      })
      .eq("id", userId)

    if (userUpdateError) {
      console.error("Error updating password change date:", userUpdateError)
      // Don't fail completely, as the password has been changed
      console.warn("Password was changed but the change date was not updated")
    }

    return {
      success: true,
      message: "Password changed successfully",
    }
  } catch (error: any) {
    console.error("Error changing password:", error)
    return {
      success: false,
      message: `An error occurred while changing password: ${error.message || "Unknown error"}`,
    }
  }
}

// Function to update user profile
export async function updateUserProfile(
  user: any,
  profileData: { displayName: string; email: string; photoURL?: string },
): Promise<boolean> {
  try {
    // Email validation
    if (!profileData.email) {
      console.error("Email address is required")
      return false
    }

    profileData.email = profileData.email.trim()

    if (!isValidEmail(profileData.email)) {
      console.error("Email address is invalid")
      return false
    }

    // Name validation
    if (!profileData.displayName) {
      console.error("Name is required")
      return false
    }

    profileData.displayName = profileData.displayName.trim()

    // In production, use Supabase
    // 1. Update email in Supabase Auth if necessary
    if (user.email !== profileData.email) {
      const { error: authError } = await supabase.auth.updateUser({
        email: profileData.email,
      })

      if (authError) {
        console.error("Error updating email:", authError)
        return false
      }
    }

    // 2. Update information in the users table
    const { error } = await supabase
      .from("users")
      .update({
        full_name: profileData.displayName,
        email: profileData.email,
        // Add photoURL if needed in the future
      })
      .eq("id", user.id)

    if (error) {
      console.error("Error updating profile:", error)
      return false
    }

    return true
  } catch (error) {
    console.error("Error updating profile:", error)
    return false
  }
}

// Function to send a password reset email
export async function sendPasswordReset(email: string): Promise<void> {
  try {
    console.log("Sending password reset email to:", email)

    // Email validation
    if (!email) {
      throw new Error("Email address is required")
    }

    email = email.trim()

    if (!isValidEmail(email)) {
      throw new Error("Email address is invalid")
    }

    // Use Supabase Auth to send a password reset email
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    })

    if (error) {
      console.error("Error sending password reset email:", error)

      // More specific error messages
      if (error.message.includes("Email address is invalid")) {
        throw new Error("Email address is invalid. Please check the format.")
      }

      throw error
    }
  } catch (error) {
    console.error("Error sending password reset email:", error)
    throw error
  }
}

export const changePassword = async (userId: string, currentPassword, newPassword) => {
  return changeUserPassword(userId, { currentPassword, newPassword })
}

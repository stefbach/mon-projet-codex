// Palette de couleurs bleu marine foncé, rouge et blanc
export const themeColors = {
  primary: {
    50: "#e6f1ff",
    100: "#cce3ff",
    200: "#99c7ff",
    300: "#66aaff",
    400: "#3388ff",
    500: "#0a2472", // Bleu marine foncé principal
    600: "#081d5c",
    700: "#061646",
    800: "#040e30",
    900: "#02071a",
  },
  secondary: {
    50: "#ffebee",
    100: "#ffcdd2",
    200: "#ef9a9a",
    300: "#e57373",
    400: "#ef5350",
    500: "#d90429", // Rouge principal
    600: "#c10024",
    700: "#a9001f",
    800: "#91001a",
    900: "#780015",
  },
  neutral: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
  },
  background: {
    light: "#ffffff", // Blanc
    dark: "#0a2472", // Bleu marine foncé
  },
}

// Types de boutons personnalisés
export const buttonVariants = {
  primary: "bg-primary-500 hover:bg-primary-600 text-white",
  secondary: "bg-secondary-500 hover:bg-secondary-600 text-white",
  outline: "border border-primary-500 text-primary-500 hover:bg-primary-50",
  ghost: "text-primary-500 hover:bg-primary-50",
  link: "text-primary-500 underline-offset-4 hover:underline",
}

// Types de cartes personnalisés
export const cardVariants = {
  default: "bg-white border border-neutral-200",
  primary: "bg-primary-50 border border-primary-200",
  secondary: "bg-secondary-50 border border-secondary-200",
}

// Statuts avec couleurs
export const statusColors = {
  "À faire": "bg-primary-100 text-primary-800",
  "En cours": "bg-blue-100 text-blue-800",
  Accepté: "bg-green-100 text-green-800",
  Refusé: "bg-secondary-100 text-secondary-800",
}

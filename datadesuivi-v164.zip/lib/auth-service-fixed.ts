import { supabase } from "./supabase"

export async function loginWithEmailPassword(email: string, password: string) {
  console.log(`Tentative de connexion avec email: ${email}`)

  try {
    // Vérifier si l'utilisateur existe dans auth.users
    const { data: userData, error: userError } = await supabase
      .from("users")
      .select("id, email")
      .eq("email", email)
      .single()

    if (userError) {
      console.warn(`Utilisateur avec email ${email} non trouvé dans la table users:`, userError)
    } else {
      console.log(`Utilisateur trouvé dans la table users:`, userData)
    }

    // Connexion avec email et mot de passe
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (error) {
      console.error("Erreur de connexion:", error)

      // Si l'erreur est "Invalid login credentials", essayons de confirmer l'utilisateur
      if (error.message.includes("Invalid login credentials")) {
        // Tenter de confirmer l'utilisateur
        await supabase.rpc("confirm_user", { email_to_confirm: email })

        // Réessayer la connexion
        const { data: retryData, error: retryError } = await supabase.auth.signInWithPassword({
          email,
          password,
        })

        if (retryError) {
          throw retryError
        }

        return { success: true, user: retryData.user, session: retryData.session }
      }

      throw error
    }

    return { success: true, user: data.user, session: data.session }
  } catch (error) {
    console.error("Erreur lors de la connexion:", error)
    return { success: false, error: error.message }
  }
}

export async function getCurrentSession() {
  try {
    const { data, error } = await supabase.auth.getSession()
    if (error) throw error
    return { success: true, session: data.session }
  } catch (error) {
    console.error("Erreur lors de la récupération de la session:", error)
    return { success: false, error: error.message }
  }
}

export async function getCurrentUser() {
  try {
    const { data, error } = await supabase.auth.getUser()
    if (error) throw error
    return { success: true, user: data.user }
  } catch (error) {
    console.error("Erreur lors de la récupération de l'utilisateur:", error)
    return { success: false, error: error.message }
  }
}

export async function logoutUser() {
  try {
    const { error } = await supabase.auth.signOut()
    if (error) throw error
    return { success: true }
  } catch (error) {
    console.error("Erreur lors de la déconnexion:", error)
    return { success: false, error: error.message }
  }
}

import { supabase } from "./supabase"
// Add this at the top of the file, after the imports
import { refreshSchemaCache } from "./supabase"
// Add the import for the validation
import patientSchema from "@/lib/validations/patient-schema"

// Importez la fonction cleanPatientDataForSupabase
import { cleanPatientDataForSupabase } from "./validations/patient-schema"

// Fonction pour vérifier si une colonne existe dans une table
async function columnExists(table: string, column: string): Promise<boolean> {
  try {
    const { data, error } = await supabase.rpc("check_column_exists", {
      table_name: table,
      column_name: column,
    })

    if (error) {
      console.error("Erreur lors de la vérification de l'existence de la colonne:", error)
      return false
    }

    return data || false
  } catch (error) {
    console.error("Exception lors de la vérification de l'existence de la colonne:", error)
    return false
  }
}

// Types
export interface Patient {
  id?: string
  name: string
  email: string
  phone?: string
  status?: string
  platform?: string
  doctor?: string
  notes?: string
  created_at?: string
  updated_at?: string
  closer?: string
  closerId?: string
  // Champs de suivi
  lastCallDate?: string | Date | null
  callCount?: number
  appointmentScheduled?: boolean
  operationDate?: string | Date | null
  // Autres champs possibles
  registrationDate?: string | Date
  consultationDate?: string | Date | null
  income?: number
  expenses?: number
  creditScore?: string
  creditPlatform?: string
  loanAmount?: number
  simulationValidated?: string | boolean
  loanRequested?: string | boolean
  nextFollowUp?: string | Date | null
  comments?: string
  validated?: boolean
  // New fields
  suiteGroupe?: string
  poids?: number
  taille?: number
  bmi?: number
  chirurgie?: string
  qualification?: string
  rdvObtenuPar?: string
  premierEmail?: string | Date | null
  premierWhatsapp?: string | Date | null
  secondEmail?: string | Date | null
  secondWhatsapp?: string | Date | null
  factureEnvoye?: boolean
  medicalAgrement?: boolean
  consentForm?: boolean
  autorisationPatientS2?: boolean
  compteRenduHospitalisation?: boolean
  compteRenduConsultation?: boolean
  emailPatientGp?: boolean
  patientS2Form?: boolean
  lettreGp?: boolean
  s2SaintJames?: boolean
  nhsTier4PremierEmail?: string | Date | null
  nhsTier4SecondEmail?: string | Date | null
}

// Interface pour les erreurs de validation
export interface ValidationError {
  field: string
  message: string
}

// Fonction pour journaliser les erreurs
async function logError(operation: string, data: any, error: any): Promise<void> {
  console.error(`Erreur lors de ${operation}:`, error)

  try {
    // Journaliser l'erreur dans Supabase
    await supabase.from("error_logs").insert([
      {
        operation,
        data: JSON.stringify(data),
        error: JSON.stringify(error),
        timestamp: new Date().toISOString(),
      },
    ])
  } catch (logError) {
    console.error("Erreur lors de la journalisation:", logError)
  }
}

// Fonction pour standardiser le nom du médecin
export function standardizeDoctorName(doctorName: string | null | undefined): string {
  if (!doctorName) return ""

  // Supprimer le préfixe "Dr " ou "Dr. "
  return doctorName.replace(/^Dr\.?\s+/i, "")
}

// Then in the validatePatientData function, update to use the imported schema directly:
function validatePatientData(patientData: Partial<Patient>): ValidationError[] {
  const errors: ValidationError[] = []

  // Use our Zod validation with the directly imported schema
  const validationResult = patientSchema.safeParse(patientData)

  if (!validationResult.success && "error" in validationResult) {
    // Convert Zod validation errors to our ValidationError format
    validationResult.error.errors.forEach((zodError) => {
      errors.push({ field: zodError.path.join("."), message: zodError.message })
    })
  }

  // Additional validation for qualification if needed
  if (patientData.qualification) {
    const validQualifications = ["chaud", "tiede", "froid", "D/DEAD"]
    if (!validQualifications.includes(patientData.qualification)) {
      errors.push({ field: "qualification", message: "Qualification non valide" })
    }
  }

  return errors
}

// Fonction pour convertir les noms de propriétés de camelCase à snake_case
function camelToSnakeCase(obj: any): any {
  if (obj === null || typeof obj !== "object") {
    return obj
  }

  const result: any = {}

  Object.keys(obj).forEach((key) => {
    // Convertir camelCase en snake_case
    const snakeKey = key.replace(/([A-Z])/g, "_$1").toLowerCase()
    result[snakeKey] = obj[key]
  })

  return result
}

// Fonction pour convertir les noms de propriétés de snake_case à camelCase
function snakeToCamelCase(obj: any): any {
  if (obj === null || typeof obj !== "object") {
    return obj
  }

  const result: any = {}

  Object.keys(obj).forEach((key) => {
    // Convertir snake_case en camelCase
    const camelKey = key.replace(/_([a-z])/g, (_, letter) => letter.toUpperCase())
    result[camelKey] = obj[key]
  })

  return result
}

// Fonction pour convertir les valeurs "Oui"/"Non" en booléens
function convertYesNoToBoolean(obj: any): any {
  if (obj === null || typeof obj !== "object") {
    return obj
  }

  const result: any = {}

  Object.keys(obj).forEach((key) => {
    if (obj[key] === "Oui") {
      result[key] = true
    } else if (obj[key] === "Non") {
      result[key] = false
    } else {
      result[key] = obj[key]
    }
  })

  return result
}

// Fonction pour convertir les booléens en "Oui"/"Non"
function convertBooleanToYesNo(obj: any): any {
  if (obj === null || typeof obj !== "object") {
    return obj
  }

  const result: any = {}

  Object.keys(obj).forEach((key) => {
    if (obj[key] === true) {
      result[key] = "Oui"
    } else if (obj[key] === false) {
      result[key] = "Non"
    } else {
      result[key] = obj[key]
    }
  })

  return result
}

// Fonction pour traiter les champs timestamp et convertir les chaînes vides en null
function handleTimestampFields(obj: any): any {
  if (obj === null || typeof obj !== "object") {
    return obj
  }

  const result: any = {}

  // Liste des champs timestamp
  const timestampFields = [
    "premierEmail",
    "premierWhatsapp",
    "secondEmail",
    "secondWhatsapp",
    "nhsTier4PremierEmail",
    "nhsTier4SecondEmail",
    "consultationDate",
    "operationDate",
    "lastCallDate",
    "nextFollowUp",
    "registrationDate",
  ]

  Object.keys(obj).forEach((key) => {
    // Si c'est un champ timestamp et qu'il est vide, le mettre à null
    if (timestampFields.includes(key) && (obj[key] === "" || obj[key] === undefined)) {
      result[key] = null
    } else {
      result[key] = obj[key]
    }
  })

  return result
}

// Fonction pour récupérer l'ID d'un closer par son nom
async function getCloserIdByName(closerName: string): Promise<string | null> {
  try {
    console.log(`Recherche du closer avec le nom: ${closerName}`)

    const { data, error } = await supabase
      .from("users")
      .select("id")
      .eq("full_name", closerName)
      .eq("role", "closer")
      .single()

    if (error) {
      console.error("Erreur lors de la récupération de l'ID du closer:", error)
      return null
    }

    if (!data) {
      console.error("Aucun closer trouvé avec ce nom:", closerName)
      return null
    }

    console.log(`Closer trouvé avec l'ID: ${data.id}`)
    return data.id
  } catch (error) {
    console.error("Exception lors de la récupération de l'ID du closer:", error)
    return null
  }
}

// Fonction pour récupérer l'ID d'un closer par son email
async function getCloserIdByEmail(closerEmail: string): Promise<string | null> {
  try {
    console.log(`Recherche du closer avec l'email: ${closerEmail}`)

    const { data, error } = await supabase
      .from("users")
      .select("id")
      .eq("email", closerEmail)
      .eq("role", "closer")
      .single()

    if (error) {
      console.error("Erreur lors de la récupération de l'ID du closer par email:", error)
      return null
    }

    if (!data) {
      console.error("Aucun closer trouvé avec cet email:", closerEmail)
      return null
    }

    console.log(`Closer trouvé avec l'ID: ${data.id}`)
    return data.id
  } catch (error) {
    console.error("Exception lors de la récupération de l'ID du closer par email:", error)
    return null
  }
}

// Fonction pour récupérer tous les closers
export async function getClosers(): Promise<{ id: string; name: string; email: string }[]> {
  try {
    const { data, error } = await supabase
      .from("users")
      .select("id, full_name, email")
      .eq("role", "closer")
      .order("full_name")

    if (error) {
      console.error("Erreur lors de la récupération des closers:", error)
      return []
    }

    return data.map((closer) => ({
      id: closer.id,
      name: closer.full_name,
      email: closer.email,
    }))
  } catch (error) {
    console.error("Exception lors de la récupération des closers:", error)
    return []
  }
}

// Fonction pour convertir les données de la base de données en objet Patient
function dbToAppPatient(dbPatient: any): Patient {
  // Convertir les noms de propriétés de snake_case à camelCase
  const camelCasePatient = snakeToCamelCase(dbPatient)

  return {
    id: camelCasePatient.id || "",
    name: camelCasePatient.fullName || "",
    email: camelCasePatient.email || "",
    phone: camelCasePatient.phone || "",
    status: camelCasePatient.status || "",
    platform: camelCasePatient.loanPlatform || "",
    doctor: camelCasePatient.doctor || "",
    notes: camelCasePatient.notes || "",
    // Utiliser des valeurs par défaut pour les champs qui pourraient ne pas exister
    created_at: camelCasePatient.createdAt || new Date().toISOString(),
    updated_at: camelCasePatient.updatedAt || new Date().toISOString(),
    closer: camelCasePatient.closerName || "",
    closerId: camelCasePatient.closerId || "",
    // Champs de suivi
    lastCallDate: camelCasePatient.lastCallDate,
    callCount: camelCasePatient.callCount || 0,
    appointmentScheduled: camelCasePatient.appointmentScheduled,
    operationDate: camelCasePatient.operationDate,
    // Autres champs possibles
    consultationDate: camelCasePatient.consultationDate,
    income: camelCasePatient.revenue,
    expenses: camelCasePatient.expenses,
    creditScore: camelCasePatient.creditScore,
    creditPlatform: camelCasePatient.creditScorePlatform,
    loanAmount: camelCasePatient.loanAmount,
    simulationValidated: camelCasePatient.loanSimulationValidated,
    loanRequested: camelCasePatient.loanRequested,
    nextFollowUp: camelCasePatient.nextFollowUp,
    // Suppression du champ commentaires
    registrationDate: camelCasePatient.registrationDate,
    validated: camelCasePatient.validatedByAdmin ? true : false,
    // New fields
    suiteGroupe: camelCasePatient.suiteGroupe,
    poids: camelCasePatient.poids,
    taille: camelCasePatient.taille,
    bmi: camelCasePatient.bmi,
    chirurgie: camelCasePatient.chirurgie,
    qualification: camelCasePatient.qualification,
    rdvObtenuPar: camelCasePatient.rdvObtenuPar,
    premierEmail: camelCasePatient.premierEmail,
    premierWhatsapp: camelCasePatient.premierWhatsapp,
    secondEmail: camelCasePatient.secondEmail,
    secondWhatsapp: camelCasePatient.secondWhatsapp,
    // Correction des champs booléens
    factureEnvoye: camelCasePatient.factureEnvoye,
    medicalAgrement: camelCasePatient.medicalAgrement,
    consentForm: camelCasePatient.consentForm,
    autorisationPatientS2: camelCasePatient.autorisationPatientS2,
    compteRenduHospitalisation: camelCasePatient.compteRenduHospitalisation,
    compteRenduConsultation: camelCasePatient.compteRenduConsultation,
    emailPatientGp: camelCasePatient.emailPatientGp,
    patientS2Form: camelCasePatient.patientS2Form,
    lettreGp: camelCasePatient.lettreGp,
    s2SaintJames: camelCasePatient.s2SaintJames,
    nhsTier4PremierEmail: camelCasePatient.nhsTier4PremierEmail,
    nhsTier4SecondEmail: camelCasePatient.nhsTier4SecondEmail,
  }
}

// Add this function to check if a user has admin permissions
export function isAdmin(user: any): boolean {
  return user && user.role === "admin"
}

// Then modify the getPatients function to handle schema refresh if needed
export async function getPatients(userId: string, userRole: string): Promise<Patient[]> {
  try {
    console.log(`Récupération des patients pour l'utilisateur ${userId}, rôle: ${userRole}`)

    // En production, utiliser Supabase
    console.log("Récupération des patients depuis Supabase")

    try {
      // Essayer d'abord de rafraîchir le cache du schéma pour éviter les problèmes de relation
      await refreshSchemaCache()

      // Construire une requête simplifiée sans relations pour éviter les erreurs de cache
      let query = supabase.from("patients").select("*").order("created_at", { ascending: false })

      // Si l'utilisateur n'est pas admin, filtrer par closer_id
      if (userRole !== "admin" && userId) {
        // Si l'utilisateur est un closer, montrer seulement ses patients
        query = query.eq("closer_id", userId)
      }

      const { data, error } = await query

      if (error) {
        console.error("Erreur Supabase lors de la récupération:", error)
        throw new Error(`Erreur Supabase lors de la récupération: ${error.message}`)
      }

      // Récupérer les informations des closers séparément
      const closerIds = data
        .map((patient) => patient.closer_id)
        .filter((id) => id !== null && id !== undefined)
        .filter((id, index, self) => self.indexOf(id) === index) // Unique IDs

      let closerMap: Record<string, any> = {}

      if (closerIds.length > 0) {
        const { data: closers, error: closersError } = await supabase
          .from("users")
          .select("id, full_name, email")
          .in("id", closerIds)

        if (!closersError && closers) {
          closerMap = closers.reduce(
            (map, closer) => {
              map[closer.id] = closer
              return map
            },
            {} as Record<string, any>,
          )
        }
      }

      // Convertir les données en objets Patient
      const patients = data.map((patient) => {
        // Ajouter le nom du closer à partir de la map
        const closer = patient.closer_id ? closerMap[patient.closer_id] : null

        const patientWithCloserInfo = {
          ...patient,
          closer_name: closer ? closer.full_name : "Non assigné",
          closer_id: patient.closer_id || null,
        }

        return dbToAppPatient(patientWithCloserInfo)
      })

      return patients
    } catch (error: any) {
      console.error("Erreur lors de la récupération des patients:", error)

      // Si l'erreur persiste après le rafraîchissement, essayer une requête encore plus simple
      if (
        error.message &&
        (error.message.includes("relationship") ||
          error.message.includes("does not exist") ||
          error.message.includes("missing"))
      ) {
        console.log("Tentative de récupération sans relations...")

        // Requête de secours ultra-simplifiée
        const { data: fallbackData, error: fallbackError } = await supabase
          .from("patients")
          .select("*")
          .order("created_at", { ascending: false })

        if (fallbackError) {
          console.error("Erreur lors de la récupération de secours:", fallbackError)
          return []
        }

        // Convertir les données en objets Patient sans informations de closer
        const patients = fallbackData.map((patient) => {
          const patientWithCloserInfo = {
            ...patient,
            closer_name: "Information non disponible",
            closer_id: patient.closer_id || null,
          }
          return dbToAppPatient(patientWithCloserInfo)
        })

        return patients
      }

      return []
    }
  } catch (error: any) {
    console.error("Erreur inattendue lors de la récupération des patients:", error)
    return []
  }
}

// Fonction pour calculer les statistiques des patients
// Fonction simplifiée pour soumettre un patient
export async function submitPatient(
  patientData: Patient,
  validate = false,
): Promise<{ success: boolean; message?: string; error?: any; validationErrors?: ValidationError[] }> {
  try {
    console.log("Données patient reçues:", patientData)

    // 1. Vérifier que l'utilisateur est authentifié
    const { data: authData } = await supabase.auth.getUser()
    if (!authData.user) {
      return {
        success: false,
        message: "Vous devez être connecté pour ajouter un patient",
      }
    }

    // 2. Valider les données du patient
    const validationErrors = validatePatientData(patientData)
    if (validationErrors.length > 0) {
      await logError("submitPatient_validation", patientData, { validationErrors })
      return {
        success: false,
        message: "Erreurs de validation. Veuillez corriger les champs indiqués.",
        validationErrors,
      }
    }

    // 3. Récupérer les informations de l'utilisateur connecté
    const { data: userData, error: userError } = await supabase
      .from("users")
      .select("id, role, full_name")
      .eq("id", authData.user.id)
      .single()

    if (userError) {
      console.error("Erreur lors de la récupération des informations de l'utilisateur:", userError)
      await logError("submitPatient_userInfo", patientData, userError)
      return {
        success: false,
        message: "Erreur lors de la récupération des informations de l'utilisateur",
      }
    }

    const isAdmin = userData.role === "admin"
    const userId = userData.id

    // 4. Récupérer l'ID du closer
    let closerId: string | null = null

    // Si un nom de closer est fourni, rechercher son ID
    if (patientData.closer) {
      console.log(`Recherche du closer: ${patientData.closer}`)

      // Essayer de trouver par nom d'abord
      closerId = await getCloserIdByName(patientData.closer)

      if (closerId) {
        console.log(`Closer trouvé par nom avec ID: ${closerId}`)
      } else {
        console.log(`Closer non trouvé par nom, essai par email`)
        // Si non trouvé par nom, essayer par email
        closerId = await getCloserIdByEmail(patientData.closer)

        if (closerId) {
          console.log(`Closer trouvé par email avec ID: ${closerId}`)
        } else {
          console.log(`Closer non trouvé par email non plus`)
        }
      }
    }

    // Si aucun closer n'est trouvé et que l'utilisateur est un closer, utiliser son ID
    if (!closerId && userData.role === "closer") {
      console.log(`Utilisation de l'ID de l'utilisateur connecté comme closer: ${userId}`)
      closerId = userId
    }

    // Si toujours pas de closer, retourner une erreur
    if (!closerId) {
      await logError("submitPatient_closerNotFound", patientData, { message: "Closer introuvable ou invalide" })
      return {
        success: false,
        message: "Erreur : closer introuvable ou invalide.",
        validationErrors: [{ field: "closer", message: "Closer introuvable ou invalide" }],
      }
    }

    // Vérifier si l'utilisateur est admin pour la validation
    if (validate && !isAdmin) {
      await logError("submitPatient_notAdmin", patientData, { message: "Validation impossible: utilisateur non admin" })
      return {
        success: false,
        message: "Impossible de valider : aucun admin connecté.",
      }
    }

    // Définir un statut par défaut si aucun n'est fourni
    if (!patientData.status) {
      patientData.status = "en_attente"
    }

    // Standardiser le nom du médecin
    if (patientData.doctor) {
      patientData.doctor = standardizeDoctorName(patientData.doctor)
    }

    // Préparation des données pour Supabase
    const dataToInsert: any = {
      full_name: patientData.name,
      email: patientData.email,
      doctor: patientData.doctor || "",
      status: patientData.status || "en_attente",
      closer_id: closerId,
    }

    // Si l'utilisateur est admin, ajouter son ID comme created_by_admin
    if (isAdmin) {
      dataToInsert.created_by_admin = userId

      // Si la validation est demandée, ajouter son ID comme validated_by_admin
      if (validate) {
        dataToInsert.validated_by_admin = userId
      }
    }

    // Ajouter les champs de suivi
    if (patientData.lastCallDate !== undefined) dataToInsert.last_call_date = patientData.lastCallDate
    if (patientData.callCount !== undefined) dataToInsert.call_count = patientData.callCount
    if (patientData.appointmentScheduled !== undefined) {
      dataToInsert.appointment_scheduled =
        patientData.appointmentScheduled === "Oui" ? true : patientData.appointmentScheduled === true ? true : false
    }
    if (patientData.operationDate !== undefined) dataToInsert.operation_date = patientData.operationDate

    // Ajouter les champs optionnels s'ils sont définis et non vides
    if (patientData.phone !== undefined) dataToInsert.phone = patientData.phone
    if (patientData.platform !== undefined) dataToInsert.loan_platform = patientData.platform
    if (patientData.notes !== undefined) dataToInsert.notes = patientData.notes
    if (patientData.consultationDate)
      dataToInsert.consultation_date = patientData.consultationDate === "" ? null : patientData.consultationDate
    if (patientData.registrationDate)
      dataToInsert.registration_date = patientData.registrationDate === "" ? null : patientData.registrationDate
    if (patientData.income !== undefined) dataToInsert.revenue = patientData.income
    if (patientData.expenses !== undefined) dataToInsert.expenses = patientData.expenses
    if (patientData.creditScore !== undefined) dataToInsert.credit_score = patientData.creditScore
    if (patientData.creditPlatform !== undefined) dataToInsert.credit_score_platform = patientData.creditPlatform
    if (patientData.loanAmount !== undefined) dataToInsert.loan_amount = patientData.loanAmount
    if (patientData.nextFollowUp)
      dataToInsert.next_follow_up = patientData.nextFollowUp === "" ? null : patientData.nextFollowUp
    if (patientData.comments !== undefined) dataToInsert.comments = patientData.comments

    // Conversion des valeurs "Oui"/"Non" en booléens
    if (patientData.simulationValidated !== undefined) {
      dataToInsert.loan_simulation_validated = patientData.simulationValidated === "Oui" ? true : false
    }
    if (patientData.loanRequested !== undefined) {
      dataToInsert.loan_requested = patientData.loanRequested === "Oui" ? true : false
    }

    // Add new fields
    if (patientData.suiteGroupe !== undefined) dataToInsert.suite_groupe = patientData.suiteGroupe
    if (patientData.poids !== undefined) dataToInsert.poids = patientData.poids
    if (patientData.taille !== undefined) dataToInsert.taille = patientData.taille
    if (patientData.bmi !== undefined) dataToInsert.bmi = patientData.bmi
    if (patientData.chirurgie !== undefined) dataToInsert.chirurgie = patientData.chirurgie
    if (patientData.qualification !== undefined) dataToInsert.qualification = patientData.qualification
    if (patientData.rdvObtenuPar !== undefined) dataToInsert.rdv_obtenu_par = patientData.rdvObtenuPar

    // Gestion explicite des champs timestamp
    if (patientData.premierEmail !== undefined)
      dataToInsert.premier_email = patientData.premierEmail === "" ? null : patientData.premierEmail
    if (patientData.premierWhatsapp !== undefined)
      dataToInsert.premier_whatsapp = patientData.premierWhatsapp === "" ? null : patientData.premierWhatsapp
    if (patientData.secondEmail !== undefined)
      dataToInsert.second_email = patientData.secondEmail === "" ? null : patientData.secondEmail
    if (patientData.secondWhatsapp !== undefined)
      dataToInsert.second_whatsapp = patientData.secondWhatsapp === "" ? null : patientData.secondWhatsapp
    if (patientData.nhsTier4PremierEmail !== undefined)
      dataToInsert.nhs_tier4_premier_email =
        patientData.nhsTier4PremierEmail === "" ? null : patientData.nhsTier4PremierEmail
    if (patientData.nhsTier4SecondEmail !== undefined)
      dataToInsert.nhs_tier4_second_email =
        patientData.nhsTier4SecondEmail === "" ? null : patientData.nhsTier4SecondEmail

    // Gestion des champs booléens
    if (patientData.factureEnvoye !== undefined) {
      dataToInsert.facture_envoye =
        patientData.factureEnvoye === "Oui" ? true : patientData.factureEnvoye === true ? true : false
    }
    if (patientData.medicalAgrement !== undefined) {
      dataToInsert.medical_agrement =
        patientData.medicalAgrement === "Oui" ? true : patientData.medicalAgrement === true ? true : false
    }
    if (patientData.consentForm !== undefined) {
      dataToInsert.consent_form =
        patientData.consentForm === "Oui" ? true : patientData.consentForm === true ? true : false
    }
    if (patientData.autorisationPatientS2 !== undefined) {
      dataToInsert.autorisation_patient_s2 =
        patientData.autorisationPatientS2 === "Oui" ? true : patientData.autorisationPatientS2 === true ? true : false
    }
    if (patientData.compteRenduHospitalisation !== undefined)
      dataToInsert.compte_rendu_hospitalisation =
        patientData.compteRenduHospitalisation === "Oui"
          ? true
          : patientData.compteRenduHospitalisation === true
            ? true
            : false
    if (patientData.compteRenduConsultation !== undefined)
      dataToInsert.compte_rendu_consultation =
        patientData.compteRenduConsultation === "Oui"
          ? true
          : patientData.compteRenduConsultation === true
            ? true
            : false
    if (patientData.emailPatientGp !== undefined)
      dataToInsert.email_patient_gp =
        patientData.emailPatientGp === "Oui" ? true : patientData.emailPatientGp === true ? true : false
    if (patientData.patientS2Form !== undefined)
      dataToInsert.patient_s2_form =
        patientData.patientS2Form === "Oui" ? true : patientData.patientS2Form === true ? true : false
    if (patientData.lettreGp !== undefined)
      dataToInsert.lettre_gp = patientData.lettreGp === "Oui" ? true : patientData.lettreGp === true ? true : false
    if (patientData.s2SaintJames !== undefined)
      dataToInsert.s2_saint_james =
        patientData.s2SaintJames === "Oui" ? true : patientData.s2SaintJames === true ? true : false

    console.log("Données préparées pour insertion:", dataToInsert)

    // Insertion dans Supabase
    const { data, error } = await supabase.from("patients").insert([dataToInsert])

    if (error) {
      console.error("Erreur Supabase lors de l'insertion:", error)
      await logError("submitPatient_insertError", dataToInsert, error)

      // Analyser l'erreur pour fournir un message plus précis
      let errorMessage = `Erreur lors de l'ajout du patient: ${error.message}`
      const fieldErrors: ValidationError[] = []

      if (error.message.includes("violates foreign key constraint")) {
        if (error.message.includes("closer_id")) {
          errorMessage = "Le commercial assigné n'existe pas dans la base de données."
          fieldErrors.push({ field: "closer", message: "Commercial invalide" })
        } else if (error.message.includes("created_by_admin")) {
          errorMessage = "L'administrateur spécifié n'existe pas dans la base de données."
        }
      } else if (error.message.includes("violates check constraint")) {
        if (error.message.includes("status")) {
          errorMessage = "Le statut spécifié n'est pas valide."
          fieldErrors.push({ field: "status", message: "Statut invalide" })
        } else if (error.message.includes("qualification")) {
          errorMessage = "La qualification spécifiée n'est pas valide."
          fieldErrors.push({ field: "qualification", message: "Qualification invalide" })
        }
      } else if (error.message.includes("violates not-null constraint")) {
        const match = error.message.match(/column "([^"]+)"/)
        if (match && match[1]) {
          const fieldName = match[1]
          errorMessage = `Le champ ${fieldName} est obligatoire.`
          fieldErrors.push({ field: fieldName, message: "Champ obligatoire" })
        }
      } else if (error.message.includes("invalid input syntax for type timestamp")) {
        errorMessage = "Format de date invalide. Assurez-vous que tous les champs de date sont correctement formatés."
        fieldErrors.push({ field: "timestamp", message: "Format de date invalide" })
      }

      return {
        success: false,
        message: errorMessage,
        error,
        validationErrors: fieldErrors.length > 0 ? fieldErrors : undefined,
      }
    }

    console.log("Patient ajouté avec succès:", data)
    return {
      success: true,
      message: "Patient ajouté avec succès",
    }
  } catch (error: any) {
    console.error("Exception lors de la soumission:", error)
    await logError("submitPatient_exception", patientData, error)
    return {
      success: false,
      message: `Exception lors de l'ajout du patient: ${error.message}`,
      error,
    }
  }
}

// Fonction pour mettre à jour un patient avec vérification des permissions
// Améliorer la fonction de formatage des dates pour gérer les valeurs nulles ou vides
const formatDateTimeWithTimezone = (dateTimeString: string | undefined | null): string | null => {
  if (!dateTimeString || dateTimeString === "") return null

  try {
    const date = new Date(dateTimeString)
    // Format ISO avec timezone
    return date.toISOString()
  } catch (error) {
    console.error("Erreur de formatage de date:", error)
    return null
  }
}

// Modifier la fonction updatePatient pour mieux gérer les champs vides
export async function updatePatient(
  patientId: string,
  patientData: Partial<Patient>,
  user: any,
): Promise<{ success: boolean; message?: string; error?: any; validationErrors?: ValidationError[] }> {
  try {
    console.log(`Mise à jour du patient ${patientId}:`, patientData)

    // 1. Vérifier que l'utilisateur est authentifié
    if (!user || !user.id) {
      return {
        success: false,
        message: "Vous devez être connecté pour modifier un patient",
      }
    }

    // 2. Valider les données du patient
    const validationErrors = validatePatientData(patientData)
    if (validationErrors.length > 0) {
      await logError("updatePatient_validation", { patientId, patientData }, { validationErrors })
      return {
        success: false,
        message: "Erreurs de validation. Veuillez corriger les champs indiqués.",
        validationErrors,
      }
    }

    // 3. Vérifier si l'utilisateur a le droit de modifier ce patient
    const isUserAdmin = user.role === "admin"

    if (!isUserAdmin) {
      // Récupérer le patient pour vérifier le closer_id
      const { data: patientRecord, error: patientError } = await supabase
        .from("patients")
        .select("closer_id")
        .eq("id", patientId)
        .single()

      if (patientError) {
        console.error("Erreur lors de la récupération du patient:", patientError)
        await logError("updatePatient_retrieveError", { patientId, patientData }, patientError)
        return {
          success: false,
          message: "Erreur lors de la récupération du patient",
        }
      }

      // Vérifier que l'utilisateur est bien le closer de ce patient
      if (patientRecord.closer_id !== user.id) {
        await logError(
          "updatePatient_unauthorized",
          { patientId, patientData, userId: user.id },
          { message: "Utilisateur non autorisé" },
        )
        return {
          success: false,
          message: "Vous n'êtes pas autorisé à modifier ce patient",
        }
      }
    }

    // Standardiser le nom du médecin
    if (patientData.doctor) {
      patientData.doctor = standardizeDoctorName(patientData.doctor)
    }

    // 4. Préparer les données pour la mise à jour
    const dataToUpdate: any = {}

    // Mettre à jour les champs de base
    if (patientData.name !== undefined) dataToUpdate.full_name = patientData.name
    if (patientData.email !== undefined) dataToUpdate.email = patientData.email
    if (patientData.doctor !== undefined) dataToUpdate.doctor = patientData.doctor
    if (patientData.status !== undefined) dataToUpdate.status = patientData.status
    if (patientData.phone !== undefined) dataToUpdate.phone = patientData.phone
    if (patientData.platform !== undefined) dataToUpdate.loan_platform = patientData.platform
    if (patientData.notes !== undefined) dataToUpdate.notes = patientData.notes

    // Mettre à jour les champs de suivi
    if (patientData.lastCallDate !== undefined) dataToUpdate.last_call_date = patientData.lastCallDate
    if (patientData.callCount !== undefined) dataToUpdate.call_count = patientData.callCount
    if (patientData.appointmentScheduled !== undefined) {
      dataToUpdate.appointment_scheduled =
        patientData.appointmentScheduled === "Oui" ? true : patientData.appointmentScheduled === true ? true : false
    }
    if (patientData.operationDate !== undefined) dataToUpdate.operation_date = patientData.operationDate

    // Mettre à jour les autres champs
    if (patientData.consultationDate !== undefined) dataToUpdate.consultation_date = patientData.consultationDate
    if (patientData.registrationDate !== undefined) dataToUpdate.registration_date = patientData.registrationDate
    if (patientData.income !== undefined) dataToUpdate.revenue = patientData.income
    if (patientData.expenses !== undefined) dataToUpdate.expenses = patientData.expenses
    if (patientData.creditScore !== undefined) dataToUpdate.credit_score = patientData.creditScore
    if (patientData.creditPlatform !== undefined) dataToUpdate.credit_score_platform = patientData.creditPlatform
    if (patientData.loanAmount !== undefined) dataToUpdate.loan_amount = patientData.loanAmount
    if (patientData.nextFollowUp !== undefined) dataToUpdate.next_follow_up = patientData.nextFollowUp
    if (patientData.comments !== undefined) dataToUpdate.comments = patientData.comments

    // Conversion des valeurs "Oui"/"Non" en booléens
    if (patientData.simulationValidated !== undefined) {
      dataToUpdate.loan_simulation_validated = patientData.simulationValidated === "Oui" ? true : false
    }
    if (patientData.loanRequested !== undefined) {
      dataToUpdate.loan_requested = patientData.loanRequested === "Oui" ? true : false
    }

    // Add new fields
    if (patientData.suiteGroupe !== undefined) dataToUpdate.suite_groupe = patientData.suiteGroupe
    if (patientData.poids !== undefined) dataToUpdate.poids = patientData.poids
    if (patientData.taille !== undefined) dataToUpdate.taille = patientData.taille
    if (patientData.bmi !== undefined) dataToUpdate.bmi = patientData.bmi
    if (patientData.chirurgie !== undefined) dataToUpdate.chirurgie = patientData.chirurgie
    if (patientData.qualification !== undefined) dataToUpdate.qualification = patientData.qualification
    if (patientData.rdvObtenuPar !== undefined) dataToUpdate.rdv_obtenu_par = patientData.rdvObtenuPar

    // Gestion explicite des champs timestamp
    if (patientData.premierEmail !== undefined) dataToUpdate.premier_email = patientData.premierEmail
    if (patientData.premierWhatsapp !== undefined) dataToUpdate.premier_whatsapp = patientData.premierWhatsapp
    if (patientData.secondEmail !== undefined) dataToUpdate.second_email = patientData.secondEmail
    if (patientData.secondWhatsapp !== undefined) dataToUpdate.second_whatsapp = patientData.secondWhatsapp
    if (patientData.nhsTier4PremierEmail !== undefined)
      dataToUpdate.nhs_tier4_premier_email = patientData.nhsTier4PremierEmail
    if (patientData.nhsTier4SecondEmail !== undefined)
      dataToUpdate.nhs_tier4_second_email = patientData.nhsTier4SecondEmail

    // Gestion des champs booléens
    if (patientData.factureEnvoye !== undefined) {
      dataToUpdate.facture_envoye =
        patientData.factureEnvoye === "Oui" ? true : patientData.factureEnvoye === true ? true : false
    }
    if (patientData.medicalAgrement !== undefined) {
      dataToUpdate.medical_agrement =
        patientData.medicalAgrement === "Oui" ? true : patientData.medicalAgrement === true ? true : false
    }
    if (patientData.consentForm !== undefined) {
      dataToUpdate.consent_form =
        patientData.consentForm === "Oui" ? true : patientData.consentForm === true ? true : false
    }
    if (patientData.autorisationPatientS2 !== undefined) {
      dataToUpdate.autorisation_patient_s2 =
        patientData.autorisationPatientS2 === "Oui" ? true : patientData.autorisationPatientS2 === true ? true : false
    }
    if (patientData.compteRenduHospitalisation !== undefined)
      dataToUpdate.compte_rendu_hospitalisation =
        patientData.compteRenduHospitalisation === "Oui"
          ? true
          : patientData.compteRenduHospitalisation === true
            ? true
            : false
    if (patientData.compteRenduConsultation !== undefined)
      dataToUpdate.compte_rendu_consultation =
        patientData.compteRenduConsultation === "Oui"
          ? true
          : patientData.compteRenduConsultation === true
            ? true
            : false
    if (patientData.emailPatientGp !== undefined)
      dataToUpdate.email_patient_gp =
        patientData.emailPatientGp === "Oui" ? true : patientData.emailPatientGp === true ? true : false
    if (patientData.patientS2Form !== undefined)
      dataToUpdate.patient_s2_form =
        patientData.patientS2Form === "Oui" ? true : patientData.patientS2Form === true ? true : false
    if (patientData.lettreGp !== undefined)
      dataToUpdate.lettre_gp = patientData.lettreGp === "Oui" ? true : patientData.lettreGp === true ? true : false
    if (patientData.s2SaintJames !== undefined)
      dataToUpdate.s2_saint_james =
        patientData.s2SaintJames === "Oui" ? true : patientData.s2SaintJames === true ? true : false

    console.log("Données préparées pour mise à jour:", dataToUpdate)

    // 5. Mettre à jour le patient dans Supabase
    const { error } = await supabase.from("patients").update(dataToUpdate).eq("id", patientId)

    if (error) {
      console.error("Erreur Supabase lors de la mise à jour:", error)
      await logError("updatePatient_updateError", { patientId, dataToUpdate }, error)

      // Analyser l'erreur pour fournir un message plus précis
      let errorMessage = `Erreur lors de la mise à jour du patient: ${error.message}`
      const fieldErrors: ValidationError[] = []

      if (error.message.includes("violates foreign key constraint")) {
        if (error.message.includes("closer_id")) {
          errorMessage = "Le commercial assigné n'existe pas dans la base de données."
          fieldErrors.push({ field: "closer", message: "Commercial invalide" })
        }
      } else if (error.message.includes("violates check constraint")) {
        if (error.message.includes("status")) {
          errorMessage = "Le statut spécifié n'est pas valide."
          fieldErrors.push({ field: "status", message: "Statut invalide" })
        } else if (error.message.includes("qualification")) {
          errorMessage = "La qualification spécifiée n'est pas valide."
          fieldErrors.push({ field: "qualification", message: "Qualification invalide" })
        }
      } else if (error.message.includes("invalid input syntax for type timestamp")) {
        errorMessage = "Format de date invalide. Assurez-vous que tous les champs de date sont correctement formatés."
        fieldErrors.push({ field: "timestamp", message: "Format de date invalide" })
      }

      return {
        success: false,
        message: errorMessage,
        error,
        validationErrors: fieldErrors.length > 0 ? fieldErrors : undefined,
      }
    }

    return {
      success: true,
      message: "Patient mis à jour avec succès",
    }
  } catch (error: any) {
    console.error("Exception lors de la mise à jour:", error)
    await logError("updatePatient_exception", { patientId, patientData }, error)
    return {
      success: false,
      message: `Exception lors de la mise à jour du patient: ${error.message}`,
      error,
    }
  }
}

// Fonction pour valider un patient (pour les admins)
export async function validatePatient(patientId: string): Promise<{ success: boolean; message?: string }> {
  try {
    // Vérifier que l'utilisateur est authentifié et est un admin
    const { data: authData } = await supabase.auth.getUser()
    if (!authData.user) {
      return {
        success: false,
        message: "Vous devez être connecté pour valider un patient",
      }
    }

    // Récupérer les informations de l'utilisateur connecté
    const { data: userData, error: userError } = await supabase
      .from("users")
      .select("id, role")
      .eq("id", authData.user.id)
      .single()

    if (userError || userData.role !== "admin") {
      await logError("validatePatient_notAdmin", { patientId }, userError || { message: "Utilisateur non admin" })
      return {
        success: false,
        message: "Vous devez être administrateur pour valider un patient",
      }
    }

    // Mettre à jour le patient
    const { error } = await supabase.from("patients").update({ validated_by_admin: userData.id }).eq("id", patientId)

    if (error) {
      console.error("Erreur lors de la validation du patient:", error)
      await logError("validatePatient_updateError", { patientId }, error)
      return {
        success: false,
        message: `Erreur lors de la validation du patient: ${error.message}`,
      }
    }

    return {
      success: true,
      message: "Patient validé avec succès",
    }
  } catch (error: any) {
    console.error("Exception lors de la validation du patient:", error)
    await logError("validatePatient_exception", { patientId }, error)
    return {
      success: false,
      message: `Exception lors de la validation du patient: ${error.message}`,
    }
  }
}

// Mettre à jour la fonction logPatientCall pour permettre la mise à jour du statut et des commentaires
export async function logPatientCall(
  patientId: string,
  callData: { date: string; notes: string; status?: string },
): Promise<{ success: boolean; message?: string }> {
  try {
    console.log(`Enregistrement d'un appel pour le patient ${patientId}:`, callData)

    // Vérifier que l'utilisateur est authentifié
    const { data: authData } = await supabase.auth.getUser()
    if (!authData.user) {
      return {
        success: false,
        message: "Vous devez être connecté pour enregistrer un appel",
      }
    }

    // Récupérer les informations de l'utilisateur connecté
    const { data: userData, error: userError } = await supabase
      .from("users")
      .select("id, role")
      .eq("id", authData.user.id)
      .single()

    if (userError) {
      console.error("Erreur lors de la récupération des informations de l'utilisateur:", userError)
      await logError("logPatientCall_userInfo", { patientId, callData }, userError)
      return {
        success: false,
        message: "Erreur lors de la récupération des informations de l'utilisateur",
      }
    }

    // Vérifier si l'utilisateur est admin ou closer
    const isAdmin = userData.role === "admin"
    const isCloser = userData.role === "closer"

    // Vérifier les permissions
    if (!isAdmin && !isCloser) {
      await logError("logPatientCall_unauthorized", { patientId, callData }, { message: "Utilisateur non autorisé" })
      return {
        success: false,
        message: "Vous n'avez pas les permissions nécessaires pour enregistrer un appel",
      }
    }

    // Préparer les données pour la mise à jour
    const dataToUpdate: any = {
      last_call_date: callData.date,
      call_count: supabase.postgrest
        .select("call_count")
        .from("patients")
        .eq("id", patientId)
        .then((res) => {
          return res.data[0].call_count + 1
        }),
    }

    // Mettre à jour le statut si fourni
    if (callData.status) {
      dataToUpdate.status = callData.status
    }

    // Ajouter les notes
    if (callData.notes) {
      dataToUpdate.comments = `${dataToUpdate.comments || ""}
${callData.date} - ${callData.notes}`
    }

    // Mettre à jour le patient dans Supabase
    const { error } = await supabase.from("patients").update(dataToUpdate).eq("id", patientId)

    if (error) {
      console.error("Erreur lors de la mise à jour du patient:", error)
      await logError("logPatientCall_updateError", { patientId, dataToUpdate }, error)
      return {
        success: false,
        message: `Erreur lors de la mise à jour du patient: ${error.message}`,
      }
    }

    return {
      success: true,
      message: "Appel enregistré avec succès",
    }
  } catch (error: any) {
    console.error("Exception lors de l'enregistrement de l'appel:", error)
    await logError("logPatientCall_exception", { patientId, callData }, error)
    return {
      success: false,
      message: `Exception lors de l'enregistrement de l'appel: ${error.message}`,
    }
  }
}

// Fonction pour supprimer un patient
export async function deletePatient(patientId: string, user: any): Promise<{ success: boolean; message?: string }> {
  try {
    console.log(`Suppression du patient ${patientId}`)

    // Vérifier que l'utilisateur est authentifié et est un admin
    if (!user || !user.id) {
      return {
        success: false,
        message: "Vous devez être connecté pour supprimer un patient",
      }
    }

    // Vérifier les permissions
    if (user.role !== "admin") {
      await logError("deletePatient_unauthorized", { patientId, userId: user.id }, { message: "Utilisateur non admin" })
      return {
        success: false,
        message: "Vous n'avez pas les permissions nécessaires pour supprimer un patient",
      }
    }

    const { error } = await supabase.from("patients").delete().eq("id", patientId)

    if (error) {
      console.error("Erreur lors de la suppression du patient:", error)
      await logError("deletePatient_deleteError", { patientId }, error)
      return {
        success: false,
        message: `Erreur lors de la suppression du patient: ${error.message}`,
      }
    }

    return {
      success: true,
      message: "Patient supprimé avec succès",
    }
  } catch (error: any) {
    console.error("Exception lors de la suppression du patient:", error)
    await logError("deletePatient_exception", { patientId }, error)
    return {
      success: false,
      message: `Exception lors de la suppression du patient: ${error.message}`,
    }
  }
}

// Ajouter cette fonction pour mettre à jour le statut d'un patient
export async function updatePatientStatus(patientId: string, status: string) {
  try {
    const { error } = await supabase.from("patients").update({ status }).eq("id", patientId)

    if (error) {
      console.error("Erreur lors de la mise à jour du statut:", error)
      await logError("updatePatientStatus_updateError", { patientId, status }, error)
      throw new Error(`Erreur lors de la mise à jour du statut: ${error.message}`)
    }

    return true
  } catch (error: any) {
    console.error("Exception lors de la mise à jour du statut:", error)
    await logError("updatePatientStatus_exception", { patientId, status }, error)
    throw error
  }
}

// Dans votre fonction d'insertion ou de mise à jour de patient, ajoutez:

// De même pour la fonction d'insertion:
export async function createPatient(patientData: any) {
  try {
    // Nettoyez les données avant de les envoyer à Supabase
    const cleanedData = cleanPatientDataForSupabase(patientData)

    const { data, error } = await supabase.from("patients").insert(cleanedData).select()

    if (error) throw error
    return { success: true, data }
  } catch (error) {
    console.error("Error creating patient:", error)
    return { success: false, error }
  }
}

// Ajoutons une fonction pour s'assurer que les données sont correctement formatées

// Ajouter cette fonction à la fin du fichier:

export async function getPatientStats(userId?: string, isAdmin = false) {
  try {
    // Utiliser la fonction existante pour obtenir les statistiques complètes
    const stats = await getCompletePatientStatistics(
      {}, // Pas de filtres par défaut
      userId,
      isAdmin ? "admin" : "closer",
    )

    // Formater les données pour le dashboard
    return {
      total: stats.totalPatients,
      conversionRate: stats.conversionRate,
      callsMade: 0, // Ces données ne sont pas disponibles dans getCompletePatientStatistics
      appointmentsScheduled: stats.statusCounts.find((s) => s.status === "RDV programmé")?.count || 0,
      statusCounts: stats.statusCounts,
      doctorDistribution: stats.doctorDistribution,
      closerPerformance: stats.closerPerformance,
    }
  } catch (error) {
    console.error("Erreur lors de la récupération des statistiques:", error)
    return {
      total: 0,
      conversionRate: 0,
      callsMade: 0,
      appointmentsScheduled: 0,
      statusCounts: [],
      doctorDistribution: [],
      closerPerformance: [],
    }
  }
}

// Fonction pour calculer les statistiques complètes des patients
export async function getCompletePatientStatistics(
  filters: any, // Ajout de l'argument filters
  userId?: string,
  userRole = "closer",
): Promise<any> {
  try {
    console.log(`Récupération des statistiques complètes des patients pour l'utilisateur ${userId}, rôle: ${userRole}`)

    // Obtenir les patients en fonction du rôle de l'utilisateur
    let patients: Patient[] = []
    if (userRole === "admin") {
      // Si l'utilisateur est un admin, récupérer tous les patients
      patients = await getPatients(userId || "", userRole)
    } else if (userId) {
      // Si l'utilisateur est un closer, récupérer uniquement ses patients
      patients = await getPatients(userId, userRole)
    } else {
      console.warn("Aucun userId fourni, impossible de filtrer les patients.")
      return {
        totalPatients: 0,
        statusCounts: [],
        doctorDistribution: [],
        closerPerformance: [],
        conversionRate: 0,
      }
    }

    // Filtrer les patients en fonction des filtres fournis
    let filteredPatients = patients
    if (filters) {
      filteredPatients = patients.filter((patient) => {
        let match = true

        // Vérifier chaque filtre
        for (const key in filters) {
          if (filters.hasOwnProperty(key)) {
            const filterValue = filters[key]

            // Gérer différents types de filtres
            if (key === "status") {
              match = match && patient.status === filterValue
            } else if (key === "doctor") {
              match = match && patient.doctor === filterValue
            } else if (key === "platform") {
              match = match && patient.platform === filterValue
            }
            // Ajoutez d'autres conditions pour d'autres filtres
          }
        }

        return match
      })
    }

    // Calculer le nombre total de patients
    const totalPatients = filteredPatients.length

    // Calculer les statistiques par statut
    const statusCounts: { status: string; count: number }[] = []
    const statusMap: { [key: string]: number } = {}
    filteredPatients.forEach((patient) => {
      const status = patient.status || "non_defini"
      if (statusMap[status]) {
        statusMap[status]++
      } else {
        statusMap[status] = 1
      }
    })
    for (const status in statusMap) {
      if (statusMap.hasOwnProperty(status)) {
        statusCounts.push({ status: status, count: statusMap[status] })
      }
    }

    // Calculer la distribution par médecin
    const doctorDistribution: { doctor: string; count: number }[] = []
    const doctorMap: { [key: string]: number } = {}
    filteredPatients.forEach((patient) => {
      const doctor = standardizeDoctorName(patient.doctor) || "non_defini"
      if (doctorMap[doctor]) {
        doctorMap[doctor]++
      } else {
        doctorMap[doctor] = 1
      }
    })
    for (const doctor in doctorMap) {
      if (doctorMap.hasOwnProperty(doctor)) {
        doctorDistribution.push({ doctor: doctor, count: doctorMap[doctor] })
      }
    }

    // Calculer la performance par closer (admin seulement)
    const closerPerformance: any[] = []
    if (userRole === "admin") {
      const closerMap: { [key: string]: { total: number; operated: number } } = {}
      filteredPatients.forEach((patient) => {
        if (patient.closerId) {
          if (!closerMap[patient.closerId]) {
            closerMap[patient.closerId] = { total: 0, operated: 0 }
          }
          closerMap[patient.closerId].total++
          if (patient.status === "vente") {
            closerMap[patient.closerId].operated++
          }
        }
      })

      for (const closerId in closerMap) {
        if (closerMap.hasOwnProperty(closerId)) {
          const closerData = closerMap[closerId]
          const closer = await supabase.from("users").select("full_name").eq("id", closerId).single()
          const closerName = closer.data?.full_name || "Inconnu"
          const conversionRate = (closerData.operated / closerData.total) * 100 || 0
          closerPerformance.push({
            closerId: closerId,
            name: closerName,
            total: closerData.total,
            operated: closerData.operated,
            conversionRate: conversionRate,
          })
        }
      }
    }

    // Calculer le taux de conversion global
    const acceptedCount = filteredPatients.filter((p) => p.status === "vente").length
    const conversionRate = totalPatients > 0 ? (acceptedCount / totalPatients) * 100 : 0

    return {
      totalPatients,
      statusCounts,
      doctorDistribution,
      closerPerformance,
      conversionRate,
    }
  } catch (error) {
    console.error("Erreur lors du calcul des statistiques complètes:", error)
    return {
      totalPatients: 0,
      statusCounts: [],
      doctorDistribution: [],
      closerPerformance: [],
      conversionRate: 0,
    }
  }
}

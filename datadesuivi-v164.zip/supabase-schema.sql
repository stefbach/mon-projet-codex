-- Table pour les utilisateurs
CREATE TABLE IF NOT EXISTS public.users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('admin', 'closer')),
    active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_password_change TIMESTAMP WITH TIME ZONE,
    password_hash TEXT
);

-- Table pour les patients
CREATE TABLE IF NOT EXISTS public.patients (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    doctor TEXT NOT NULL,
    consultation_date TEXT,
    income NUMERIC,
    expenses NUMERIC,
    credit_score TEXT,
    credit_platform TEXT,
    loan_amount NUMERIC,
    simulation_validated TEXT,
    platform TEXT,
    status TEXT,
    loan_requested TEXT,
    next_follow_up TEXT,
    closer TEXT NOT NULL,
    comments TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE
);

-- Créer des index pour améliorer les performances
CREATE INDEX IF NOT EXISTS idx_patients_closer ON public.patients(closer);
CREATE INDEX IF NOT EXISTS idx_patients_status ON public.patients(status);
CREATE INDEX IF NOT EXISTS idx_patients_platform ON public.patients(platform);
CREATE INDEX IF NOT EXISTS idx_patients_doctor ON public.patients(doctor);

-- Ajouter des utilisateurs de test
INSERT INTO public.users (email, name, role, active, created_at, password_hash)
VALUES 
('admin@email.com', 'Administrateur', 'admin', true, NOW(), '$2a$10$hACwQ5/HQI6FhbIISOUVeusy3sKyUDhSq36fF5d/54aAdiC4rFZMG'), -- mot de passe: admin123
('closer@email.com', 'Closer', 'closer', true, NOW(), '$2a$10$hACwQ5/HQI6FhbIISOUVeusy3sKyUDhSq36fF5d/54aAdiC4rFZMG') -- mot de passe: closer123
ON CONFLICT (email) DO NOTHING;

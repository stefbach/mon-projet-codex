-- Création de l'extension uuid-ossp si elle n'existe pas déjà
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Création de la table users si elle n'existe pas
CREATE TABLE IF NOT EXISTS public.users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL,
    active BOOLEAN DEFAULT true,
    password_hash VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    password_updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insertion de données de test pour les utilisateurs
INSERT INTO public.users (id, email, name, role, active, password_hash, created_at, password_updated_at)
VALUES 
('00000000-0000-0000-0000-000000000001', 'admin@email.com', 'Administrateur', 'admin', true, '$2a$10$X7VYHy.iYDVB.J7tgJq5B.D5jS9EVz1gHjzGhpnT7s9k9LJZUUeim', NOW(), NOW()),
('00000000-0000-0000-0000-000000000002', 'closer@email.com', 'Closer', 'closer', true, '$2a$10$X7VYHy.iYDVB.J7tgJq5B.D5jS9EVz1gHjzGhpnT7s9k9LJZUUeim', NOW(), NOW())
ON CONFLICT (email) DO NOTHING;

-- Création d'un index sur l'email pour accélérer les recherches
CREATE INDEX IF NOT EXISTS users_email_idx ON public.users (email);

-- Création d'un index sur le rôle pour accélérer les filtres
CREATE INDEX IF NOT EXISTS users_role_idx ON public.users (role);

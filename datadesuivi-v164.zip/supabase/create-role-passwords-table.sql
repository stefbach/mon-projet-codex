-- Créer la table pour stocker les mots de passe par rôle
CREATE TABLE IF NOT EXISTS public.role_passwords (
  id SERIAL PRIMARY KEY,
  role TEXT NOT NULL UNIQUE,
  password TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Insérer les mots de passe par défaut
INSERT INTO public.role_passwords (role, password)
VALUES 
  ('admin', 'admin123'),
  ('closer', 'closer123')
ON CONFLICT (role) DO NOTHING;

-- Désactiver RLS pour cette table
ALTER TABLE public.role_passwords DISABLE ROW LEVEL SECURITY;

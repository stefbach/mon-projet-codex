-- Script pour réparer la relation entre patients et users

-- Vérifier si la contrainte existe et la supprimer si c'est le cas
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'patients_closer_id_fkey' 
    AND table_name = 'patients'
  ) THEN
    EXECUTE 'ALTER TABLE patients DROP CONSTRAINT patients_closer_id_fkey';
    RAISE NOTICE 'Contrainte patients_closer_id_fkey supprimée';
  END IF;
  
  -- Recréer la contrainte correctement
  BEGIN
    EXECUTE 'ALTER TABLE patients ADD CONSTRAINT patients_closer_id_fkey 
             FOREIGN KEY (closer_id) REFERENCES auth.users(id) ON DELETE SET NULL';
    RAISE NOTICE 'Contrainte patients_closer_id_fkey recréée avec succès';
  EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'Erreur lors de la création de la contrainte: %', SQLERRM;
    
    -- Essayer une approche alternative
    BEGIN
      EXECUTE 'ALTER TABLE patients ADD CONSTRAINT patients_closer_id_fkey 
               FOREIGN KEY (closer_id) REFERENCES users(id) ON DELETE SET NULL';
      RAISE NOTICE 'Contrainte patients_closer_id_fkey recréée avec succès (méthode alternative)';
    EXCEPTION WHEN OTHERS THEN
      RAISE NOTICE 'Erreur lors de la création de la contrainte (méthode alternative): %', SQLERRM;
    END;
  END;
END $$;

-- Vérifier que la contrainte a été créée
SELECT 
    tc.constraint_name, 
    tc.table_name, 
    kcu.column_name, 
    ccu.table_name AS foreign_table_name,
    ccu.column_name AS foreign_column_name
FROM 
    information_schema.table_constraints AS tc 
    JOIN information_schema.key_column_usage AS kcu
      ON tc.constraint_name = kcu.constraint_name
      AND tc.table_schema = kcu.table_schema
    JOIN information_schema.constraint_column_usage AS ccu
      ON ccu.constraint_name = tc.constraint_name
      AND ccu.table_schema = tc.table_schema
WHERE tc.constraint_type = 'FOREIGN KEY' 
    AND tc.table_name = 'patients'
    AND kcu.column_name = 'closer_id';

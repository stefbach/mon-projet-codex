-- 1. Confirmer tous les utilisateurs existants
UPDATE auth.users
SET email_confirmed_at = NOW()
WHERE email_confirmed_at IS NULL;

-- 2. Vérifier si les utilisateurs existent dans la table public.users
DO $$
DECLARE
  missing_users_count INTEGER;
BEGIN
  SELECT COUNT(*)
  INTO missing_users_count
  FROM auth.users au
  LEFT JOIN public.users pu ON au.id = pu.id
  WHERE pu.id IS NULL;
  
  RAISE NOTICE 'Nombre d''utilisateurs manquants dans public.users: %', missing_users_count;
END $$;

-- 3. Ajouter les utilisateurs manquants à la table public.users
INSERT INTO public.users (id, email, name, role, active, created_at)
SELECT 
  au.id,
  au.email,
  COALESCE(au.raw_user_meta_data->>'name', split_part(au.email, '@', 1)),
  COALESCE(au.raw_user_meta_data->>'role', 'closer'),
  TRUE,
  NOW()
FROM auth.users au
LEFT JOIN public.users pu ON au.id = pu.id
WHERE pu.id IS NULL;

-- 4. Vérifier les paramètres d'authentification
DO $$
BEGIN
  -- Vérifier si la table auth.identities existe et contient des données
  PERFORM * FROM auth.identities LIMIT 1;
  
  IF NOT FOUND THEN
    RAISE NOTICE 'Attention: La table auth.identities est vide!';
  ELSE
    RAISE NOTICE 'La table auth.identities contient des données.';
  END IF;
END $$;

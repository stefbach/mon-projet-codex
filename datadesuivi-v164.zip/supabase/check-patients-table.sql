-- Check the structure of the patients table
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'patients';

-- Fonction pour confirmer automatiquement un utilisateur par email
CREATE OR REPLACE FUNCTION admin_confirm_user(user_email TEXT)
RETURNS VOID AS $$
BEGIN
  -- Mettre à jour la colonne email_confirmed_at pour l'utilisateur spécifié
  UPDATE auth.users
  SET email_confirmed_at = NOW()
  WHERE email = user_email AND email_confirmed_at IS NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Accorder les privilèges d'exécution à anon et authenticated
GRANT EXECUTE ON FUNCTION admin_confirm_user(TEXT) TO anon, authenticated;

-- Fonction pour vérifier si un utilisateur existe et est confirmé
CREATE OR REPLACE FUNCTION check_user_status(user_email TEXT)
RETURNS TABLE (
  exists BOOLEAN,
  confirmed BOOLEAN,
  user_id UUID
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    COUNT(*) > 0 AS exists,
    COUNT(email_confirmed_at) > 0 AS confirmed,
    id AS user_id
  FROM auth.users
  WHERE email = user_email
  GROUP BY id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Accorder les privilèges d'exécution à anon et authenticated
GRANT EXECUTE ON FUNCTION check_user_status(TEXT) TO anon, authenticated;

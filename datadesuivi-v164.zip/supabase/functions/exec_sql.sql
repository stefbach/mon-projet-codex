-- Fonction pour exécuter des requêtes SQL brutes en toute sécurité
-- ATTENTION: Cette fonction doit être utilisée avec précaution et uniquement par des administrateurs
CREATE OR REPLACE FUNCTION exec_sql(sql_query TEXT)
RETURNS JSONB AS $$
DECLARE
  result JSONB;
BEGIN
  -- Exécuter la requête SQL et récupérer le résultat sous forme de JSONB
  EXECUTE 'SELECT jsonb_agg(row_to_json(t)) FROM (' || sql_query || ') t' INTO result;
  RETURN result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Ajouter une politique pour restreindre l'accès à cette fonction aux administrateurs
REVOKE ALL ON FUNCTION exec_sql FROM PUBLIC;
GRANT EXECUTE ON FUNCTION exec_sql TO authenticated;

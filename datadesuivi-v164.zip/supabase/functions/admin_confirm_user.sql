-- Fonction pour confirmer manuellement un utilisateur
CREATE OR REPLACE FUNCTION admin_confirm_user(user_email TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Mettre à jour le champ email_confirmed_at pour confirmer l'utilisateur
  UPDATE auth.users
  SET email_confirmed_at = now()
  WHERE email = user_email AND email_confirmed_at IS NULL;
  
  RETURN FOUND;
END;
$$;

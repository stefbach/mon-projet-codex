-- Fonction pour récupérer la contrainte d'une colonne
CREATE OR REPLACE FUNCTION public.get_column_constraint(table_name text, column_name text)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    constraint_def text;
BEGIN
    SELECT pg_get_constraintdef(c.oid)
    INTO constraint_def
    FROM pg_constraint c
    JOIN pg_namespace n ON n.oid = c.connamespace
    JOIN pg_class cl ON cl.oid = c.conrelid
    JOIN pg_attribute a ON a.attrelid = c.conrelid AND a.attnum = ANY(c.conkey)
    WHERE n.nspname = 'public'
    AND cl.relname = table_name
    AND a.attname = column_name
    AND c.contype = 'c';
    
    RETURN constraint_def;
END;
$$;

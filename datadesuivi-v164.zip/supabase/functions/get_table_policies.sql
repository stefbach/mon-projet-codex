-- Fonction pour récupérer les politiques RLS d'une table
CREATE OR REPLACE FUNCTION get_table_policies(table_name TEXT)
RETURNS TABLE (
  policy_name TEXT,
  operation TEXT,
  definition TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.policyname::TEXT,
    p.operation::TEXT,
    p.definition::TEXT
  FROM 
    pg_policies p
  WHERE 
    p.schemaname = 'public' AND 
    p.tablename = get_table_policies.table_name;
END;
$$;

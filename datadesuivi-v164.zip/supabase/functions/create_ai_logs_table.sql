-- Fonction pour créer la table ai_usage_logs
CREATE OR REPLACE FUNCTION create_ai_logs_table()
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Créer la table si elle n'existe pas
  CREATE TABLE IF NOT EXISTS ai_usage_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    provider VARCHAR(50) NOT NULL,
    model VARCHAR(100) NOT NULL,
    prompt TEXT,
    success BOOLEAN NOT NULL DEFAULT FALSE,
    error TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL
  );

  -- Ajouter des index pour améliorer les performances
  CREATE INDEX IF NOT EXISTS idx_ai_usage_logs_provider ON ai_usage_logs(provider);
  CREATE INDEX IF NOT EXISTS idx_ai_usage_logs_model ON ai_usage_logs(model);
  CREATE INDEX IF NOT EXISTS idx_ai_usage_logs_success ON ai_usage_logs(success);
  CREATE INDEX IF NOT EXISTS idx_ai_usage_logs_created_at ON ai_usage_logs(created_at);
  CREATE INDEX IF NOT EXISTS idx_ai_usage_logs_user_id ON ai_usage_logs(user_id);

  -- Activer RLS
  ALTER TABLE ai_usage_logs ENABLE ROW LEVEL SECURITY;

  -- Créer une politique pour permettre l'insertion par les utilisateurs authentifiés
  CREATE POLICY insert_ai_usage_logs ON ai_usage_logs
    FOR INSERT
    TO authenticated
    WITH CHECK (true);

  -- Créer une politique pour permettre la lecture par les administrateurs
  CREATE POLICY read_ai_usage_logs ON ai_usage_logs
    FOR SELECT
    TO authenticated
    USING (auth.uid() IN (SELECT id FROM auth.users WHERE role = 'admin'));

  RETURN TRUE;
END;
$$;

-- Fonction pour vérifier si une table existe
CREATE OR REPLACE FUNCTION check_table_exists(table_name TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  table_exists BOOLEAN;
BEGIN
  SELECT EXISTS (
    SELECT FROM information_schema.tables 
    WHERE table_schema = 'public'
    AND table_name = check_table_exists.table_name
  ) INTO table_exists;
  
  RETURN table_exists;
END;
$$;

-- Fonction pour vérifier si un utilisateur existe et s'il est confirmé
CREATE OR REPLACE FUNCTION check_user_exists(email_input TEXT)
RETURNS TABLE (
  exists BOOLEAN,
  confirmed BOOLEAN
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    COUNT(*) > 0 as exists,
    email_confirmed_at IS NOT NULL as confirmed
  FROM auth.users
  WHERE email = email_input;
END;
$$;

-- Fonction correcte pour vérifier l'existence d'une colonne sans ambiguïté
CREATE OR REPLACE FUNCTION check_column_exists_fixed(p_table_name TEXT, p_column_name TEXT)
RETURNS BOOLEAN AS $$
DECLARE
  column_exists BOOLEAN;
BEGIN
  -- Utiliser information_schema.columns sans préfixe public
  SELECT EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_name = p_table_name
    AND column_name = p_column_name
  ) INTO column_exists;
  
  RETURN column_exists;
END;
$$ LANGUAGE plpgsql;

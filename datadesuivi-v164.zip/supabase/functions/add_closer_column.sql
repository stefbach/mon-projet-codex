CREATE OR REPLACE FUNCTION add_closer_column()
RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
  column_exists boolean;
BEGIN
  -- Vérifier si la colonne existe déjà
  SELECT EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_schema = 'public'
    AND table_name = 'patients'
    AND column_name = 'closer'
  ) INTO column_exists;
  
  -- Si la colonne n'existe pas, l'ajouter
  IF NOT column_exists THEN
    ALTER TABLE public.patients ADD COLUMN closer TEXT;
    
    -- Mettre à jour les enregistrements existants avec une valeur par défaut
    UPDATE public.patients SET closer = 'system@example.com';
    
    RETURN 'Colonne closer ajoutée avec succès';
  ELSE
    RETURN 'La colonne closer existe déjà';
  END IF;
END;
$$;

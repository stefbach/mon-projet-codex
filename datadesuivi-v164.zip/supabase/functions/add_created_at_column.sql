CREATE OR REPLACE FUNCTION add_created_at_column()
RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
  column_exists boolean;
BEGIN
  -- Vérifier si la colonne existe déjà
  SELECT EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_schema = 'public'
    AND table_name = 'patients'
    AND column_name = 'created_at'
  ) INTO column_exists;
  
  -- Si la colonne n'existe pas, l'ajouter
  IF NOT column_exists THEN
    ALTER TABLE public.patients ADD COLUMN created_at TIMESTAMPTZ DEFAULT now();
    
    -- Mettre à jour les enregistrements existants avec la date actuelle
    UPDATE public.patients SET created_at = now();
    
    RETURN 'Colonne created_at ajoutée avec succès';
  ELSE
    RETURN 'La colonne created_at existe déjà';
  END IF;
END;
$$;

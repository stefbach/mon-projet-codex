-- Fonction pour récupérer la définition de la contrainte suite_groupe
CREATE OR REPLACE FUNCTION public.get_suite_groupe_constraint()
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    constraint_def text;
BEGIN
    SELECT pg_get_constraintdef(c.oid)
    INTO constraint_def
    FROM pg_constraint c
    JOIN pg_namespace n ON n.oid = c.connamespace
    JOIN pg_class cl ON cl.oid = c.conrelid
    JOIN pg_attribute a ON a.attrelid = c.conrelid AND a.attnum = ANY(c.conkey)
    WHERE n.nspname = 'public'
    AND cl.relname = 'patients'
    AND a.attname = 'suite_groupe'
    AND c.contype = 'c';
    
    RETURN constraint_def;
END;
$$;

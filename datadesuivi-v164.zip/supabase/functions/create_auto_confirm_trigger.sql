-- Fonction pour confirmer automatiquement les utilisateurs
CREATE OR REPLACE FUNCTION public.auto_confirm_user()
RETURNS TRIGGER AS $$
BEGIN
  -- Mettre à jour le champ email_confirmed_at pour confirmer l'utilisateur
  UPDATE auth.users
  SET email_confirmed_at = now()
  WHERE id = NEW.id AND email_confirmed_at IS NULL;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Déclencheur qui s'exécute après l'insertion d'un nouvel utilisateur
DROP TRIGGER IF EXISTS confirm_users_trigger ON auth.users;
CREATE TRIGGER confirm_users_trigger
AFTER INSERT ON auth.users
FOR EACH ROW
EXECUTE PROCEDURE public.auto_confirm_user();

-- Fonction pour mettre à jour la contrainte suite_groupe
CREATE OR REPLACE FUNCTION public.update_suite_groupe_constraint(allowed_values text[])
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    constraint_name text;
    constraint_def text;
    values_list text;
BEGIN
    -- Récupérer le nom de la contrainte
    SELECT c.conname
    INTO constraint_name
    FROM pg_constraint c
    JOIN pg_namespace n ON n.oid = c.connamespace
    JOIN pg_class cl ON cl.oid = c.conrelid
    JOIN pg_attribute a ON a.attrelid = c.conrelid AND a.attnum = ANY(c.conkey)
    WHERE n.nspname = 'public'
    AND cl.relname = 'patients'
    AND a.attname = 'suite_groupe'
    AND c.contype = 'c';
    
    -- Construire la liste des valeurs autorisées
    SELECT string_agg(quote_literal(val), ', ')
    INTO values_list
    FROM unnest(allowed_values) AS val;
    
    -- Si la contrainte existe, la supprimer
    IF constraint_name IS NOT NULL THEN
        EXECUTE 'ALTER TABLE public.patients DROP CONSTRAINT ' || quote_ident(constraint_name);
    END IF;
    
    -- Créer la nouvelle contrainte
    EXECUTE 'ALTER TABLE public.patients ADD CONSTRAINT patients_suite_groupe_check CHECK (suite_groupe IS NULL OR suite_groupe = '''' OR suite_groupe IN (' || values_list || '))';
END;
$$;

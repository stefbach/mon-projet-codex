-- Script complet pour réparer les relations entre tables dans Supabase

-- 1. Vérifier et corriger la relation entre patients et users
DO $$
DECLARE
    constraint_exists BOOLEAN;
BEGIN
    -- Vérifier si la contrainte existe déjà
    SELECT EXISTS (
        SELECT 1 FROM information_schema.table_constraints 
        WHERE constraint_name = 'patients_closer_id_fkey' 
        AND table_name = 'patients'
    ) INTO constraint_exists;

    -- Si la contrainte existe, la supprimer d'abord
    IF constraint_exists THEN
        EXECUTE 'ALTER TABLE patients DROP CONSTRAINT patients_closer_id_fkey';
        RAISE NOTICE 'Contrainte patients_closer_id_fkey supprimée';
    END IF;

    -- Vérifier si la colonne closer_id existe dans la table patients
    IF EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'patients' AND column_name = 'closer_id'
    ) THEN
        -- Essayer d'abord avec auth.users
        BEGIN
            EXECUTE 'ALTER TABLE patients ADD CONSTRAINT patients_closer_id_fkey 
                     FOREIGN KEY (closer_id) REFERENCES auth.users(id) ON DELETE SET NULL';
            RAISE NOTICE 'Contrainte patients_closer_id_fkey créée avec auth.users';
        EXCEPTION WHEN OTHERS THEN
            RAISE NOTICE 'Erreur lors de la création de la contrainte avec auth.users: %', SQLERRM;
            
            -- Essayer ensuite avec la table users
            BEGIN
                EXECUTE 'ALTER TABLE patients ADD CONSTRAINT patients_closer_id_fkey 
                         FOREIGN KEY (closer_id) REFERENCES users(id) ON DELETE SET NULL';
                RAISE NOTICE 'Contrainte patients_closer_id_fkey créée avec users';
            EXCEPTION WHEN OTHERS THEN
                RAISE NOTICE 'Erreur lors de la création de la contrainte avec users: %', SQLERRM;
            END;
        END;
    ELSE
        RAISE NOTICE 'La colonne closer_id n''existe pas dans la table patients';
    END IF;
END $$;

-- 2. Vérifier et corriger les autres relations potentiellement problématiques
DO $$
BEGIN
    -- Vérifier et corriger la relation created_by_admin
    IF EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'patients' AND column_name = 'created_by_admin'
    ) THEN
        -- Supprimer la contrainte si elle existe
        IF EXISTS (
            SELECT 1 FROM information_schema.table_constraints 
            WHERE constraint_name = 'patients_created_by_admin_fkey' 
            AND table_name = 'patients'
        ) THEN
            EXECUTE 'ALTER TABLE patients DROP CONSTRAINT patients_created_by_admin_fkey';
        END IF;
        
        -- Essayer de créer la contrainte
        BEGIN
            EXECUTE 'ALTER TABLE patients ADD CONSTRAINT patients_created_by_admin_fkey 
                     FOREIGN KEY (created_by_admin) REFERENCES users(id) ON DELETE SET NULL';
        EXCEPTION WHEN OTHERS THEN
            RAISE NOTICE 'Erreur lors de la création de la contrainte created_by_admin: %', SQLERRM;
        END;
    END IF;

    -- Vérifier et corriger la relation validated_by_admin
    IF EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'patients' AND column_name = 'validated_by_admin'
    ) THEN
        -- Supprimer la contrainte si elle existe
        IF EXISTS (
            SELECT 1 FROM information_schema.table_constraints 
            WHERE constraint_name = 'patients_validated_by_admin_fkey' 
            AND table_name = 'patients'
        ) THEN
            EXECUTE 'ALTER TABLE patients DROP CONSTRAINT patients_validated_by_admin_fkey';
        END IF;
        
        -- Essayer de créer la contrainte
        BEGIN
            EXECUTE 'ALTER TABLE patients ADD CONSTRAINT patients_validated_by_admin_fkey 
                     FOREIGN KEY (validated_by_admin) REFERENCES users(id) ON DELETE SET NULL';
        EXCEPTION WHEN OTHERS THEN
            RAISE NOTICE 'Erreur lors de la création de la contrainte validated_by_admin: %', SQLERRM;
        END;
    END IF;
END $$;

-- 3. Vérifier les contraintes créées
SELECT 
    tc.constraint_name, 
    tc.table_name, 
    kcu.column_name, 
    ccu.table_name AS foreign_table_name,
    ccu.column_name AS foreign_column_name
FROM 
    information_schema.table_constraints AS tc 
    JOIN information_schema.key_column_usage AS kcu
      ON tc.constraint_name = kcu.constraint_name
      AND tc.table_schema = kcu.table_schema
    JOIN information_schema.constraint_column_usage AS ccu
      ON ccu.constraint_name = tc.constraint_name
      AND ccu.table_schema = tc.table_schema
WHERE tc.constraint_type = 'FOREIGN KEY' 
    AND tc.table_name = 'patients';

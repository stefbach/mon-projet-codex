-- Script de réinitialisation complète des relations dans la base de données
-- Ce script doit être exécuté en tant qu'administrateur de la base de données

-- 1. Obtenir les informations sur la structure actuelle
DO $$
DECLARE
    exists_closer_column BOOLEAN;
    constraint_exists BOOLEAN;
BEGIN
    -- Vérifier si la colonne closer_id existe
    SELECT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'patients' AND column_name = 'closer_id'
    ) INTO exists_closer_column;

    -- Journaliser l'état
    RAISE NOTICE 'La colonne closer_id existe: %', exists_closer_column;

    -- Vérifier si la contrainte existe
    SELECT EXISTS (
        SELECT 1 FROM information_schema.table_constraints 
        WHERE constraint_name = 'patients_closer_id_fkey' 
        AND table_name = 'patients'
    ) INTO constraint_exists;

    RAISE NOTICE 'La contrainte patients_closer_id_fkey existe: %', constraint_exists;

    -- Si la contrainte existe, la supprimer
    IF constraint_exists THEN
        EXECUTE 'ALTER TABLE patients DROP CONSTRAINT patients_closer_id_fkey';
        RAISE NOTICE 'Contrainte patients_closer_id_fkey supprimée';
    END IF;
END $$;

-- 2. Créer une colonne temporaire pour backup
DO $$
BEGIN
    -- Vérifier si la colonne closer_id_backup n'existe pas déjà
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'patients' AND column_name = 'closer_id_backup'
    ) THEN
        -- Ajouter la colonne backup
        ALTER TABLE patients ADD COLUMN closer_id_backup UUID;
        
        -- Copier les données
        UPDATE patients SET closer_id_backup = closer_id;
        
        RAISE NOTICE 'Colonne closer_id_backup créée et données copiées';
    ELSE
        RAISE NOTICE 'La colonne closer_id_backup existe déjà';
    END IF;
END $$;

-- 3. Supprimer et recréer la colonne closer_id
DO $$
BEGIN
    -- Supprimer la colonne closer_id si elle existe
    IF EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'patients' AND column_name = 'closer_id'
    ) THEN
        ALTER TABLE patients DROP COLUMN closer_id;
        RAISE NOTICE 'Colonne closer_id supprimée';
    END IF;
    
    -- Recréer la colonne
    ALTER TABLE patients ADD COLUMN closer_id UUID;
    
    -- Restaurer les données depuis la backup
    UPDATE patients SET closer_id = closer_id_backup;
    
    RAISE NOTICE 'Colonne closer_id recréée et données restaurées';
END $$;

-- 4. Recréer la contrainte de clé étrangère
DO $$
BEGIN
    -- Essayer de créer la contrainte avec auth.users
    BEGIN
        ALTER TABLE patients 
        ADD CONSTRAINT patients_closer_id_fkey 
        FOREIGN KEY (closer_id) REFERENCES auth.users(id) ON DELETE SET NULL;
        
        RAISE NOTICE 'Contrainte recréée avec auth.users';
    EXCEPTION WHEN OTHERS THEN
        RAISE NOTICE 'Erreur lors de la création de la contrainte avec auth.users: %', SQLERRM;
        
        -- Si ça échoue, essayer avec public.users
        BEGIN
            ALTER TABLE patients 
            ADD CONSTRAINT patients_closer_id_fkey 
            FOREIGN KEY (closer_id) REFERENCES public.users(id) ON DELETE SET NULL;
            
            RAISE NOTICE 'Contrainte recréée avec public.users';
        EXCEPTION WHEN OTHERS THEN
            RAISE NOTICE 'Erreur lors de la création de la contrainte avec public.users: %', SQLERRM;
            
            -- Si ça échoue encore, laisser la colonne sans contrainte
            RAISE NOTICE 'Impossible de créer la contrainte. La colonne closer_id sera laissée sans contrainte.';
        END;
    END;
END $$;

-- 5. Vérifier l'état final
SELECT 
    tc.constraint_name, 
    tc.table_name, 
    kcu.column_name, 
    ccu.table_name AS foreign_table_name,
    ccu.column_name AS foreign_column_name
FROM 
    information_schema.table_constraints AS tc 
    JOIN information_schema.key_column_usage AS kcu
      ON tc.constraint_name = kcu.constraint_name
      AND tc.table_schema = kcu.table_schema
    JOIN information_schema.constraint_column_usage AS ccu
      ON ccu.constraint_name = tc.constraint_name
      AND ccu.table_schema = tc.table_schema
WHERE tc.constraint_type = 'FOREIGN KEY' 
    AND tc.table_name = 'patients';

-- 1. Créer la fonction pour confirmer les utilisateurs
CREATE OR REPLACE FUNCTION public.confirm_user(email_to_confirm TEXT)
RETURNS VOID AS $$
BEGIN
  UPDATE auth.users
  SET email_confirmed_at = NOW()
  WHERE email = email_to_confirm;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 2. Accorder les permissions d'exécution
GRANT EXECUTE ON FUNCTION public.confirm_user(TEXT) TO authenticated, anon;

-- 3. Créer la fonction pour récupérer tous les utilisateurs
CREATE OR REPLACE FUNCTION public.get_all_users()
RETURNS TABLE (
  id UUID,
  email TEXT,
  confirmed BOOLEAN,
  created_at TIMESTAMPTZ,
  last_sign_in_at TIMESTAMPTZ
) 
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    u.id,
    u.email,
    u.email_confirmed_at IS NOT NULL as confirmed,
    u.created_at,
    u.last_sign_in_at
  FROM auth.users u
  ORDER BY u.created_at DESC;
END;
$$ LANGUAGE plpgsql;

-- 4. Accorder les permissions d'exécution
GRANT EXECUTE ON FUNCTION public.get_all_users() TO authenticated, anon;

-- 5. S'assurer que la table users existe avec les bonnes colonnes
CREATE TABLE IF NOT EXISTS public.users (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  name TEXT,
  role TEXT DEFAULT 'closer',
  active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. Désactiver RLS pour simplifier les tests
ALTER TABLE public.users DISABLE ROW LEVEL SECURITY;

-- 7. Confirmer tous les utilisateurs existants
UPDATE auth.users
SET email_confirmed_at = NOW()
WHERE email_confirmed_at IS NULL;

-- Vérifier si la contrainte de vérification existe déjà
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'patients_status_check' 
    AND conrelid = 'patients'::regclass
  ) THEN
    -- Supprimer la contrainte existante
    ALTER TABLE patients DROP CONSTRAINT patients_status_check;
  END IF;
  
  -- Ajouter la nouvelle contrainte avec no_show
  ALTER TABLE patients ADD CONSTRAINT patients_status_check 
    CHECK (status IN ('en_attente', 'a_contacter', 'rdv_programme', 'vente', 'perdu', 
                     'non_defini', 'en_cours', 'annule', 'a_rappeler', 'non_interesse', 'no_show'));
END $$;

-- Ajouter une page de test pour exécuter cette migration

-- Fonction pour confirmer automatiquement les nouveaux utilisateurs
CREATE OR REPLACE FUNCTION auto_confirm_user()
RETURNS TRIGGER AS $$
BEGIN
  -- Confirmer automatiquement l'email de l'utilisateur
  NEW.email_confirmed_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Supprimer le déclencheur s'il existe déjà
DROP TRIGGER IF EXISTS confirm_new_users ON auth.users;

-- Créer le déclencheur pour confirmer automatiquement les nouveaux utilisateurs
CREATE TRIGGER confirm_new_users
BEFORE INSERT ON auth.users
FOR EACH ROW
EXECUTE FUNCTION auto_confirm_user();

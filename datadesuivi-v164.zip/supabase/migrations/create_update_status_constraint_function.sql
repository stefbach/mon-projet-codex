-- Fonction pour créer une fonction temporaire qui met à jour la contrainte de statut
CREATE OR REPLACE FUNCTION create_temp_update_function(function_name TEXT)
RETURNS void AS $$
BEGIN
  EXECUTE format('
    CREATE OR REPLACE FUNCTION %I()
    RETURNS void AS $func$
    BEGIN
      IF EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = ''patients_status_check'' 
        AND conrelid = ''patients''::regclass
      ) THEN
        -- Supprimer la contrainte existante
        ALTER TABLE patients DROP CONSTRAINT patients_status_check;
      END IF;
      
      -- Ajouter la nouvelle contrainte avec no_show
      ALTER TABLE patients ADD CONSTRAINT patients_status_check 
        CHECK (status IN (''en_attente'', ''a_contacter'', ''rdv_programme'', ''vente'', ''perdu'', 
                         ''non_defini'', ''en_cours'', ''annule'', ''a_rappeler'', ''non_interesse'', ''no_show''));
    END;
    $func$ LANGUAGE plpgsql SECURITY DEFINER;
  ', function_name);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Créer la fonction update_status_constraint
SELECT create_temp_update_function('update_status_constraint');

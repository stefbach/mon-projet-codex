-- Create table for logging system actions
CREATE TABLE IF NOT EXISTS system_action_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  action_type TEXT NOT NULL,
  patient_id UUID REFERENCES patients(id) ON DELETE CASCADE,
  parameters JSONB,
  executed_by UUID REFERENCES auth.users(id),
  executed_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  reason TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Add index for faster queries
CREATE INDEX IF NOT EXISTS idx_system_action_logs_patient_id ON system_action_logs(patient_id);
CREATE INDEX IF NOT EXISTS idx_system_action_logs_executed_by ON system_action_logs(executed_by);
CREATE INDEX IF NOT EXISTS idx_system_action_logs_action_type ON system_action_logs(action_type);

-- Add RLS policies
ALTER TABLE system_action_logs ENABLE ROW LEVEL SECURITY;

-- Only admins can view all logs
CREATE POLICY "Admins can view all logs" 
  ON system_action_logs 
  FOR SELECT 
  TO authenticated 
  USING (auth.uid() IN (SELECT id FROM users WHERE role = 'admin'));

-- Closers can only view logs for their patients
CREATE POLICY "Closers can view logs for their patients" 
  ON system_action_logs 
  FOR SELECT 
  TO authenticated 
  USING (
    auth.uid() IN (SELECT id FROM users WHERE role = 'closer')
    AND
    patient_id IN (SELECT id FROM patients WHERE closer_id = auth.uid())
  );

-- Only admins can insert logs
CREATE POLICY "Only admins can insert logs" 
  ON system_action_logs 
  FOR INSERT 
  TO authenticated 
  WITH CHECK (auth.uid() IN (SELECT id FROM users WHERE role = 'admin'));

-- Function to increment call count
CREATE OR REPLACE FUNCTION increment_call_count(patient_id UUID)
RETURNS INTEGER AS $$
DECLARE
  current_count INTEGER;
BEGIN
  SELECT COALESCE(call_count, 0) INTO current_count FROM patients WHERE id = patient_id;
  RETURN current_count + 1;
END;
$$ LANGUAGE plpgsql;

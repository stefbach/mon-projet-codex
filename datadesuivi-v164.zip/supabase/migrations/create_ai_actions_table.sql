-- Create AI actions table to store validated actions
CREATE TABLE IF NOT EXISTS ai_actions (
  id UUID PRIMARY KEY,
  type VARCHAR(50) NOT NULL,
  description TEXT NOT NULL,
  details TEXT,
  due_date TIMESTAMP WITH TIME ZONE,
  priority VARCHAR(20) NOT NULL,
  validated_by UUID REFERENCES auth.users(id),
  validated_at TIMESTAMP WITH TIME ZONE NOT NULL,
  completed_at TIMESTAMP WITH TIME ZONE,
  completed_by UUID REFERENCES auth.users(id),
  status VARCHAR(20) NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add RLS policies
ALTER TABLE ai_actions ENABLE ROW LEVEL SECURITY;

-- Policy for admins (full access)
CREATE POLICY admin_all_access ON ai_actions
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM users
    WHERE users.id = auth.uid() AND users.role = 'admin'
  ));

-- Policy for closers (read access to their own actions)
CREATE POLICY closer_read_own ON ai_actions
  FOR SELECT
  TO authenticated
  USING (
    validated_by = auth.uid() OR
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid() AND users.role = 'closer'
    )
  );

-- Policy for closers (update access to their own actions)
CREATE POLICY closer_update_own ON ai_actions
  FOR UPDATE
  TO authenticated
  USING (validated_by = auth.uid());

-- Create trigger to update updated_at
CREATE OR REPLACE FUNCTION update_ai_actions_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_ai_actions_updated_at
BEFORE UPDATE ON ai_actions
FOR EACH ROW
EXECUTE FUNCTION update_ai_actions_updated_at();

-- Check if patients table exists, if not create it with correct field types
CREATE TABLE IF NOT EXISTS patients (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  status TEXT DEFAULT 'En attente',
  loan_platform TEXT,
  doctor TEXT,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  assigned_closer TEXT DEFAULT 'system@example.com',
  registration_date DATE,
  consultation_date DATE,
  revenue NUMERIC,
  expenses NUMERIC,
  credit_score TEXT,
  credit_score_platform TEXT,
  loan_amount NUMERIC,
  loan_simulation_validated BOOLEAN DEFAULT FALSE,
  loan_requested BOOLEAN DEFAULT FALSE,
  next_follow_up DATE,
  comments TEXT
);

-- If the table already exists, ensure assigned_closer is a TEXT field
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'patients' AND column_name = 'assigned_closer'
  ) THEN
    -- Change the type if needed
    BEGIN
      ALTER TABLE patients ALTER COLUMN assigned_closer TYPE TEXT;
    EXCEPTION
      WHEN others THEN
        -- Handle the case where the column already has the correct type
        NULL;
    END;
  ELSE
    -- Add the column if it doesn't exist
    ALTER TABLE patients ADD COLUMN assigned_closer TEXT DEFAULT 'system@example.com';
  END IF;
END $$;

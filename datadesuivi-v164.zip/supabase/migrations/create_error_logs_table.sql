-- Table pour stocker les journaux d'erreurs
CREATE TABLE IF NOT EXISTS error_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    operation TEXT NOT NULL,
    data JSONB,
    error JSONB,
    timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Ajouter des commentaires pour la documentation
COMMENT ON TABLE error_logs IS 'Journal des erreurs de traitement des données patients';
COMMENT ON COLUMN error_logs.operation IS 'Type d''opération qui a causé l''erreur';
COMMENT ON COLUMN error_logs.data IS 'Données

## 3. Créer une Fonction Utilitaire pour Gérer les Champs Timestamp

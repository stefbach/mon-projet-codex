-- Mise à jour de la contrainte de vérification pour le statut des patients
DO $$
BEGIN
    -- Supprimer la contrainte existante si elle existe
    BEGIN
        ALTER TABLE patients DROP CONSTRAINT IF EXISTS patients_status_check;
    EXCEPTION
        WHEN undefined_object THEN
            RAISE NOTICE 'La contrainte patients_status_check n''existe pas, aucune suppression nécessaire';
    END;

    -- Ajouter la nouvelle contrainte avec les statuts supplémentaires
    ALTER TABLE patients ADD CONSTRAINT patients_status_check 
    CHECK (status IN (
        'en_attente', 
        'a_contacter', 
        'rdv_programme', 
        'vente', 
        'perdu', 
        'non_defini', 
        'en_cours', 
        'annule', 
        'a_rappeler', 
        'non_interesse', 
        'no_show',
        'invoice_sent',
        'refus_credit',
        'no_answer',
        'en_attente_paiement',
        'simulation_a_faire',
        'process_depasse',
        'phone_not_available',
        'paiement_fait',
        'credit_approuval_en_cours',
        'hors_cible',
        'simulation_faite_refus'
    ));

    RAISE NOTICE 'Contrainte de vérification du statut mise à jour avec succès';
END $$;

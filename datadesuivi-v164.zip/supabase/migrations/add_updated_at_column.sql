-- Vérifier si la colonne updated_at existe déjà
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_name = 'patients'
        AND column_name = 'updated_at'
    ) THEN
        -- Ajouter la colonne updated_at si elle n'existe pas
        ALTER TABLE patients ADD COLUMN updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();
        
        -- Mettre à jour les valeurs existantes
        UPDATE patients SET updated_at = created_at WHERE updated_at IS NULL;
        
        RAISE NOTICE 'Colonne updated_at ajoutée à la table patients';
    ELSE
        RAISE NOTICE 'La colonne updated_at existe déjà dans la table patients';
    END IF;
END $$;

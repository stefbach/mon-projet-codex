-- Create patients table with updated field names
CREATE TABLE IF NOT EXISTS public.patients (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  doctor TEXT,
  registration_date DATE,
  consultation_date DATE,
  revenue NUMERIC,
  expenses NUMERIC,
  credit_score INTEGER,
  credit_score_platform TEXT,
  loan_amount NUMERIC,
  loan_simulation_validated BOOLEAN DEFAULT false,
  loan_platform TEXT,
  loan_requested BOOLEAN DEFAULT false,
  assigned_closer TEXT,
  status TEXT DEFAULT 'En attente',
  next_follow_up DATE,
  comments TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create an update trigger to set updated_at on row update
CREATE OR REPLACE FUNCTION update_modified_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS set_patients_updated_at ON patients;
CREATE TRIGGER set_patients_updated_at
BEFORE UPDATE ON patients
FOR EACH ROW
EXECUTE FUNCTION update_modified_column();

-- Add RLS policies
ALTER TABLE public.patients ENABLE ROW LEVEL SECURITY;

-- Policy to allow users to see only their own patients unless they are admin
CREATE POLICY patients_select_policy ON patients
FOR SELECT USING (
  auth.uid()::text = assigned_closer OR 
  EXISTS (SELECT 1 FROM auth.users WHERE auth.users.id = auth.uid() AND auth.users.is_admin = true)
);

-- Policy to allow users to insert their own patients
CREATE POLICY patients_insert_policy ON patients
FOR INSERT WITH CHECK (
  auth.uid()::text = assigned_closer OR 
  EXISTS (SELECT 1 FROM auth.users WHERE auth.users.id = auth.uid() AND auth.users.is_admin = true)
);

-- Policy to allow users to update their own patients
CREATE POLICY patients_update_policy ON patients
FOR UPDATE USING (
  auth.uid()::text = assigned_closer OR 
  EXISTS (SELECT 1 FROM auth.users WHERE auth.users.id = auth.uid() AND auth.users.is_admin = true)
);

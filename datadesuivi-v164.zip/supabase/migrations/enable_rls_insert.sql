-- Activer RLS sur la table patients
ALTER TABLE public.patients ENABLE ROW LEVEL SECURITY;

-- Créer une politique pour permettre les insertions
CREATE POLICY patients_insert_policy
ON public.patients
FOR INSERT
TO authenticated
WITH CHECK (true);

-- Créer une politique pour permettre la lecture
CREATE POLICY patients_select_policy
ON public.patients
FOR SELECT
TO authenticated
USING (true);

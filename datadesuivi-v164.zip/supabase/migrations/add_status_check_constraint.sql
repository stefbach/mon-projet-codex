-- Ajouter une contrainte CHECK pour valider les statuts des patients
DO $$
BEGIN
  -- Vérifier si la contrainte existe déjà
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'patients_status_check'
  ) THEN
    -- Ajouter la contrainte CHECK
    ALTER TABLE patients
    ADD CONSTRAINT patients_status_check
    CHECK (
      status IN (
        'en_attente', 
        'en_cours', 
        'valide', 
        'refuse', 
        'annule', 
        'vente', 
        'à_rappeler', 
        'non_intéressé', 
        'rdv_programmé'
      )
    );
    
    RAISE NOTICE 'Contrainte CHECK ajoutée pour le champ status de la table patients';
  ELSE
    RAISE NOTICE 'La contrainte CHECK existe déjà pour le champ status de la table patients';
  END IF;
END $$;

-- Mettre à jour les statuts existants qui ne correspondent pas aux valeurs autorisées
UPDATE patients
SET status = 'en_attente'
WHERE status IS NULL OR status NOT IN (
  'en_attente', 
  'en_cours', 
  'valide', 
  'refuse', 
  'annule', 
  'vente', 
  'à_rappeler', 
  'non_intéressé', 
  'rdv_programmé'
);

-- Ajouter une valeur par défaut pour le champ status
DO $$
BEGIN
  -- Vérifier si la colonne a déjà une valeur par défaut
  IF NOT EXISTS (
    SELECT 1 FROM pg_attrdef ad
    JOIN pg_attribute a ON a.attrelid = ad.adrelid AND a.attnum = ad.adnum
    JOIN pg_class c ON c.oid = a.attrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE c.relname = 'patients' 
    AND a.attname = 'status'
    AND n.nspname = 'public'
  ) THEN
    -- Ajouter la valeur par défaut
    ALTER TABLE patients
    ALTER COLUMN status SET DEFAULT 'en_attente';
    
    RAISE NOTICE 'Valeur par défaut ajoutée pour le champ status de la table patients';
  ELSE
    RAISE NOTICE 'Le champ status de la table patients a déjà une valeur par défaut';
  END IF;
END $$;

-- S'assurer que le champ status n'est pas NULL
UPDATE patients
SET status = 'en_attente'
WHERE status IS NULL;

-- Rendre le champ status NOT NULL
DO $$
BEGIN
  -- Vérifier si la colonne est déjà NOT NULL
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public'
    AND table_name = 'patients'
    AND column_name = 'status'
    AND is_nullable = 'YES'
  ) THEN
    -- Rendre la colonne NOT NULL
    ALTER TABLE patients
    ALTER COLUMN status SET NOT NULL;
    
    RAISE NOTICE 'Contrainte NOT NULL ajoutée pour le champ status de la table patients';
  ELSE
    RAISE NOTICE 'Le champ status de la table patients est déjà NOT NULL';
  END IF;
END $$;

-- Fonction pour confirmer automatiquement un utilisateur par email
-- Cette fonction peut être appelée par un administrateur pour confirmer un utilisateur
-- sans que celui-ci n'ait à cliquer sur le lien de confirmation

CREATE OR REPLACE FUNCTION admin_confirm_user(user_email TEXT)
RETURNS VOID AS $$
DECLARE
  _user_id UUID;
BEGIN
  -- Récupérer l'ID de l'utilisateur à partir de son email
  SELECT id INTO _user_id FROM auth.users WHERE email = user_email;
  
  -- Vérifier si l'utilisateur existe
  IF _user_id IS NULL THEN
    RAISE EXCEPTION 'Utilisateur avec l''email % non trouvé', user_email;
  END IF;
  
  -- Mettre à jour le statut de confirmation de l'utilisateur
  UPDATE auth.users
  SET email_confirmed_at = NOW(),
      confirmed_at = NOW(),
      updated_at = NOW()
  WHERE id = _user_id;
  
  -- Ajouter un log
  INSERT INTO public.system_action_logs (action, details, status, user_id)
  VALUES (
    'admin_confirm_user',
    json_build_object('email', user_email),
    'success',
    _user_id
  );
  
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Accorder les privilèges d'exécution à la fonction
GRANT EXECUTE ON FUNCTION admin_confirm_user(TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION admin_confirm_user(TEXT) TO anon;
GRANT EXECUTE ON FUNCTION admin_confirm_user(TEXT) TO service_role;

-- Standardisation des noms de médecins en supprimant le préfixe "Dr "
UPDATE patients 
SET doctor = REGEXP_REPLACE(doctor, '^Dr\s+', '', 'i')
WHERE doctor LIKE 'Dr %' OR doctor LIKE 'dr %';

-- Standardisation des noms de médecins en supprimant le préfixe "Dr. "
UPDATE patients 
SET doctor = REGEXP_REPLACE(doctor, '^Dr\.\s*', '', 'i')
WHERE doctor LIKE 'Dr.%' OR doctor LIKE 'dr.%';

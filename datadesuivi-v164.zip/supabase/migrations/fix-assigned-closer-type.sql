-- Create a new table with the correct structure
CREATE TABLE IF NOT EXISTS patients_new (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  status TEXT DEFAULT 'En attente',
  loan_platform TEXT,
  doctor TEXT,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  assigned_closer TEXT DEFAULT 'system@example.com',
  registration_date DATE,
  consultation_date DATE,
  revenue NUMERIC,
  expenses NUMERIC,
  credit_score TEXT,
  credit_score_platform TEXT,
  loan_amount NUMERIC,
  loan_simulation_validated BOOLEAN DEFAULT FALSE,
  loan_requested BOOLEAN DEFAULT FALSE,
  next_follow_up DATE,
  comments TEXT
);

-- Copy data from the old table if it exists
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'patients') THEN
    INSERT INTO patients_new (
      id, full_name, email, phone, status, loan_platform, doctor, notes, 
      created_at, updated_at, registration_date, consultation_date, 
      revenue, expenses, credit_score, credit_score_platform, 
      loan_amount, loan_simulation_validated, loan_requested, 
      next_follow_up, comments
    )
    SELECT 
      id, full_name, email, phone, status, loan_platform, doctor, notes, 
      created_at, updated_at, registration_date, consultation_date, 
      revenue, expenses, credit_score, credit_score_platform, 
      loan_amount, loan_simulation_validated, loan_requested, 
      next_follow_up, comments
    FROM patients;
    
    -- Set a default value for assigned_closer
    UPDATE patients_new SET assigned_closer = 'summer';
    
    -- Drop the old table and rename the new one
    DROP TABLE patients;
    ALTER TABLE patients_new RENAME TO patients;
  END IF;
END $$;

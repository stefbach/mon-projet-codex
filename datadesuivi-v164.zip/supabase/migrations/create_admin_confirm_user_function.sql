-- Fonction pour confirmer un utilisateur par email
CREATE OR REPLACE FUNCTION admin_confirm_user(user_email TEXT)
RETURNS VOID AS $$
DECLARE
  target_user_id UUID;
BEGIN
  -- Récupérer l'ID de l'utilisateur à partir de son email
  SELECT id INTO target_user_id FROM auth.users WHERE email = user_email;
  
  -- Vérifier si l'utilisateur existe
  IF target_user_id IS NULL THEN
    RAISE EXCEPTION 'Utilisateur non trouvé avec l''email: %', user_email;
  END IF;
  
  -- Mettre à jour le champ email_confirmed_at pour confirmer l'utilisateur
  UPDATE auth.users
  SET email_confirmed_at = NOW()
  WHERE id = target_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Accorder les droits d'exécution à la fonction
GRANT EXECUTE ON FUNCTION admin_confirm_user(TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION admin_confirm_user(TEXT) TO anon;
GRANT EXECUTE ON FUNCTION admin_confirm_user(TEXT) TO service_role;

-- Vérifier si la colonne 'notes' existe déjà
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_name = 'patients'
        AND column_name = 'notes'
    ) THEN
        -- Ajouter la colonne 'notes' de type text
        ALTER TABLE patients ADD COLUMN notes TEXT;
        
        -- Ajouter un commentaire à la colonne pour la documentation
        COMMENT ON COLUMN patients.notes IS 'Notes de suivi pour le patient';
    ELSE
        RAISE NOTICE 'La colonne notes existe déjà dans la table patients';
    END IF;
END $$;

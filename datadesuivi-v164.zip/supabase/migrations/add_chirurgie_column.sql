-- Ajouter la colonne chirurgie à la table patients
ALTER TABLE patients ADD COLUMN IF NOT EXISTS chirurgie VARCHAR(50);

-- Créer un type enum pour les valeurs possibles (optionnel mais recommandé)
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'chirurgie_type') THEN
        CREATE TYPE chirurgie_type AS ENUM ('sg', 'bariclip', 'bypass', 'egs', 'sassi');
        
        -- Si vous préférez utiliser un type enum au lieu d'un VARCHAR
        -- ALTER TABLE patients ALTER COLUMN chirurgie TYPE chirurgie_type USING chirurgie::chirurgie_type;
    END IF;
END
$$;

-- Ajouter un commentaire à la colonne pour la documentation
COMMENT ON COLUMN patients.chirurgie IS 'Type de chirurgie: sg, bariclip, bypass, egs, sassi';

-- Supprimer la table patients existante si elle existe
DROP TABLE IF EXISTS public.patients;

-- Créer une nouvelle table patients simplifiée
CREATE TABLE public.patients (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  doctor TEXT,
  status TEXT DEFAULT 'En attente',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  closer TEXT,
  phone TEXT,
  platform TEXT,
  notes TEXT,
  consultation_date DATE,
  income NUMERIC,
  expenses NUMERIC,
  credit_score TEXT,
  credit_platform TEXT,
  loan_amount NUMERIC,
  simulation_validated BOOLEAN DEFAULT false,
  loan_requested BOOLEAN DEFAULT false,
  next_follow_up DATE,
  comments TEXT
);

-- Désactiver temporairement RLS pour faciliter le débogage
ALTER TABLE public.patients DISABLE ROW LEVEL SECURITY;

-- Accorder tous les privilèges à l'utilisateur authentifié
GRANT ALL PRIVILEGES ON TABLE public.patients TO authenticated;
GRANT ALL PRIVILEGES ON TABLE public.patients TO anon;
GRANT ALL PRIVILEGES ON TABLE public.patients TO service_role;

-- Créer un index sur l'email pour accélérer les recherches
CREATE INDEX patients_email_idx ON public.patients (email);

-- Créer un index sur le closer pour accélérer les filtres
CREATE INDEX patients_closer_idx ON public.patients (closer);

-- Fonction pour vérifier le statut d'un utilisateur
CREATE OR REPLACE FUNCTION get_user_status(user_email TEXT)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  user_record RECORD;
  result JSON;
BEGIN
  -- Vérifier si l'utilisateur existe
  SELECT id, email_confirmed_at, created_at, last_sign_in_at
  INTO user_record
  FROM auth.users
  WHERE email = user_email;
  
  -- Si l'utilisateur n'existe pas, retourner un statut simple
  IF user_record IS NULL THEN
    result := json_build_object(
      'exists', FALSE,
      'confirmed', FALSE
    );
  ELSE
    -- Sinon, retourner les détails complets
    result := json_build_object(
      'exists', TRUE,
      'confirmed', user_record.email_confirmed_at IS NOT NULL,
      'created_at', user_record.created_at,
      'last_sign_in', user_record.last_sign_in_at
    );
  END IF;
  
  RETURN result;
END;
$$;

-- Autoriser l'accès anonyme à cette fonction
GRANT EXECUTE ON FUNCTION get_user_status(TEXT) TO anon;
GRANT EXECUTE ON FUNCTION get_user_status(TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION get_user_status(TEXT) TO service_role;

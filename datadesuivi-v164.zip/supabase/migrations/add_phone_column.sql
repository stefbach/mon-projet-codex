-- Vérifier si la colonne 'phone' existe déjà
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_name = 'patients'
        AND column_name = 'phone'
    ) THEN
        -- Ajouter la colonne 'phone' de type text
        ALTER TABLE patients ADD COLUMN phone TEXT;
        
        -- Ajouter un commentaire à la colonne pour la documentation
        COMMENT ON COLUMN patients.phone IS 'Numéro de téléphone du patient';
    ELSE
        RAISE NOTICE 'La colonne phone existe déjà dans la table patients';
    END IF;
END $$;

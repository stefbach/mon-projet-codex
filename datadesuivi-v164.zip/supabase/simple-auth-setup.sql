-- 1. Créer la fonction pour confirmer les utilisateurs
CREATE OR REPLACE FUNCTION public.confirm_user(email_to_confirm TEXT)
RETURNS VOID AS $$
BEGIN
  UPDATE auth.users
  SET email_confirmed_at = NOW()
  WHERE email = email_to_confirm;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 2. Accorder les permissions d'exécution
GRANT EXECUTE ON FUNCTION public.confirm_user(TEXT) TO authenticated, anon;

-- 3. S'assurer que la table users existe avec les bonnes colonnes
CREATE TABLE IF NOT EXISTS public.users (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  name TEXT,
  role TEXT DEFAULT 'closer',
  active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Désactiver RLS pour simplifier les tests
ALTER TABLE public.users DISABLE ROW LEVEL SECURITY;

-- 5. Confirmer tous les utilisateurs existants
UPDATE auth.users
SET email_confirmed_at = NOW()
WHERE email_confirmed_at IS NULL;

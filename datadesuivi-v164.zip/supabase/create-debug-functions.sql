-- Fonction pour récupérer les colonnes d'une table
CREATE OR REPLACE FUNCTION get_table_columns(table_name text)
RETURNS TABLE (
  column_name text,
  data_type text,
  is_nullable text,
  column_default text
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    columns.column_name::text,
    columns.data_type::text,
    columns.is_nullable::text,
    columns.column_default::text
  FROM 
    information_schema.columns
  WHERE 
    columns.table_name = get_table_columns.table_name
  ORDER BY 
    ordinal_position;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Fonction pour récupérer les clés étrangères d'une table
CREATE OR REPLACE FUNCTION get_foreign_keys(table_name text)
RETURNS TABLE (
  constraint_name text,
  column_name text,
  foreign_table_name text,
  foreign_column_name text
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    tc.constraint_name::text,
    kcu.column_name::text,
    ccu.table_name::text AS foreign_table_name,
    ccu.column_name::text AS foreign_column_name
  FROM
    information_schema.table_constraints AS tc
    JOIN information_schema.key_column_usage AS kcu
      ON tc.constraint_name = kcu.constraint_name
    JOIN information_schema.constraint_column_usage AS ccu
      ON ccu.constraint_name = tc.constraint_name
  WHERE 
    tc.constraint_type = 'FOREIGN KEY' 
    AND tc.table_name = get_foreign_keys.table_name;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Fonction pour créer la fonction get_table_columns
CREATE OR REPLACE FUNCTION create_get_table_columns_function()
RETURNS void AS $$
BEGIN
  -- La fonction est déjà créée ci-dessus
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Fonction pour créer la fonction get_foreign_keys
CREATE OR REPLACE FUNCTION create_get_foreign_keys_function()
RETURNS void AS $$
BEGIN
  -- La fonction est déjà créée ci-dessus
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Création de la table patients
CREATE TABLE IF NOT EXISTS public.patients (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    doctor TEXT NOT NULL,
    consultation_date TEXT,
    income NUMERIC,
    expenses NUMERIC,
    credit_score TEXT,
    credit_platform TEXT,
    loan_amount NUMERIC,
    simulation_validated TEXT,
    platform TEXT,
    status TEXT,
    loan_requested TEXT,
    next_follow_up TEXT,
    closer TEXT NOT NULL,
    comments TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE
);

-- Créer des index pour améliorer les performances
CREATE INDEX IF NOT EXISTS idx_patients_closer ON public.patients(closer);
CREATE INDEX IF NOT EXISTS idx_patients_status ON public.patients(status);
CREATE INDEX IF NOT EXISTS idx_patients_platform ON public.patients(platform);
CREATE INDEX IF NOT EXISTS idx_patients_doctor ON public.patients(doctor);

-- Ajouter quelques données de test
INSERT INTO public.patients (id, name, email, doctor, consultation_date, income, expenses, credit_score, credit_platform, loan_amount, simulation_validated, platform, status, loan_requested, next_follow_up, closer, comments, created_at, updated_at)
VALUES 
(uuid_generate_v4(), 'Jean Dupont', 'jean.dupont@example.com', 'Dr Noel', '2023-05-15', 3500, 2000, '720', 'Experian', 15000, 'Oui', 'Zopa', 'Accepté', 'Oui', '2023-06-15', 'closer@email.com', 'Client sérieux et fiable', NOW(), NULL),
(uuid_generate_v4(), 'Marie Martin', 'marie.martin@example.com', 'Dr Smith', '2023-05-20', 4200, 2500, '680', 'Equifax', 20000, 'Oui', 'Lending Club', 'En cours', 'Non', '2023-06-20', 'closer@email.com', 'En attente de documents supplémentaires', NOW(), NULL),
(uuid_generate_v4(), 'Pierre Dubois', 'pierre.dubois@example.com', 'Dr Johnson', '2023-05-25', 3000, 1800, '620', 'TransUnion', 10000, 'Non', 'Prosper', 'Refusé', 'Oui', '2023-07-01', 'closer@email.com', 'Score de crédit trop bas', NOW(), NULL),
(uuid_generate_v4(), 'Sophie Leroy', 'sophie.leroy@example.com', 'Dr Williams', '2023-05-12', 5000, 3000, '750', 'Experian', 25000, 'Oui', 'SoFi', 'Accepté', 'Oui', '2023-06-10', 'autre.closer@email.com', 'Excellent dossier', NOW(), NULL),
(uuid_generate_v4(), 'Thomas Bernard', 'thomas.bernard@example.com', 'Dr Brown', '2023-05-18', 3800, 2200, '700', 'Equifax', 18000, 'Oui', 'Upstart', 'À faire', 'Non', '2023-06-25', 'autre.closer@email.com', 'Premier contact effectué', NOW(), NULL);

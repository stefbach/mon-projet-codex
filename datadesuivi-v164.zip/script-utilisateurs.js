// Script pour la gestion des utilisateurs (à copier dans votre projet Google Apps Script)

// ID de la feuille Google Sheets pour les utilisateurs
const USERS_SHEET_ID = "VOTRE_ID_DE_FEUILLE_GOOGLE_SHEETS"
const USERS_SHEET_NAME = "Utilisateurs" // Nom de l'onglet

function doGet(e) {
  // Activer CORS
  const output = ContentService.createTextOutput()
  output.setMimeType(ContentService.MimeType.JSON)

  // Récupérer l'action demandée
  const action = e.parameter.action

  // Exécuter l'action appropriée
  let result
  try {
    if (action === "createUser") {
      result = createUser(e.parameter)
    } else if (action === "getUsers") {
      result = getUsers()
    } else if (action === "updateUser") {
      result = updateUser(e.parameter)
    } else if (action === "deleteUser") {
      result = deleteUser(e.parameter)
    } else if (action === "authenticateUser") {
      result = authenticateUser(e.parameter)
    } else {
      result = { success: false, message: "Action non reconnue: " + action }
    }
  } catch (error) {
    result = { success: false, message: "Erreur: " + error.toString() }
  }

  // Retourner le résultat
  output.setContent(JSON.stringify(result))
  return output
}

// Fonction pour créer un utilisateur
function createUser(params) {
  try {
    // Ouvrir la feuille
    const ss = SpreadsheetApp.openById(USERS_SHEET_ID)
    const sheet = ss.getSheetByName(USERS_SHEET_NAME)

    // Vérifier si l'email existe déjà
    const data = sheet.getDataRange().getValues()
    for (let i = 1; i < data.length; i++) {
      if (data[i][1] === params.email) {
        return { success: false, message: "Un utilisateur avec cet email existe déjà" }
      }
    }

    // Générer un ID unique
    const id = Utilities.getUuid()

    // Préparer les données
    const now = new Date().toISOString()
    const rowData = [
      id, // ID
      params.email, // Email
      params.name, // Nom
      params.role, // Rôle
      params.password, // Mot de passe (à hacher dans une version de production)
      params.active === "true" ? true : false, // Actif
      now, // Date de création
      now, // Dernière modification du mot de passe
    ]

    // Ajouter l'utilisateur
    sheet.appendRow(rowData)

    // Retourner le succès
    return {
      success: true,
      message: "Utilisateur créé avec succès",
      user: {
        id: id,
        email: params.email,
        name: params.name,
        role: params.role,
        active: params.active === "true",
        created_at: now,
        last_password_change: now,
      },
    }
  } catch (error) {
    return { success: false, message: "Erreur lors de la création de l'utilisateur: " + error.toString() }
  }
}

// Fonction pour récupérer tous les utilisateurs
function getUsers() {
  try {
    // Ouvrir la feuille
    const ss = SpreadsheetApp.openById(USERS_SHEET_ID)
    const sheet = ss.getSheetByName(USERS_SHEET_NAME)

    // Récupérer les données
    const data = sheet.getDataRange().getValues()
    const headers = data[0]

    // Convertir les données en objets
    const users = []
    for (let i = 1; i < data.length; i++) {
      const user = {}
      for (let j = 0; j < headers.length; j++) {
        user[headers[j]] = data[i][j]
      }
      users.push(user)
    }

    // Retourner les utilisateurs
    return users
  } catch (error) {
    return { success: false, message: "Erreur lors de la récupération des utilisateurs: " + error.toString() }
  }
}

// Fonction pour mettre à jour un utilisateur
function updateUser(params) {
  try {
    // Ouvrir la feuille
    const ss = SpreadsheetApp.openById(USERS_SHEET_ID)
    const sheet = ss.getSheetByName(USERS_SHEET_NAME)

    // Récupérer les données
    const data = sheet.getDataRange().getValues()
    const headers = data[0]

    // Trouver l'utilisateur
    let rowIndex = -1
    for (let i = 1; i < data.length; i++) {
      if (data[i][0] === params.userId) {
        rowIndex = i + 1 // +1 car les indices de feuille commencent à 1
        break
      }
    }

    if (rowIndex === -1) {
      return { success: false, message: "Utilisateur non trouvé" }
    }

    // Mettre à jour les champs
    for (let j = 0; j < headers.length; j++) {
      const field = headers[j]
      if (params[field] !== undefined) {
        sheet.getRange(rowIndex, j + 1).setValue(params[field])
      }
    }

    // Retourner le succès
    return { success: true, message: "Utilisateur mis à jour avec succès" }
  } catch (error) {
    return { success: false, message: "Erreur lors de la mise à jour de l'utilisateur: " + error.toString() }
  }
}

// Fonction pour supprimer un utilisateur
function deleteUser(params) {
  try {
    // Ouvrir la feuille
    const ss = SpreadsheetApp.openById(USERS_SHEET_ID)
    const sheet = ss.getSheetByName(USERS_SHEET_NAME)

    // Récupérer les données
    const data = sheet.getDataRange().getValues()

    // Trouver l'utilisateur
    let rowIndex = -1
    for (let i = 1; i < data.length; i++) {
      if (data[i][0] === params.userId) {
        rowIndex = i + 1 // +1 car les indices de feuille commencent à 1
        break
      }
    }

    if (rowIndex === -1) {
      return { success: false, message: "Utilisateur non trouvé" }
    }

    // Supprimer la ligne
    sheet.deleteRow(rowIndex)

    // Retourner le succès
    return { success: true, message: "Utilisateur supprimé avec succès" }
  } catch (error) {
    return { success: false, message: "Erreur lors de la suppression de l'utilisateur: " + error.toString() }
  }
}

// Fonction pour authentifier un utilisateur
function authenticateUser(params) {
  try {
    // Ouvrir la feuille
    const ss = SpreadsheetApp.openById(USERS_SHEET_ID)
    const sheet = ss.getSheetByName(USERS_SHEET_NAME)

    // Récupérer les données
    const data = sheet.getDataRange().getValues()
    const headers = data[0]

    // Trouver l'utilisateur
    let user = null
    for (let i = 1; i < data.length; i++) {
      if (data[i][1] === params.email && data[i][4] === params.password) {
        user = {}
        for (let j = 0; j < headers.length; j++) {
          user[headers[j]] = data[i][j]
        }
        break
      }
    }

    if (!user) {
      return { success: false, message: "Email ou mot de passe incorrect" }
    }

    // Vérifier si l'utilisateur est actif
    if (!user.active) {
      return { success: false, message: "Compte désactivé" }
    }

    // Retourner le succès
    return {
      success: true,
      message: "Authentification réussie",
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        active: user.active,
        created_at: user.created_at,
        last_password_change: user.last_password_change,
      },
    }
  } catch (error) {
    return { success: false, message: "Erreur lors de l'authentification: " + error.toString() }
  }
}
